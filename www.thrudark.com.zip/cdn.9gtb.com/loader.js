var ConvertRootLoader;
(() => {
    "use strict";
    const e = "convert-bundle-loader",
        n = "revenue-addon-bundle",
        o = "shop_name",
        t = "g_cvt_id",
        i = "rev_id";
    var r;
    [{
        name: "rev-script-bundle",
        url: `${(r=function(){let r;const s=document.getElementsByTagName("script");for(let d=0;d<s.length;d++){const a=s[d].getAttribute("src");if(!a)continue;if(s[d].hasAttribute("data-gorgias-loader-convert")&&a.includes(`${o}=`)){if(r=a.split("/").slice(0,3).join("/"),window.CONVERT_SHOP_NAME)break;const e=new URLSearchParams(a.split("?")[1]).get(o);if(e){window.CONVERT_SHOP_NAME=e;break}}const c=s[d].getAttribute("id");if(a.includes(`
        $ {
            t
        } = `)||a.includes(`
        $ {
            i
        } = `)||[e,n].includes(c)){if(r=a.split("/").slice(0,3).join("/"),window.REVENUE_ADDON_ID)break;const e=new URLSearchParams(a.split("?")[1]);[t,i].forEach((n=>{const o=e.get(n);o&&(window.REVENUE_ADDON_ID=o)}))}}return{baseUrl:window.REVENUE_ADDON_CDN||r||"https://cdn.9gtb.com",revision:window.REVENUE_ADDON_REVISION||"714e2e5"}}()).baseUrl}/script.js?rev=${r.revision}`
    }].map((e => {
            if (window.__CVT_BUNDLE_LOCKER ? .[e.name]) return void console.debug(`\ud83d\udeab Bundle ${e.name} is already loaded`);
            window.__CVT_BUNDLE_LOCKER = { ...window.__CVT_BUNDLE_LOCKER,
                [e.name]: !0
            };
            const n = document.createElement("script");
            n.src = e.url, n.id = e.name;
            const o = () => document.body.appendChild(n);
            "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", o) : o()
        })),
        function() {
            if (window.GorgiasBridge) return;
            const e = {
                get(e, n) {
                    if ("init" !== n && "resolve" !== n && "_isMockFunction" !== n) throw new Error(`You are trying to use the Gorgias Bridge API before its initialization (property or function \\"${n}\\")! Please use \`GorgiasBridge.init()\`. Refer to our documentation https://gorgias-convert.com/r/1GAI1s for more info.`);
                    const o = e[n];
                    return "function" == typeof o ? o.bind(e) : o
                }
            };
            window.GorgiasBridge = new Proxy({}, e);
            const n = new Promise((function(e) {
                window.GorgiasBridge.resolve = e
            }));
            window.GorgiasBridge.init = function() {
                return n
            }
        }(), ConvertRootLoader = {}
})();