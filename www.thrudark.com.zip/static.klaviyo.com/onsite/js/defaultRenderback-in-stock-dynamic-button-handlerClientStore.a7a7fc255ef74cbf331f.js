"use strict";
(self.webpackChunk_klaviyo_onsite_modules = self.webpackChunk_klaviyo_onsite_modules || []).push([
    [5492], {
        23074: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return i
                }
            });
            var o = n(68502),
                r = n(43581);
            const i = (e, t, n) => {
                const i = (0, r.c)(o.Z.getState());
                return void 0 === i ? n(...t) : i.emit(e, ...t)
            }
        },
        35818: function(e, t, n) {
            n.d(t, {
                V: function() {
                    return o
                }
            });
            const o = (e, t) => {
                const n = t.onsiteState.openFormVersions[e.id],
                    o = n ? {
                        [e.id]: Object.assign({}, n, e.changes)
                    } : {};
                return Object.assign({}, t, {
                    onsiteState: Object.assign({}, t.onsiteState, {
                        openFormVersions: Object.assign({}, t.onsiteState.openFormVersions, o)
                    })
                })
            }
        },
        42376: function(e, t, n) {
            n.d(t, {
                M: function() {
                    return M
                },
                E: function() {
                    return L
                }
            });
            var o = n(5645),
                r = n.n(o),
                i = n(2609),
                c = n(98072),
                s = n(92719),
                u = n(47774),
                d = n(51950),
                a = n(17859),
                m = n(82734),
                f = n(49917),
                l = n(22982),
                p = n(48957),
                _ = (n(92461), n(84618), n(53742)),
                b = n(34463);
            const I = Object.values(_.rN),
                S = e => !!e && ("object" == typeof e && ("metric" in e && "string" == typeof e.metric && (e.metric in _.rN || I.includes(e.metric)))),
                v = "back-in-stock",
                g = "signup-forms";
            var k = ({
                    events: e,
                    companyId: t,
                    metricGroup: n
                }) => {
                    if ((0, m.O)(p.T4) && (e => e.every(S))(e)) {
                        if ((e => {
                                try {
                                    return (0, b.Gi)(e), !0
                                } catch (t) {
                                    return t instanceof Error && (0, l.T)(t, {
                                        extra: {
                                            events: e.events
                                        }
                                    }), !1
                                }
                            })({
                                metricGroup: n || g,
                                events: e,
                                companyId: t
                            })) return new Promise((e => e()))
                    }
                    return new Promise((o => {
                        (0, f.Z)({
                            metricGroup: n || g,
                            events: e,
                            companyId: t
                        }).then((() => o())).catch((t => {
                            "undefined" != typeof ProgressEvent && t instanceof ProgressEvent || void 0 !== window.XMLHttpRequestProgressEvent && t instanceof window.XMLHttpRequestProgressEvent || (0, l.T)(t, {
                                tags: {
                                    logMetric: "True"
                                },
                                extra: {
                                    events: e
                                }
                            }), o()
                        }))
                    }))
                },
                y = n(68502),
                O = n(23074),
                T = n(35818);
            const w = ["metric", "formVersionId", "formId", "companyId", "formType", "metricGroup", "isBackInStockForm"],
                C = ["metric", "formId", "formVersionId", "companyId"],
                V = ["metric", "formId", "formVersionCId", "companyId", "logCustomEvent", "logTelemetric", "allowReTriggering"],
                B = ["formId", "companyId"];

            function E(e, t) {
                const n = t || {
                        bubbles: !1,
                        cancelable: !1,
                        detail: null
                    },
                    o = document.createEvent("CustomEvent");
                return o.initCustomEvent(e, n.bubbles, n.cancelable, n.detail), o
            }
            const F = async e => {
                    var t, o;
                    let {
                        metric: s,
                        formVersionId: d,
                        formId: m,
                        companyId: f,
                        formType: l,
                        metricGroup: p,
                        isBackInStockForm: _ = !1
                    } = e, b = r()(e, w);
                    const I = (0, a.Z)(),
                        S = (0, i.af)(),
                        v = (0, i.FU)(),
                        g = u.UF[s];
                    let y = {};
                    if (_) try {
                        const {
                            detectPlatform: e
                        } = await Promise.all([n.e(2462), n.e(8760), n.e(8257)]).then(n.bind(n, 47072));
                        y = {
                            back_in_stock_platform: e()
                        }
                    } catch (e) {
                        y = {
                            back_in_stock_platform: "custom"
                        }
                    }
                    return {
                        metric: s,
                        response: await (0, O.Z)("trackAggregateEvent", [{
                            companyId: f,
                            metricGroup: p,
                            events: [{
                                metric: u.aD[s],
                                logToStatsd: !0,
                                logToS3: !0,
                                logToMetricsService: !!g,
                                metricServiceEventName: g,
                                eventDetails: Object.assign({}, I, b, y, {
                                    form_id: m,
                                    form_version_id: d,
                                    form_type: l,
                                    device_type: (0, c.Z)() ? "MOBILE" : "DESKTOP",
                                    hostname: window.location.hostname,
                                    href: window.location.href,
                                    page_url: `${window.location.origin}${window.location.pathname}`,
                                    first_referrer: null == v || null == (t = v.$referrer) ? void 0 : t.first_page,
                                    referrer: null == v || null == (o = v.$last_referrer) ? void 0 : o.first_page
                                }, S || {})
                            }]
                        }], k)
                    }
                },
                h = e => {
                    let {
                        metric: t,
                        formId: n,
                        formVersionId: o,
                        companyId: i
                    } = e, c = r()(e, C);
                    const s = new E(u.In, {
                        detail: Object.assign({
                            type: t,
                            formId: n,
                            formVersionId: o,
                            companyId: i
                        }, c)
                    });
                    window.dispatchEvent(s)
                },
                M = async e => {
                    if (e.submittedFields && u.z5.includes(e.metric)) {
                        var t;
                        let n = null == (t = y.Z.getState().onsiteState.openFormVersions[e.formVersionCId]) ? void 0 : t.sentIdentifiers;
                        if (e.submittedFields && d.HD in e.submittedFields) {
                            const t = e.submittedFields[d.HD];
                            n = Object.assign({}, n, {
                                [d.HD]: t
                            })
                        }
                        if (e.submittedFields && d.lL in e.submittedFields) {
                            const t = e.submittedFields[d.lL];
                            n = Object.assign({}, n, {
                                [d.lL]: t
                            })
                        }
                        if (e.submittedFields && d.vC in e.submittedFields) {
                            const t = e.submittedFields[d.vC];
                            "string" == typeof t && (n = Object.assign({}, n, {
                                [d.vC]: t
                            }))
                        }
                        y.Z.setState((t => (0, T.V)({
                            id: e.formVersionCId,
                            changes: {
                                sentIdentifiers: n
                            }
                        }, t)))
                    }
                    const n = await (async e => {
                        var t;
                        let {
                            metric: n,
                            formId: o,
                            formVersionCId: i,
                            companyId: c,
                            logCustomEvent: d = !1,
                            logTelemetric: a = !0,
                            allowReTriggering: m = !1
                        } = e, f = r()(e, V);
                        const l = y.Z.getState(),
                            p = l.formsState.forms[o];
                        if (!p) return;
                        const _ = p.liveFormVersion || p.liveFormVersions && p.liveFormVersions[0],
                            {
                                sentSubmitMetric: b,
                                sentCloseMetric: I,
                                sentCloseTeaserMetric: S,
                                sentOpenMetric: k,
                                logCloseMetric: O
                            } = l.onsiteState.openFormVersions[i] || {},
                            T = {
                                metric: n,
                                formId: o,
                                formVersionId: _,
                                companyId: c,
                                metaData: f.submittedFields && Object.assign({}, f.submittedFields)
                            };
                        if (n === u.dm && b && !m) return void(d && h(T));
                        if (n === u.M7 && k && !m) return void(d && h(T));
                        if (n === u.sv && S && !m) return void(d && h(T));
                        if (n === u.uw && (I && !m || void 0 !== O && !O)) return void(d && h(T));
                        const w = l.formsState.formVersions[_];
                        if (!w) return;
                        const C = null == (t = w.formSpecialties) ? void 0 : t.includes("BACK_IN_STOCK"),
                            B = C ? v : g,
                            E = w.formType,
                            M = !l.onsiteState.client.isDesignWorkflow;
                        if ((0, s.li)(`${o}:${n}`), n === u.n5 && !m) {
                            const e = Number(f.step_number);
                            if (!Number.isNaN(e) && e > 0) {
                                var L;
                                const t = l.onsiteState.openFormVersions[i];
                                if (null != t && null != (L = t.sentViewedSteps) && L[e]) return void(d && h(T))
                            }
                        }
                        if (d && h(T), a && M) {
                            const e = await F(Object.assign({
                                metric: n,
                                formVersionId: _,
                                formVersionCId: i,
                                formId: o,
                                companyId: c,
                                isClient: M,
                                formType: E,
                                metricGroup: B,
                                isBackInStockForm: C
                            }, f));
                            return Object.assign({
                                formVersionCId: i
                            }, e)
                        }
                    })(e);
                    if (n)
                        if (n.metric === u.dm && n.formVersionCId) y.Z.setState((t => (0, T.V)({
                            id: e.formVersionCId,
                            changes: {
                                sentSubmitMetric: !0
                            }
                        }, t)));
                        else if (n.metric === u.uw && n.formVersionCId) y.Z.setState((t => (0, T.V)({
                        id: e.formVersionCId,
                        changes: {
                            sentCloseMetric: !0,
                            sentCloseEvent: !0
                        }
                    }, t)));
                    else if (n.metric === u.M7 && n.formVersionCId) y.Z.setState((t => (0, T.V)({
                        id: e.formVersionCId,
                        changes: {
                            sentOpenMetric: !0,
                            sentOpenEvent: !0
                        }
                    }, t)));
                    else if (n.metric === u.n5 && n.formVersionCId) {
                        const t = Number(e.step_number);
                        !Number.isNaN(t) && t > 0 && y.Z.setState((n => {
                            var o;
                            return (0, T.V)({
                                id: e.formVersionCId,
                                changes: {
                                    sentViewedSteps: Object.assign({}, (null == (o = n.onsiteState.openFormVersions[e.formVersionCId]) ? void 0 : o.sentViewedSteps) || {}, {
                                        [t]: !0
                                    })
                                }
                            }, n)
                        }))
                    }
                },
                L = async e => {
                    var t;
                    let {
                        formId: n,
                        companyId: o
                    } = e, i = r()(e, B);
                    const c = y.Z.getState(),
                        d = u.J3,
                        a = c.formsState.forms[n];
                    if (!a) return;
                    const m = a.liveFormVersion || a.liveFormVersions && a.liveFormVersions[0],
                        f = c.formsState.formVersions[m];
                    if (!f) return;
                    const l = null == (t = f.formSpecialties) ? void 0 : t.includes("BACK_IN_STOCK"),
                        p = l ? v : g,
                        _ = f.formType,
                        b = !c.onsiteState.client.isDesignWorkflow;
                    (0, s.li)(`${n}:${d}`), b && await F({
                        metric: u.J3,
                        formVersionId: m,
                        formId: n,
                        companyId: o,
                        isClient: b,
                        formType: _,
                        metricGroup: p,
                        isBackInStockForm: l,
                        additionalData: i
                    })
                }
        },
        43581: function(e, t, n) {
            n.d(t, {
                c: function() {
                    return o
                }
            });
            const o = e => e.messageBus
        },
        51950: function(e, t, n) {
            n.d(t, {
                B1: function() {
                    return l
                },
                Ct: function() {
                    return i
                },
                Ep: function() {
                    return C
                },
                HD: function() {
                    return M
                },
                HO: function() {
                    return Z
                },
                J8: function() {
                    return s
                },
                K0: function() {
                    return k
                },
                L9: function() {
                    return w
                },
                My: function() {
                    return W
                },
                Nd: function() {
                    return x
                },
                OV: function() {
                    return _
                },
                SO: function() {
                    return y
                },
                Tc: function() {
                    return V
                },
                Td: function() {
                    return G
                },
                UO: function() {
                    return f
                },
                X0: function() {
                    return K
                },
                XK: function() {
                    return z
                },
                Xe: function() {
                    return p
                },
                YQ: function() {
                    return o
                },
                Ys: function() {
                    return I
                },
                ZC: function() {
                    return H
                },
                ZW: function() {
                    return m
                },
                _2: function() {
                    return S
                },
                eC: function() {
                    return v
                },
                eQ: function() {
                    return j
                },
                hD: function() {
                    return a
                },
                ip: function() {
                    return X
                },
                jR: function() {
                    return r
                },
                lL: function() {
                    return h
                },
                nk: function() {
                    return J
                },
                no: function() {
                    return q
                },
                qn: function() {
                    return u
                },
                rY: function() {
                    return g
                },
                sZ: function() {
                    return b
                },
                t5: function() {
                    return T
                },
                vC: function() {
                    return $
                },
                xC: function() {
                    return c
                },
                ye: function() {
                    return O
                },
                zV: function() {
                    return d
                }
            });
            n(70917), n(93677), n(84304), n(75723), n(20696), n(38528), n(72418);
            const o = "BUTTON",
                r = "TEXT",
                i = "IMAGE",
                c = "EMAIL",
                s = "PHONE_NUMBER",
                u = "TEXT_INPUT",
                d = "MULTI_CHECKBOX",
                a = "RADIO_BUTTONS",
                m = "DATE",
                f = "DROPDOWN",
                l = "COUPON",
                p = "SMS_DISCLOSURE",
                _ = "PROMOTIONAL_SMS_CHECKBOX",
                b = "BIS_PROMOTIONAL_EMAIL_CHECKBOX",
                I = "AGE_GATE",
                S = "COUNTDOWN_TIMER",
                v = "OPT_IN_CODE_INPUT",
                g = "ENGAGEMENT_COUNTER",
                k = "SPIN_TO_WIN",
                y = "GO_TO_INBOX",
                O = "REVIEWS",
                T = "MOBILE",
                w = "DESKTOP",
                C = "ALL",
                V = "kl-private-reset-css-Xuajs1",
                B = "$first_name",
                E = "$last_name",
                F = "$title",
                h = "$phone_number",
                M = "$email",
                L = "$organization",
                P = "$address1",
                N = "$address2",
                A = "$city",
                R = "$region",
                U = "$country",
                D = "$zip",
                $ = "$age_gated_date_of_birth",
                Z = "phone_number",
                G = "email",
                W = "opt_in_code",
                j = "opt_in_promotional_sms",
                q = {
                    [B]: "given-name",
                    [E]: "family-name",
                    [F]: "honorific-prefix",
                    [M]: "email",
                    [h]: "tel",
                    [L]: "organization",
                    [P]: "address-line1",
                    [N]: "address-line2",
                    [A]: "address-level2",
                    [R]: "address-level1",
                    [U]: "country",
                    [D]: "postal-code"
                },
                H = "vertical",
                K = new Set([u, c, s, d, a, m, f, I, v, _, b]),
                X = [u, m, c, a, d, f, s, I, v],
                x = [m, f, s],
                J = [m],
                z = ["$source", "source", "Source"];
            new Set([p, k, s, c, b, _, l, v])
        },
        47774: function(e, t, n) {
            n.d(t, {
                AH: function() {
                    return u
                },
                DF: function() {
                    return a
                },
                Eo: function() {
                    return O
                },
                FB: function() {
                    return p
                },
                In: function() {
                    return l
                },
                J3: function() {
                    return o
                },
                JO: function() {
                    return F
                },
                Jv: function() {
                    return y
                },
                M7: function() {
                    return r
                },
                MD: function() {
                    return R
                },
                NY: function() {
                    return v
                },
                PZ: function() {
                    return d
                },
                Q$: function() {
                    return E
                },
                U9: function() {
                    return U
                },
                UF: function() {
                    return q
                },
                U_: function() {
                    return S
                },
                VJ: function() {
                    return h
                },
                Wx: function() {
                    return w
                },
                X7: function() {
                    return _
                },
                Yu: function() {
                    return P
                },
                _5: function() {
                    return k
                },
                aD: function() {
                    return $
                },
                dm: function() {
                    return s
                },
                kM: function() {
                    return L
                },
                lq: function() {
                    return K
                },
                mC: function() {
                    return I
                },
                n5: function() {
                    return g
                },
                nR: function() {
                    return f
                },
                nn: function() {
                    return B
                },
                ps: function() {
                    return H
                },
                qA: function() {
                    return A
                },
                qo: function() {
                    return T
                },
                r2: function() {
                    return X
                },
                sv: function() {
                    return c
                },
                t2: function() {
                    return M
                },
                tr: function() {
                    return b
                },
                uf: function() {
                    return C
                },
                us: function() {
                    return x
                },
                uw: function() {
                    return i
                },
                wL: function() {
                    return V
                },
                x_: function() {
                    return N
                },
                yH: function() {
                    return m
                },
                z5: function() {
                    return J
                }
            });
            const o = "qualify",
                r = "open",
                i = "close",
                c = "closeTeaser",
                s = "submit",
                u = "stepSubmit",
                d = "embedOpen",
                a = "errorView",
                m = "submitRateLimit",
                f = "redirectedToUrl",
                l = "klaviyoForms",
                p = "subscribedViaSMS",
                _ = "subscribedViaWhatsApp",
                b = "klaviyoBranding",
                I = "showEmailField",
                S = "shopLoginSuccess",
                v = "failedAgeGate",
                g = "viewedStep",
                k = "redirectedToUrlFromStep",
                y = "submitOptInCode",
                O = "resendOptInCode",
                T = "openFormActionFormOpened",
                w = "triggeredBotProtection",
                C = "falsePositiveBotProtection",
                V = "requestBlockedByWAF",
                B = "submitSpinToWin",
                E = "receivedOutcomeView",
                F = "receivedOutcomeViewAndCouponCode",
                h = "redirectedToDeepLink",
                M = "clickedRedirectToInbox",
                L = "hideRedirectToInbox",
                P = "failedToRedirectToInbox",
                N = "submitBackInStockForm",
                A = "dynamicButtonBackInStockClicked",
                R = "dynamicButtonBackInStockPlaced",
                U = "submitBackInStockStep",
                D = "customerHubLoyaltyProviderLoaded",
                $ = {
                    [o]: "qualifyModal",
                    [r]: "openModal",
                    [i]: "closeModal",
                    [c]: "closeTeaser",
                    [s]: "submitModal",
                    [u]: "stepSubmit",
                    [a]: "showErrorView",
                    [d]: "loadedEmbed",
                    [f]: "redirectedToUrl",
                    [p]: "subscribedViaSMS",
                    [m]: "submitRateLimit",
                    [b]: "clickedKlaviyoBranding",
                    [I]: "showEmailField",
                    showShopLogin: "showShopLogin",
                    [S]: "shopLoginSuccess",
                    [v]: "failedAgeGate",
                    [g]: "viewedStep",
                    [k]: "redirectedToUrlFromStep",
                    [y]: "submitOptInCode",
                    [O]: "resendOptInCode",
                    [T]: "openFormActionFormOpened",
                    [w]: "triggeredBotProtection",
                    [C]: "falsePositiveBotProtection",
                    [V]: "requestBlockedByWAF",
                    [B]: "submitSpinToWin",
                    [E]: "receivedOutcomeView",
                    [F]: "receivedOutcomeViewAndCouponCode",
                    [h]: h,
                    [M]: M,
                    [L]: L,
                    [P]: P,
                    [N]: "submitBackInStockForm",
                    [A]: "dynamicButtonBackInStockClicked",
                    [R]: "dynamicButtonBackInStockPlaced",
                    [U]: "submitBackInStockStep",
                    [_]: "subscribedViaWhatsApp",
                    [D]: "customerHubLoyaltyProviderLoaded"
                },
                Z = "viewed_form",
                G = "engaged_with_form",
                W = "submitted_form_step",
                j = "bot_protection",
                q = {
                    [o]: "qualified_form",
                    [r]: Z,
                    [i]: "closed_form",
                    [c]: "closed_teaser",
                    [d]: Z,
                    [s]: G,
                    [f]: G,
                    [p]: G,
                    [_]: G,
                    [y]: G,
                    [v]: "failed_age_gate",
                    [g]: "viewed_form_step",
                    [u]: W,
                    [k]: W,
                    [w]: j,
                    [C]: j,
                    [V]: j,
                    [h]: G,
                    [N]: "submitted_back_in_stock_form",
                    [A]: "dynamic_button_back_in_stock_clicked",
                    [R]: "dynamic_button_back_in_stock_placed",
                    [U]: "submitted_back_in_stock_form_step",
                    [D]: "customer_hub_loyalty_provider_loaded"
                },
                H = "identify",
                K = "profile",
                X = "blank",
                x = [H, K, X],
                J = [s, u, p, _, y, h, N, U]
        },
        17859: function(e, t, n) {
            n(26650), n(92461), n(83362);
            var o = n(20461);
            const r = ["utm_source", "utm_medium", "utm_campaign", "utm_content", "utm_term"];
            t.Z = () => {
                const e = window.location.search.substring(1).split("&").reduce(((e, t) => {
                    const [n, r] = t.split("=");
                    return (0, o.Z)(n) || (0, o.Z)(r) || (e[decodeURIComponent(n)] = decodeURIComponent(r)), e
                }), {});
                return r.reduce(((t, n) => {
                    const o = e[n];
                    return o && (t[n] = o), t
                }), {})
            }
        },
        34463: function(e, t, n) {
            n.d(t, {
                Gi: function() {
                    return s
                },
                KS: function() {
                    return r
                }
            });
            var o = n(48957);
            class r extends CustomEvent {
                constructor(e) {
                    super(o.Rc, {
                        detail: e
                    })
                }
            }
            const i = [],
                c = e => {
                    const t = new r(e);
                    window.dispatchEvent(t)
                },
                s = e => {
                    if (window.onsiteTelemetryLoaded) {
                        for (; i.length > 0;) {
                            const e = i.shift();
                            e && c(e)
                        }
                        c(e)
                    } else i.push(e)
                }
        },
        48957: function(e, t, n) {
            n.d(t, {
                Rc: function() {
                    return o
                },
                T4: function() {
                    return c
                },
                Xf: function() {
                    return i
                },
                lv: function() {
                    return r
                }
            });
            const o = "ONSITE_TELEMETRICS_EVENT",
                r = "visitor-tracking",
                i = "signup-forms",
                c = "onsite_visitor_tracking"
        },
        53742: function(e, t, n) {
            n.d(t, {
                UF: function() {
                    return A
                },
                mq: function() {
                    return F
                },
                oO: function() {
                    return E
                },
                rN: function() {
                    return h
                }
            });
            const o = "qualify",
                r = "open",
                i = "close",
                c = "closeTeaser",
                s = "submit",
                u = "stepSubmit",
                d = "embedOpen",
                a = "redirectedToUrl",
                m = "subscribedViaSMS",
                f = "subscribedViaWhatsApp",
                l = "failedAgeGate",
                p = "viewedStep",
                _ = "redirectedToUrlFromStep",
                b = "submitOptInCode",
                I = "triggeredBotProtection",
                S = "falsePositiveBotProtection",
                v = "requestBlockedByWAF",
                g = "redirectedToDeepLink",
                k = "clickedRedirectToInbox",
                y = "hideRedirectToInbox",
                O = "failedToRedirectToInbox",
                T = "submitBackInStockForm",
                w = "dynamicButtonBackInStockClicked",
                C = "dynamicButtonBackInStockPlaced",
                V = "submitBackInStockStep",
                B = "customerHubLoyaltyProviderLoaded",
                E = "klaviyojsSessionStarted",
                F = "userIdentified",
                h = {
                    [o]: "qualifyModal",
                    [r]: "openModal",
                    [i]: "closeModal",
                    [c]: "closeTeaser",
                    [s]: "submitModal",
                    [u]: "stepSubmit",
                    errorView: "showErrorView",
                    [d]: "loadedEmbed",
                    [a]: "redirectedToUrl",
                    [m]: "subscribedViaSMS",
                    submitRateLimit: "submitRateLimit",
                    klaviyoBranding: "clickedKlaviyoBranding",
                    showEmailField: "showEmailField",
                    showShopLogin: "showShopLogin",
                    shopLoginSuccess: "shopLoginSuccess",
                    [l]: "failedAgeGate",
                    [p]: "viewedStep",
                    [_]: "redirectedToUrlFromStep",
                    [b]: "submitOptInCode",
                    resendOptInCode: "resendOptInCode",
                    openFormActionFormOpened: "openFormActionFormOpened",
                    [I]: "triggeredBotProtection",
                    [S]: "falsePositiveBotProtection",
                    [v]: "requestBlockedByWAF",
                    submitSpinToWin: "submitSpinToWin",
                    receivedOutcomeView: "receivedOutcomeView",
                    receivedOutcomeViewAndCouponCode: "receivedOutcomeViewAndCouponCode",
                    [g]: "redirectedToDeepLink",
                    [k]: k,
                    [y]: y,
                    [O]: O,
                    [T]: "submitBackInStockForm",
                    [w]: "dynamicButtonBackInStockClicked",
                    [C]: "dynamicButtonBackInStockPlaced",
                    [V]: "submitBackInStockStep",
                    [E]: E,
                    [F]: F,
                    [f]: "subscribedViaWhatsApp",
                    [B]: "customerHubLoyaltyProviderLoaded"
                },
                M = "viewed_form",
                L = "engaged_with_form",
                P = "submitted_form_step",
                N = "bot_protection",
                A = {
                    [o]: "qualified_form",
                    [r]: M,
                    [i]: "closed_form",
                    [c]: "closed_teaser",
                    [d]: M,
                    [s]: L,
                    [a]: L,
                    [m]: L,
                    [b]: L,
                    [l]: "failed_age_gate",
                    [p]: "viewed_form_step",
                    [u]: P,
                    [_]: P,
                    [I]: N,
                    [S]: N,
                    [v]: N,
                    [g]: L,
                    [T]: "submitted_back_in_stock_form",
                    [w]: "dynamic_button_back_in_stock_clicked",
                    [C]: "dynamic_button_back_in_stock_placed",
                    [V]: "submitted_back_in_stock_form_step",
                    [E]: "klaviyojs_session_started",
                    [F]: "user_identified",
                    [f]: L,
                    [B]: "customer_hub_loyalty_provider_loaded"
                }
        }
    }
]);