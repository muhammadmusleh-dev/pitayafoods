"use strict";
(self.webpackChunk_klaviyo_onsite_modules = self.webpackChunk_klaviyo_onsite_modules || []).push([
    [135], {
        85747: function(e, t, n) {
            const o = {
                ref: () => {},
                attributes: {},
                listeners: {},
                collected: {},
                className: ""
            };
            t.Z = ({
                children: e
            }) => e(o)
        },
        14500: function(e, t, n) {
            n.d(t, {
                c: function() {
                    return jn
                }
            });
            var o = n(51950),
                i = n(67895),
                r = n.n(i),
                s = n(18359),
                a = n.n(s),
                l = n(38612),
                d = n(5645),
                c = n.n(d),
                m = (n(56816), n(82734)),
                u = n(87377),
                f = n(92719),
                p = n(6138),
                h = n(7385),
                v = n(47774),
                g = n(94756),
                y = n(22982),
                I = n(49064),
                b = n(42376);
            var S = n(99449),
                w = n(68502),
                C = n(87467),
                E = n(10386),
                x = n(57511),
                V = n(74729),
                _ = n(17859),
                T = n(36947),
                k = n(12262);
            var $ = async ({
                    actionId: e,
                    formVersionCId: t,
                    getState: n
                }) => {
                    var o;
                    (0, f.qB)(`Running Transition View Action | Action ID: ${e}`);
                    const i = n(),
                        r = i.onsiteState.openFormVersions[t];
                    if (!r) throw new Error("Open Form Version does not exist");
                    const s = i.formsState.actions ? i.formsState.actions[e] : void 0;
                    if (!s) throw new Error("Form Action does not exist");
                    if (!s.viewId) throw new Error("Transition Action missing a View ID");
                    const a = i.onsiteState.client.klaviyoCompanyId;
                    if (!a) throw new Error("Company ID does not exist");
                    let l = s.viewId;
                    const d = (0, x.sb)(i, r.formVersionId, (0, V.Z)());
                    if ((0, T.mn)(i, r.formVersionId) && l === d) {
                        const e = (0, T.Bu)(i, t);
                        (0, T.rm)(e, a, i, t, l, I.fK)
                    }
                    null != (o = i.onsiteState.dynamicViewOverrides) && o[l] && (l = (0, E.L)(i, l) || l);
                    const c = (0, x.Tf)(i, r.formVersionId);
                    return c && c === s.viewId && (0, C.A)(a, r.formId, t, l), await (({
                        getState: e,
                        formVersionCId: t,
                        openFormVersion: n,
                        newViewId: o
                    }) => {
                        const i = e(),
                            r = (0, V.Z)(),
                            s = i.formsState.formVersions[n.formVersionId];
                        if (s) {
                            var a;
                            const e = (0, x.sb)(i, s.formVersionId, r, (0, S.wf)(i, t)) === o,
                                l = !(null == (a = i.onsiteState.createdProfileEvents[n.formId]) || !a.formCompleted);
                            !l && e && (0, k.ej)({
                                state: w.Z.getState(),
                                formId: n.formId,
                                formVersionId: n.formVersionId,
                                pageUrl: window.location.href,
                                deviceType: r,
                                hasCompletedEventBeenCreated: l,
                                utmParams: (0, _.Z)()
                            })
                        }
                    })({
                        getState: n,
                        formVersionCId: t,
                        openFormVersion: r,
                        newViewId: s.viewId
                    }), (0, I.Cm)({
                        id: t,
                        changes: {
                            currentViewId: l
                        }
                    })
                },
                F = (n(51778), n(92461), n(39265), n(61099), n(70917), n(93677), n(84304), n(75723), n(20696), n(38528), n(72418), n(76419)),
                O = n(89331),
                Z = n(22027),
                A = n(29974),
                M = n(40823),
                D = n(2609);
            const B = ({
                    getState: e,
                    formVersionCId: t
                }) => {
                    const n = e().onsiteState.openFormVersions[t];
                    return n && null != n && n.formId && null != n && n.formVersionId ? {
                        form: {
                            data: {
                                type: "form",
                                id: n.formId
                            }
                        },
                        "form-version": {
                            data: {
                                type: "form-version",
                                id: n.formVersionId
                            }
                        }
                    } : {}
                },
                N = async ({
                    getState: e,
                    formVersionCId: t,
                    composedFields: n
                }) => {
                    const o = (0, D.Un)();
                    let i;
                    const r = new Promise((e => {
                            i = e
                        })),
                        s = Object.assign({}, n);
                    return delete s.opt_in_promotional_sms, delete s.opt_in_promotional_whatsapp, delete s.opt_in_promotional_email, delete s.opt_in_code, !0 !== o ? Promise.resolve(null) : ((0, D.ro)({
                        fields: s,
                        relationships: B({
                            getState: e,
                            formVersionCId: t
                        }),
                        callback: () => (i(!0), !0)
                    }), r)
                };
            n(78575), n(56220), n(70818), n(63880), n(60873);
            var j = n(61081),
                R = n(45641);
            n(22923), n(44159);
            var P = n(71429),
                L = n(24745),
                z = n(72487),
                W = n(91342),
                H = n(39355),
                U = n(20222),
                q = n(39820),
                K = n(72543);
            const G = ({
                    composedFields: e,
                    requestOTPCode: t = !1,
                    phoneInputConsentTypes: n,
                    listRelationships: i,
                    formRelationships: r,
                    profileEvents: s
                }) => {
                    const a = new Date,
                        {
                            $exchange_id: l
                        } = (0, D.zy)(),
                        {
                            attributes: d,
                            properties: c,
                            customSource: m
                        } = (e => {
                            let t = Object.assign({}, e);
                            const n = {};
                            let i;
                            return "email" in e && (n.email = e.email, delete t.email), "$email" in e && (n.email = e.$email, delete t.$email), "sms_consent" in e && (e.sms_consent && (n.phone_number = e.$phone_number, delete t.$phone_number), delete t.sms_consent), "whatsapp_consent" in e && (e.whatsapp_consent && (n.phone_number = e.$phone_number, delete t.$phone_number), delete t.whatsapp_consent), delete t.opt_in_promotional_email, delete t.opt_in_promotional_sms, delete t.opt_in_promotional_whatsapp, delete t.opt_in_code, "sentIdentifiers" in e && (t = Object.assign({}, t, e.sentIdentifiers), delete t.sentIdentifiers), o.XK.forEach((n => {
                                if (e[n]) {
                                    const o = e[n];
                                    i = Array.isArray(o) ? 1 === o.length ? o[0] : o.join(", ") : o, delete t[n]
                                }
                            })), {
                                attributes: n,
                                properties: t,
                                customSource: i
                            }
                        })(e),
                        u = Object.values(s).filter((e => null !== e)),
                        f = Object.keys(i).length > 0 || Object.keys(r).length > 0,
                        p = (({
                            attributes: e,
                            composedFields: t,
                            phoneInputConsentTypes: n
                        }) => {
                            let o = {};
                            if (e.email && "false" !== t.opt_in_promotional_email && (o = Object.assign({}, o, {
                                    email: {
                                        marketing: {
                                            consent: "SUBSCRIBED"
                                        }
                                    }
                                })), e.phone_number) {
                                switch (null == n ? void 0 : n.sms) {
                                    case W.E3.PROMOTIONAL:
                                        "false" !== t.opt_in_promotional_sms && (o = Object.assign({}, o, {
                                            sms: {
                                                marketing: {
                                                    consent: "SUBSCRIBED"
                                                }
                                            }
                                        }));
                                        break;
                                    case W.E3.TRANSACTIONAL:
                                    case W.E3.MULTI_STEP_TRANSACTIONAL_PROMOTIONAL:
                                        o = Object.assign({}, o, {
                                            sms: {
                                                transactional: {
                                                    consent: "SUBSCRIBED"
                                                }
                                            }
                                        });
                                        break;
                                    case W.E3.SINGLE_STEP_TRANSACTIONAL_PROMOTIONAL:
                                        o = Object.assign({}, o, {
                                            sms: Object.assign({
                                                transactional: {
                                                    consent: "SUBSCRIBED"
                                                }
                                            }, "true" === t.opt_in_promotional_sms ? {
                                                marketing: {
                                                    consent: "SUBSCRIBED"
                                                }
                                            } : {})
                                        })
                                }
                                switch (null == n ? void 0 : n.whatsApp) {
                                    case W.E3.PROMOTIONAL:
                                        "false" !== t.opt_in_promotional_whatsapp && (o = Object.assign({}, o, {
                                            whatsapp: {
                                                marketing: {
                                                    consent: "SUBSCRIBED"
                                                }
                                            }
                                        }));
                                        break;
                                    case W.E3.TRANSACTIONAL:
                                    case W.E3.MULTI_STEP_TRANSACTIONAL_PROMOTIONAL:
                                        o = Object.assign({}, o, {
                                            whatsapp: {
                                                transactional: {
                                                    consent: "SUBSCRIBED"
                                                }
                                            }
                                        });
                                        break;
                                    case W.E3.SINGLE_STEP_TRANSACTIONAL_PROMOTIONAL:
                                        o = Object.assign({}, o, {
                                            whatsapp: Object.assign({
                                                transactional: {
                                                    consent: "SUBSCRIBED"
                                                }
                                            }, "true" === t.opt_in_promotional_whatsapp ? {
                                                marketing: {
                                                    consent: "SUBSCRIBED"
                                                }
                                            } : {})
                                        })
                                }
                            }
                            return o
                        })({
                            attributes: d,
                            composedFields: e,
                            phoneInputConsentTypes: n
                        });
                    return Object.assign({
                        data: Object.assign({
                            type: Z.NR,
                            attributes: Object.assign({}, u.length > 0 ? {
                                events: {
                                    data: u
                                }
                            } : {}, {
                                profile: {
                                    data: {
                                        type: Z.cC,
                                        attributes: Object.assign({}, d, {
                                            subscriptions: Object.assign({}, p),
                                            properties: Object.assign({}, c, {
                                                $timezone_offset: -a.getTimezoneOffset() / 60
                                            }, l ? {
                                                $exchange_id: l
                                            } : {})
                                        })
                                    }
                                }
                            }, m ? {
                                custom_source: m
                            } : {})
                        }, f ? {
                            relationships: Object.assign({}, i, r)
                        } : {})
                    }, t ? {
                        meta: {
                            send_otp_code: !0
                        }
                    } : {})
                },
                Y = ({
                    getState: e,
                    formVersionCId: t,
                    openFormVersion: n,
                    formAction: o,
                    composedFields: i
                }) => {
                    const r = e(),
                        s = n.formId,
                        a = r.onsiteState.client.klaviyoCompanyId;
                    if (!a) throw new Error("Company ID does not exist");
                    const l = (0, S.io)(r, t),
                        d = (({
                            listId: e
                        }) => e ? {
                            list: {
                                data: {
                                    type: Z._,
                                    id: e
                                }
                            }
                        } : {})({
                            listId: o.listId
                        }),
                        c = B({
                            getState: e,
                            formVersionCId: t
                        }),
                        m = (0, S.jo)(r, t, void 0, i),
                        u = "object" == typeof window.Shopify && window.Shopify.shop ? {
                            services: JSON.stringify({
                                shopify: {
                                    source: "form"
                                }
                            })
                        } : {},
                        h = Object.assign({}, i, m || {}, u),
                        g = (({
                            getState: e,
                            formVersionCId: t,
                            openFormVersion: n,
                            formAction: o,
                            composedFields: i
                        }) => {
                            var r;
                            let s = {
                                formSubmitted: null,
                                formCompleted: null
                            };
                            const a = e(),
                                {
                                    $exchange_id: l
                                } = (0, D.zy)(),
                                {
                                    formId: d,
                                    formVersionId: c,
                                    currentViewId: m
                                } = n,
                                u = (0, x.QR)(a, c),
                                f = u.length,
                                p = !(null == (r = a.onsiteState.createdProfileEvents[d]) || !r.formSubmitted),
                                h = (0, V.Z)(),
                                v = a.formsState.formVersions[c],
                                g = (0, K.iv)(K.yn),
                                y = (null == g ? void 0 : g.submittedForms) || {},
                                I = (null == g ? void 0 : g.completedForms) || {},
                                b = p || d in y ? null : (0, U.Z)({
                                    exchangeId: l,
                                    email: i.$email,
                                    phoneNumber: i.$phone_number,
                                    formId: d,
                                    formVersionId: c,
                                    deviceType: h,
                                    pageUrl: window.location.href,
                                    metricName: "Form submitted by profile",
                                    utmParams: (0, _.Z)()
                                }),
                                w = (0, S.p$)({
                                    state: a,
                                    formVersionId: c,
                                    deviceType: h
                                }),
                                C = d in I ? null : (0, U.Z)({
                                    exchangeId: l,
                                    email: i.$email,
                                    phoneNumber: i.$phone_number,
                                    formId: d,
                                    formVersionId: c,
                                    deviceType: h,
                                    pageUrl: window.location.href,
                                    metricName: "Form completed by profile",
                                    utmParams: (0, _.Z)(),
                                    successStepName: w
                                });
                            2 === f && (s = {
                                formSubmitted: b,
                                formCompleted: C
                            });
                            const E = (v ? (0, x.sb)(a, v.formVersionId, h, (0, S.wf)(a, t)) : void 0) === o.viewId,
                                T = u.find((({
                                    viewId: e
                                }) => e === m));
                            if ((0, P.x)(T)) return {
                                formSubmitted: null,
                                formCompleted: null
                            };
                            const k = (0, x.ad)(a, T, h);
                            return f > 2 && k.length > 1 && (s = Object.assign({}, s, {
                                formSubmitted: b
                            }), E && (s = Object.assign({}, s, {
                                formSubmitted: b,
                                formCompleted: C
                            }))), f > 2 && 1 === k.length && (s = Object.assign({}, s, {
                                formSubmitted: b,
                                formCompleted: C
                            })), s
                        })({
                            getState: e,
                            formVersionCId: t,
                            openFormVersion: n,
                            formAction: o,
                            composedFields: i
                        }),
                        y = G({
                            composedFields: h,
                            requestOTPCode: l,
                            phoneInputConsentTypes: (0, O.CW)(r, t),
                            listRelationships: d,
                            formRelationships: c,
                            profileEvents: g
                        });
                    return (0, j.x7)(y), (0, L.W)((() => (0, q.s)(a, y)), 5, 1e3 + 1e3 * Math.random(), [429]).then((e => {
                        if (429 === e.status) throw new p.TT;
                        if (403 === e.status) throw new p.FR;
                        return e
                    })).then((e => {
                        if (e.status === Z.Sz && o.actionType) {
                            const e = Object.fromEntries(Object.entries(g).filter((([, e]) => null !== e))),
                                t = Object.keys(e);
                            if ((0, z.Z)(s, t), t.length > 0) {
                                const e = (0, K.iv)(K.yn),
                                    n = (null == e ? void 0 : e.submittedForms) || {},
                                    o = (null == e ? void 0 : e.completedForms) || {};
                                try {
                                    (0, K.$T)(K.yn, Object.assign({}, e, {
                                        submittedForms: Object.assign({}, n, t.includes("formSubmitted") ? {
                                            [s]: (new Date).toISOString()
                                        } : {}),
                                        completedForms: Object.assign({}, o, t.includes("formCompleted") ? {
                                            [s]: (new Date).toISOString()
                                        } : {})
                                    }))
                                } catch (e) {
                                    console.error("Error saving session storage", e)
                                }
                            }
                        }
                        return e
                    })).catch((async r => {
                        if (!(r instanceof p.a)) {
                            if ((0, p.pS)(r)) throw new p.FR;
                            throw r
                        }
                        await (async ({
                            formVersionCId: e,
                            composedFields: t,
                            formId: n,
                            companyId: o,
                            onSuccessfulCaptcha: i
                        }) => ((0, f.qB)("Submit Action | Datadome Bot Detection Triggered"), new Promise(((r, s) => {
                            const a = new AbortController,
                                {
                                    signal: l
                                } = a;
                            window.addEventListener(H.H, (async () => {
                                try {
                                    await i(), (0, b.M)({
                                        metric: v.uf,
                                        formVersionCId: e,
                                        formId: n,
                                        companyId: o,
                                        submittedFields: t,
                                        logTelemetric: !0
                                    }), a.abort(), r()
                                } catch (e) {
                                    a.abort(), s(e)
                                }
                            }), {
                                signal: l
                            }), window.addEventListener(H.vT, (() => {
                                (0, I.et)({
                                    formVersionCId: e
                                }), a.abort(), s()
                            }), {
                                signal: l
                            }), (0, b.M)({
                                metric: v.Wx,
                                formVersionCId: e,
                                formId: n,
                                companyId: o,
                                submittedFields: t,
                                logTelemetric: !0
                            })
                        }))))({
                            formVersionCId: t,
                            composedFields: i,
                            formId: s,
                            companyId: a,
                            onSuccessfulCaptcha: async () => {
                                await Y({
                                    getState: e,
                                    formVersionCId: t,
                                    openFormVersion: n,
                                    formAction: o,
                                    composedFields: i
                                })
                            }
                        })
                    }))
                };
            var X = n(76101);
            const J = new Set,
                Q = async ({
                    getState: e,
                    formVersionCId: t,
                    composedFields: n
                }) => {
                    const o = e(),
                        i = o.onsiteState.openFormVersions[t];
                    if (null == i || !i.currentViewId) return;
                    const r = i.currentViewId;
                    if (J.has(r)) return;
                    const s = new M.e(i, n).checkAndRunViewSideEffects({
                        state: o
                    });
                    J.add(r), await Promise.allSettled(s)
                },
                ee = ({
                    getState: e,
                    formVersionCId: t,
                    openFormVersion: n
                }) => {
                    var o;
                    const i = e(),
                        r = (0, V.Z)(),
                        s = i.formsState.formVersions[n.formVersionId],
                        a = !(null == (o = i.onsiteState.createdProfileEvents[n.formId]) || !o.formSubmitted);
                    if (a || (0, k.LY)({
                            formId: n.formId,
                            formVersionId: n.formVersionId,
                            pageUrl: window.location.href,
                            deviceType: r,
                            hasSubmittedEventBeenCreated: a,
                            utmParams: (0, _.Z)()
                        }), s) {
                        var l;
                        const e = (0, x.sb)(i, s.formVersionId, r, (0, S.wf)(i, t)) === n.currentViewId,
                            o = !(null == (l = i.onsiteState.createdProfileEvents[n.formId]) || !l.formCompleted);
                        !o && e && (0, k.ej)({
                            state: w.Z.getState(),
                            formId: n.formId,
                            formVersionId: n.formVersionId,
                            pageUrl: window.location.href,
                            deviceType: r,
                            hasCompletedEventBeenCreated: o,
                            utmParams: (0, _.Z)()
                        })
                    }
                };
            var te = async ({
                actionId: e,
                formVersionCId: t,
                getState: n
            }) => {
                var i, r, s, a;
                (0, f.qB)(`Running Submit Action | Action ID: ${e}`);
                const l = n(),
                    d = l.onsiteState.openFormVersions[t];
                if (!d) throw new Error("Open Form Version does not exist");
                const c = l.formsState.actions ? l.formsState.actions[e] : void 0;
                if (!c) throw new Error("Form Action does not exist");
                const m = (0, O.cA)(l, e),
                    u = (0, S.$f)({
                        state: l,
                        formVersionCId: t,
                        hiddenFieldsComponentId: m,
                        formActionType: c.actionType
                    }),
                    h = await (0, I.eN)({
                        formVersionCId: t
                    });
                if (h && h.some((({
                        valid: e
                    }) => !e))) throw new p.mN({
                    type: "form"
                });
                await Q({
                    getState: n,
                    formVersionCId: t,
                    composedFields: u
                }), await N({
                    getState: n,
                    formVersionCId: t,
                    composedFields: u
                }), (({
                    getState: e,
                    openFormVersion: t,
                    composedFields: n
                }) => {
                    const i = e(),
                        r = i.onsiteState.client.klaviyoCompanyId;
                    if (!r) throw new Error("Company ID does not exist");
                    const s = Object.values(i.formsState.views).filter((e => (null == e ? void 0 : e.formVersionId) === t.formVersionId)).flatMap((e => e ? (0, x.nC)(i, e.viewId).map((e => e ? i.formsState.components[e.componentId] : void 0)) : [])),
                        a = s.some((e => !!e && (0, O.FW)(i, e))),
                        l = s.some((e => !!e && (0, O.wj)(i, e)));
                    if (a && n[o.HD]) {
                        const e = {
                            companyId: r,
                            form_id: t.formId,
                            email: n[o.HD]
                        };
                        (0, R.Y)("sms", e).then((({
                            data: {
                                uniqueId: e
                            }
                        }) => {
                            void 0 !== e && (0, j.UY)({
                                smsSubscriptionUniqueId: e
                            })
                        })).catch((() => {}))
                    }
                    if (l && n[o.HD]) {
                        const e = {
                            companyId: r,
                            form_id: t.formId,
                            email: n[o.HD]
                        };
                        (0, R.Y)("whatsapp", e).then((({
                            data: {
                                uniqueId: e
                            }
                        }) => {
                            void 0 !== e && (0, j.UY)({
                                whatsappSubscriptionUniqueId: e
                            })
                        })).catch((() => {}))
                    }
                })({
                    getState: n,
                    openFormVersion: d,
                    composedFields: u
                });
                const g = (0, O.xU)(l, d.formVersionId),
                    y = void 0 !== (0, O.CW)(l, t),
                    w = (0, A.Z)(c.actionType, u, g, y);
                let C;
                if (w && (C = await Y({
                        getState: n,
                        formVersionCId: t,
                        openFormVersion: d,
                        formAction: c,
                        composedFields: u
                    }), C && C.status !== Z.Sz && C.status !== Z.dl)) throw new p.vS;
                await (({
                    getState: e,
                    formVersionCId: t,
                    openFormVersion: n,
                    composedFields: o,
                    isSubscribe: i = !1,
                    submitMetric: r = v.dm,
                    submitMetricActionType: s = "Submit Form"
                }) => {
                    const a = e(),
                        {
                            currentViewId: l,
                            formId: d
                        } = n,
                        c = a.onsiteState.client.klaviyoCompanyId;
                    if (!c) throw new Error("Company ID does not exist");
                    const m = (0, k.f8)(a, t, i),
                        u = (0, x.E5)(a, l),
                        f = a.formsState.views[l],
                        p = f ? (0, x.O)(a, f) : void 0,
                        h = [(0, b.M)({
                            metric: v.AH,
                            formVersionCId: t,
                            logCustomEvent: !0,
                            formId: d,
                            companyId: c,
                            submittedFields: Object.assign({}, o, {
                                $step_name: u
                            }),
                            step_name: u,
                            step_number: void 0 !== p ? p + 1 : p,
                            action_type: "Submit Step"
                        })],
                        g = (0, x.Qe)(a, n.currentViewId),
                        y = (0, x.Tf)(a, n.formVersionId);
                    if (g && y) {
                        var w;
                        const e = (0, E.L)(a, y),
                            n = null == (w = g.data.wheelLogic.slices.find((t => t.childViewId === e))) ? void 0 : w.probability;
                        h.push((0, b.M)({
                            metric: v.nn,
                            formVersionCId: t,
                            formId: d,
                            companyId: c,
                            step_name: u,
                            step_number: void 0 !== p ? p + 1 : p,
                            componentId: g.componentId,
                            overrideViewId: e,
                            outcomeProbability: n
                        }))
                    }
                    return (i || (0, S.Gt)(a, t, m)) && h.push((0, b.M)({
                        metric: r,
                        logCustomEvent: !0,
                        formVersionCId: t,
                        formId: d,
                        companyId: c,
                        submittedFields: o,
                        action_type: s
                    })), n && v.us.indexOf(m) < v.us.indexOf(n.topHierarchySubmitted) && (0, I.fK)({
                        id: t,
                        changes: {
                            topHierarchySubmitted: m
                        }
                    }), Promise.all(h)
                })({
                    getState: n,
                    formVersionCId: t,
                    openFormVersion: d,
                    composedFields: u,
                    isSubscribe: w
                }), (0, F.$k)({
                    formId: d.formId,
                    successActionType: c.actionType
                }), await ee({
                    getState: n,
                    formVersionCId: t,
                    openFormVersion: d
                });
                const V = null == l || null == (i = l.onsiteState) || null == (i = i.formSettings) ? void 0 : i.shopifyVisitorApi;
                if (null != (r = C) && r.status && (null == (s = C) ? void 0 : s.status) >= 200 && (null == (a = C) ? void 0 : a.status) < 300 && V && (0, X.h)()) {
                    const {
                        syncSMSConsent: e,
                        syncEmailConsent: t
                    } = V, {
                        [o.HD]: n,
                        [o.lL]: i
                    } = u;
                    if (n || i) {
                        const o = Object.assign({}, n && t ? {
                            email: n
                        } : {}, i && e ? {
                            phone: i
                        } : {});
                        (0, X.N)(o)
                    }
                }
            };
            var ne = async ({
                actionId: e,
                formVersionCId: t,
                getState: n
            }) => {
                await te({
                    actionId: e,
                    formVersionCId: t,
                    getState: n
                });
                n().onsiteState.openFormVersions[t] && await $({
                    actionId: e,
                    formVersionCId: t,
                    getState: n
                })
            };
            var oe = async ({
                actionId: e,
                formVersionCId: t,
                isSubmit: n = !1
            }) => ((0, f.qB)(`Running Close Form Action | Action ID: ${e}`), (0, I.fK)({
                id: t,
                changes: {
                    logCloseMetric: !0
                }
            }), (0, I.et)({
                formVersionCId: t,
                isSubmit: n
            }));
            var ie = async ({
                actionId: e,
                formVersionCId: t,
                getState: n
            }) => {
                await te({
                    actionId: e,
                    formVersionCId: t,
                    getState: n
                }), await oe({
                    actionId: e,
                    formVersionCId: t,
                    getState: n,
                    isSubmit: !0
                })
            };
            var re = async ({
                    actionId: e,
                    formVersionCId: t,
                    getState: n
                }) => {
                    (0, f.qB)(`Running Back in Stock Submit Action | Action ID: ${e}`);
                    const o = n(),
                        i = o.onsiteState.openFormVersions[t];
                    if (!i) throw new Error("Open Form Version does not exist");
                    const r = o.formsState.actions ? o.formsState.actions[e] : void 0;
                    if (!r) throw new Error("Form Action does not exist");
                    const s = (0, O.cA)(o, e),
                        a = (0, S.$f)({
                            state: o,
                            formVersionCId: t,
                            hiddenFieldsComponentId: s,
                            formActionType: r.actionType
                        });
                    (({
                        formVersionCId: e,
                        openFormVersion: t,
                        composedFields: n
                    }) => {
                        const o = Object.assign({}, t.accumulatedFormData, n);
                        (0, I.fK)({
                            id: e,
                            changes: {
                                accumulatedFormData: o
                            }
                        })
                    })({
                        formVersionCId: t,
                        openFormVersion: i,
                        composedFields: a
                    });
                    const l = (0, T.Bu)(o, t, a),
                        d = await (0, I.eN)({
                            formVersionCId: t
                        });
                    if (d && d.some((({
                            valid: e
                        }) => !e))) throw new p.mN({
                        type: "form"
                    });
                    await Q({
                        getState: n,
                        formVersionCId: t,
                        composedFields: a
                    }), await N({
                        getState: n,
                        formVersionCId: t,
                        composedFields: a
                    });
                    (!!a.opt_in_promotional_email && "true" === a.opt_in_promotional_email || !!a.$phone_number) && await te({
                        actionId: e,
                        formVersionCId: t,
                        getState: n
                    }), await (({
                        getState: e,
                        formVersionCId: t,
                        openFormVersion: n,
                        accumulatedFields: o
                    }) => {
                        const i = e(),
                            {
                                currentViewId: r,
                                formId: s
                            } = n,
                            a = i.onsiteState.client.klaviyoCompanyId;
                        if (!a) throw new Error("Company ID does not exist");
                        const l = (0, x.E5)(i, r),
                            d = i.formsState.views[r],
                            c = d ? (0, x.O)(i, d) : void 0,
                            m = [(0, b.M)({
                                metric: v.U9,
                                formVersionCId: t,
                                formId: s,
                                companyId: a,
                                submittedFields: Object.assign({}, o, {
                                    $step_name: l
                                }),
                                step_name: l,
                                step_number: void 0 !== c ? c + 1 : c,
                                logCustomEvent: !0,
                                logTelemetric: !0
                            })];
                        return n.sentBackInStockSubmitMetric || (m.push((0, b.M)({
                            metric: v.x_,
                            formVersionCId: t,
                            formId: s,
                            companyId: a,
                            submittedFields: o,
                            logCustomEvent: !0,
                            logTelemetric: !0
                        })), (0, I.fK)({
                            id: t,
                            changes: {
                                sentBackInStockSubmitMetric: !0
                            }
                        })), Promise.all(m)
                    })({
                        getState: n,
                        formVersionCId: t,
                        openFormVersion: i,
                        accumulatedFields: l
                    }), await ee({
                        getState: n,
                        formVersionCId: t,
                        openFormVersion: i
                    }), await $({
                        actionId: e,
                        formVersionCId: t,
                        getState: n
                    })
                },
                se = (n(26650), n(72012)),
                ae = n(91977);
            const le = ({
                redirectUrl: e,
                newWindow: t
            }) => {
                const n = e.replace(/^javascript:/, "");
                if (t) {
                    const e = window.open(n, "_blank");
                    null == e || e.focus()
                } else(0, ae.Z)(n)
            };
            var de = async ({
                actionId: e,
                formVersionCId: t,
                getState: n,
                isSubmit: o = !1
            }) => {
                var i, r;
                (0, f.qB)(`Running Redirect To URL Action | Action ID: ${e}`);
                const s = n(),
                    a = s.onsiteState.openFormVersions[t];
                if (!a) throw new Error("Open Form Version does not exist");
                const l = s.formsState.actions ? s.formsState.actions[e] : void 0;
                if (!l) throw new Error("Form Action does not exist");
                if (!s.onsiteState.client.klaviyoCompanyId) throw new Error("Company ID does not exist");
                const d = (null == (i = l.data) ? void 0 : i.redirectUrl) || "about:blank",
                    c = !(null == (r = l.data) || !r.newWindow) && l.actionType === g.$b;
                l.actionType === g.$b && (0, F.$k)({
                    formId: a.formId,
                    successActionType: g.$b
                }), await (({
                    getState: e,
                    formVersionCId: t,
                    openFormVersion: n
                }) => {
                    const o = e(),
                        i = (0, V.Z)(),
                        r = o.formsState.formVersions[n.formVersionId];
                    if (r) {
                        var s;
                        const e = (0, x.sb)(o, r.formVersionId, i, (0, S.wf)(o, t)) === n.currentViewId,
                            a = !(null == (s = o.onsiteState.createdProfileEvents[n.formId]) || !s.formCompleted);
                        !a && e && (0, k.ej)({
                            state: w.Z.getState(),
                            formId: n.formId,
                            formVersionId: n.formVersionId,
                            pageUrl: window.location.href,
                            deviceType: i,
                            hasCompletedEventBeenCreated: a,
                            utmParams: (0, _.Z)()
                        })
                    }
                })({
                    getState: n,
                    formVersionCId: t,
                    openFormVersion: a
                });
                const m = (({
                    getState: e,
                    formVersionCId: t,
                    openFormVersion: n,
                    isSubmit: o,
                    redirectUrl: i
                }) => {
                    const r = e(),
                        {
                            currentViewId: s,
                            formId: a
                        } = n,
                        l = r.onsiteState.client.klaviyoCompanyId;
                    if (!l) throw new Error("Company ID does not exist");
                    const d = (0, x.E5)(r, s),
                        c = r.formsState.views[s],
                        m = c ? (0, x.O)(r, c) : void 0,
                        u = [(0, b.M)({
                            metric: v.nR,
                            logTelemetric: !o && !n.sentSubmitMetric,
                            logCustomEvent: !0,
                            formVersionCId: t,
                            formId: a,
                            companyId: l,
                            action_type: "Go to URL",
                            destination_url: i
                        }), (0, b.M)({
                            metric: v._5,
                            logTelemetric: !o,
                            logCustomEvent: !0,
                            formVersionCId: t,
                            formId: a,
                            companyId: l,
                            action_type: "Go to URL",
                            destination_url: i,
                            step_number: m ? m + 1 : void 0,
                            step_name: d
                        })];
                    return Promise.allSettled(u)
                })({
                    getState: n,
                    formVersionCId: t,
                    openFormVersion: a,
                    isSubmit: o,
                    redirectUrl: d
                });
                return c ? (le({
                    redirectUrl: d,
                    newWindow: c
                }), m) : (0, se.n)(200, m).then((() => le({
                    redirectUrl: d,
                    newWindow: c
                }))).catch((() => le({
                    redirectUrl: d,
                    newWindow: c
                })))
            };
            var ce = async ({
                    actionId: e,
                    formVersionCId: t,
                    getState: n
                }) => {
                    const o = n(),
                        i = o.formsState.actions ? o.formsState.actions[e] : void 0;
                    if (!i) throw new Error("Form Action does not exist");
                    const r = (0, O.cA)(o, e),
                        s = (0, S.$f)({
                            state: o,
                            formVersionCId: t,
                            hiddenFieldsComponentId: r,
                            formActionType: i.actionType
                        });
                    await te({
                        actionId: e,
                        formVersionCId: t,
                        getState: n
                    }), new Promise((e => {
                        if (s.$email || s.$phone_number) {
                            let t = 5;
                            const n = setInterval((() => {
                                ((0, D.pN)() || 0 === t) && (clearInterval(n), e(!0)), t -= 1
                            }), 600)
                        }
                        e(!0)
                    })).then((async () => {
                        await de({
                            actionId: e,
                            formVersionCId: t,
                            getState: n,
                            isSubmit: !0
                        })
                    }))
                },
                me = n(47474),
                ue = n(68371),
                fe = n(85301);
            var pe = async ({
                actionId: e,
                formVersionCId: t,
                getState: n
            }) => {
                var i, r;
                (0, f.qB)(`Running Redirect To Inbox Action | Action ID: ${e}`);
                const s = n(),
                    a = s.onsiteState.openFormVersions[t];
                if (!a) throw new Error("Open Form Version does not exist");
                const l = s.onsiteState.client.klaviyoCompanyId;
                if (!l) throw new Error("Company ID does not exist");
                const {
                    previousFormSubmitBody: d
                } = s.onsiteState.client, c = (null == d ? void 0 : d.data.attributes.profile.data.attributes[o.Td]) || (null == d || null == (i = d.data.attributes.profile.data.attributes.properties) ? void 0 : i[o.HD]), m = null == d || null == (r = d.data) || null == (r = r.relationships) || null == (r = r.list) || null == (r = r.data) ? void 0 : r.id;
                if (!c || !m || !(0, ue.q)(s, m)) throw (0, b.M)({
                    metric: v.Yu,
                    logCustomEvent: !0,
                    formVersionCId: t,
                    formId: a.formId,
                    companyId: l,
                    userEmail: c,
                    listId: m
                }), new Error(`Cannot redirect to inbox. Email address and list ID must both be present. List must be a Double Opt-In list. userEmail: ${c} listId: ${m}`);
                const {
                    senderEmail: u,
                    subject: p
                } = (0, ue.U)(s, m), h = (0, V.Z)() === fe.Jq, g = (0, me.qV)({
                    userEmail: c,
                    subject: p,
                    senderEmail: u
                }), {
                    link: y,
                    provider: I
                } = g || {};
                if ((0, b.M)({
                        metric: v.t2,
                        logCustomEvent: !0,
                        formVersionCId: t,
                        formId: a.formId,
                        companyId: l,
                        userEmail: c,
                        listId: m,
                        sniper_link: y,
                        emailProvider: I
                    }), y) {
                    const e = window.open(y, "_blank");
                    null == e || e.focus()
                } else(0, f.qB)(`Could not generate sniper link. User email: ${c}. List ID: ${m}. isMobileDevice: ${h}. subject: ${p}. senderEmail: ${u}`)
            };
            var he = async ({
                actionId: e,
                formVersionCId: t,
                getState: n
            }) => {
                var o, i;
                (0, f.qB)(`Running Open Form Action | Action ID: ${e}`);
                const r = n(),
                    s = r.onsiteState.openFormVersions[t];
                if (!s) throw new Error("Open Form Version does not exist");
                const a = r.formsState.actions ? r.formsState.actions[e] : void 0;
                if (!a) throw new Error("Form Action does not exist");
                const l = r.onsiteState.client.klaviyoCompanyId;
                if (!l) throw new Error("Company ID does not exist");
                const d = null == (o = a.data) ? void 0 : o.formIdToOpen;
                if (!d) throw new Error("No form to open specified.");
                const c = r.formsState.forms[d];
                if (null == c || !c.liveFormVersion) throw console.error(`Form with formId: ${d} does not have a live form version. Please check the form configuration.`), new p._D(`Form with formId: ${d} does not have a live form version. Please check the form configuration.`);
                a.actionType === g.y6 && (0, F.$k)({
                    formId: s.formId,
                    successActionType: g.y6
                }), (0, b.M)({
                    metric: v.qo,
                    logCustomEvent: !0,
                    formVersionCId: t,
                    formId: s.formId,
                    companyId: l,
                    action_type: "Open Form",
                    form_to_open: d
                }), null != (i = a.data) && i.closeSourceForm && (0, I.et)({
                    formVersionCId: t
                }), (0, I.f7)({
                    formVersionId: c.liveFormVersion,
                    onRenderForms: () => {},
                    allowReTriggering: !0
                })
            };
            const ve = (e, t, n, o, i) => {
                    (0, f.qB)(`Action Error Handler | ${e.message}`);
                    if ([p.mN].some((t => e instanceof t))) throw e;
                    const r = e instanceof p.TT,
                        s = e instanceof p.FR;
                    let a = h.xl,
                        l = v.DF;
                    r ? (a = h.gl, l = v.yH) : s && (l = v.wL), ((e, t, n, o, i, r, s) => {
                        const a = (0, p.pS)(n),
                            l = n instanceof p.vS,
                            d = n instanceof p.TT,
                            c = n instanceof p.FR,
                            m = n instanceof p._D;
                        (0, I.Cm)({
                            id: o,
                            changes: {
                                errorViewMessage: e
                            }
                        }), m || (t === v.wL ? (0, b.M)({
                            metric: v.wL,
                            formVersionCId: o,
                            formId: r || "",
                            companyId: s || "",
                            logTelemetric: !0
                        }) : (0, b.M)({
                            metric: t,
                            formVersionCId: o,
                            formId: r || "",
                            companyId: s || "",
                            listId: null == i ? void 0 : i.listId,
                            isProgressEventError: a,
                            errorName: n.name,
                            errorMessage: n.message
                        })), a || l || d || c || m || (0, y.T)(n, {
                            tags: {
                                onSubmit: "True"
                            },
                            extra: {
                                submitAction: !0,
                                formId: r,
                                companyId: s
                            }
                        })
                    })(a, l, e, t, n, o, i)
                },
                ge = ["children", "actionId", "formVersionCId"];
            var ye = e => {
                let {
                    children: t,
                    actionId: n,
                    formVersionCId: o
                } = e, i = c()(e, ge);
                const [r, a] = (0, s.useState)(!1), l = (0, w.Z)((e => {
                    var t;
                    return e.formsState.actions && n ? null == (t = e.formsState.actions[n]) ? void 0 : t.actionType : void 0
                })), d = (0, w.Z)((e => {
                    var t;
                    return e.formsState.actions && n ? null == (t = e.formsState.actions[n]) || null == (t = t.data) ? void 0 : t.newWindow : void 0
                })), p = (0, w.Z)((e => {
                    var t;
                    return e.formsState.actions && n ? null == (t = e.formsState.actions[n]) || null == (t = t.data) ? void 0 : t.redirectUrl : void 0
                })), h = (0, s.useMemo)((() => n && l ? (0, g.l9)(l, {
                    newWindow: d,
                    redirectUrl: p
                }) : {}), [n, l, d, p]);
                if (!n) return t(Object.assign({
                    onClick: void 0,
                    handlingFormAction: r,
                    ariaProps: h
                }, i));
                if ((0, m.O)("onsite_form_actions_v2") && localStorage.getItem("kl_onsite_form_actions_v2")) {
                    const e = () => {
                        a(!0), (async ({
                            actionId: e,
                            formVersionCId: t,
                            getState: n
                        }) => {
                            var o;
                            const i = n(),
                                r = i.formsState.actions ? i.formsState.actions[e] : void 0,
                                s = null == r ? void 0 : r.actionType,
                                a = null == (o = i.onsiteState.openFormVersions[t]) ? void 0 : o.formId,
                                l = i.onsiteState.client.klaviyoCompanyId;
                            (0, f.qB)(`Running Action | ID: ${e} Type: ${s}`);
                            try {
                                switch (s) {
                                    case g.p:
                                        return await ne({
                                            actionId: e,
                                            formVersionCId: t,
                                            getState: n
                                        });
                                    case g.hL:
                                        return await $({
                                            actionId: e,
                                            formVersionCId: t,
                                            getState: n
                                        });
                                    case g.Pj:
                                        return await oe({
                                            actionId: e,
                                            formVersionCId: t,
                                            getState: n,
                                            isSubmit: !1
                                        });
                                    case g.Ry:
                                        return await ie({
                                            actionId: e,
                                            formVersionCId: t,
                                            getState: n
                                        });
                                    case g.r8:
                                        return await re({
                                            actionId: e,
                                            formVersionCId: t,
                                            getState: n
                                        });
                                    case g.uo:
                                        return await ce({
                                            actionId: e,
                                            formVersionCId: t,
                                            getState: n
                                        });
                                    case g.$b:
                                        return await de({
                                            actionId: e,
                                            formVersionCId: t,
                                            getState: n,
                                            isSubmit: !1
                                        });
                                    case g.Cd:
                                        return await pe({
                                            actionId: e,
                                            formVersionCId: t,
                                            getState: n
                                        });
                                    case g.y6:
                                        return await he({
                                            actionId: e,
                                            formVersionCId: t,
                                            getState: n
                                        });
                                    case g.T5:
                                    case g.p4:
                                    case g.Kc:
                                    case g.WP:
                                    case g.pt:
                                    case g.eZ:
                                        throw new Error(`Actions V2: ${s} not implemented yet.`);
                                    default:
                                        throw new Error(`Unknown action type: ${s}`)
                                }
                            } catch (e) {
                                const n = e instanceof Error ? e : new Error(String(e));
                                return ve(n, t, r, a, l), Promise.reject(n)
                            }
                        })({
                            actionId: n,
                            formVersionCId: o,
                            getState: w.Z.getState
                        }).catch((() => {
                            a(!1);
                            const e = document.querySelector(`.klaviyo-form-version-cid_${o} [aria-invalid="true"]`);
                            e && e.focus()
                        })).finally((() => {
                            a(!1)
                        }))
                    };
                    return t(Object.assign({
                        onClick: n ? e : void 0,
                        handlingFormAction: r,
                        ariaProps: h
                    }, i))
                }
                const v = (0, u.j)({
                    actionId: n,
                    formVersionCId: o,
                    getState: w.Z.getState
                });
                if (!v) return t(Object.assign({
                    onClick: void 0,
                    handlingFormAction: r,
                    ariaProps: h
                }, i));
                const y = new v({
                    actionId: n,
                    formVersionCId: o,
                    getState: w.Z.getState
                });
                return t(Object.assign({
                    onClick: n ? () => {
                        v.formActionType && g.NB.has(v.formActionType) && a(!0), y.runAction().catch((() => {
                            a(!1);
                            const e = document.querySelector(`.klaviyo-form-version-cid_${o} [aria-invalid="true"]`);
                            e && e.focus()
                        })).finally((() => {
                            a(!1)
                        }))
                    } : void 0,
                    handlingFormAction: r,
                    ariaProps: h
                }, i))
            };
            const Ie = () => null;
            var be = ({
                    formVersionCId: e,
                    componentId: t,
                    a11yIdentifierBlock: n
                }) => {
                    const o = (0, w.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                        i = (0, w.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.styling
                        })),
                        s = (0, w.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.image
                        })),
                        d = (0, w.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.altText
                        })),
                        c = (0, w.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) ? void 0 : n.actionId
                        })),
                        m = c ? l.aG : l.Ei,
                        u = (null == i ? void 0 : i.width) || 100;
                    return a().createElement(l.ZC, {
                        style: {
                            display: "flex",
                            alignItems: "center",
                            width: "100%",
                            height: "auto"
                        },
                        a11yIdentifier: n
                    }, o && !s ? a().createElement(Ie, null) : s && a().createElement(ye, {
                        actionId: c,
                        formVersionCId: e
                    }, (({
                        onClick: e,
                        handlingFormAction: t,
                        ariaProps: i
                    }) => a().createElement(l.ZC, {
                        className: t ? "klaviyo-spinner" : "",
                        style: {
                            position: "relative",
                            display: "flex",
                            alignItems: "center",
                            width: "100%",
                            height: "auto"
                        },
                        onClick: e,
                        a11yIdentifier: n
                    }, a().createElement(m, r()({
                        a11yIdentifier: n,
                        style: {
                            maxWidth: "100%",
                            width: u,
                            height: "auto",
                            cursor: e ? "pointer" : "initial"
                        },
                        src: s.url,
                        tabIndex: o || !c ? -1 : 0
                    }, d && d.length > 0 ? {
                        alt: d
                    } : {}, i))))))
                },
                Se = n(85912),
                we = n(23409),
                Ce = n(23034),
                Ee = n(16792),
                xe = n(75107),
                Ve = n(99877),
                _e = n(95255),
                Te = n(24878),
                ke = n(36679);
            let $e, Fe = e => e;
            var Oe = ({
                    formVersionCId: e,
                    componentId: t,
                    theme: n,
                    a11yIdentifierStyles: i
                }) => {
                    var r;
                    const d = (0, w.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                        c = (0, w.Z)((n => {
                            var o;
                            const i = null == (o = n.onsiteState.openFormVersions[e]) ? void 0 : o.components[t];
                            return !!n.onsiteState.client.isDesignWorkflow || !i || i.valid || void 0 === i.valid
                        })),
                        m = (0, w.Z)((n => {
                            var o;
                            return null == (o = n.onsiteState.openFormVersions[e]) || null == (o = o.components[t]) ? void 0 : o.metadata
                        }), Ce.X),
                        u = (0, w.Z)((n => {
                            var o;
                            return null == (o = n.onsiteState.openFormVersions[e]) || null == (o = o.components[t]) ? void 0 : o.validationErrorType
                        })),
                        f = (0, w.Z)((n => (0, S.HN)(n, e, t))),
                        p = (0, w.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.required
                        })),
                        h = (0, w.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.label
                        })),
                        g = (0, w.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.showLabel
                        })),
                        y = (0, w.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.placeholder
                        })),
                        C = (0, w.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) ? void 0 : n.componentType
                        })),
                        E = (0, w.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.fieldId
                        })),
                        x = (0, w.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.format
                        })),
                        V = (0, w.Z)((e => {
                            var n;
                            return (null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.delimiter) || ""
                        })),
                        _ = (0, w.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.prefill
                        })),
                        T = (0, w.Z)((t => {
                            var n;
                            return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formId
                        })),
                        k = (0, w.Z)((t => {
                            var n;
                            return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formVersionId
                        })),
                        $ = (0, w.Z)((e => e.onsiteState.client.klaviyoCompanyId)),
                        F = (0, w.Z)((t => (0, S.wf)(t, e))),
                        Z = (0, w.Z)((e => {
                            const n = e.formsState.components[t];
                            return void 0 !== n && (0, O.En)(n)
                        })),
                        A = (0, s.useMemo)((() => C === o.ZW || C === o.Ys), [C]),
                        M = (0, s.useMemo)((() => `${null==E?void 0:E.replace(/ /g,"_").replace(/\$/g,"")}_${t}`), [E, t]),
                        B = (0, s.useMemo)((() => C === o.eC ? "one-time-code" : E && o.no[E] ? o.no[E] : void 0), [E, C]),
                        {
                            current: N
                        } = (0, s.useRef)((0, Se.Z)("klaviyo_ariaid_")),
                        [j, R] = (0, s.useState)(!1),
                        [P, L] = (0, s.useState)(),
                        z = ({
                            value: n,
                            validate: o,
                            hasChangedSinceLastValidation: i
                        }) => {
                            var r;
                            const s = void 0 !== n ? n : "";
                            L(s), R(!!i), (0, I.hX)({
                                formVersionCId: e,
                                componentId: t,
                                value: A ? null == (r = Ee.Tb.find((({
                                    format: e
                                }) => JSON.stringify(e) === JSON.stringify(x)))) ? void 0 : r.formatDate(s, V) : s,
                                validate: o
                            })
                        };
                    (0, s.useEffect)((() => {
                        const e = (0, D.FU)();
                        if (_ && e && C === o.xC && !d) {
                            const {
                                [o.HD]: t
                            } = e;
                            z({
                                value: t,
                                validate: !1
                            })
                        }
                    }), []), (0, s.useEffect)((() => {
                        Z && !d && T && e && F && ((0, ke.WN)(T), $ && (0, b.M)({
                            metric: v.mC,
                            formVersionCId: e,
                            formId: T,
                            companyId: $
                        }))
                    }), [Z, d, T, $, e, F, k]);
                    const W = (0, s.useMemo)((() => `label-${M}`), [M]),
                        H = (0, s.useMemo)((() => h ? void 0 : y), [h, y]),
                        U = j || c,
                        q = A && !y ? null == (r = Ee.Tb.find((({
                            format: e
                        }) => JSON.stringify(e) === JSON.stringify(x)))) ? void 0 : r.label.replace(/ /g, V) : y,
                        K = A ? xe.n : l.II;
                    return a().createElement(l.ZC, {
                        style: {
                            display: "flex",
                            flexGrow: 1,
                            flexDirection: "column",
                            alignSelf: "flex-end"
                        },
                        a11yIdentifier: i
                    }, a().createElement(Ve.Z, {
                        id: W,
                        a11yIdentifier: i,
                        theme: n,
                        htmlFor: M,
                        showLabel: !(void 0 !== g || !h) || g
                    }, h), a().createElement(K, {
                        id: M,
                        className: (0, we.iv)($e || ($e = Fe `
          &&& {
            &::placeholder {
              color: ${0};
              font-family: ${0};
              font-size: ${0};
              font-weight: ${0};
              letter-spacing: ${0}px;
            }
            &::-moz-placeholder {
              line-height: ${0}px;
            }
            &:hover {
              border-color: ${0} !important;
            }
            &:focus-visible {
              outline-width: 2px;
              outline-style: auto;
              outline-color: ${0};
              outline-offset: 0;
            }
          }
        `), n.inputStyles.textStyles.placeholderColor, n.inputStyles.textStyles.fontFamily, n.inputStyles.textStyles.fontSize, n.inputStyles.textStyles.fontWeight, n.inputStyles.textStyles.letterSpacing, n.inputStyles.textStyles.height, n.inputStyles.border.activeColor, U ? n.inputStyles.border.activeColor || n.focusColor : n.inputStyles.border.errorColor),
                        style: {
                            boxSizing: "border-box",
                            borderRadius: n.inputStyles.borderRadius,
                            paddingLeft: 16,
                            paddingRight: 0,
                            paddingTop: 0,
                            paddingBottom: 0,
                            height: n.inputStyles.textStyles.height,
                            textAlign: "left",
                            color: n.inputStyles.textStyles.formInputTextColor,
                            fontFamily: n.inputStyles.textStyles.fontFamily,
                            fontSize: n.inputStyles.textStyles.fontSize,
                            fontWeight: n.inputStyles.textStyles.fontWeight,
                            letterSpacing: n.inputStyles.textStyles.letterSpacing,
                            backgroundColor: n.inputStyles.inputBackgroundColor,
                            border: "1px solid",
                            borderColor: n.inputStyles.border[U ? "defaultColor" : "errorColor"]
                        },
                        type: (e => {
                            switch (e) {
                                case o.xC:
                                    return "email";
                                case o.J8:
                                    return "tel";
                                default:
                                    return "text"
                            }
                        })(C),
                        autoComplete: B,
                        name: C === o.xC ? "email" : void 0,
                        tabIndex: d ? -1 : 0,
                        placeholder: q,
                        "aria-label": H,
                        "aria-required": p || void 0,
                        "aria-invalid": !U,
                        "aria-describedby": U ? void 0 : N,
                        onInit: () => {
                            d || (0, I.DK)({
                                formVersionCId: e,
                                componentId: t
                            })
                        },
                        onBlur: e => z({
                            value: e.target.value,
                            validate: !1,
                            hasChangedSinceLastValidation: !1
                        }),
                        onChange: e => {
                            (0, Te.l)(), z({
                                value: e.target.value,
                                validate: !1,
                                hasChangedSinceLastValidation: !0
                            })
                        },
                        options: A ? {
                            date: !0,
                            datePattern: x,
                            delimiter: V
                        } : {
                            delimiter: ""
                        },
                        value: P || "",
                        a11yIdentifier: i
                    }), !d && !j && a().createElement(_e.Z, {
                        theme: n,
                        formVersionCId: e,
                        componentAriaID: N,
                        metadata: m,
                        validationErrorType: u,
                        validationErrorMessage: f,
                        a11yIdentifier: i
                    }))
                },
                Ze = n(91854);
            let Ae, Me = e => e;
            const {
                THEME_KEY: De
            } = Ze.default;
            var Be = ({
                    componentId: e,
                    formVersionCId: t,
                    theme: n,
                    a11yIdentifierBlock: o
                }) => {
                    const i = (0, w.Z)((t => {
                            var n;
                            return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.content
                        })),
                        r = (0, w.Z)((t => {
                            var n;
                            return null == (n = t.formsState.components[e]) ? void 0 : n.actionId
                        })),
                        s = (0, w.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                        d = (0, we.iv)(Ae || (Ae = Me `
    &&& {
      ${0}
      &:focus-visible {
        outline-width: 2px;
        outline-style: auto;
        outline-color: ${0};
        outline-offset: 0;
      }
    }
  `), !1 !== n[De].specifyHoverBackgroundColor ? `\n            &:hover {\n              background-color: ${n[De].hoverBackgroundColor} !important;\n              ${n[De].hoverTextColor||n[De].textColor?`color: ${n[De].hoverTextColor||n[De].textColor} !important;`:""}\n            }` : "", n.inputStyles.border.activeColor || n.focusColor);
                    return a().createElement(ye, {
                        formVersionCId: t,
                        actionId: r
                    }, (({
                        onClick: e,
                        handlingFormAction: t
                    }) => a().createElement(l.zx, {
                        a11yIdentifier: o,
                        className: t ? `klaviyo-spinner ${d}` : d,
                        style: Object.assign({
                            background: n[De].backgroundColor,
                            borderRadius: n[De].borderRadius,
                            borderStyle: n[De].borderStyle,
                            borderColor: n[De].borderColor,
                            borderWidth: n[De].borderWidth,
                            color: n[De].textStyles.color,
                            fontFamily: n[De].textStyles.fontFamily,
                            fontSize: n[De].textStyles.fontSize,
                            fontWeight: n[De].textStyles.fontWeight,
                            letterSpacing: n[De].textStyles.letterSpacing,
                            lineHeight: 1,
                            fontStyle: n[De].textStyles.fontStyle,
                            textDecoration: n[De].textStyles.textDecoration,
                            whiteSpace: "normal",
                            paddingTop: n[De].paddingTop,
                            paddingBottom: n[De].paddingBottom,
                            textAlign: "center",
                            wordBreak: "break-word",
                            alignSelf: "flex-end",
                            cursor: "pointer",
                            pointerEvents: t ? "none" : "auto",
                            height: n[De].height
                        }, n[De].fullWidth ? {
                            width: "100%"
                        } : {
                            paddingLeft: 10,
                            paddingRight: 10
                        }),
                        type: "button",
                        disabled: t,
                        onClick: e,
                        tabIndex: s ? -1 : 0
                    }, i)))
                },
                Ne = n(68414);
            const je = `\n  color: #000000;\n  line-height: normal;\n\n  p {\n    margin: 0px;\n  }\n  span {\n    display: inline;\n  }\n  ol,\n  ul {\n    padding: 0 0 0 48px;\n    margin: 0;\n  }\n  ul {\n    list-style-type: disc;\n  }\n  li {\n    line-height: 18px;\n  }\n  a {\n    color: ${n(83657).Z.blue};\n    text-decoration: underline;\n    border-bottom: none;\n  }\n`,
                Re = (0, we.iv)(je),
                Pe = ["html"],
                Le = e => {
                    let {
                        html: t
                    } = e, n = c()(e, Pe);
                    return a().createElement("div", r()({}, t ? {
                        dangerouslySetInnerHTML: {
                            __html: t
                        }
                    } : {}, {
                        style: {
                            width: "100%"
                        },
                        className: `${o.Tc} ${Re}`
                    }, n))
                },
                {
                    A11yWrapper: ze = (() => null),
                    useRecursivelySetA11yAttribute: We = (() => "")
                } = {},
                He = ({
                    a11yIdentifierBlock: e,
                    id: t,
                    html: n
                }) => {
                    const o = We({
                        a11yIdentifier: e || "",
                        html: n
                    });
                    return e ? a().createElement(ze, {
                        identifier: e
                    }, a().createElement(Le, {
                        id: t,
                        html: o
                    })) : a().createElement(Le, {
                        id: t,
                        html: n
                    })
                };
            var Ue = ({
                itemId: e,
                parentType: t = Ne.A,
                a11yIdentifierBlock: n
            }) => {
                const o = (0, w.Z)((n => {
                        var o, i;
                        return t === Ne.p && n.formsState.teasers ? null == (o = n.formsState.teasers[e]) || null == (o = o.data) || null == (o = o.content) ? void 0 : o.html : null == (i = n.formsState.components[e]) || null == (i = i.data) || null == (i = i.content) ? void 0 : i.html
                    })),
                    i = (0, s.useMemo)((() => `rich-text-${e}`), [e]);
                return a().createElement(He, {
                    a11yIdentifierBlock: n,
                    id: i,
                    html: o
                })
            };
            n(83362);
            const qe = ["selectorType", "fillColor", "formVersionCId", "id"],
                Ke = ({
                    fillColor: e,
                    id: t
                }) => a().createElement("g", {
                    id: t,
                    stroke: "none",
                    strokeWidth: "1",
                    fill: "none",
                    fillRule: "evenodd"
                }, a().createElement("g", {
                    id: `checkbox-on-${t}`,
                    transform: "translate(3.000000, 4.000000)",
                    fill: "#303B43"
                }, a().createElement("polygon", {
                    id: `shape-${t}`,
                    fill: e,
                    points: "4.45454545 9.20149254 1.11363636 5.75373134 0 6.90298507 4.45454545 11.5 14 1.64925373 12.8863636 0.5"
                }))),
                Ge = ({
                    fillColor: e,
                    id: t
                }) => a().createElement("g", {
                    id: t,
                    stroke: "none",
                    strokeWidth: "1",
                    fill: "none",
                    fillRule: "evenodd"
                }, a().createElement("g", {
                    id: `shape-${t}`,
                    transform: "translate(4.000000, 4.000000)",
                    fill: "#303B43"
                }, a().createElement("circle", {
                    fill: e,
                    id: `oval-${t}`,
                    cx: "6",
                    cy: "6",
                    r: "5.55555556"
                })));
            var Ye = e => {
                let {
                    selectorType: t,
                    fillColor: n,
                    id: o
                } = e, i = c()(e, qe);
                return a().createElement("svg", r()({
                    style: {
                        cursor: "pointer",
                        display: "none",
                        position: "absolute",
                        margin: 0
                    },
                    width: "20px",
                    height: "20px",
                    viewBox: "0 0 20 20",
                    version: "1.1",
                    xmlns: "http://www.w3.org/2000/svg",
                    "aria-hidden": "true"
                }, i), a().createElement("defs", null), "radio" === t ? a().createElement(Ge, {
                    id: `radio_inner_${o}`,
                    fillColor: n
                }) : a().createElement(Ke, {
                    id: `checkbox_inner_${o}`,
                    fillColor: n
                }))
            };
            const Xe = ["selectorType", "valid", "theme", "formVersionCId"],
                Je = ({
                    backgroundColor: e
                }) => a().createElement("g", null, a().createElement("g", null, a().createElement("rect", {
                    strokeWidth: "1",
                    x: "0.5",
                    y: "0.5",
                    width: "19",
                    height: "19",
                    rx: "2.22222222",
                    fill: e
                }))),
                Qe = ({
                    backgroundColor: e
                }) => a().createElement("g", null, a().createElement("g", null, a().createElement("circle", {
                    strokeWidth: "1",
                    cx: "10",
                    cy: "10",
                    r: "9.5",
                    fill: e
                })));
            var et = e => {
                let {
                    selectorType: t,
                    valid: n,
                    theme: o
                } = e, i = c()(e, Xe);
                return a().createElement("svg", r()({
                    style: {
                        stroke: n ? o.inputStyles.border.defaultColor : o.inputStyles.border.errorColor,
                        marginRight: 8,
                        minWidth: 20,
                        width: "auto",
                        height: "auto",
                        borderRadius: "radio" === t ? "50%" : void 0
                    },
                    width: "20px",
                    height: "20px",
                    viewBox: "0 0 20 20",
                    version: "1.1",
                    xmlns: "http://www.w3.org/2000/svg",
                    "aria-hidden": "true"
                }, i), "radio" === t ? a().createElement(Qe, {
                    backgroundColor: o.inputStyles.inputBackgroundColor
                }) : a().createElement(Je, {
                    backgroundColor: o.inputStyles.inputBackgroundColor
                }))
            };
            let tt, nt = e => e;
            var ot = ({
                name: e,
                label: t,
                isValid: n,
                componentAriaID: i,
                componentType: r,
                onChange: d,
                tabIndex: c,
                theme: m,
                formVersionCId: u,
                a11yIdentifierStyles: f,
                a11yIdentifierBlock: p,
                alignCheckbox: h,
                ariaRequired: v
            }) => {
                const {
                    current: g
                } = (0, s.useRef)((0, Se.Z)(`${e}__`)), y = r === o.hD ? "radio" : "checkbox";
                return a().createElement(a().Fragment, null, a().createElement(l.II, {
                    className: "klaviyo-sr-only",
                    tabIndex: c,
                    type: y,
                    id: g,
                    name: e,
                    onChange: d,
                    "aria-invalid": !n,
                    "aria-label": t,
                    "aria-describedby": n ? void 0 : i,
                    "aria-required": v,
                    a11yIdentifier: p
                }), a().createElement(l.__, {
                    className: (0, we.iv)(tt || (tt = nt `
          &&&& {
            &:hover {
              svg {
                stroke: ${0} !important;
              }
            }
          }
        `), m.inputStyles.border.activeColor),
                    style: {
                        display: "flex",
                        alignItems: null != h ? h : "center",
                        flex: m.inputStyles.arrangement === o.ZC ? " 1 0 100%" : " 0 0 auto",
                        paddingBottom: 8,
                        wordBreak: "break-word",
                        maxWidth: "100%",
                        cursor: "pointer"
                    },
                    htmlFor: g,
                    a11yIdentifier: f
                }, a().createElement(et, {
                    valid: n,
                    selectorType: y,
                    "aria-hidden": "true",
                    theme: m,
                    formVersionCId: u
                }), a().createElement(Ye, {
                    selectorType: y,
                    "aria-hidden": "true",
                    formVersionCId: u,
                    fillColor: m.inputStyles.textStyles.formInputTextColor,
                    id: g
                }), a().createElement(l.ZC, {
                    style: {
                        cursor: "pointer",
                        color: m.inputStyles.textStyles.color,
                        fontFamily: m.inputStyles.textStyles.fontFamily,
                        fontSize: m.inputStyles.textStyles.fontSize,
                        fontWeight: m.inputStyles.textStyles.fontWeight,
                        letterSpacing: m.inputStyles.textStyles.letterSpacing,
                        marginRight: 24,
                        display: "flex",
                        position: "relative",
                        top: 1
                    },
                    a11yIdentifier: f
                }, t)))
            };
            let it, rt = e => e;
            const st = ["selected", "id", "label"],
                at = {
                    right: "flex-end",
                    left: "flex-start",
                    center: "center"
                },
                lt = ({
                    options: e,
                    componentType: t,
                    toggledOptionIndex: n
                }) => e.reduce(((e, i, r) => {
                    let {
                        selected: s,
                        id: a,
                        label: l
                    } = i, d = c()(i, st), m = t !== o.hD && s;
                    return n === r && (m = !m), e.push(Object.assign({
                        selected: m,
                        label: l,
                        id: a || (0, Se.Z)(`${l}__`)
                    }, d)), e
                }), []);
            var dt = ({
                    formVersionCId: e,
                    componentId: t,
                    theme: n,
                    a11yIdentifierStyles: i,
                    a11yIdentifierBlock: r
                }) => {
                    const d = (0, w.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                        c = (0, w.Z)((n => {
                            var o;
                            const i = null == (o = n.onsiteState.openFormVersions[e]) ? void 0 : o.components[t];
                            return !!n.onsiteState.client.isDesignWorkflow || !i || i.valid || void 0 === i.valid
                        })),
                        m = (0, w.Z)((n => {
                            var o;
                            return null == (o = n.onsiteState.openFormVersions[e]) || null == (o = o.components[t]) ? void 0 : o.metadata
                        }), Ce.X),
                        u = (0, w.Z)((n => {
                            var o;
                            return null == (o = n.onsiteState.openFormVersions[e]) || null == (o = o.components[t]) ? void 0 : o.validationErrorType
                        })),
                        f = (0, w.Z)((n => (0, S.HN)(n, e, t))),
                        p = (0, w.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) ? void 0 : n.componentType
                        })),
                        h = (0, w.Z)((e => {
                            var n;
                            return (null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.options) || []
                        }), Ce.X),
                        v = (0, w.Z)((e => {
                            var n;
                            return (null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.fieldId) || ""
                        })),
                        g = (0, w.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.required
                        })),
                        y = (0, w.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.label
                        })),
                        b = (0, w.Z)((e => {
                            var n;
                            return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.showLabel
                        })),
                        C = (0, w.Z)((e => {
                            var n;
                            const o = null == (n = e.formsState.components[t]) || null == (n = n.data) || null == (n = n.styling) ? void 0 : n.innerAlignment;
                            return o ? at[o] : "flex-start"
                        })),
                        [E, x] = (0, s.useState)([]);
                    (0, s.useEffect)((() => {
                        x(lt({
                            options: h,
                            componentType: p
                        }))
                    }), [h]);
                    const {
                        inputName: V,
                        labelId: _
                    } = (0, s.useMemo)((() => {
                        const e = (0, Se.Z)(`${encodeURIComponent(v)}__`);
                        return {
                            inputName: e,
                            labelId: `kl_${e}_label`
                        }
                    }), []), T = 1 === E.length;
                    return a().createElement(l.ZC, {
                        style: {
                            width: "100%",
                            justifyContent: C,
                            display: "flex"
                        }
                    }, a().createElement(l.C3, {
                        className: (0, we.iv)(it || (it = rt `
          &&& {
            input:focus-visible + label > svg {
              outline-width: 2px;
              outline-style: auto;
              outline-color: ${0};
              outline-offset: 0;
            }
          }
        `), n.inputStyles.border.activeColor || n.focusColor),
                        style: Object.assign({
                            alignSelf: "flex-end"
                        }, n.inputStyles.arrangement === o.ZC ? {
                            display: "block"
                        } : {
                            flexDirection: "column",
                            flexWrap: "wrap"
                        }),
                        a11yIdentifier: i
                    }, a().createElement(Ve.Z, {
                        a11yIdentifier: i,
                        id: _,
                        theme: n,
                        style: {
                            marginRight: 8,
                            marginBottom: 8
                        },
                        showLabel: !(void 0 !== b || !y) || b,
                        asLegend: !0
                    }, y), a().createElement(l.ZC, {
                        style: Object.assign({}, n.inputStyles.arrangement === o.ZC ? {
                            display: "block"
                        } : {
                            display: "inline-flex",
                            justifyContent: "flex-start",
                            flexWrap: "wrap"
                        }),
                        role: p === o.hD ? "radiogroup" : "group",
                        a11yIdentifier: i
                    }, E.map((({
                        label: s,
                        id: l
                    }, m) => a().createElement(ot, {
                        key: l,
                        formVersionCId: e,
                        theme: n,
                        name: V,
                        label: s,
                        isValid: c,
                        componentType: p,
                        componentAriaID: _,
                        onChange: () => (n => {
                            (0, Te.l)();
                            const i = lt({
                                options: E,
                                componentType: p,
                                toggledOptionIndex: n
                            });
                            x(i);
                            const r = (e => e.filter((({
                                selected: e
                            }) => e)).map((e => e.value || e.label)))(i);
                            (0, I.hX)({
                                formVersionCId: e,
                                componentId: t,
                                value: p === o.hD ? r.toString() : r
                            })
                        })(m),
                        tabIndex: d ? -1 : 0,
                        a11yIdentifierStyles: i,
                        a11yIdentifierBlock: r,
                        ariaRequired: T && g || void 0
                    })))), !d && a().createElement(_e.Z, {
                        theme: n,
                        formVersionCId: e,
                        componentAriaID: _,
                        validationErrorType: u,
                        validationErrorMessage: f,
                        metadata: m,
                        a11yIdentifier: i
                    })))
                },
                ct = (n(60624), n(75479), n(49889)),
                mt = n.n(ct),
                ut = n(21836),
                ft = n(94841);
            let pt, ht = e => e;
            const vt = "rgb(96, 106, 114)",
                gt = "white",
                yt = "copy",
                It = "applied",
                bt = {
                    [yt]: {
                        message: "Copied!",
                        couponTooltipRectangleWidth: 80
                    },
                    [It]: {
                        message: "Coupon applied to checkout!",
                        couponTooltipRectangleWidth: 196
                    }
                };
            var St, wt, Ct = ({
                show: e,
                theme: t,
                type: n,
                a11yIdentifier: o,
                successMessage: i
            }) => {
                const r = i || bt[n].message,
                    s = bt[n].couponTooltipRectangleWidth;
                return a().createElement(l.ZC, {
                    style: {
                        width: "100%",
                        position: "relative"
                    },
                    a11yIdentifier: o
                }, e && a().createElement(l.ZC, {
                    a11yIdentifier: o,
                    style: {
                        backgroundColor: "transparent",
                        position: "absolute",
                        zIndex: 1,
                        height: "37px",
                        minWidth: `${s}px`,
                        left: "50%",
                        transform: "translate(-50%, 0)",
                        bottom: "-21px",
                        borderRadius: 4,
                        animationName: "klaviyo-fadein, klaviyo-fadeout",
                        animationDuration: "0.4s, 0.4s",
                        animationDelay: "0s, 1.6s"
                    }
                }, a().createElement(l.ZC, {
                    a11yIdentifier: o,
                    className: (0, we.iv)(pt || (pt = ht `
              &&& {
                &::after {
                  content: '';
                  display: block;
                  position: absolute;
                  width: 0;
                  height: 0;
                  bottom: ${0}px;
                  left: calc(50% - ${0}px);
                  border-style: solid;
                  border-width: ${0}px;
                  border-top-color: ${0};
                  border-right-color: transparent;
                  border-bottom-color: transparent;
                  border-left-color: transparent;
                }
                &::before {
                  content: '';
                  display: block;
                  position: absolute;
                  width: 0;
                  height: 0;
                  bottom: ${0}px;
                  left: calc(50% - ${0}px);
                  border-style: solid;
                  border-width: ${0}px;
                  border-top-color: ${0};
                  border-right-color: transparent;
                  border-bottom-color: transparent;
                  border-left-color: transparent;
                }
              }
            `), -6, 6, 6, vt, -8, 7, 7, gt),
                    style: {
                        borderRadius: 4,
                        boxShadow: "1px 1px 4px 0 rgba(0, 0, 0, 0.26)",
                        border: "1px solid white",
                        backgroundColor: vt
                    }
                }, a().createElement(l.Dr, {
                    a11yIdentifier: o,
                    style: {
                        fontSize: 14,
                        fontFamily: t.inputStyles.textStyles.fontFamily,
                        textAlign: "center",
                        color: gt,
                        padding: 8,
                        height: "30px",
                        boxSizing: "border-box",
                        whiteSpace: "nowrap"
                    },
                    role: "alert"
                }, r))))
            };

            function Et() {
                return Et = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var o in n)({}).hasOwnProperty.call(n, o) && (e[o] = n[o])
                    }
                    return e
                }, Et.apply(null, arguments)
            }
            var xt, Vt, _t = function(e) {
                return s.createElement("svg", Et({
                    width: 32,
                    height: 33,
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), St || (St = s.createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M3.602 1.1a3 3 0 0 0-3 3v18.4a3 3 0 0 0 3 3H8v-2H3.602a1 1 0 0 1-1-1V4.1a1 1 0 0 1 1-1h15.2a1 1 0 0 1 1 1v1.2h2V4.1a3 3 0 0 0-3-3h-15.2Z",
                    fill: "currentColor"
                })), wt || (wt = s.createElement("rect", {
                    x: 11.199,
                    y: 8.5,
                    width: 19.2,
                    height: 22.4,
                    rx: 2,
                    stroke: "currentColor",
                    strokeWidth: 2
                })))
            };

            function Tt() {
                return Tt = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var o in n)({}).hasOwnProperty.call(n, o) && (e[o] = n[o])
                    }
                    return e
                }, Tt.apply(null, arguments)
            }
            var kt = function(e) {
                return s.createElement("svg", Tt({
                    width: 32,
                    height: 33,
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), xt || (xt = s.createElement("g", {
                    clipPath: "url(#check_svg__a)"
                }, s.createElement("path", {
                    d: "m11.16 18.992-4.493-4.494a1.73 1.73 0 0 0-2.45 2.443l5.512 6.144c.79.844 2.133.834 2.912-.021l13.321-14.13a1.678 1.678 0 0 0-2.446-2.299L11.16 18.992Z",
                    fill: "#2CB46F",
                    stroke: "#fff"
                }))), Vt || (Vt = s.createElement("defs", null, s.createElement("clipPath", {
                    id: "check_svg__a"
                }, s.createElement("path", {
                    fill: "#fff",
                    transform: "translate(0 .5)",
                    d: "M0 0h32v32H0z"
                })))))
            };
            var $t = ({
                copied: e,
                color: t,
                a11yIdentifier: n
            }) => e ? a().createElement(l.ny, {
                style: {
                    height: 32,
                    width: 32,
                    paddingLeft: "16px",
                    cursor: "pointer",
                    flexShrink: 0
                },
                a11yIdentifier: n
            }, a().createElement(kt, null)) : a().createElement(l.ny, {
                style: {
                    color: t,
                    height: 32,
                    width: 32,
                    paddingLeft: "16px",
                    cursor: "pointer",
                    flexShrink: 0
                },
                a11yIdentifier: n
            }, a().createElement(_t, null));
            let Ft, Ot = e => e;
            const {
                THEME_KEY: Zt
            } = ut.default;
            var At = ({
                    theme: e,
                    a11yIdentifier: t
                }) => {
                    const n = (0, we.iv)(Ft || (Ft = Ot `
    &&& .klaviyo-spinner {
      &.overlay {
        &:before {
          background-color: ${0};
        }
      }
      &:after {
        top: auto;
        bottom: 0;
        width: 30px;
        height: 30px;
        margin-top: -15px;
        margin-left: -15px;
        border-top-color: ${0};
        border-left-color: ${0};
      }
    }
  `), e[Zt].backgroundColor, e[Zt].textStyles.color, e[Zt].textStyles.color);
                    return a().createElement(l.ZC, {
                        a11yIdentifier: t,
                        className: n,
                        style: {
                            height: 32,
                            width: "100%",
                            paddingTop: "16px",
                            position: "relative"
                        }
                    }, a().createElement(l.ZC, {
                        a11yIdentifier: t,
                        className: "klaviyo-spinner"
                    }))
                },
                Mt = n(16506);
            let Dt, Bt = e => e;
            const {
                THEME_KEY: Nt
            } = ut.default, jt = () => null;
            var Rt = ({
                formVersionCId: e,
                componentId: t,
                theme: n,
                a11yIdentifierBlock: o,
                a11yIdentifierStyles: i
            }) => {
                const r = (0, w.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                    d = (0, w.Z)((e => {
                        var n;
                        return null == (n = e.formsState.components[t]) || null == (n = n.data) ? void 0 : n.couponType
                    })),
                    c = (0, w.Z)((e => {
                        var n;
                        return null == (n = e.formsState.components[t]) || null == (n = n.data) || null == (n = n.couponData) ? void 0 : n.text
                    })),
                    m = (0, w.Z)((e => {
                        var n;
                        return null == (n = e.formsState.components[t]) || null == (n = n.data) || null == (n = n.couponData) ? void 0 : n.successMessage
                    })),
                    u = (0, w.Z)((e => {
                        var n;
                        return null == (n = e.formsState.components[t]) || null == (n = n.data) || null == (n = n.couponData) ? void 0 : n.name
                    })),
                    f = (0, w.Z)((e => {
                        var n;
                        return null == (n = e.formsState.components[t]) || null == (n = n.data) || null == (n = n.couponData) ? void 0 : n.fallback
                    })),
                    p = (0, w.Z)((e => e.onsiteState.couponCodes[t])),
                    v = (0, w.Z)((e => e.onsiteState.datadomeCaptchaUrls[t])),
                    g = (0, w.Z)((e => e.onsiteState.client.showingShopLogin)),
                    [y, b] = (0, s.useState)(!1),
                    [S, C] = (0, s.useState)(!1),
                    [E, x] = (0, s.useState)(!1),
                    [V, _] = (0, s.useState)(yt),
                    T = (0, s.useMemo)((() => d === Mt.$i.STATIC ? c || Mt.I4 : d === Mt.$i.UNIQUE && r ? u ? (0, Mt.xB)(u) : void 0 : p || f), [d, p, f, u, r, c]),
                    k = v && !E;
                return (0, s.useEffect)((() => {
                    "https://static.klaviyo-dev.com/index.html" === window.location.href || "localhost" === window.location.hostname && "static_page" === new URL(window.location.href).searchParams.get("env") || r || d !== Mt.$i.UNIQUE || p || (C(!0), (0, I.zS)({
                        formVersionCId: e
                    }))
                }), [E, d, p, e, r]), (0, s.useEffect)((() => {
                    const t = () => {
                            x(!0)
                        },
                        n = () => {
                            (0, I.Cm)({
                                id: e,
                                changes: {
                                    errorViewMessage: h.w5
                                }
                            })
                        };
                    return window.addEventListener(H.H, t, !1), window.addEventListener(H.vT, n, !1), () => {
                        window.removeEventListener(H.H, t, !1), window.removeEventListener(H.vT, n, !1)
                    }
                }), []), (0, s.useEffect)((() => {
                    (k || T) && S && C(!1)
                }), [k, T, S]), (0, s.useEffect)((() => {
                    window.Shopify && !S && T && V !== It && (_(It), fetch(`/discount/${T}`))
                }), [V, T, S]), a().createElement(l.ZC, {
                    a11yIdentifier: o,
                    style: {
                        alignItems: "center",
                        justifyContent: "center",
                        width: "100%",
                        height: "auto"
                    }
                }, r && !T ? a().createElement(jt, null) : a().createElement(a().Fragment, null, !!T && !S && a().createElement(Ct, {
                    a11yIdentifier: o,
                    show: y,
                    theme: n,
                    type: V,
                    successMessage: m
                }), k ? a().createElement("iframe", {
                    title: "Recaptcha",
                    src: v,
                    frameBorder: "0",
                    width: "100%",
                    height: "600px"
                }) : a().createElement(l.zx, {
                    role: "button",
                    "aria-label": "Copy coupon code",
                    a11yIdentifier: o,
                    onClick: e => {
                        e.preventDefault(), T && mt()(T), b(!0);
                        const t = setTimeout((() => {
                            b(!1)
                        }), 2e3);
                        return () => clearTimeout(t)
                    },
                    className: (0, we.iv)(Dt || (Dt = Bt `
                &&& {
                  &:focus-visible {
                    outline-width: 2px;
                    outline-style: auto;
                    outline-color: ${0};
                    outline-offset: 0;
                  }
                }
              `), n.inputStyles.border.activeColor || n.focusColor),
                    style: {
                        position: "relative",
                        display: "flex",
                        flexDirection: "row",
                        flex: "1 1",
                        alignItems: "center",
                        justifyContent: "center",
                        background: n[Nt].backgroundColor,
                        borderRadius: n[Nt].borderRadius,
                        borderStyle: n[Nt].borderStyle,
                        borderColor: n[Nt].borderColor,
                        borderWidth: n[Nt].borderWidth,
                        color: n[Nt].textStyles.color,
                        lineHeight: 1,
                        whiteSpace: "normal",
                        paddingTop: n[Nt].paddingTop,
                        paddingBottom: n[Nt].paddingBottom,
                        paddingLeft: n[Nt].paddingLeft,
                        paddingRight: n[Nt].paddingRight,
                        textAlign: "center",
                        wordBreak: "break-word",
                        alignSelf: "flex-end",
                        cursor: S ? "auto" : "pointer",
                        boxSizing: "border-box",
                        width: "100%"
                    }
                }, S || g === ft.K.SHOWING ? a().createElement(l.ZC, {
                    a11yIdentifier: o
                }, a().createElement(l.ZC, {
                    a11yIdentifier: i,
                    style: {
                        flex: "1 1",
                        fontFamily: n.inputStyles.textStyles.fontFamily,
                        fontSize: 18,
                        fontWeight: n.inputStyles.textStyles.fontWeight,
                        letterSpacing: n.inputStyles.textStyles.letterSpacing
                    }
                }, "Loading Coupon"), a().createElement(At, {
                    a11yIdentifier: o,
                    theme: n
                })) : a().createElement(a().Fragment, null, a().createElement(l.ZC, {
                    a11yIdentifier: o,
                    style: {
                        flex: "1 1",
                        fontFamily: n[Nt].textStyles.fontFamily,
                        fontSize: n[Nt].textStyles.fontSize,
                        fontWeight: n[Nt].textStyles.fontWeight,
                        letterSpacing: n[Nt].textStyles.letterSpacing
                    }
                }, T), a().createElement($t, {
                    copied: y,
                    color: n[Nt].textStyles.color,
                    a11yIdentifier: o
                })))))
            };
            let Pt, Lt = e => e;
            const zt = ["html", "textStyles"];
            var Wt = e => {
                let {
                    html: t,
                    textStyles: n
                } = e, i = c()(e, zt);
                return n ? a().createElement("div", r()({}, t ? {
                    dangerouslySetInnerHTML: {
                        __html: t
                    }
                } : {}, {
                    style: {
                        width: "100%"
                    },
                    className: (0, we.iv)(Pt || (Pt = Lt `
        &&& {
          :not(a) {
            color: ${0};
            font-family: ${0};
            font-size: ${0}px;
          }
          a {
            color: ${0};
            font-family: ${0};
            font-size: ${0}px;
          }
        }
        ${0}
        ${0}
      `), n.text.color, n.text.fontFamily, n.text.fontSize, n.link.color, n.link.fontFamily, n.link.fontSize, o.Tc, Re)
                }, i)) : null
            };
            const {
                A11yWrapper: Ht = (() => null),
                useRecursivelySetA11yAttribute: Ut = (() => "")
            } = {};
            var qt = ({
                    componentId: e,
                    formVersionCId: t,
                    a11yIdentifierBlock: n
                }) => {
                    const o = (0, w.Z)((t => {
                            var n;
                            return null == (n = t.formsState.components[e]) || null == (n = n.data) || null == (n = n.content) ? void 0 : n.html
                        })),
                        i = (0, w.Z)((n => {
                            var o;
                            const i = null == (o = n.onsiteState.openFormVersions[t]) ? void 0 : o.currentViewId;
                            if (!i) return;
                            const {
                                formSMSDisclosure: r
                            } = (0, O.su)(n, e, i);
                            return null == r ? void 0 : r.textStyles
                        }), Ce.X),
                        r = Ut({
                            html: o,
                            a11yIdentifier: n || ""
                        });
                    return n ? a().createElement(Ht, {
                        identifier: n
                    }, a().createElement(Wt, {
                        html: r,
                        textStyles: i
                    })) : a().createElement(Wt, {
                        html: o,
                        textStyles: i
                    })
                },
                Kt = n(18735);
            n(78991), n(24570);
            const Gt = e => {
                    const t = new Intl.DateTimeFormat("en-GB", {
                            hour: "2-digit",
                            minute: "2-digit",
                            second: "2-digit",
                            hour12: !1
                        }).formatToParts(e),
                        n = `${t[0].value}:${t[2].value}:${t[4].value}`;
                    if (!(e => /[0-9]{2}:[0-9]{2}:[0-9]{2}/.test(e))(n)) throw new Error("The provided Date was not able to be converted to a valid ISO Time string.");
                    return n
                },
                Yt = e => Gt(e);
            var Xt = n(21682);
            const Jt = ["text", "theme", "a11yIdentifierBlock"],
                {
                    THEME_KEY: Qt
                } = Xt.default;
            var en = e => {
                let {
                    text: t,
                    theme: n,
                    a11yIdentifierBlock: o
                } = e, i = c()(e, Jt);
                return a().createElement(l.ZC, r()({
                    a11yIdentifier: o
                }, i), a().createElement(l.Dr, {
                    className: "klaviyo-sr-only"
                }, t.startsWith("0") ? t.substring(1) : t), a().createElement(l.Dr, {
                    "aria-hidden": "true",
                    style: {
                        color: n[Qt].textStyles.color,
                        fontFamily: n[Qt].textStyles.fontFamily,
                        fontSize: n[Qt].textStyles.fontSize,
                        fontWeight: n[Qt].textStyles.fontWeight
                    }
                }, t))
            };
            let tn, nn, on, rn, sn, an = e => e;
            const {
                THEME_KEY: ln
            } = Xt.default, dn = "0.72em", cn = "0.15em";
            var mn = ({
                text: e,
                prevText: t = "00",
                animate: n = !1,
                theme: o,
                a11yIdentifierBlock: i
            }) => {
                const r = (0, s.useMemo)((() => ({
                    card: (0, we.iv)(tn || (tn = an `
        &&& {
          & {
            text-align: center;
            display: inline-block;
            margin: 0 5px;
            display: block;
            position: relative;
            font-size: ${0};
          }

          *,
          *:before,
          *:after {
            box-sizing: border-box;
          }
        }
      `), o[ln].textStyles.fontSize),
                    card_top: (0, we.iv)(nn || (nn = an `
        &&& {
          & {
            display: block;
            height: ${0};
            border-radius: ${0} ${0} 0 0;
            backface-visibility: hidden;
            aspect-ratio: 2/1;
            overflow: hidden;

            background: ${0};
            color: ${0};
            font-family: ${0};
            font-size: ${0};
            font-weight: ${0};
          }

          &::after {
            display: block;
            content: '${0}';
            height: 100%;
            width: 100%;
            text-align: center;
            line-height: 150%;

            color: ${0};
            font-family: ${0};
            font-size: ${0};
            font-weight: ${0};
          }
        }
      `), dn, cn, cn, o[ln].cardColor, o[ln].textStyles.color, o[ln].textStyles.fontFamily, o[ln].textStyles.fontSize, o[ln].textStyles.fontWeight, e, o[ln].textStyles.color, o[ln].textStyles.fontFamily, o[ln].textStyles.fontSize, o[ln].textStyles.fontWeight),
                    card_bottom: (0, we.iv)(on || (on = an `
        &&& {
          & {
            border-top: solid 1px #fff;
            border-radius: 0 0 ${0} ${0};

            display: block;
            height: ${0};
            backface-visibility: hidden;
            aspect-ratio: 2/1;
            overflow: hidden;

            background: ${0};
            color: ${0};
            font-family: ${0};
            font-size: ${0};
            font-weight: ${0};
          }

          &::after {
            display: block;
            margin-top: -${0};
            content: '${0}';
            height: 100%;
            width: 100%;
            text-align: center;
            line-height: 150%;

            color: ${0};
            font-family: ${0};
            font-size: ${0};
            font-weight: ${0};
          }
        }
      `), cn, cn, dn, o[ln].cardColor, o[ln].textStyles.color, o[ln].textStyles.fontFamily, o[ln].textStyles.fontSize, o[ln].textStyles.fontWeight, dn, n ? t : e, o[ln].textStyles.color, o[ln].textStyles.fontFamily, o[ln].textStyles.fontSize, o[ln].textStyles.fontWeight),
                    card_animate: (0, we.iv)(rn || (rn = an `
        &&& {
          & {
            position: absolute;
            top: 0;
            height: 100%;
            left: 0%;
            pointer-events: none;

            z-index: 2;
          }

          &::before {
            content: '${0}';
            z-index: -1;
            height: 100%;
            width: 100%;
            text-align: center;
            line-height: 150%;

            animation: klaviyo-flipTop 0.3s cubic-bezier(0.37, 0.01, 0.94, 0.35)
              1;
            animation-fill-mode: both;
            transform-origin: center bottom;

            display: block;
            height: ${0};
            border-radius: ${0} ${0} 0 0;
            backface-visibility: hidden;
            aspect-ratio: 2/1;
            overflow: hidden;

            background: ${0};
            color: ${0};
            font-family: ${0};
            font-size: ${0};
            font-weight: ${0};
          }
        }
      `), t, dn, cn, cn, o[ln].cardColor, o[ln].textStyles.color, o[ln].textStyles.fontFamily, o[ln].textStyles.fontSize, o[ln].textStyles.fontWeight),
                    card_animate_bottom: (0, we.iv)(sn || (sn = an `
        &&& {
          & {
            border-top: solid 1px #fff;
            border-radius: 0 0 ${0} ${0};

            display: block;
            height: ${0};
            backface-visibility: hidden;
            aspect-ratio: 2/1;
            overflow: hidden;

            background: ${0};
            color: ${0};
            font-family: ${0};
            font-size: ${0};
            font-weight: ${0};
          }

          &::after {
            display: block;
            margin-top: -${0};
            content: '${0}';
            height: 100%;
            width: 100%;
            text-align: center;
            line-height: 150%;

            color: ${0};
            font-family: ${0};
            font-size: ${0};
            font-weight: ${0};
          }
        }
      `), cn, cn, dn, o[ln].cardColor, o[ln].textStyles.color, o[ln].textStyles.fontFamily, o[ln].textStyles.fontSize, o[ln].textStyles.fontWeight, dn, e, o[ln].textStyles.color, o[ln].textStyles.fontFamily, o[ln].textStyles.fontSize, o[ln].textStyles.fontWeight)
                })), [o, e, t, n]);
                return a().createElement(l.ZC, {
                    a11yIdentifier: i,
                    className: r.card
                }, a().createElement(l.ZC, {
                    a11yIdentifier: i,
                    className: r.card_top
                }), a().createElement(l.ZC, {
                    a11yIdentifier: i,
                    className: r.card_bottom
                }), n && a().createElement(l.ZC, {
                    a11yIdentifier: i,
                    className: r.card_animate,
                    key: e
                }, a().createElement(l.ZC, {
                    a11yIdentifier: i,
                    className: r.card_animate_bottom,
                    style: {
                        transformOrigin: "center top",
                        animationFillMode: "both",
                        animation: "klaviyo-flipBottom 0.6s cubic-bezier(.15,.45,.28,1) 1"
                    }
                })))
            };
            const {
                THEME_KEY: un
            } = Xt.default;
            var fn = ({
                text: e,
                clockFace: t = "simple",
                theme: n,
                a11yIdentifierBlock: o
            }) => {
                const i = (0, s.useMemo)((() => "flip" === t ? n[un].cardColor : n[un].textStyles.color), [t, n]);
                return a().createElement(l.ZC, {
                    a11yIdentifier: o,
                    style: {
                        color: i,
                        fontFamily: n[un].textStyles.fontFamily,
                        fontSize: n[un].textStyles.labelFontSize,
                        fontWeight: n[un].textStyles.labelFontWeight,
                        justifyContent: "center",
                        justifySelf: "center"
                    }
                }, e)
            };
            const pn = {
                    name: "none",
                    duration: 0
                },
                hn = {
                    name: "flash",
                    duration: 1
                },
                vn = {
                    name: "heartbeat",
                    duration: 1.3
                },
                gn = {
                    name: "pulse",
                    duration: 1
                },
                yn = "fixed",
                In = "variable",
                bn = "full",
                Sn = "shortened",
                wn = "single_char",
                Cn = "double_char";
            var En = ({
                componentId: e,
                formVersionCId: t,
                theme: n,
                a11yIdentifierBlock: o
            }) => {
                const i = (0, w.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                    r = (0, w.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.dateType
                    })),
                    d = (0, w.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) || null == (n = n.date) ? void 0 : n.variable
                    })),
                    c = (0, w.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) || null == (n = n.date) ? void 0 : n.fixed
                    })),
                    m = (0, w.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.clockFace
                    })),
                    u = (0, w.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.timerAnimation
                    })),
                    f = (0, w.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.labelFormat
                    })),
                    p = (0, w.Z)((e => {
                        var n;
                        return null == (n = e.onsiteState.openFormVersions[t]) ? void 0 : n.opened
                    })),
                    {
                        dateInUserTimezoneISOString: h
                    } = (0, s.useMemo)((() => function(e, t) {
                        if (!e) return {
                            dateInUserTimezoneISOString: null,
                            timeInUserTimezone: null,
                            timezone: null != t ? t : "US/Eastern"
                        };
                        const n = (0, Kt.Z)(new Date(e), null != t ? t : "US/Eastern");
                        return {
                            dateInUserTimezoneISOString: n.toISOString(),
                            timeInUserTimezone: Yt(n),
                            timezone: null != t ? t : "US/Eastern"
                        }
                    }(null == c ? void 0 : c.utcIsoString, Intl.DateTimeFormat().resolvedOptions().timeZone)), [c]),
                    v = (0, s.useMemo)((() => {
                        if (r === In) return {
                            days: d.days > 0 ? `${d.days.toString().padStart(2,"0")}` : void 0,
                            hours: d.days > 0 || d.hours > 0 ? `${d.hours.toString().padStart(2,"0")}` : void 0,
                            minutes: `${d.minutes.toString().padStart(2,"0")}`,
                            seconds: "00"
                        };
                        if (r === yn) {
                            if (!h) return {
                                minutes: "00",
                                seconds: "00"
                            };
                            const e = new Date(h),
                                t = new Date,
                                n = e.getTime() - t.getTime();
                            if (n <= 0) return {
                                minutes: "00",
                                seconds: "00"
                            };
                            const o = Math.floor(n / 864e5),
                                r = Math.floor(n % 864e5 / 36e5),
                                s = Math.floor(n % 36e5 / 6e4),
                                a = Math.floor(n % 6e4 / 1e3);
                            return i ? {
                                days: o > 0 ? "00" : void 0,
                                hours: o > 0 || r > 0 ? "00" : void 0,
                                minutes: "00",
                                seconds: "00"
                            } : {
                                days: o > 0 ? `${o.toString().padStart(2,"0")}` : void 0,
                                hours: o > 0 || r > 0 ? `${r.toString().padStart(2,"0")}` : void 0,
                                minutes: `${s.toString().padStart(2,"0")}`,
                                seconds: `${a.toString().padStart(2,"0")}`
                            }
                        }
                        return {
                            minutes: "00",
                            seconds: "00"
                        }
                    }), [r, d, h, i]),
                    [g, y] = (0, s.useState)(v),
                    [I, b] = (0, s.useState)(g),
                    [S, C] = (0, s.useState)(!1),
                    [E, x] = (0, s.useState)(0);
                (0, s.useEffect)((() => {
                    if (i) return b(g), y(v), () => {};
                    if (r === In && p && !S) {
                        const e = new Date;
                        e.setDate(e.getDate() + d.days), e.setHours(e.getHours() + d.hours), e.setMinutes(e.getMinutes() + d.minutes), x(e.getTime()), C(!0)
                    }
                    if (r === yn && !S && h) {
                        const e = new Date(h);
                        x(e.getTime()), C(!0)
                    }
                    const e = setInterval((() => {
                        if (S && (Number(g.seconds) > 0 || Number(g.minutes) > 0 || Number(g.hours) > 0 || Number(g.days) > 0)) {
                            const e = new Date,
                                t = E - e.getTime();
                            if (t < 0) return b(g), void y({
                                minutes: "00",
                                seconds: "00"
                            });
                            b(g), y((e => {
                                const t = Math.floor(e / 864e5),
                                    n = Math.floor(e % 864e5 / 36e5),
                                    o = Math.floor(e % 36e5 / 6e4),
                                    i = Math.floor(e % 6e4 / 1e3);
                                return {
                                    days: t > 0 ? `${t.toString().padStart(2,"0")}` : void 0,
                                    hours: t > 0 || n > 0 ? `${n.toString().padStart(2,"0")}` : void 0,
                                    minutes: `${o.toString().padStart(2,"0")}`,
                                    seconds: `${i.toString().padStart(2,"0")}`
                                }
                            })(t))
                        }
                    }), 1e3);
                    return () => {
                        clearInterval(e)
                    }
                }), [i, r, p, S, v, d, h, E, g]);
                const V = (0, s.useRef)(u),
                    [_, T] = (0, s.useState)(!1);
                (0, s.useEffect)((() => {
                    T(V.current !== u), V.current = u
                }), [u]);
                const k = (0, s.useMemo)((() => {
                        if (i && !_) return "";
                        if (!i && (Number(g.seconds) > 0 || Number(g.minutes) > 0 || Number(g.hours) > 0 || Number(g.days) > 0) || u === pn.name) return "";
                        let e = "";
                        return u === hn.name ? e = `klaviyo-${hn.name} ${hn.duration}s` : u === vn.name ? e = `klaviyo-${vn.name} ${vn.duration}s` : u === gn.name && (e = `klaviyo-${gn.name} ${gn.duration}s`), i ? `${e} 1` : `${e} 1s infinite`
                    }), [u, i, g, _]),
                    $ = (0, s.useMemo)((() => {
                        switch (f) {
                            case bn:
                                return {
                                    days: "days",
                                    hours: "hours",
                                    minutes: "minutes",
                                    seconds: "seconds"
                                };
                            case Sn:
                                return {
                                    days: "days",
                                    hours: "hrs",
                                    minutes: "mins",
                                    seconds: "secs"
                                };
                            case Cn:
                                return {
                                    days: "DD",
                                    hours: "HH",
                                    minutes: "MM",
                                    seconds: "SS"
                                };
                            case wn:
                                return {
                                    days: "D",
                                    hours: "H",
                                    minutes: "M",
                                    seconds: "S"
                                };
                            default:
                                return {
                                    days: "days",
                                    hours: "hours",
                                    minutes: "minutes",
                                    seconds: "seconds"
                                }
                        }
                    }), [f]);
                return "simple" === m ? a().createElement(l.ZC, {
                    className: "klaviyo-countdown",
                    a11yIdentifier: o,
                    "data-testid": "klaviyo-countdown",
                    role: "timer",
                    "aria-live": "polite",
                    "aria-atomic": "true",
                    style: {
                        width: "100%",
                        justifyContent: "center",
                        justifySelf: "center",
                        display: "flex",
                        animation: `${k}`,
                        fontVariantNumeric: "tabular-nums"
                    }
                }, a().createElement(l.Dr, {
                    className: "klaviyo-sr-only"
                }, "Countdown ends in:"), (null == g ? void 0 : g.days) && a().createElement(a().Fragment, null, a().createElement(l.ZC, {
                    a11yIdentifier: o,
                    style: {
                        justifyContent: "center",
                        justifySelf: "center",
                        display: "grid"
                    }
                }, a().createElement(en, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: null == g ? void 0 : g.days
                }), a().createElement(fn, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    clockFace: m,
                    text: $.days
                })), a().createElement(en, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: " "
                })), (null == g ? void 0 : g.hours) && a().createElement(a().Fragment, null, a().createElement(l.ZC, {
                    a11yIdentifier: o,
                    style: {
                        justifyContent: "center",
                        justifySelf: "center",
                        display: "grid"
                    }
                }, a().createElement(en, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: null == g ? void 0 : g.hours
                }), a().createElement(fn, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    clockFace: m,
                    text: $.hours
                })), a().createElement(en, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: ":"
                })), a().createElement(l.ZC, {
                    a11yIdentifier: o,
                    style: {
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center"
                    }
                }, a().createElement(en, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: null == g ? void 0 : g.minutes
                }), a().createElement(fn, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    clockFace: m,
                    text: $.minutes
                })), a().createElement(en, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: ":"
                }), a().createElement(l.ZC, {
                    a11yIdentifier: o,
                    style: {
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center"
                    },
                    "aria-hidden": "true"
                }, a().createElement(en, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: null == g ? void 0 : g.seconds
                }), a().createElement(fn, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    clockFace: m,
                    text: $.seconds
                }))) : "flip" === m ? a().createElement(l.ZC, {
                    className: "klaviyo-countdown",
                    a11yIdentifier: o,
                    "data-testid": "klaviyo-countdown",
                    role: "timer",
                    "aria-live": "polite",
                    "aria-atomic": "true",
                    style: {
                        width: "100%",
                        justifyContent: "center",
                        justifySelf: "center",
                        display: "flex",
                        animation: `${k}`,
                        fontVariantNumeric: "tabular-nums"
                    }
                }, a().createElement(l.Dr, {
                    className: "klaviyo-sr-only"
                }, "Countdown ends in:"), (null == g ? void 0 : g.days) && a().createElement(l.ZC, {
                    a11yIdentifier: o,
                    style: {
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center"
                    }
                }, a().createElement(mn, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: null == g ? void 0 : g.days,
                    prevText: null == I ? void 0 : I.days,
                    animate: !i
                }), a().createElement(fn, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    clockFace: m,
                    text: $.days
                })), (null == g ? void 0 : g.hours) && a().createElement(l.ZC, {
                    a11yIdentifier: o,
                    style: {
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center"
                    }
                }, a().createElement(mn, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: null == g ? void 0 : g.hours,
                    prevText: null == I ? void 0 : I.hours,
                    animate: !i
                }), a().createElement(fn, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    clockFace: m,
                    text: $.hours
                })), a().createElement(l.ZC, {
                    a11yIdentifier: o,
                    style: {
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center"
                    }
                }, a().createElement(mn, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: null == g ? void 0 : g.minutes,
                    prevText: null == I ? void 0 : I.minutes,
                    animate: !i
                }), a().createElement(fn, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    clockFace: m,
                    text: $.minutes
                })), a().createElement(l.ZC, {
                    a11yIdentifier: o,
                    style: {
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center"
                    },
                    "aria-hidden": "true"
                }, a().createElement(mn, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    text: null == g ? void 0 : g.seconds,
                    prevText: null == I ? void 0 : I.seconds,
                    animate: !i
                }), a().createElement(fn, {
                    theme: n,
                    a11yIdentifierBlock: o,
                    clockFace: m,
                    text: $.seconds
                }))) : a().createElement(l.ZC, null)
            };
            var xn = ({
                itemId: e,
                a11yIdentifierBlock: t
            }) => {
                const n = (0, w.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                    o = (0, w.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) || null == (n = n.content) ? void 0 : n.html
                    })),
                    i = (0, s.useMemo)((() => `engagement-counter-${e}`), [e]),
                    r = /{{ *(&nbsp; *)*form_submit_count *(&nbsp; *)*}}/,
                    l = (0, w.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.dynamicInfoState) || null == (n = n.results) ? void 0 : n[e].submits
                    }));
                let d = null;
                const c = (0, w.Z)((t => {
                    var n;
                    return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.minThreshold
                }));
                return n ? d = a().createElement(He, {
                    a11yIdentifierBlock: t,
                    id: i,
                    html: o
                }) : "number" == typeof l && l >= c && (d = a().createElement(He, {
                    a11yIdentifierBlock: t,
                    id: i,
                    html: o.replace(r, null == l ? void 0 : l.toString())
                })), d
            };
            let Vn, _n = e => e;
            const Tn = {
                right: "flex-end",
                left: "flex-start",
                center: "center"
            };
            var kn = ({
                    componentId: e,
                    a11yIdentifierBlock: t,
                    formVersionCId: n,
                    theme: i,
                    a11yIdentifierStyles: r
                }) => {
                    const d = (0, w.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                        c = (0, w.Z)((t => {
                            var n;
                            return (null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.fieldId) || ""
                        })),
                        m = (0, w.Z)((t => {
                            var n;
                            return (null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.label) || ""
                        })),
                        u = (0, w.Z)((t => {
                            var n;
                            return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.showLabel
                        })),
                        f = (0, w.Z)((t => {
                            var n;
                            return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.checkboxLabel
                        })),
                        p = (0, w.Z)((t => {
                            var n;
                            const o = null == (n = t.formsState.components[e]) || null == (n = n.data) || null == (n = n.styling) ? void 0 : n.innerAlignment;
                            return o ? Tn[o] : "flex-start"
                        })),
                        {
                            inputName: h,
                            labelId: v
                        } = (0, s.useMemo)((() => {
                            const e = (0, Se.Z)(`${encodeURIComponent(c)}__`);
                            return {
                                inputName: e,
                                labelId: `kl_${e}_label`
                            }
                        }), [c]);
                    (0, s.useEffect)((() => {
                        (0, I.hX)({
                            formVersionCId: n,
                            componentId: e,
                            value: "false"
                        })
                    }), [e, n]);
                    return a().createElement(l.ZC, {
                        a11yIdentifier: t,
                        style: {
                            width: "100%",
                            justifyContent: p,
                            display: "flex"
                        }
                    }, a().createElement(l.C3, {
                        className: (0, we.iv)(Vn || (Vn = _n `
          &&& {
            input:focus-visible + label > svg {
              outline: 2px solid;
              outline-color: ${0};
              outline-offset: 0;
              box-shadow: 0 0 0 4px #ffffff;
            }
          }
        `), i.inputStyles.border.activeColor || i.focusColor),
                        style: {
                            alignSelf: "flex-end",
                            display: "block"
                        },
                        a11yIdentifier: r
                    }, a().createElement(Ve.Z, {
                        a11yIdentifier: r,
                        id: v,
                        theme: i,
                        style: {
                            marginRight: 8,
                            marginBottom: 8
                        },
                        showLabel: !(void 0 !== u || !m) || u,
                        asLegend: !0
                    }, m), a().createElement(ot, {
                        formVersionCId: n,
                        theme: i,
                        name: h,
                        label: f,
                        alignCheckbox: "flex-start",
                        isValid: !0,
                        componentType: o.OV,
                        componentAriaID: v,
                        onChange: t => {
                            (0, Te.l)(), (0, I.hX)({
                                formVersionCId: n,
                                componentId: e,
                                value: t.target.checked.toString()
                            })
                        },
                        tabIndex: d ? -1 : 0,
                        a11yIdentifierStyles: r
                    })))
                },
                $n = n(13062),
                Fn = n(64214),
                On = n(4396);
            const Zn = () => null,
                {
                    THEME_KEY: An
                } = Fn.default,
                Mn = {
                    blue: "https://d3k81ch9hvuctc.cloudfront.net/assets/email/review-block/verified.png",
                    dark: "https://d3k81ch9hvuctc.cloudfront.net/assets/email/review-block/verified-dark.png",
                    light: "https://d3k81ch9hvuctc.cloudfront.net/assets/email/review-block/verified-light.png"
                },
                Dn = e => "center" === e ? "center" : "right" === e ? "flex-end" : "flex-start";
            var Bn = ({
                componentId: e,
                theme: t,
                a11yIdentifierBlock: n
            }) => {
                var o, i, r, s, d, c, m, u, f, p, h, v, g, y, I, b, S, C, E;
                const x = (0, w.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                    V = (0, w.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.reviewData
                    })),
                    _ = (0, w.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.reviewDisplayOptions
                    })),
                    T = !!V,
                    k = null != (o = null == V ? void 0 : V.rating) ? o : 5,
                    $ = null != (i = null == V ? void 0 : V.content) ? i : "",
                    F = (null == V ? void 0 : V.author) || "",
                    O = "stacked" === (null == (r = t[An].reviewerNameStyle) ? void 0 : r.layout),
                    Z = !O && F ? `- ${F}` : F,
                    A = null != (s = null == V ? void 0 : V.verified) && s,
                    M = null == (d = null == _ ? void 0 : _.showRating) || d,
                    D = null == (c = null == _ ? void 0 : _.showAuthor) || c,
                    B = null == (m = null == _ ? void 0 : _.showVerified) || m,
                    N = {
                        color: t[An].ratingStyle.color,
                        fontSize: t[An].ratingStyle.fontSize
                    },
                    j = {
                        color: t[An].ratingStyle.emptyColor,
                        fontSize: t[An].ratingStyle.fontSize
                    },
                    R = (e => {
                        switch (e) {
                            case On.B.STAR:
                                return "★";
                            case On.B.HEART:
                                return "♥";
                            case On.B.CIRCLE:
                                return "●";
                            default:
                                return "★"
                        }
                    })(t[An].ratingStyle.shape),
                    P = () => {
                        var e;
                        return a().createElement("span", {
                            "data-a11y-identifier": n,
                            style: {
                                color: null == (e = t[An].reviewerNameStyle) ? void 0 : e.textColor,
                                display: "inline-flex",
                                alignItems: "center",
                                gap: "4px"
                            }
                        }, a().createElement("span", {
                            "data-a11y-identifier": n
                        }, Z), A && B && a().createElement("img", {
                            "data-a11y-identifier": n,
                            src: Mn[t[An].verifiedBadgeStyle.colorAsset],
                            alt: "Verified",
                            style: {
                                width: t[An].verifiedBadgeStyle.size,
                                height: t[An].verifiedBadgeStyle.size
                            }
                        }))
                    };
                return x && !T ? a().createElement(Zn, null) : a().createElement(l.ZC, {
                    a11yIdentifier: n,
                    "data-testid": "reviews-component",
                    style: {
                        alignItems: "center",
                        justifyContent: "center",
                        width: "100%",
                        height: "auto"
                    }
                }, M && a().createElement("div", {
                    "data-a11y-identifier": n,
                    style: {
                        display: "flex",
                        justifyContent: Dn(t[An].ratingStyle.alignment),
                        gap: `${t[An].ratingStyle.characterSpacing}px`,
                        marginBottom: "12px"
                    }
                }, a().createElement("span", {
                    "data-a11y-identifier": n,
                    style: k >= 1 ? N : j
                }, R), a().createElement("span", {
                    style: k >= 2 ? N : j
                }, R), a().createElement("span", {
                    style: k >= 3 ? N : j
                }, R), a().createElement("span", {
                    style: k >= 4 ? N : j
                }, R), a().createElement("span", {
                    "data-a11y-identifier": n,
                    style: k >= 5 ? N : j
                }, R)), a().createElement("div", {
                    style: {
                        marginBottom: "8px",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: Dn(O ? t[An].quoteStyle.alignment : null == (u = t[An].reviewerNameStyle) ? void 0 : u.alignment),
                        gap: "8px",
                        flexDirection: O ? "column" : "row",
                        width: "100%"
                    }
                }, O ? a().createElement(a().Fragment, null, a().createElement("span", {
                    style: {
                        fontFamily: t[An].quoteStyle.fontFamily,
                        fontSize: t[An].quoteStyle.fontSize,
                        color: t[An].quoteStyle.textColor,
                        letterSpacing: `${t[An].quoteStyle.characterSpacing}px`,
                        fontWeight: t[An].quoteStyle.fontWeight,
                        lineHeight: t[An].quoteStyle.lineHeight,
                        display: "block",
                        width: "100%",
                        textAlign: t[An].quoteStyle.alignment
                    }
                }, a().createElement("span", {
                    "data-a11y-identifier": n
                }, "“", $, "”")), D && F && a().createElement("div", {
                    style: {
                        display: "flex",
                        alignItems: "center",
                        justifyContent: Dn(null == (f = t[An].reviewerNameStyle) ? void 0 : f.alignment),
                        gap: "4px",
                        width: "100%",
                        lineHeight: null == (p = t[An].reviewerNameStyle) ? void 0 : p.lineHeight,
                        fontFamily: null == (h = t[An].reviewerNameStyle) ? void 0 : h.fontFamily,
                        fontSize: null == (v = t[An].reviewerNameStyle) ? void 0 : v.fontSize,
                        fontWeight: null == (g = t[An].reviewerNameStyle) ? void 0 : g.fontWeight,
                        letterSpacing: `${null==(y=t[An].reviewerNameStyle)?void 0:y.characterSpacing}px`
                    }
                }, P())) : a().createElement("span", {
                    style: {
                        fontFamily: t[An].quoteStyle.fontFamily,
                        fontSize: t[An].quoteStyle.fontSize,
                        color: t[An].quoteStyle.textColor,
                        letterSpacing: `${t[An].quoteStyle.characterSpacing}px`,
                        fontWeight: t[An].quoteStyle.fontWeight,
                        lineHeight: t[An].quoteStyle.lineHeight,
                        display: "block",
                        width: "100%",
                        textAlign: t[An].quoteStyle.alignment
                    }
                }, a().createElement("span", {
                    "data-a11y-identifier": n
                }, "“", $, "”"), D && F && a().createElement("span", {
                    style: {
                        display: "inline",
                        lineHeight: null == (I = t[An].reviewerNameStyle) ? void 0 : I.lineHeight,
                        fontFamily: null == (b = t[An].reviewerNameStyle) ? void 0 : b.fontFamily,
                        fontSize: null == (S = t[An].reviewerNameStyle) ? void 0 : S.fontSize,
                        fontWeight: null == (C = t[An].reviewerNameStyle) ? void 0 : C.fontWeight,
                        letterSpacing: `${null==(E=t[An].reviewerNameStyle)?void 0:E.characterSpacing}px`
                    }
                }, " ", P()))))
            };
            var Nn = (e, t = (() => a().createElement(a().Fragment, null))) => {
                function n(n) {
                    const [o, i] = a().useState(0), r = a().useCallback((() => i((e => e < 5 ? e + 1 : e))), []), s = a().useMemo((() => a().lazy((() => e().catch((() => ({
                        default: () => (r(), a().createElement(a().Fragment, null))
                    })))))), [e, o]);
                    return a().createElement(a().Suspense, {
                        fallback: a().createElement(t, null)
                    }, a().createElement(s, n))
                }
                return n.displayName = "LazyLoader", n
            };
            const jn = {
                [o.Ct]: be,
                [o.jR]: Ue,
                [o.qn]: Oe,
                [o.xC]: Oe,
                [o.J8]: Nn((() => Promise.all([n.e(2462), n.e(9734), n.e(4371), n.e(6908)]).then(n.bind(n, 23705)))),
                [o.YQ]: Be,
                [o.zV]: dt,
                [o.hD]: dt,
                [o.ZW]: Oe,
                [o.UO]: Nn((() => Promise.all([n.e(2462), n.e(9734), n.e(4983)]).then(n.bind(n, 44867)))),
                [o.B1]: Rt,
                [o.Xe]: qt,
                [o.Ys]: Oe,
                [o._2]: En,
                [o.eC]: Oe,
                [o.rY]: xn,
                [o.OV]: kn,
                [o.sZ]: kn,
                [o.K0]: $n.ZP,
                [o.SO]: Be,
                [o.ye]: Bn
            }
        },
        99877: function(e, t, n) {
            var o = n(67895),
                i = n.n(o),
                r = n(5645),
                s = n.n(r),
                a = n(18359),
                l = n.n(a),
                d = n(38612);
            const c = ["children", "theme", "showLabel", "style", "asLegend"];
            t.Z = e => {
                let {
                    children: t,
                    theme: n,
                    showLabel: o,
                    style: r,
                    asLegend: a
                } = e, m = s()(e, c);
                if (!t) return null;
                const u = a ? d.De : d.__;
                return l().createElement(u, i()({
                    className: o ? "" : "klaviyo-sr-only",
                    style: Object.assign({
                        color: n.inputStyles.textStyles.color,
                        fontFamily: n.inputStyles.textStyles.fontFamily,
                        fontSize: n.inputStyles.textStyles.fontSize,
                        fontWeight: n.inputStyles.textStyles.labelFontWeight,
                        letterSpacing: n.inputStyles.textStyles.letterSpacing,
                        paddingBottom: 6
                    }, r)
                }, m), t)
            }
        },
        13062: function(e, t, n) {
            n.d(t, {
                Rd: function() {
                    return V
                }
            });
            n(92461), n(39265), n(60873), n(83362);
            var o = n(18359),
                i = n.n(o),
                r = n(23409),
                s = n(71429),
                a = n(38612),
                l = n(68502),
                d = n(10386),
                c = n(89331),
                m = n(57511);
            let u, f, p, h, v, g, y, I, b, S, w, C, E = e => e;
            const x = 1e3,
                V = 8e3,
                _ = e => {
                    let t = 0;
                    e > 75 ? t = 270 : e > 50 ? t = 180 : e > 25 && (t = 90);
                    const n = 3.6 * e - t,
                        o = (90 - n) * (Math.PI / 180),
                        i = 50 * Math.sin(o),
                        r = n * (Math.PI / 180),
                        s = 50 * Math.sin(r);
                    let a = `\n    50% 50%,\n    50% 0%,\n    100% 0%,\n    ${e<=25?`${50+s}% ${50-i}%`:"100% 50%"}\n  `;
                    return e > 25 && (a = `${a},\n      100% 100%,\n      ${e<=50?`${50+i}% ${50+s}%`:"50% 100%"}\n    `), e > 50 && (a = `${a},\n      0% 100%,\n      ${e<=75?`${50-s}% ${50+i}%`:"0% 100%"}\n    `), e > 75 && (a = `${a},\n      0% 0%,\n      ${e<=100?`${50-i}% ${50-s}%`:"50% 0%"}\n    `), `polygon(${a})`
                };
            t.ZP = ({
                componentId: e,
                a11yIdentifierBlock: t
            }) => {
                const n = (0, l.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.wheelLogic
                    })),
                    V = (0, l.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.wheelStyle
                    })),
                    T = (0, l.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.sliceStyles
                    })) || [],
                    k = (0, l.Z)((t => {
                        var n;
                        return null == (n = t.formsState.components[e]) || null == (n = n.data) ? void 0 : n.textStyle
                    })),
                    $ = (0, o.useMemo)((() => {
                        let e = [];
                        return e = null != n && n.duplicate ? null != n && n.slices ? [...null == n ? void 0 : n.slices, ...null == n ? void 0 : n.slices] : [] : null != n && n.slices ? [...n.slices] : [], e.map(((e, t) => Object.assign({}, e, {
                            key: `slice_${t}`
                        })))
                    }), [n]),
                    F = (0, l.Z)((t => {
                        var n;
                        const o = (0, c.Hp)(t, e);
                        if (!o) return null;
                        const i = null == (n = t.formsState.views[o]) ? void 0 : n.formVersionId;
                        return i ? (0, m.Tf)(t, i) : null
                    })),
                    O = (0, l.Z)((e => F ? (0, d.L)(e, F) : "")),
                    Z = (0, o.useMemo)((() => null != n && n.slices && O ? n.slices.find((e => e.childViewId === O)) : null), [n, O]),
                    A = (0, o.useMemo)((() => {
                        if (!Z) return null;
                        const e = ((e, t) => {
                            const n = ((e, t) => e.reduce(((e, n, o) => (n.childViewId === t && e.push(o), e)), []))(e, t);
                            return n.length ? n[Math.floor(Math.random() * n.length)] : null
                        })($, Z.childViewId);
                        if ((0, s.x)(e)) return null;
                        const {
                            anticipation: t,
                            acceleration: n,
                            deceleration: o,
                            overshoot: i
                        } = ((e, t) => {
                            const n = 360 / t,
                                o = e * n,
                                i = (e => 90 - 360 / e / 2)(t),
                                s = i - o + 3240,
                                a = s - (Math.floor(Math.random() * n / 2) - n / 2) + 720;
                            return {
                                anticipation: (0, r.F4)(u || (u = E `
      0% {
        transform: rotate(0deg);
      }
      100% {
        transform: rotate(-8deg);
      }
    `)),
                                acceleration: (0, r.F4)(f || (f = E `
      0% {
        transform: rotate(-8deg);
      }
      100% {
        transform: rotate(${0}deg);
      }
    `), s),
                                deceleration: (0, r.F4)(p || (p = E `
      0% {
        transform: rotate(${0}deg);
      }
      100% {
        transform: rotate(${0}deg);
      }
    `), s, a),
                                overshoot: (0, r.F4)(h || (h = E `
      0% {
        transform: rotate(${0}deg);
      }
      100% {
        transform: rotate(${0}deg);
      }
    `), a, a - 4)
                            }
                        })(e, $.length);
                        return `${t} 500ms cubic-bezier(0.35, 0, 0.50, 1) forwards,\n            ${n} 2750ms cubic-bezier(0.36, 0, 0.52, 0.70) 500ms forwards,\n            ${o} 3000ms cubic-bezier(0.3, 0.8, 0.5, 0.99) 3250ms forwards,\n            ${i} 1000ms cubic-bezier(0.75, 0.2, 0.67, 1) 6250ms forwards`
                    }), [Z, $]),
                    M = (0, o.useMemo)((() => {
                        var e, t;
                        let n = null != (e = null == V ? void 0 : V.wheelSize) ? e : 400,
                            o = n / 2,
                            i = n / 5,
                            s = n / 5;
                        n > x && (n = x, o = 500, i = 200, s = 200);
                        const a = .23 * n,
                            l = .08 * n;
                        let d = null != (t = null == V ? void 0 : V.outlineThickness) ? t : 0;
                        return d > 100 && (d = 100), {
                            container: (0, r.iv)(v || (v = E `
        &&& {
          & {
            position: relative;
            width: ${0}px;
            height: ${0}px;
            display: flex;
            justify-content: center;
            align-items: center;
          }
        }
      `), n, n + d),
                            innerContainer: (0, r.iv)(g || (g = E `
        &&& {
          & {
            width: ${0}px;
            height: ${0}px;
            display: flex;
            justify-content: center;
            align-items: center;
            ${0};
          }
        }
      `), n, n, A ? `@media (prefers-reduced-motion: no-preference) {\n                  animation: ${A};\n                }` : ""),
                            slice: (0, r.iv)(y || (y = E `
        &&& {
          & {
            position: absolute;
            width: ${0}px;
            height: ${0}px;
            transform-origin: center;
            border-radius: 50%;
            border: ${0}px solid ${0};
          }
        }
      `), n, n, d, null == V ? void 0 : V.outlineColor),
                            sliceLabelContainer: (0, r.iv)(I || (I = E `
        &&& {
          & {
            width: ${0}px;
            margin: 0 auto;
            transform: rotate(-90deg) translate(-${0}px);
            transform-origin: center;
          }
        }
      `), o, a),
                            sliceLabel: (0, r.iv)(b || (b = E `
        &&& {
          & {
            text-align: center;
            font-family: ${0};
            font-size: ${0};
            font-weight: ${0};
            transform: rotate(${0}deg);
            transform-origin: left;
            padding-left: ${0}px;
            text-overflow: ellipsis;
            overflow: hidden;
          }
        }
      `), null == k ? void 0 : k.fontFamily, null == k ? void 0 : k.fontSize, null == k ? void 0 : k.fontWeight, 180 / $.length, l),
                            center: (0, r.iv)(S || (S = E `
        &&& {
          & {
            position: absolute;
            width: ${0}px;
            height: ${0}px;
            background-color: ${0};
            border-radius: 50%;
            display: flex;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2),
              0 6px 20px 0 rgba(0, 0, 0, 0.2);
          }
        }
      `), i, i, null == V ? void 0 : V.centerColor),
                            pin: (0, r.iv)(w || (w = E `
        &&& {
          & {
            position: absolute;
            right: 1px;
            width: ${0}px;
            height: ${0}px;
            background-color: ${0};
            clip-path: polygon(100% 0%, 50% 50%, 100% 100%);
            border-radius: 20%;
            display: flex;
          }
        }
      `), s, s, null == V ? void 0 : V.pinColor),
                            pinOutline: (0, r.iv)(C || (C = E `
        &&& {
          & {
            position: absolute;
            width: ${0}px;
            height: ${0}px;
            border-radius: 49%;
            display: flex;
            background: radial-gradient(
              circle at center,
              transparent 69%,
              ${0} 25%
            );
          }
        }
      `), n, n, null == V ? void 0 : V.pinColor)
                        }
                    }), [V, k, $, A]);
                return i().createElement(a.ZC, {
                    className: "klaviyo-spintowin",
                    a11yIdentifier: t,
                    "data-testid": "klaviyo-spintowin",
                    style: {
                        width: "100%",
                        justifyContent: "center",
                        justifySelf: "center",
                        display: "flex"
                    }
                }, i().createElement(a.ZC, {
                    className: M.container,
                    a11yIdentifier: t
                }, i().createElement(a.ZC, {
                    className: M.innerContainer,
                    a11yIdentifier: t
                }, $.map(((e, n) => {
                    var o, r;
                    return i().createElement(a.ZC, {
                        key: e.key,
                        className: M.slice,
                        a11yIdentifier: t,
                        style: {
                            clipPath: _(100 / $.length),
                            transform: `rotate(${n*(360/$.length)}deg)`,
                            backgroundColor: null == (o = T[n % T.length]) ? void 0 : o.backgroundColor
                        }
                    }, i().createElement(a.ZC, {
                        className: M.sliceLabelContainer,
                        a11yIdentifier: t
                    }, i().createElement(a.ZC, {
                        className: M.sliceLabel,
                        a11yIdentifier: t,
                        style: {
                            color: null == (r = T[n % T.length]) ? void 0 : r.textColor
                        }
                    }, e.label)))
                }))), i().createElement(a.ZC, {
                    className: M.center,
                    a11yIdentifier: t
                }), i().createElement(a.ZC, {
                    className: M.pin,
                    a11yIdentifier: t
                }), i().createElement(a.ZC, {
                    className: M.pinOutline,
                    a11yIdentifier: t
                })))
            }
        },
        95255: function(e, t, n) {
            var o = n(18359),
                i = n.n(o),
                r = n(23409),
                s = n(38612),
                a = n(9289),
                l = n(46780),
                d = n(25006),
                c = n(34069),
                m = n(36506),
                u = n(32962),
                f = n(68502);
            let p, h = e => e;
            t.Z = ({
                formVersionCId: e,
                validationErrorType: t,
                validationErrorMessage: n,
                metadata: o,
                componentAriaID: v,
                theme: g,
                a11yIdentifier: y
            }) => {
                const I = (0, f.Z)((t => {
                        var n;
                        const o = t.onsiteState.openFormVersions[e];
                        return o ? null == (n = t.formsState.formVersions[o.formVersionId]) ? void 0 : n.formTypeDirection : void 0
                    })),
                    b = !(null == I || !I.startsWith("BOTTOM")),
                    S = g.inputStyles.textStyles.errorColor;
                return i().createElement(s.ZC, {
                    style: {
                        width: "100%",
                        position: "relative"
                    },
                    a11yIdentifier: y
                }, t && i().createElement(s.ZC, {
                    a11yIdentifier: y,
                    style: Object.assign({
                        backgroundColor: "white",
                        position: "absolute",
                        zIndex: 1,
                        right: 0,
                        borderRadius: 4,
                        animation: "klaviyo-fadein 0.4s",
                        pointerEvents: "none"
                    }, b ? {
                        bottom: 47
                    } : {
                        top: 9
                    })
                }, i().createElement(s.ZC, {
                    a11yIdentifier: y,
                    className: (0, r.iv)(p || (p = h `
              &&& {
                &::after {
                  content: '';
                  display: block;
                  position: absolute;
                  width: 0;
                  height: 0;
                  border-style: solid;
                  left: 8px;
                  border-width: 8px;
                  ${0}
                }
                &::before {
                  content: '';
                  display: block;
                  position: absolute;
                  width: 0;
                  height: 0;
                  border-style: solid;
                  border-width: 9px;
                  left: 7px;
                  ${0};
                }
              }
            `), b ? "bottom: -15px;\n                  border-color: rgb(255, 244, 240) transparent transparent transparent;" : "top: -15px;\n                  border-color: transparent transparent rgb(255, 244, 240) transparent;", b ? `bottom: -17px;\n                    border-color: ${S} transparent transparent transparent;` : `top: -17px;\n                    border-color: transparent transparent ${S} transparent;`),
                    style: {
                        borderRadius: 4,
                        boxShadow: "1px 1px 4px 0 rgba(0, 0, 0, 0.26)",
                        border: `1px solid ${g.inputStyles.textStyles.errorColor}`,
                        backgroundColor: "rgb(255, 244, 240)",
                        pointerEvents: "none"
                    }
                }, i().createElement(s.Dr, {
                    style: {
                        fontSize: 14,
                        padding: 8,
                        fontFamily: g.inputStyles.textStyles.fontFamily,
                        color: g.inputStyles.textStyles.errorColor,
                        pointerEvents: "none"
                    },
                    role: "alert",
                    id: v,
                    a11yIdentifier: y
                }, (({
                    validationErrorType: e,
                    validationErrorMessage: t,
                    metadata: n
                }) => {
                    if (t) return t;
                    switch (e) {
                        case a.d:
                            return "This field is required";
                        case l.d:
                            return "This email is invalid";
                        case d.d:
                            return "The date format is invalid";
                        case c.d:
                            return n ? `Must be ${n.smsMinimumAge||21} or older.` : "";
                        case m.d:
                            return "This number is invalid";
                        case u.pv:
                            return "This code is invalid";
                        default:
                            return ""
                    }
                })({
                    validationErrorType: t,
                    validationErrorMessage: n,
                    metadata: o
                })))))
            }
        },
        54228: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return E
                }
            });
            var o = n(67895),
                i = n.n(o),
                r = n(18359),
                s = n.n(r),
                a = n(62945),
                l = n(23409),
                d = n(23034),
                c = n(68502),
                m = n(38612),
                u = n(83657),
                f = n(86434),
                p = n(85301),
                h = n(85413),
                v = n(57511),
                g = n(85747);

            function y() {
                const [e, t] = (0, r.useState)({
                    top: 0,
                    right: 0,
                    left: 0
                });
                return (0, r.useEffect)((() => {
                    const e = () => {
                        window.innerWidth > window.innerHeight ? t(function() {
                            const e = getComputedStyle(document.documentElement);
                            return {
                                top: parseFloat(e.getPropertyValue("--safe-area-inset-top")) || 0,
                                right: parseFloat(e.getPropertyValue("--safe-area-inset-right")) || 0,
                                left: parseFloat(e.getPropertyValue("--safe-area-inset-left")) || 0
                            }
                        }()) : t({
                            top: 0,
                            right: 0,
                            left: 0
                        })
                    };
                    return e(), window.addEventListener("resize", e), () => window.removeEventListener("resize", e)
                }), []), e
            }
            let I, b = e => e;
            const S = () => null,
                w = {
                    right: 0,
                    top: 0
                },
                C = g.Z;
            var E = ({
                title: e,
                onClick: t,
                viewId: n,
                buttonStyling: o,
                positionalStyles: g = w,
                isTeaser: E = !1,
                designerFunctions: x,
                designerInfo: V
            }) => {
                const _ = (0, c.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                    T = (0, c.Z)((e => {
                        if (n) return (0, v.l)(e, n)
                    }), d.X),
                    k = null == V ? void 0 : V.activeSidebar,
                    $ = (0, r.useMemo)((() => (null == k ? void 0 : k.type) === p.cn), [k]),
                    F = () => {
                        x && !E && x.setActiveSidebar({
                            type: p.cn
                        })
                    },
                    O = E ? h.Z.dismissButtonStyles : u.Z.dismissButtonStyles,
                    Z = (0, a.Z)({}, O, o),
                    A = Z.size,
                    M = $,
                    D = (0, r.useMemo)((() => _ ? "dismiss:dismiss:form" : void 0), [_]),
                    B = (0, c.Z)(v.ek),
                    N = y(),
                    [j, R] = (0, r.useState)(!1),
                    [P, L] = (0, r.useState)(!1);
                (0, r.useEffect)((() => {
                    var e;
                    R("in-app" === (null == (e = window) || null == (e = e.klaviyoModulesObject) ? void 0 : e.env));
                    const t = () => {
                        L(window.innerWidth > window.innerHeight)
                    };
                    return t(), window.addEventListener("resize", t), () => window.removeEventListener("resize", t)
                }), []);
                const z = (0, r.useMemo)((() => function(e, t, n, o) {
                        return {
                            top: (() => {
                                if (void 0 !== e.top) return o && n && 0 === t.top && 0 === t.left && 0 === t.right ? "max(16px, env(safe-area-inset-top))" : `${e.top}px`
                            })(),
                            right: (() => {
                                if (void 0 !== e.right) return t.right > 0 ? `${Math.max(e.right,t.right)}px` : t.left > 0 ? `${e.right+t.left}px` : o && n ? "max(16px, env(safe-area-inset-right))" : `${e.right}px`
                            })(),
                            bottom: "bottom" in e && void 0 !== e.bottom ? `${e.bottom}px` : void 0,
                            left: "left" in e && void 0 !== e.left ? `${e.left}px` : void 0
                        }
                    }(g, N, j, P)), [g, N, j, P]),
                    W = g === w,
                    H = (0, r.useMemo)((() => function(e, t, n, o, i, r) {
                        if (!r) return {
                            marginTop: e,
                            marginRight: t
                        };
                        const s = n.top > 0 || n.left > 0;
                        let a = e;
                        return o && i && (a = s ? 0 : e + 16), {
                            marginTop: a,
                            marginRight: t
                        }
                    }(Z.margin.top, Z.margin.right, N, j, P, W)), [Z.margin.top, Z.margin.right, N, j, P, W]);
                return s().createElement(s().Fragment, null, M && s().createElement(S, {
                    size: A,
                    isSelected: $,
                    $margin: W ? Z.margin : {},
                    positionalStyles: g,
                    closeButton: !0
                }), s().createElement(C, {
                    isIAMEditor: B,
                    componentId: p.cn,
                    readonly: !0
                }, (n => s().createElement(m.CI, i()({
                    dndElProps: n,
                    a11yIdentifier: D,
                    width: A,
                    height: A,
                    tabIndex: _ ? -1 : 0,
                    alt: "Close dialog",
                    style: Object.assign({
                        position: "absolute",
                        zIndex: 6,
                        cursor: "pointer",
                        height: `${A}px`,
                        width: `${A}px`,
                        borderRadius: "50%",
                        top: z.top,
                        right: z.right,
                        bottom: z.bottom,
                        left: z.left
                    }, W && {
                        marginRight: `${H.marginRight}px`,
                        marginTop: `${H.marginTop}px`
                    }),
                    className: `${_?"":"klaviyo-close-form"} ${(0,l.iv)(I||(I=b`
              &&& {
                &:focus-visible {
                  outline-width: 2px;
                  outline-style: auto;
                  outline-color: ${0};
                  outline-offset: 0;
                }
              }
            `),(null==T?void 0:T.focusColor)||f.Z.theme.focusColor)}`,
                    viewBox: "0 0 20 20",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    onClick: t,
                    "aria-label": e,
                    "aria-hidden": "true"
                }, _ && !B && {
                    onClick: F
                }), s().createElement("title", {
                    id: `title-${e.split(" ").join("-")}`
                }, e), s().createElement("circle", {
                    style: {
                        cursor: "pointer"
                    },
                    cx: "10",
                    cy: "10",
                    r: "9.5",
                    fill: Z.backgroundColor,
                    stroke: Z.borderColor
                }), s().createElement("path", {
                    style: {
                        cursor: "pointer"
                    },
                    d: "M6 6L14 14M6 14L14 6L6 14Z",
                    stroke: Z.xColor,
                    strokeWidth: Z.xStroke,
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                })))))
            }
        },
        46516: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return me
                }
            });
            var o = n(67895),
                i = n.n(o),
                r = (n(92461), n(39265), n(18359)),
                s = n.n(r),
                a = n(23409),
                l = n(23034),
                d = n(98072),
                c = n(67555);
            var m = () => (0, d.Z)() && !window.klaviyoForceMobile && window.screen.availHeight < window.screen.availWidth,
                u = n(61471);
            var f = (e, t) => {
                    var n, o, i;
                    let r = e.formType === u.nq && [u.Gi, u.qK].includes(null == (n = e.data) || null == (n = n.flyoutOptions) ? void 0 : n.docking);
                    m() && (r = !1);
                    let s = e.formTypeDirection || null;
                    var a;
                    r && t && (s = (null == (a = e.data) || null == (a = a.flyoutOptions) ? void 0 : a.docking) === u.Gi ? u.DA : u.qS);
                    return {
                        isDocked: r && t,
                        evaluatedFormTypeDirection: s,
                        dockedDirection: (null == (o = e.data) || null == (o = o.flyoutOptions) ? void 0 : o.docking) === u.kW || null == (i = e.data) || null == (i = i.flyoutOptions) ? void 0 : i.docking
                    }
                },
                p = n(49054),
                h = n(86434),
                v = n(85301),
                g = n(44397),
                y = n(9655),
                I = n(85912),
                b = n(12083),
                S = n.n(b),
                w = n(78315),
                C = n(22074),
                E = n(68502),
                x = n(38612),
                V = n(47774),
                _ = n(42376);

            function T() {
                return T = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var o in n)({}).hasOwnProperty.call(n, o) && (e[o] = n[o])
                    }
                    return e
                }, T.apply(null, arguments)
            }
            var k, $, F, O = function(e) {
                return r.createElement("svg", T({
                    width: 160,
                    height: 24,
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), r.createElement("path", {
                    d: "M0 4a4 4 0 0 1 4-4h152a4 4 0 0 1 4 4v20H0V4Z",
                    fill: "#373D44",
                    style: {
                        fill: "color(display-p3 .2157 .2392 .2667)",
                        fillOpacity: 1
                    }
                }), r.createElement("path", {
                    d: "M25.109 16.183c-.702 0-1.309-.165-1.82-.495-.513-.329-.909-.796-1.188-1.401-.276-.606-.413-1.324-.413-2.154v-.01c0-.835.137-1.555.413-2.16.28-.605.673-1.073 1.182-1.402.512-.33 1.119-.494 1.82-.494.545 0 1.039.107 1.483.322.448.211.816.507 1.106.886.29.376.473.811.548 1.306l-.005.01h-.972l-.006-.01a2.123 2.123 0 0 0-.435-.86 2.074 2.074 0 0 0-.746-.564 2.313 2.313 0 0 0-.973-.198c-.494 0-.923.128-1.289.386-.361.258-.64.623-.837 1.096-.197.473-.296 1.033-.296 1.681v.01c0 .645.099 1.204.296 1.677.197.472.476.838.837 1.095.366.258.797.387 1.295.387.361 0 .69-.057.983-.172.293-.118.54-.284.741-.5.2-.218.34-.476.419-.773l.01-.01h.978v.01a2.673 2.673 0 0 1-.558 1.236c-.287.347-.65.617-1.09.81-.438.194-.932.29-1.483.29ZM29.744 16v-5.79h.935v.86h.086c.11-.305.299-.541.564-.71.265-.168.592-.252.983-.252.089 0 .177.005.263.016.09.007.157.014.204.021v.908a2.713 2.713 0 0 0-.285-.037 2.45 2.45 0 0 0-.29-.017c-.297 0-.56.06-.79.178-.229.118-.41.283-.542.494a1.395 1.395 0 0 0-.193.741V16h-.935Zm6.392.102c-.552 0-1.026-.122-1.424-.365a2.418 2.418 0 0 1-.913-1.031c-.21-.448-.317-.974-.317-1.58v-.005c0-.598.106-1.123.317-1.574.215-.45.518-.804.908-1.058s.847-.381 1.37-.381c.526 0 .977.122 1.353.365.38.244.67.584.87 1.02.204.434.306.939.306 1.515v.366h-4.64v-.747h4.162l-.462.682v-.37c0-.455-.067-.83-.204-1.123a1.441 1.441 0 0 0-.564-.655 1.552 1.552 0 0 0-.827-.22c-.311 0-.59.076-.838.23-.243.15-.436.375-.58.672-.143.297-.215.662-.215 1.095v.371c0 .412.07.765.21 1.058.14.29.338.514.596.672.258.154.562.23.913.23.262 0 .489-.035.682-.107.194-.072.353-.163.478-.274.126-.11.213-.224.264-.338l.021-.049h.935l-.011.043a1.78 1.78 0 0 1-.269.575c-.125.183-.288.35-.488.5-.201.146-.44.265-.715.354a3.042 3.042 0 0 1-.918.13Zm5.51 0c-.365 0-.694-.07-.988-.21a1.703 1.703 0 0 1-.693-.596 1.633 1.633 0 0 1-.252-.913v-.01c0-.516.182-.919.548-1.209.369-.294.89-.46 1.563-.5l2.127-.128v.746l-2.014.13c-.44.024-.763.115-.967.273-.2.158-.301.38-.301.666v.01c0 .294.11.524.333.688.222.161.501.242.838.242.318 0 .601-.063.848-.188a1.49 1.49 0 0 0 .58-.521c.144-.218.215-.466.215-.741v-1.805c0-.358-.109-.63-.327-.816-.215-.19-.54-.285-.972-.285-.348 0-.632.063-.854.188a.909.909 0 0 0-.446.521l-.006.016h-.934l.005-.032c.05-.304.176-.57.376-.795.204-.23.467-.406.79-.532.322-.129.689-.193 1.1-.193.473 0 .873.077 1.199.23.329.155.578.377.746.667.172.286.258.63.258 1.031V16h-.935v-.854h-.085c-.122.204-.27.378-.446.521a1.844 1.844 0 0 1-.586.328 2.3 2.3 0 0 1-.72.107Zm6.537-.059c-.594 0-1.026-.12-1.294-.36-.265-.24-.398-.636-.398-1.187v-3.513h-.913v-.773h.913V8.711h.967v1.499h1.268v.773h-1.268v3.277c0 .34.065.585.193.736.13.146.344.22.645.22.082 0 .152-.002.21-.006.06-.003.134-.009.22-.016v.795c-.09.015-.18.027-.269.038-.09.01-.18.016-.274.016Zm4.227.06c-.551 0-1.026-.123-1.423-.366a2.418 2.418 0 0 1-.913-1.031c-.212-.448-.317-.974-.317-1.58v-.005c0-.598.105-1.123.317-1.574.215-.45.517-.804.907-1.058s.847-.381 1.37-.381c.526 0 .978.122 1.354.365.38.244.67.584.87 1.02.204.434.306.939.306 1.515v.366h-4.64v-.747h4.162l-.462.682v-.37c0-.455-.068-.83-.204-1.123a1.44 1.44 0 0 0-.564-.655 1.553 1.553 0 0 0-.827-.22c-.312 0-.591.076-.838.23-.244.15-.437.375-.58.672-.143.297-.215.662-.215 1.095v.371c0 .412.07.765.21 1.058.139.29.338.514.596.672.257.154.562.23.913.23.261 0 .488-.035.682-.107.193-.072.353-.163.478-.274.125-.11.213-.224.263-.338l.022-.049h.934l-.01.043c-.05.197-.14.389-.27.575-.125.183-.288.35-.488.5-.2.146-.439.265-.714.354a3.042 3.042 0 0 1-.919.13Zm6.059 0c-.487 0-.913-.125-1.279-.372a2.412 2.412 0 0 1-.848-1.041c-.2-.452-.301-.978-.301-1.58v-.01c0-.605.1-1.132.3-1.58.201-.447.482-.794.844-1.041.365-.248.793-.371 1.284-.371.397 0 .757.093 1.08.28.325.182.567.427.724.735h.086V7.911h.935V16h-.935v-.924h-.086a1.93 1.93 0 0 1-.73.758c-.312.178-.67.268-1.074.268Zm.215-.828c.35 0 .653-.088.907-.263.255-.176.45-.425.586-.747.136-.326.204-.71.204-1.155v-.01c0-.448-.068-.833-.204-1.155a1.668 1.668 0 0 0-.586-.747 1.559 1.559 0 0 0-.907-.263c-.351 0-.654.088-.908.263-.25.172-.444.42-.58.742-.133.322-.199.708-.199 1.16v.01c0 .448.066.835.199 1.16.136.323.33.572.58.747.254.172.557.258.908.258Zm8.615.725-1.622-5.79h.934l1.139 4.63h.086l1.294-4.63h.887l1.294 4.63h.086l1.139-4.63h.929L71.843 16h-.94l-1.295-4.48h-.086L68.233 16H67.3Zm7.423 0v-5.79h.934V16h-.934Zm.472-6.907a.633.633 0 0 1-.456-.188.633.633 0 0 1-.188-.457c0-.179.063-.331.188-.456a.633.633 0 0 1 .456-.188c.18 0 .332.062.457.188a.622.622 0 0 1 .188.456.633.633 0 0 1-.188.457.622.622 0 0 1-.457.188Zm4.281 6.95c-.594 0-1.026-.12-1.294-.36-.265-.24-.398-.636-.398-1.187v-3.513h-.913v-.773h.913V8.711h.967v1.499h1.268v.773H78.75v3.277c0 .34.064.585.193.736.13.146.344.22.645.22.082 0 .152-.002.21-.006.06-.003.134-.009.22-.016v.795c-.09.015-.18.027-.269.038-.09.01-.18.016-.274.016ZM81.468 16V7.911h.934v3.17h.086c.147-.309.358-.547.634-.715.276-.172.627-.258 1.053-.258.433 0 .8.084 1.1.252.302.165.53.407.688.725.158.32.237.708.237 1.166V16h-.935v-3.523c0-.523-.11-.91-.333-1.16-.218-.255-.558-.382-1.02-.382-.308 0-.575.066-.8.199-.226.132-.402.32-.527.564a1.938 1.938 0 0 0-.183.875V16h-.934ZM117.901 7c0-.267.102-.524.285-.715a.984.984 0 0 1 .691-.307 1 1 0 0 1 .705.304c.187.192.294.452.297.723a1.033 1.033 0 0 1-.303.708.97.97 0 0 1-1.388-.007 1.02 1.02 0 0 1-.287-.706Zm7.78 2.168c.472 0 .782.271.782.861 0 .332-.133.89-.413 1.677a85.436 85.436 0 0 0-1.209 3.638c-.191-.663-.56-1.721-1.016-2.932l-.391-1.115c-.221-.619-.34-1.102-.34-1.42 0-.438.207-.684.605-.724v-.196h-3.349v.196c.457.045.825.483 1.311 1.813l2.122 5.753c.281.755.251 1.434-.088 2.053-.251.544-.589.815-1.002.815-.515 0-.782-.226-.782-.695 0-.18.34-.543.34-.89 0-.483-.368-.71-.781-.71-.573 0-.954.408-.954 1.026.014.907.763 1.677 1.768 1.677.516.045.929-.227 1.208-.468.178-.136.398-.604.516-.83.09-.18.164-.367.221-.56.104-.257.163-.468.207-.604.043-.136.132-.362.235-.71l.236-.77a91.748 91.748 0 0 1 1.812-5.285c.34-.86.778-1.369.999-1.48.12-.065.248-.11.382-.135v-.196h-2.416l-.003.21ZM102.42 16.31c-.428-.075-.796-.468-.796-1.299V5l-2.432.544v.21c.413-.044.826.333.826 1.134v8.124c0 .782-.413 1.239-.826 1.3a1.271 1.271 0 0 1-.732-.097 1.857 1.857 0 0 1-.83-.794l-1.125-1.845a2.082 2.082 0 0 0-1.005-.852 2.022 2.022 0 0 0-1.302-.067l1.266-1.435c.96-1.087 1.843-1.783 2.683-2.069v-.196H95.36v.196c.722.286.679.921-.147 1.918l-1.782 2.13V5L91 5.544v.21c.413 0 .825.424.825 1.164v8.094c0 .892-.398 1.239-.825 1.3v.195h3.227v-.196c-.53-.075-.795-.498-.795-1.299v-1.495l.692-.782 1.68 2.824c.398.684.763.95 1.356.95h5.603v-.154s-.156-.014-.343-.044Zm7.48.024v.195s-1.654.612-2.154-.424a2.14 2.14 0 0 1-.209-.88c-.456.966-1.458 1.48-2.402 1.48-1.193 0-2.048-.574-2.048-1.827.001-.315.093-.623.266-.885.353-.543.763-.83 1.533-1.132.381-.151.706-.257.953-.332.248-.075.573-.152.954-.227l.737-.18v-.911c0-1.51-.634-2.19-1.518-2.19-.692 0-1.09.468-1.09 1.012 0 .302.206.74.206 1.057 0 .423-.368.725-.884.725-.486 0-.781-.408-.781-.951 0-.56.265-1.042.81-1.467a2.903 2.903 0 0 1 1.828-.634c2.068 0 2.972 1.006 3.004 3.214v3.371c.011.22.071 1.104.795.986Zm-2.363-3.991c-.088.046-.294.121-.633.257l-.678.257c-.17.08-.295.15-.545.287a1.807 1.807 0 0 0-.516.377 1.714 1.714 0 0 0-.412 1.042c0 .892.471 1.375 1.193 1.375.369 0 .722-.152 1.061-.438.354-.288.53-.695.53-1.193v-1.964Zm27.283.391a4.01 4.01 0 0 1-.277 1.521c-.19.483-.473.923-.83 1.293-.339.367-.748.66-1.201.86a3.547 3.547 0 0 1-2.868 0 3.627 3.627 0 0 1-1.2-.86 4.02 4.02 0 0 1-1.091-2.816 3.997 3.997 0 0 1 .272-1.511c.188-.48.466-.918.82-1.287a3.585 3.585 0 0 1 1.197-.872 3.515 3.515 0 0 1 2.875 0c.453.203.86.5 1.197.872.358.366.641.803.832 1.284.19.48.284.995.275 1.514l-.001.002Zm-2.409-2.675c-.291-.586-.676-.926-1.124-1.018-.912-.188-1.717.772-2.018 2.299a7.36 7.36 0 0 0-.095 2.08 5.85 5.85 0 0 0 .556 1.997c.292.586.676.927 1.125 1.018.912.19 1.741-.813 2.043-2.355.257-1.29.129-2.86-.487-4.02Zm-12.679 4.952V8.957h-5.187v.181c.693.106 1.022.642.707 1.51-1.622 4.516-1.518 4.313-1.622 4.675-.103-.347-.338-1.202-.722-2.274-.383-1.072-.635-1.781-.731-2.1-.397-1.252-.265-1.72.382-1.796v-.196h-3.364v.196c.502.106.944.695 1.312 1.752l.516 1.375c.567 1.484 1.233 3.534 1.456 4.228h1.117c.36-1.076 1.802-5.363 1.995-5.8.208-.496.444-.873.708-1.133a1.48 1.48 0 0 1 1.001-.428s.81-.036.81.802v5.063c0 .847-.398 1.239-.81 1.3v.195h3.212v-.196c-.427-.06-.78-.452-.78-1.299ZM140 5h-5.638v3.957H140l-1.112-1.978L140 5Z",
                    fill: "#fff",
                    style: {
                        fill: "#fff",
                        fillOpacity: 1
                    }
                }))
            };

            function Z() {
                return Z = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var o in n)({}).hasOwnProperty.call(n, o) && (e[o] = n[o])
                    }
                    return e
                }, Z.apply(null, arguments)
            }
            var A = function(e) {
                    return r.createElement("svg", Z({
                        width: 160,
                        height: 24,
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg"
                    }, e), k || (k = r.createElement("path", {
                        d: "M0 0h160v22a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V0Z",
                        fill: "#373F47"
                    })), $ || ($ = r.createElement("path", {
                        d: "M24.728 15.144c1.416 0 2.376-.672 3.048-1.596l-.84-.456a2.723 2.723 0 0 1-2.208 1.164c-1.752 0-3.084-1.356-3.084-3.252 0-1.92 1.332-3.252 3.084-3.252.912 0 1.752.48 2.208 1.164l.828-.468c-.636-.912-1.62-1.584-3.036-1.584-2.304 0-4.116 1.68-4.116 4.14s1.812 4.14 4.116 4.14ZM29.909 15v-4.104c.264-.468 1.02-.924 1.584-.924.132 0 .24.012.348.024v-.924c-.792 0-1.464.456-1.932 1.056v-.924h-.9V15h.9Zm5.69.144c.935 0 1.715-.324 2.303-.9l-.432-.588a2.522 2.522 0 0 1-1.8.744c-1.248 0-2.004-.912-2.076-2.004h4.68v-.228c0-1.74-1.032-3.108-2.784-3.108-1.656 0-2.856 1.356-2.856 3.036 0 1.812 1.236 3.048 2.964 3.048Zm1.787-3.42h-3.804c.048-.876.66-1.92 1.896-1.92 1.32 0 1.896 1.068 1.908 1.92ZM44.256 15v-3.984c0-1.404-1.008-1.956-2.244-1.956-.948 0-1.692.312-2.316.96l.42.624c.516-.564 1.08-.804 1.776-.804.84 0 1.464.444 1.464 1.212v1.044c-.468-.528-1.128-.78-1.92-.78-.984 0-2.016.6-2.016 1.908 0 1.26 1.044 1.92 2.016 1.92.78 0 1.452-.276 1.92-.804V15h.9Zm-2.484-.504c-.852 0-1.44-.528-1.44-1.272 0-.732.588-1.26 1.44-1.26.624 0 1.236.24 1.584.708v1.104c-.348.48-.96.72-1.584.72Zm5.776.648c.516 0 .84-.156 1.068-.372l-.264-.684a.852.852 0 0 1-.612.252c-.384 0-.576-.312-.576-.744v-3.6h1.176v-.792h-1.176V7.62h-.912v1.584h-.96v.792h.96v3.792c0 .864.432 1.356 1.296 1.356Zm4.68 0c.935 0 1.715-.324 2.303-.9l-.432-.588a2.522 2.522 0 0 1-1.8.744c-1.248 0-2.004-.912-2.076-2.004h4.68v-.228c0-1.74-1.032-3.108-2.784-3.108-1.656 0-2.856 1.356-2.856 3.036 0 1.812 1.236 3.048 2.964 3.048Zm1.787-3.42h-3.804c.048-.876.66-1.92 1.896-1.92 1.32 0 1.896 1.068 1.908 1.92ZM61.461 15V6.996h-.9v3.084c-.468-.636-1.176-1.02-1.956-1.02-1.512 0-2.58 1.188-2.58 3.048 0 1.884 1.068 3.036 2.58 3.036a2.44 2.44 0 0 0 1.956-1.008V15h.9Zm-2.628-.66c-1.176 0-1.872-.948-1.872-2.232 0-1.284.696-2.244 1.872-2.244.708 0 1.416.432 1.728.936v2.616c-.312.504-1.02.924-1.728.924Zm13.464.66 1.848-5.796h-.948l-1.416 4.62-1.512-4.62h-.78l-1.524 4.62-1.416-4.62h-.936L67.46 15h.9l1.512-4.656L71.385 15h.912Zm3.34-6.624c.336 0 .6-.264.6-.6a.604.604 0 0 0-.6-.612.615.615 0 0 0-.612.612c0 .336.276.6.612.6ZM76.081 15V9.204h-.9V15h.9Zm3.272.144c.516 0 .84-.156 1.068-.372l-.264-.684a.852.852 0 0 1-.612.252c-.384 0-.576-.312-.576-.744v-3.6h1.176v-.792h-1.176V7.62h-.912v1.584h-.96v.792h.96v3.792c0 .864.432 1.356 1.296 1.356ZM86.228 15v-4.092c0-1.26-.636-1.848-1.848-1.848-.876 0-1.668.492-2.064.984V6.996h-.9V15h.9v-4.236c.336-.468 1.008-.9 1.704-.9.792 0 1.308.288 1.308 1.32V15h.9ZM119.251 7.717a.956.956 0 0 0 .684-.287 1.03 1.03 0 0 0 .296-.703 1.052 1.052 0 0 0-.29-.717.973.973 0 0 0-.69-.301.959.959 0 0 0-.676.307c-.178.19-.277.446-.276.711.002.262.103.513.281.698.178.185.419.29.671.292ZM125.909 8.667h2.363v.195c-.131.024-.257.07-.375.135-.216.105-.648.614-.979 1.468-.562 1.483-1.152 3.235-1.772 5.242l-.23.762c-.102.344-.188.569-.231.704-.043.136-.101.344-.202.599-.057.19-.13.376-.219.554-.116.224-.332.685-.505.824-.274.24-.677.509-1.181.464-.98 0-1.714-.761-1.729-1.662 0-.614.375-1.019.937-1.019.403 0 .763.229.763.704 0 .345-.331.704-.331.884 0 .464.259.685.764.685.402 0 .732-.27.979-.809.331-.614.36-1.288.086-2.037l-2.074-5.706c-.476-1.318-.836-1.751-1.282-1.798v-.195h3.27v.195c-.389.045-.591.285-.591.719 0 .314.115.794.331 1.408l.389 1.108c.447 1.199.806 2.247.995 2.906a81.428 81.428 0 0 1 1.181-3.61c.274-.778.403-1.332.403-1.662 0-.584-.302-.854-.763-.854l.003-.204ZM103.166 15.963c-.418-.076-.778-.465-.778-1.288v-9.93l-2.377.538v.21c.404-.045.806.33.806 1.123v8.059c0 .778-.404 1.227-.806 1.288a1.221 1.221 0 0 1-.715-.096c-.319-.145-.585-.403-.81-.788l-1.1-1.828a2.043 2.043 0 0 0-.981-.846 1.95 1.95 0 0 0-1.274-.067l1.24-1.423c.935-1.078 1.8-1.767 2.62-2.052v-.195h-2.725v.195c.706.285.663.914-.146 1.903l-1.743 2.112V4.744L92 5.284v.21c.403 0 .805.418.805 1.152v8.029c0 .883-.388 1.227-.805 1.288v.195h3.158v-.195c-.519-.076-.778-.494-.778-1.288v-1.483l.677-.779 1.638 2.8c.39.675.75.945 1.326.945h5.485v-.153s-.157-.011-.34-.042ZM109.707 15.014v-3.35c-.032-2.19-.915-3.188-2.938-3.188a2.808 2.808 0 0 0-1.786.63c-.533.419-.792.898-.792 1.453 0 .539.288.943.763.943.505 0 .865-.3.865-.719 0-.314-.202-.749-.202-1.048 0-.54.389-1.004 1.066-1.004.865 0 1.484.674 1.484 2.172v.898l-.72.18a10.01 10.01 0 0 0-.937.228c-.245.076-.561.18-.936.33-.75.3-1.152.584-1.499 1.123a1.62 1.62 0 0 0-.259.884c0 1.242.836 1.812 2.003 1.812.922 0 1.904-.51 2.348-1.468.006.302.076.6.204.871.488 1.028 2.106.42 2.106.42v-.195c-.708.115-.767-.76-.77-.972Zm-1.538-1.037c0 .494-.173.899-.519 1.183-.331.285-.676.435-1.037.435-.706 0-1.167-.48-1.167-1.364 0-.418.22-.808.404-1.033.145-.155.316-.282.504-.374.245-.135.366-.204.533-.285l.659-.254c.331-.135.533-.21.619-.255l.004 1.947ZM140 8.668h-5.603V4.744H140l-1.176 1.962L140 8.668ZM128.61 15.203a4.018 4.018 0 0 1-1.068-2.79 4.01 4.01 0 0 1 .266-1.5c.183-.476.456-.91.802-1.276.707-.78 1.572-1.17 2.583-1.17.995 0 1.861.39 2.568 1.17.351.363.627.796.813 1.273.186.477.278.988.269 1.503a4.04 4.04 0 0 1-.27 1.508 3.9 3.9 0 0 1-.812 1.282c-.707.761-1.573 1.155-2.568 1.155-1.011 0-1.876-.39-2.583-1.155Zm3.881-5.441c-.285-.58-.659-.92-1.098-1.01-.892-.187-1.679.765-1.973 2.28a7.466 7.466 0 0 0-.09 2.062c.064.689.248 1.36.543 1.98.286.58.659.918 1.099 1.01.891.186 1.701-.806 1.997-2.336.246-1.278.121-2.835-.482-3.987h.004Z",
                        fill: "#fff"
                    })), F || (F = r.createElement("path", {
                        d: "M120.085 14.675V8.67h-5.071v.18c.678.105 1 .637.692 1.499-1.584 4.478-1.483 4.277-1.584 4.636-.101-.345-.332-1.192-.706-2.255-.374-1.063-.62-1.768-.721-2.082-.389-1.243-.259-1.708.375-1.782V8.67h-3.285v.195c.49.105.922.689 1.282 1.737l.505 1.363c.554 1.472 1.205 3.502 1.423 4.194h1.092c.351-1.066 1.761-5.32 1.95-5.752.204-.492.435-.866.692-1.124.125-.139.276-.248.445-.322a1.24 1.24 0 0 1 .532-.102s.792 0 .792.794v5.022c0 .838-.389 1.228-.792 1.288v.195h3.14v-.195c-.415-.06-.761-.449-.761-1.288Z",
                        fill: "#fff"
                    })))
                },
                M = n(85747),
                D = n(57511);
            const B = () => null,
                N = () => null,
                j = M.Z;
            var R = ({
                    openFormVersion: e,
                    designerFunctions: t,
                    designerInfo: n,
                    formType: o,
                    abTestValue: r
                }) => {
                    const a = "FULLSCREEN" === o,
                        l = (0, E.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                        d = (0, E.Z)((e => e.onsiteState.client.klaviyoCompanyId)),
                        c = (0, E.Z)(D.ek),
                        [m, u] = s().useState(!1),
                        f = null == n ? void 0 : n.activeSidebar,
                        p = (null == f ? void 0 : f.type) === v.zQ,
                        h = {
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                            cursor: "pointer",
                            marginTop: a ? "4px" : 0,
                            marginBottom: "0px"
                        },
                        g = s().createElement(j, {
                            isIAMEditor: c,
                            componentId: v.zQ,
                            readonly: !0
                        }, (e => s().createElement(x.ZC, i()({
                            ref: e.ref
                        }, e.listeners, e.attributes, {
                            className: e.className,
                            style: h
                        }), s().createElement(A, null)))),
                        y = s().createElement(x.ZC, {
                            style: h,
                            onMouseLeave: () => u(!1),
                            onMouseEnter: () => u(!0),
                            onClick: () => {
                                B("F2P | Experiment 1G - Clicked Created with Klaviyo logo in forms editor", {
                                    formType: o,
                                    experiment: "1G",
                                    abTestValue: r
                                }), t && t.setActiveSidebar({
                                    type: v.zQ
                                })
                            }
                        }, s().createElement(N, {
                            isHovering: m,
                            isSelected: p,
                            isFullPage: a,
                            shouldWrap: p || m
                        }, a ? s().createElement(O, null) : s().createElement(A, null))),
                        I = s().createElement("a", {
                            style: h,
                            href: "https://klaviyo.com/features/forms-web-personalization?utm_medium=referral&utm_source=plgform",
                            target: "_blank",
                            rel: "noopener noreferrer",
                            "aria-label": "Created with Klaviyo - opens in a new tab",
                            onClick: () => {
                                (0, _.M)({
                                    metric: V.tr,
                                    formVersionCId: e.formVersionCId,
                                    formId: e.formId,
                                    companyId: d
                                })
                            }
                        }, a ? s().createElement(O, null) : s().createElement(A, null));
                    return s().createElement(x.ZC, {
                        style: Object.assign({
                            display: "flex",
                            justifyContent: "center"
                        }, a ? {
                            zIndex: 10,
                            position: "absolute",
                            bottom: "0px",
                            left: "0px",
                            right: "0px",
                            margin: "0 auto",
                            width: "100%",
                            overflow: "hidden"
                        } : {})
                    }, c && g, !c && l && y, !c && !l && I)
                },
                P = n(5645),
                L = n.n(P),
                z = n(40549),
                W = n(49064);
            const H = ["animatingOut", "touchStartHandler", "touchMoveHandler", "touchEndHandler", "dragOffset", "useTransition", "transitionSpeed", "isSwipeToDismissEnabled", "formVersionCId", "designerInfo", "isA11y"],
                U = {
                    LEFT: "slideinleft",
                    TOP_CENTER: "slideinup",
                    BOTTOM_CENTER: "slideindown",
                    RIGHT: "slideinright"
                },
                q = {
                    POPUP: "fadeinup",
                    FULLSCREEN: "fadein"
                },
                K = ({
                    formType: e,
                    formTypeDirection: t,
                    teaserAnimationExists: n = !1,
                    animatingOut: o = !1,
                    isDesignWorkflow: i,
                    isA11y: r
                }) => {
                    const s = o || !o && n ? "both" : "forwards",
                        a = e === u.DV || e === u.UW ? q[e] : U[Object.keys(U).find((e => t && t.endsWith(e)))];
                    return Object.assign({}, z.s, {
                        animationFillMode: s
                    }, i ? {} : {
                        animationDelay: !o && n ? "0.25s" : "0s"
                    }, {
                        animationName: `klaviyo-${a}`
                    }, o ? {
                        animationDirection: "reverse",
                        animationDuration: e === u.DV || e === u.UW ? "0.35s" : ".5s"
                    } : {
                        animationDirection: "normal",
                        animationDuration: e === u.DV || e === u.UW ? "0.35s" : "1s"
                    }, r ? {
                        animationDelay: "0s",
                        animationDuration: "0s"
                    } : {})
                },
                G = ({
                    formTypeDirection: e,
                    modalScale: t
                }) => {
                    const n = {
                            TOP: {
                                top: 0
                            },
                            CENTER: {
                                top: "50%",
                                transform: `scale(${t}) translateY(-50%)`,
                                marginTop: "auto",
                                marginBottom: "auto"
                            },
                            BOTTOM: {
                                bottom: 0
                            }
                        },
                        o = {
                            LEFT: {
                                left: 0
                            },
                            CENTER: {
                                left: "50%",
                                transform: `scale(${t}) translateX(-50%)`,
                                marginLeft: "auto",
                                marginRight: "auto"
                            },
                            RIGHT: {
                                right: 0
                            }
                        };
                    return Object.assign({}, n[Object.keys(n).find((t => e && e.startsWith(t)))], o[Object.keys(o).find((t => e && e.endsWith(t)))])
                },
                Y = e => {
                    let {
                        animatingOut: t = !1,
                        touchStartHandler: n,
                        touchMoveHandler: o,
                        touchEndHandler: a,
                        dragOffset: l = 0,
                        useTransition: c = !1,
                        transitionSpeed: m = .5,
                        isSwipeToDismissEnabled: p = !1,
                        formVersionCId: h,
                        designerInfo: g,
                        isA11y: y
                    } = e, I = L()(e, H);
                    const b = (0, E.Z)((e => {
                            var t;
                            return null == (t = e.onsiteState.openFormVersions[h]) ? void 0 : t.teaserAnimationInProgress
                        })),
                        S = (0, E.Z)((e => {
                            var t;
                            return null == (t = e.onsiteState.openFormVersions[h]) ? void 0 : t.formAnimationInProgress
                        })),
                        w = (0, E.Z)((e => {
                            var t;
                            return null == (t = e.onsiteState.openFormVersions[h]) ? void 0 : t.formVersionId
                        })),
                        C = (0, E.Z)((e => {
                            var t;
                            return null == (t = e.onsiteState.openFormVersions[h]) ? void 0 : t.currentViewId
                        })),
                        V = (0, E.Z)((e => {
                            var t;
                            return w ? null == (t = e.formsState.formVersions[w]) ? void 0 : t.formType : void 0
                        })),
                        _ = (0, E.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                        T = (0, E.Z)((e => {
                            const t = w ? e.formsState.formVersions[w] : void 0;
                            if (t) return f(t, _ ? (null == g ? void 0 : g.mobileDesktopType) === v.Jq : (0, d.Z)()).evaluatedFormTypeDirection
                        })),
                        [k, $] = (0, r.useState)(!1);
                    (0, r.useEffect)((() => {
                        b && !k && $(!0)
                    }), [k, b]);
                    const F = (0, r.useMemo)((() => _ ? `${v.Sq}:${v.Pg}:${C}` : void 0), [_, C]);
                    return s().createElement(x.ZC, i()({
                        a11yIdentifier: F
                    }, I, {
                        onAnimationEnd: () => {
                            (0, W.fK)({
                                id: h,
                                changes: {
                                    formAnimationInProgress: !1
                                }
                            }), (0, W.sd)({
                                formVersionCId: h
                            })
                        },
                        onTouchStart: e => {
                            n && n(e)
                        },
                        onTouchMove: e => {
                            o && o(e)
                        },
                        onTouchEnd: e => {
                            a && a(e)
                        },
                        onAnimationStart: () => {
                            (0, W.fK)({
                                id: h,
                                changes: {
                                    hideFormBeforeAnimation: !1
                                }
                            })
                        },
                        style: Object.assign({
                            flex: 1,
                            minHeight: V === u.UW ? "100%" : void 0
                        }, p ? Object.assign({
                            bottom: -1 * l + "px",
                            position: "relative"
                        }, c ? {
                            transition: `bottom ${m}s`
                        } : {}) : {}, (S || _ || t) && K({
                            formType: V,
                            formTypeDirection: T,
                            teaserAnimationExists: k,
                            animatingOut: t,
                            isDesignWorkflow: _,
                            isA11y: y
                        }) || {})
                    }))
                };
            var X = n(94841),
                J = n(99449),
                Q = n(54228),
                ee = n(63296),
                te = n(14377);
            let ne, oe, ie = e => e;
            const re = e => !!e.id.includes("downshift") || !("FORM" === e.tagName || !e.parentElement) && re(e.parentElement);
            var se = ({
                closePortal: e,
                formVersionCId: t,
                style: n,
                setOverlayDismissalPercentage: o,
                designerFunctions: c,
                designerInfo: m,
                isA11y: p = !1,
                a11yViewId: g,
                className: y
            }) => {
                var b, V, _, T, k, $;
                const F = (0, E.Z)((e => e.onsiteState.openFormVersions[t]), l.X),
                    O = (0, E.Z)((e => {
                        var n;
                        return null == (n = e.onsiteState.openFormVersions[t]) ? void 0 : n.modalIsClosing
                    })),
                    Z = (0, E.Z)((e => {
                        var n;
                        return null == (n = e.onsiteState.openFormVersions[t]) ? void 0 : n.closePortal
                    })),
                    A = (0, E.Z)((e => F ? e.formsState.formVersions[F.formVersionId] : void 0), l.X),
                    M = (0, E.Z)((e => {
                        var t;
                        return F ? null == (t = e.formsState.formVersions[F.formVersionId]) || null == (t = t.data) ? void 0 : t.ignoreOverlayDismissal : void 0
                    })),
                    D = (0, E.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                    B = (0, E.Z)((e => e.onsiteState.client.showingShopLogin)),
                    N = (0, r.useMemo)((() => null == A ? void 0 : A.formType), [null == A ? void 0 : A.formType]),
                    j = N === u.UW,
                    P = N === u.nq,
                    L = N === u.DV,
                    z = (0, E.Z)((e => {
                        const t = F ? e.formsState.forms[F.formId] : void 0;
                        return !!t && t.showKlaviyoBrandingFullpageAndFlyoutForms
                    })),
                    H = (0, E.Z)((e => {
                        const t = F ? e.formsState.forms[F.formId] : void 0;
                        return L ? !!t && (t.showKlaviyoBranding || !0 === z) : !(!j && !P) && z
                    })),
                    U = (0, E.Z)((e => (0, J.FK)(e))),
                    q = (0, E.Z)((e => {
                        var n;
                        return p && g ? g : null == (n = e.onsiteState.openFormVersions[t]) ? void 0 : n.currentViewId
                    })),
                    K = null == A || null == (b = A.data) ? void 0 : b.styling,
                    G = null == A || null == (V = A.data) || null == (V = V.styling) ? void 0 : V.borderRadius,
                    se = null == A || null == (_ = A.data) || null == (_ = _.styling) ? void 0 : _.dropShadow,
                    ae = null == A || null == (T = A.data) || null == (T = T.styling) ? void 0 : T.isReflow,
                    le = null == m ? void 0 : m.mobileDesktopType,
                    {
                        isDocked: de,
                        evaluatedFormTypeDirection: ce,
                        dockedDirection: me
                    } = A ? f(A, D ? le === v.Jq : (0, d.Z)()) : {
                        isDocked: void 0,
                        evaluatedFormTypeDirection: void 0,
                        dockedDirection: void 0
                    },
                    [ue, fe] = (0, r.useState)(),
                    pe = (0, r.useRef)(null);
                (0, r.useEffect)((() => {
                    fe((0, I.Z)("modal_animation_key"))
                }), [null == A ? void 0 : A.formType, null == A ? void 0 : A.formTypeDirection, le]);
                const he = () => {
                        (0, W.et)({
                            formVersionCId: t
                        })
                    },
                    [ve, ge] = (0, r.useState)(0),
                    [ye, Ie] = (0, r.useState)(0),
                    [be, Se] = (0, r.useState)(!1),
                    [we, Ce] = (0, r.useState)(.5),
                    [Ee, xe] = (0, r.useState)(new Date),
                    Ve = (e, t = !1) => {
                        o && o(e, t)
                    };
                (0, r.useEffect)((() => {
                    !Z && (null == F || !F.modalIsClosing || null != F && F.formAnimationInProgress || !F.closeModalWhenAnimationCompletes) && (null != F && F.modalIsClosing || null != F && F.teaserAnimationInProgress || null == F || !F.closeModalWhenAnimationCompletes || F.currentTeaserId) || e()
                }), [Z, F]), (0, r.useEffect)((() => {
                    const n = n => {
                        var o;
                        null != (o = pe.current) && o.contains(n.target) || D || t !== U || null === e || null != F && F.currentTeaserId || null != F && F.closeModalWhenAnimationCompletes || !((e, t, n) => !(!e || n === X.K.SHOWING || e === u.UW || e === u.nq || e === u.Mk || void 0 !== t && e === u.DV && ((0, d.Z)() ? !0 === (null == t ? void 0 : t.mobile) : !0 === (null == t ? void 0 : t.desktop))))(null == A ? void 0 : A.formType, M, B) || he()
                    };
                    return document.addEventListener("mousedown", n), document.addEventListener("touchstart", n), () => {
                        document.removeEventListener("mousedown", n), document.removeEventListener("touchstart", n)
                    }
                }), [D, t, U, e, M, F, B]);
                const _e = null == A || null == (k = A.data) || null == (k = k.styling) ? void 0 : k.margin,
                    Te = (0, r.useMemo)((() => D ? `${v.Sq}:${v.Pg}:${q}` : void 0), [D, q]),
                    ke = !D && de,
                    $e = (0, a.iv)(oe || (oe = ie `
    &&& {
      &::before {
        content: '';
        height: 100%;
        background-color: ${0};
        top: ${0};
        width: 100%;
        position: absolute;
      }
    }
  `), (null == K ? void 0 : K.backgroundColor) || h.Z.theme.backgroundColor, me === u.qK ? "50%" : "-50%"),
                    Fe = (0, r.useMemo)((() => (null == A ? void 0 : A.formType) !== u.Mk || void 0 === (null == A ? void 0 : A.data.showCloseButton) || (null == A ? void 0 : A.data.showCloseButton)), [null == A ? void 0 : A.data.showCloseButton, null == A ? void 0 : A.formType]),
                    Oe = (0, ee.C)();
                return ue ? s().createElement(x.ZC, {
                    a11yIdentifier: Te,
                    ref: pe,
                    style: Object.assign({}, n, {
                        borderRadius: `${G||h.Z.theme.borderRadius}px`,
                        position: "relative",
                        display: "flex",
                        justifyContent: "center"
                    }, !ae && {
                        flex: "0 0 auto"
                    }, (null == A ? void 0 : A.formType) === u.DV ? {
                        alignSelf: "center"
                    } : {}, (null == A ? void 0 : A.formType) === u.UW || (null == A ? void 0 : A.formType) === u.Mk ? {
                        alignSelf: "stretch",
                        flex: 1
                    } : {}, p ? {
                        position: "absolute",
                        zIndex: 1
                    } : {}),
                    "data-testid": le,
                    className: y
                }, s().createElement(r.Suspense, {
                    fallback: s().createElement(x.ZC, null)
                }, s().createElement(Y, i()({
                    key: ue,
                    formVersionCId: t,
                    animatingOut: O,
                    "data-testid": null == A ? void 0 : A.formType,
                    isSwipeToDismissEnabled: ke
                }, ke ? {
                    touchStartHandler: e => {
                        re(e.target) || (Ce(.5), Se(!1), Ie(e.touches[0].clientY), xe(new Date))
                    },
                    touchMoveHandler: e => {
                        if (re(e.target)) return;
                        e.preventDefault();
                        const t = Math.abs(e.touches[0].clientY - ye);
                        if (me === u.qK)
                            if (ye <= e.touches[0].clientY) {
                                const e = window.innerHeight - ye;
                                Ve(t / e), ge(t)
                            } else {
                                const e = .8 * window.innerHeight;
                                if (Ce(.1), t < e) {
                                    ge(-1 * t / (10 / 2 ** (-1 * t / e)))
                                }
                            }
                        else if (ye >= e.touches[0].clientY) {
                            Ve(t / ye), ge(-1 * t)
                        } else {
                            const e = .8 * window.innerHeight;
                            if (t < e) {
                                ge(t / (10 / 2 ** (-1 * t / e)))
                            }
                        }
                    },
                    touchEndHandler: e => {
                        if (re(e.target)) return;
                        Se(!0);
                        const t = (new Date).getTime() - Ee.getTime(),
                            n = Math.abs(e.changedTouches[0].clientY - ye),
                            o = n / t,
                            i = me === u.qK ? e.changedTouches[0].clientY > ye : e.changedTouches[0].clientY < ye,
                            r = me === u.qK ? .9 : .1;
                        (me === u.qK ? e.changedTouches[0].clientY / window.innerHeight > r : e.changedTouches[0].clientY / window.innerHeight < r) && n > .2 * window.innerHeight || Math.abs(o) > .8 && i && n >= .2 * window.innerHeight ? (ge(me === u.qK ? window.innerHeight : -1 * window.innerHeight), Ve(1, !0), setTimeout((() => he()), 500)) : (ge(0), Ve(0, !0)), Ie(0)
                    },
                    dragOffset: ve,
                    useTransition: be,
                    transitionSpeed: we
                } : {}, {
                    designerInfo: m,
                    isA11y: p
                }), (Ze = s().createElement(x.ZC, {
                    a11yIdentifier: Te,
                    className: S()(!D && de ? $e : "", L ? Oe : ""),
                    style: (null == A ? void 0 : A.formType) === u.UW ? {
                        display: "flex",
                        flex: 1,
                        alignSelf: "stretch"
                    } : void 0
                }, s().createElement(x.ZC, {
                    inert: !(!(0, d.Z)() || null == F || !F.currentTeaserId) || void 0,
                    a11yIdentifier: Te,
                    style: Object.assign({
                        position: "relative",
                        display: "flex"
                    }, {
                        flex: 1,
                        alignSelf: "stretch"
                    }, se && se.enabled ? {
                        boxShadow: `0px 0px ${se.blur}px ${se.color}`
                    } : {}, G ? {
                        borderRadius: `${G}px`
                    } : {})
                }, Fe && !!q && s().createElement(te.y, {
                    formType: N,
                    style: {
                        position: "absolute"
                    }
                }, s().createElement(Q.Z, {
                    viewId: q,
                    buttonStyling: null == A || null == ($ = A.data) || null == ($ = $.styling) ? void 0 : $.dismissButtonStyles,
                    title: "Close dialog",
                    onClick: he,
                    designerFunctions: c,
                    designerInfo: m
                })), null != F && F.errorViewMessage || null == F || !F.formVersionId || !q ? s().createElement(C.Z, {
                    errorViewMessage: null == F ? void 0 : F.errorViewMessage,
                    isFullscreen: (null == A ? void 0 : A.formType) === u.UW
                }) : s().createElement(w.Z, {
                    formVersionCId: t,
                    formVersionId: null == F ? void 0 : F.formVersionId,
                    viewId: q,
                    isDocked: de,
                    formTypeDirection: ce,
                    designerFunctions: c,
                    designerInfo: m
                }), H && !!F && j && s().createElement(R, {
                    openFormVersion: F,
                    designerFunctions: c,
                    designerInfo: m,
                    formType: N,
                    abTestValue: z
                })), H && !!F && !j && s().createElement(R, {
                    openFormVersion: F,
                    designerFunctions: c,
                    designerInfo: m,
                    formType: N,
                    abTestValue: z
                })), de ? Ze : s().createElement(x.ZC, {
                    a11yIdentifier: Te,
                    className: (0, a.iv)(ne || (ne = ie `
            &&& {
              &::before {
                content: '';
                display: block;
                min-height: ${0}px;
                width: 100%;
              }
              &::after {
                content: '';
                display: block;
                min-height: ${0}px;
                width: 100%;
              }
            }
          `), (null == _e ? void 0 : _e.top) || 0, (null == _e ? void 0 : _e.bottom) || 0),
                    style: {
                        position: "relative",
                        flexDirection: "column",
                        display: "flex",
                        marginLeft: null == _e ? void 0 : _e.left,
                        marginRight: null == _e ? void 0 : _e.right,
                        flex: 1,
                        alignSelf: "stretch",
                        minHeight: (null == A ? void 0 : A.formType) === u.UW ? "100%" : void 0
                    }
                }, Ze))))) : null;
                var Ze
            };
            let ae, le, de = e => e;
            const ce = 'button, [href], input:not([tabindex="-1"]), select, textarea, details, [tabindex]:not([tabindex="-1"])';
            var me = ({
                formVersionCId: e,
                closePortal: t,
                className: n,
                designerFunctions: o,
                designerInfo: m,
                isA11y: I = !1,
                a11yViewId: b,
                portalNode: S
            }) => {
                var w, C, V;
                const _ = (0, E.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                    T = _ && (null == m ? void 0 : m.isPartOfBoth),
                    k = (0, E.Z)(D.ek),
                    $ = (0, E.Z)((t => {
                        var n;
                        return I && b ? b : null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.currentViewId
                    })),
                    F = (0, E.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.currentTeaserId
                    })),
                    O = (0, E.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formVersionId
                    })),
                    Z = (0, E.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.teaserAnimationInProgress
                    })),
                    A = (0, E.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formAnimationInProgress
                    })),
                    M = (0, E.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.closeModalWhenAnimationCompletes
                    })),
                    B = (0, E.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.hideFormBeforeAnimation
                    })),
                    N = (0, E.Z)((e => O ? e.formsState.formVersions[O] : void 0), l.X);
                let j = (0, E.Z)((e => {
                    var t;
                    return (O ? null == (t = e.formsState.formVersions[O]) || null == (t = t.data) || null == (t = t.styling) ? void 0 : t.size : void 0) || h.Z.theme.size
                }));
                const R = (0, E.Z)((e => {
                        var t;
                        return O ? null == (t = e.formsState.formVersions[O]) || null == (t = t.data) ? void 0 : t.sideImage : void 0
                    }), l.X),
                    P = (0, E.Z)((e => {
                        var t;
                        return (O ? null == (t = e.formsState.formVersions[O]) || null == (t = t.data) || null == (t = t.styling) ? void 0 : t.overlayColor : void 0) || h.Z.theme.overlayColor
                    })),
                    L = (0, E.Z)((e => {
                        var t;
                        return (O ? null == (t = e.formsState.formVersions[O]) || null == (t = t.data) || null == (t = t.styling) ? void 0 : t.mobileOverlay : void 0) || h.Z.theme.mobileOverlay
                    }), l.X),
                    z = (0, E.Z)((e => e.onsiteState.client.isFetchingForms)),
                    H = (0, E.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.modalIsClosing
                    })),
                    U = (0, E.Z)((e => Object.values(e.formsState.columns).find((e => (null == e ? void 0 : e.position) === (null == R ? void 0 : R.position) && (null == e ? void 0 : e.viewId) === $))), l.X),
                    q = (e => {
                        const t = (0, r.useRef)(!1),
                            n = (0, r.useRef)(null),
                            [o, i] = (0, r.useState)(null);
                        return (0, r.useEffect)((() => (t.current = !0, () => {
                            t.current = !1
                        })), []), (0, r.useEffect)((() => {
                            if (!e) return;
                            const t = new ResizeObserver((e => {
                                var t;
                                const o = null == e || null == (t = e[0]) || null == (t = t.contentRect) ? void 0 : t.width;
                                o && o !== n.current && i(o)
                            }));
                            return t.observe(e, {
                                box: "content-box"
                            }), () => t.disconnect()
                        }), [e]), o
                    })(S),
                    K = (0, r.useRef)(null),
                    [Y, X] = (0, r.useState)(0),
                    [Q, ee] = (0, r.useState)(!1),
                    [te, ne] = (0, r.useState)("none"),
                    oe = null == R || null == (w = R.data) || null == (w = w.styling) ? void 0 : w.sizeMultiplier,
                    ie = oe ? (0, c.Z)(oe, j) : 0,
                    re = null == m ? void 0 : m.mobileDesktopType,
                    me = _ && re === v.Jq,
                    {
                        isDocked: ue,
                        evaluatedFormTypeDirection: fe
                    } = N ? f(N, _ ? re === v.Jq : (0, d.Z)()) : {
                        isDocked: void 0,
                        evaluatedFormTypeDirection: void 0
                    };
                ((0, d.Z)() || me) && R && !(0, p.V)(R, _, re || v.q5, U) && (j -= ie);
                const pe = null == N || null == (C = N.data) || null == (C = C.styling) ? void 0 : C.margin,
                    he = ue ? 0 : (null == pe ? void 0 : pe.left) || 0,
                    ve = ue ? 0 : (null == pe ? void 0 : pe.right) || 0,
                    ge = null == N || null == (V = N.data) || null == (V = V.styling) ? void 0 : V.isReflow,
                    ye = Math.max(Math.min(parseInt(j.toString(), 10), g.Ez), g.Gg) + ve + he,
                    [Ie, be] = (0, r.useState)(1),
                    Se = (0, a.iv)(ae || (ae = de `
    &&& {
      [data-testid='form-row'] {
        margin-bottom: calc((${0} - 1) * 1%);
      }
    }
  `), Ie),
                    we = (0, r.useMemo)((() => _ ? Se : void 0), [Se, _]),
                    [Ce, Ee] = (0, r.useState)(!1);
                (0, r.useEffect)((() => {
                    Z && !Ce && Ee(!0)
                }), [Ce, Z]);
                const xe = Object.assign({
                        animationTimingFunction: "ease",
                        animationPlayState: "running",
                        animationIterationCount: 1,
                        animationFillMode: !H && Ce ? "both" : "forwards"
                    }, I ? {
                        animationDelay: "0s",
                        animationDuration: "0s"
                    } : {
                        animationDelay: H || !Ce || _ ? "0s" : "0.25s",
                        animationDuration: "0.35s"
                    }),
                    Ve = Object.assign({}, xe, {
                        animationName: "klaviyo-fadeout"
                    }),
                    _e = Object.assign({}, xe, {
                        animationName: "klaviyo-fadein"
                    });
                (0, r.useEffect)((() => {
                    if (ge) return () => {};
                    const e = () => {
                        if ((null == N ? void 0 : N.formType) !== u.UW && (null == N ? void 0 : N.formType) !== u.Mk) {
                            var e;
                            const t = (null == (e = document) || null == (e = e.documentElement) ? void 0 : e.clientWidth) || window.innerWidth,
                                n = me ? v.aH : Math.min(t, q || 1 / 0),
                                o = ue ? n / ye : Math.min(n / ye, 1);
                            be(o)
                        }
                    };
                    return window.addEventListener("resize", e), e(), () => {
                        window.removeEventListener("resize", e)
                    }
                }), [ge, q, ye, re]);
                const Te = (0, E.Z)((t => (0, J.JZ)(t, e)));
                ((e, t, n, o, i, s, a) => {
                    const l = (0, r.useRef)(!1);
                    (0, r.useEffect)((() => {
                        l.current = !!i
                    }), [i]), (0, r.useEffect)((() => {
                        let o;
                        if (!t && (a === u.DV || a === u.UW) && n && !l.current) {
                            const t = null == e ? void 0 : e.querySelectorAll(ce);
                            if (e && t)
                                if (t.length > 1) {
                                    const e = Array.from(t).find((e => "INPUT" === e.nodeName));
                                    null == e || e.focus()
                                } else if (t.length) {
                                var i;
                                null == (i = t[0]) || i.focus()
                            }
                            o = null == e ? void 0 : e.addEventListener("keydown", (t => {
                                if ("Tab" !== t.key && 9 !== t.keyCode) return;
                                const n = e.querySelectorAll(ce),
                                    o = null == n ? void 0 : n[0],
                                    i = null == n ? void 0 : n[n.length - 1];
                                o !== i && (t.shiftKey ? document.activeElement === o && (null == i || i.focus(), t.preventDefault()) : document.activeElement === i && (null == o || o.focus(), t.preventDefault()))
                            }))
                        }
                        return () => o ? null == e ? void 0 : e.removeEventListener("keydown", o) : void 0
                    }), [e, t, a, n, o, s])
                })(K.current, _, Te, !!Z, H, $, null == N ? void 0 : N.formType);
                let ke = Object.assign({
                    display: te,
                    zIndex: _ ? 0 : y.B
                }, B ? {
                    opacity: 0
                } : {});
                if (re === v.Jq && _ && (null == N ? void 0 : N.formType) !== u.Mk) ke = Object.assign({}, ke, {
                    position: "relative",
                    justifyContent: "center",
                    alignItems: (Ae = null == N ? void 0 : N.formType, Me = fe, Ae === u.nq && Me ? Me.startsWith("BOTTOM") ? "flex-end" : Me.startsWith("CENTER") ? "center" : "flex-start" : "center"),
                    backgroundColor: (null == N ? void 0 : N.formType) === u.nq ? (null == L ? void 0 : L.enabled) && (null == L ? void 0 : L.color) || "transparent" : P,
                    alignSelf: "center",
                    height: "100%",
                    width: "100%",
                    overflowY: "auto",
                    overflowX: "clip"
                });
                else if ((me || (0, d.Z)()) && (null == N ? void 0 : N.formType) === u.Mk) {
                    var $e, Fe;
                    ke = Object.assign({}, ke, {
                        width: "100%",
                        position: _ || null == N || null == ($e = N.data.bannerOptions) || !$e.scrollWithPage ? "absolute" : "fixed",
                        overflow: _ ? "initial" : "visible"
                    }, (null == N || null == (Fe = N.data) || null == (Fe = Fe.bannerOptions) ? void 0 : Fe.mobileBannerPosition) === u.ko ? {
                        top: 0
                    } : {
                        bottom: 0
                    })
                } else if ((null == N ? void 0 : N.formType) === u.nq) ke = Object.assign({}, ke, Object.assign({
                    maxHeight: _ ? "100%" : 100 / Ie + "%",
                    position: _ ? "absolute" : "fixed",
                    transform: `scale(${Ie})`,
                    transformOrigin: `${fe&&fe.endsWith("RIGHT")?"right":"left"} ${fe&&fe.startsWith("BOTTOM")?"bottom":"top"}`,
                    overflow: _ ? "initial" : "visible"
                }, G({
                    formTypeDirection: fe,
                    modalScale: Ie
                })));
                else if ((null == N ? void 0 : N.formType) === u.Mk) {
                    var Oe, Ze;
                    ke = Object.assign({}, ke, {
                        width: "100%",
                        position: _ || null == N || null == (Oe = N.data.bannerOptions) || !Oe.scrollWithPage ? "absolute" : "fixed"
                    }, (null == N || null == (Ze = N.data) || null == (Ze = Ze.bannerOptions) ? void 0 : Ze.desktopBannerPosition) === u.ko ? {
                        top: 0
                    } : {
                        bottom: 0
                    })
                } else ke = Object.assign({}, ke, {
                    position: _ ? "initial" : "fixed",
                    left: 0,
                    top: 0,
                    width: "100%",
                    height: k ? "initial" : "100%",
                    justifyContent: "center",
                    alignItems: _ ? "flex-start" : "center",
                    overflow: k ? "initial" : "auto",
                    backgroundColor: P,
                    overflowX: "clip"
                }, H ? Ve : _e);
                var Ae, Me;
                T && (null == N ? void 0 : N.formType) !== u.nq && (null == N ? void 0 : N.formType) !== u.Mk && (ke = Object.assign({}, ke, {
                    position: "relative",
                    left: void 0,
                    top: void 0,
                    justifyContent: "flex-start",
                    alignItems: "flex-start",
                    alignSelf: "flex-start",
                    overflowX: "visible",
                    overflowY: "visible",
                    backgroundColor: "transparent",
                    animationName: void 0,
                    pointerEvents: "none"
                }), (null == N ? void 0 : N.formType) !== u.UW && (ke = Object.assign({}, ke, {
                    width: "auto",
                    height: "auto"
                })));
                let De = {};
                re === v.Jq && _ ? De = Object.assign({
                    position: "absolute",
                    transform: `scale(${Ie})`,
                    transformOrigin: (null == N ? void 0 : N.formType) === u.nq && fe ? "" + (fe.startsWith("BOTTOM") ? "bottom" : "top") : "center",
                    maxHeight: 100 / Ie + "%",
                    pointerEvents: "auto"
                }, (null == N ? void 0 : N.formType) !== u.nq || ue || 1 !== Ie ? {} : G({
                    formTypeDirection: fe,
                    modalScale: Ie
                })) : (null == N ? void 0 : N.formType) !== u.DV && (null == N ? void 0 : N.formType) !== u.UW || (De = {
                    overflow: _ ? "initial" : "visible",
                    transform: `scale(${Ie})`,
                    transformOrigin: "center",
                    maxHeight: _ ? "100%" : 100 / Ie + "%"
                }), !T || (null == N ? void 0 : N.formType) === u.nq && me || (De = Object.assign({}, De, {
                    transformOrigin: "left top"
                }));
                const Be = null == L ? void 0 : L.enabled,
                    Ne = (0, a.iv)(le || (le = de `
    &&& {
      &::before {
        content: '';
        background-color: ${0};
        height: 100%;
        width: 100%;
        left: 0;
        top: 0;
        bottom: 0;
        right: 0;
        position: fixed;
        z-index: ${0};
        ${0};
        opacity: ${0};
      }
    }
  `), (null == L ? void 0 : L.color) || h.Z.theme.mobileOverlay.color, y.B, Q ? "transition: opacity .5s ease;" : "", Y ? 1 - Y : 1),
                    je = (0, r.useMemo)((() => _ ? `${v.Pg}:${v.Pg}:${$}` : void 0), [_, $]);
                return (0, r.useEffect)((() => {
                    !F || Z || A ? ne(!F && Z && M ? "none" : "flex") : (!_ && H && (0, W.fK)({
                        id: e,
                        changes: {
                            modalIsClosing: !1,
                            modalWasDismissed: !0
                        }
                    }), ne("none"))
                }), [F, Z, A, H]), (0, r.useEffect)((() => ("flex" === te && !_ && ((null == N ? void 0 : N.formType) === u.DV || (null == N ? void 0 : N.formType) === u.UW) ? document.body.classList.add("klaviyo-prevent-body-scrolling") : document.body.classList.remove("klaviyo-prevent-body-scrolling"), () => {
                    document.body.classList.remove("klaviyo-prevent-body-scrolling")
                })), [te, _, null == N ? void 0 : N.formType]), Re = (null == N ? void 0 : N.formType) === u.nq && (0, d.Z)() && (null == L ? void 0 : L.enabled) && "none" !== ke.display, Pe = s().createElement(x.ZC, {
                    a11yIdentifier: je,
                    ref: K,
                    role: "dialog",
                    "aria-modal": "true",
                    "aria-label": `${null==N?void 0:N.formType} Form`,
                    className: n || "",
                    style: Object.assign({}, ke, I ? {
                        position: "absolute",
                        transform: "scale(0.001)",
                        zIndex: 1
                    } : {})
                }, z ? s().createElement(x.P, null, "Loading...") : s().createElement(se, i()({
                    closePortal: t,
                    formVersionCId: e,
                    style: De,
                    designerFunctions: o,
                    designerInfo: m
                }, Be ? {
                    setOverlayDismissalPercentage: (e, t = !1) => {
                        X(e), ee(t)
                    }
                } : {}, {
                    isA11y: I,
                    a11yViewId: b,
                    className: we
                }))), _ ? Pe : s().createElement(x.ZC, {
                    style: Object.assign({}, I ? {
                        position: "absolute",
                        transform: "scale(0.001)",
                        zIndex: 1
                    } : {}),
                    a11yIdentifier: je
                }, s().createElement(x.ZC, {
                    a11yIdentifier: je,
                    className: Ne,
                    style: Be && Re ? Object.assign({}, H ? Ve : _e) : {
                        display: "none"
                    }
                }), Pe);
                var Re, Pe
            }
        },
        75107: function(e, t, n) {
            n.d(t, {
                n: function() {
                    return u
                }
            });
            var o = n(67895),
                i = n.n(o),
                r = n(5645),
                s = n.n(r),
                a = n(18359),
                l = n.n(a),
                d = n(51950);
            const c = ["a11yIdentifier"],
                m = l().lazy((() => n.e(4077).then(n.t.bind(n, 84420, 23)))),
                u = e => {
                    let {
                        a11yIdentifier: t
                    } = e, n = s()(e, c);
                    return l().createElement(a.Suspense, {
                        fallback: l().createElement("div", null)
                    }, l().createElement(m, i()({}, n, {
                        "data-a11y-identifier": t,
                        className: `needsclick ${n.className} ${d.Tc}`
                    })))
                }
        },
        38612: function(e, t, n) {
            n.d(t, {
                C3: function() {
                    return k
                },
                CI: function() {
                    return N
                },
                De: function() {
                    return $
                },
                Dr: function() {
                    return A
                },
                Ei: function() {
                    return Z
                },
                II: function() {
                    return D
                },
                P: function() {
                    return O
                },
                ZC: function() {
                    return _
                },
                __: function() {
                    return j
                },
                aG: function() {
                    return B
                },
                l0: function() {
                    return T
                },
                ny: function() {
                    return M
                },
                zx: function() {
                    return F
                }
            });
            var o = n(67895),
                i = n.n(o),
                r = n(5645),
                s = n.n(r),
                a = n(18359),
                l = n.n(a),
                d = n(12083),
                c = n.n(d),
                m = n(51950);
            n(88224);
            const u = ["a11yIdentifier"],
                f = ["a11yIdentifier"],
                p = ["a11yIdentifier"],
                h = ["a11yIdentifier"],
                v = ["a11yIdentifier"],
                g = ["a11yIdentifier"],
                y = ["a11yIdentifier"],
                I = ["a11yIdentifier"],
                b = ["a11yIdentifier"],
                S = ["a11yIdentifier"],
                w = ["a11yIdentifier"],
                C = ["tabIndex", "className", "alt", "a11yIdentifier"],
                E = ["tabIndex", "className", "style", "alt", "onClick", "a11yIdentifier", "aria-label", "children", "dndElProps"],
                x = ["a11yIdentifier"],
                V = ({
                    children: e
                }) => e,
                _ = l().forwardRef(((e, t) => {
                    let {
                        a11yIdentifier: n
                    } = e, o = s()(e, u);
                    return l().createElement("div", i()({
                        ref: t
                    }, o, {
                        "data-a11y-identifier": n,
                        className: `needsclick ${o.className||""} ${m.Tc}`
                    }))
                }));
            _.displayName = "Div";
            const T = l().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, f);
                return l().createElement("form", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }))
            }));
            T.displayName = "Form";
            const k = l().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, p);
                return l().createElement("fieldset", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }))
            }));
            k.displayName = "FieldSet";
            const $ = l().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, h);
                return l().createElement("legend", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }))
            }));
            $.displayName = "Legend";
            const F = l().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, v);
                return l().createElement("button", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }), o.children)
            }));
            F.displayName = "Button";
            const O = l().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, g);
                return l().createElement("p", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }))
            }));
            O.displayName = "P";
            l().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, y);
                return l().createElement("a", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }))
            })).displayName = "A";
            const Z = l().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, I);
                return l().createElement("img", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }))
            }));
            Z.displayName = "Img";
            const A = l().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, b);
                return l().createElement("span", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }))
            }));
            A.displayName = "Span";
            const M = l().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, S);
                return l().createElement("svg", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }))
            }));
            M.displayName = "Svg";
            const D = l().forwardRef(((e, t) => {
                let {
                    a11yIdentifier: n
                } = e, o = s()(e, w);
                return l().createElement("input", i()({
                    ref: t
                }, o, {
                    "data-a11y-identifier": n,
                    className: `needsclick ${o.className||""} ${m.Tc}`
                }))
            }));
            D.displayName = "Input";
            const B = e => {
                    let {
                        tabIndex: t,
                        className: n,
                        alt: o,
                        a11yIdentifier: r
                    } = e, a = s()(e, C);
                    return l().createElement(F, {
                        type: "button",
                        tabIndex: t,
                        className: n
                    }, l().createElement(Z, i()({
                        alt: o
                    }, a, {
                        a11yIdentifier: r
                    })))
                },
                N = e => {
                    let {
                        tabIndex: t,
                        className: n,
                        style: o,
                        onClick: r,
                        a11yIdentifier: a,
                        "aria-label": d,
                        children: m,
                        dndElProps: u
                    } = e, f = s()(e, E);
                    return l().createElement(F, i()({
                        tabIndex: t,
                        className: c()(n, u.className),
                        style: o,
                        onClick: r,
                        "aria-label": d,
                        ref: u.ref
                    }, u.listeners, u.attributes), l().createElement(M, i()({
                        role: "img"
                    }, f, {
                        "data-a11y-identifier": a
                    }), a && m ? l().createElement(V, {
                        identifier: a
                    }, l().createElement(l().Fragment, null, m)) : m))
                },
                j = l().forwardRef(((e, t) => {
                    let {
                        a11yIdentifier: n
                    } = e, o = s()(e, x);
                    return l().createElement("label", i()({
                        ref: t
                    }, o, {
                        "data-a11y-identifier": n,
                        className: `needsclick ${o.className||""} ${m.Tc}`
                    }))
                }));
            j.displayName = "Label"
        },
        14377: function(e, t, n) {
            n.d(t, {
                y: function() {
                    return l
                }
            });
            var o = n(18359),
                i = n.n(o),
                r = n(38612),
                s = n(63296),
                a = n(61471);
            const l = ({
                formType: e,
                style: t,
                children: n
            }) => {
                const o = (0, s.C)();
                return e === a.UW ? i().createElement(r.ZC, {
                    className: o,
                    style: Object.assign({
                        width: "100%"
                    }, t)
                }, n) : n
            }
        },
        63296: function(e, t, n) {
            n.d(t, {
                C: function() {
                    return m
                }
            });
            var o = n(23409),
                i = n(57511),
                r = n(68502);
            let s, a, l = e => e;
            const d = (0, o.iv)(s || (s = l `
  margin-top: var(--safe-area-inset-top, env(safe-area-inset-top));
  margin-bottom: var(--safe-area-inset-bottom, env(safe-area-inset-bottom));
  margin-left: var(--safe-area-inset-left, env(safe-area-inset-left));
  margin-right: var(--safe-area-inset-right, env(safe-area-inset-right));
`)),
                c = (0, o.iv)(a || (a = l `
  margin-top: 47px;
  margin-bottom: 34px;
  margin-left: 0;
  margin-right: 0;
`)),
                m = () => {
                    var e;
                    const t = "in-app" === (null == (e = window) || null == (e = e.klaviyoModulesObject) ? void 0 : e.env);
                    let n;
                    return n = (0, r.Z)(i.ek) ? c : t ? d : void 0, n
                }
        },
        68973: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return W
                }
            });
            var o = n(67895),
                i = n.n(o),
                r = (n(92461), n(70818), n(39265), n(18359)),
                s = n.n(r),
                a = n(85912),
                l = n(23034),
                d = n(98072),
                c = n(12083),
                m = n.n(c),
                u = n(84786),
                f = n(68502),
                p = n(38612),
                h = n(14500),
                v = n(68414),
                g = n(85301);
            var y = ({
                    formVersionCId: e,
                    designerInfo: t,
                    teaserId: n
                }) => {
                    const o = (0, f.Z)((t => {
                            var n, o;
                            const i = null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formVersionId;
                            return i ? null == (o = t.formsState.formVersions[i]) ? void 0 : o.formType : void 0
                        })),
                        i = (0, f.Z)((t => {
                            var n, o;
                            const i = null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formVersionId;
                            return i ? null == (o = t.formsState.formVersions[i]) ? void 0 : o.formTypeDirection : void 0
                        })),
                        d = (0, f.Z)((t => {
                            var o;
                            const i = null == (o = t.onsiteState.openFormVersions[e]) ? void 0 : o.formVersionId,
                                r = t.formsState.teasers ? Object.values(t.formsState.teasers).filter((e => (null == e ? void 0 : e.formVersionId) === i)) : [];
                            return n ? r.find((e => (null == e ? void 0 : e.teaserId) === n)) : r.find((e => {
                                var t, n;
                                return "ALL" === (null == e || null == (t = e.data) ? void 0 : t.deviceType) || void 0 === (null == e || null == (n = e.data) ? void 0 : n.deviceType)
                            })) || r[0]
                        }), l.X),
                        c = (0, f.Z)((e => e.onsiteState.client.isDesignWorkflow)),
                        m = null == t ? void 0 : t.mobileDesktopType,
                        [u, y] = (0, r.useState)();
                    (0, r.useEffect)((() => {
                        y((0, a.Z)("modal_animation_key"))
                    }), [o, i, m]);
                    const I = h.c.TEXT,
                        b = (0, r.useMemo)((() => c ? `${g.KI}:${g.s4}:${null==d?void 0:d.teaserId}` : void 0), [c, null == d ? void 0 : d.teaserId]);
                    return u && d ? s().createElement(p.ZC, {
                        a11yIdentifier: b
                    }, s().createElement(r.Suspense, {
                        fallback: s().createElement(p.ZC, null)
                    }, s().createElement(I, {
                        itemId: d.teaserId,
                        parentType: v.p,
                        formVersionCId: e,
                        a11yIdentifierBlock: b
                    }))) : null
                },
                I = n(49064),
                b = n(51950),
                S = n(35001),
                w = n(9655),
                C = n(76300),
                E = n(23409),
                x = n(61471),
                V = n(85413);
            let _;
            const T = 16,
                k = {
                    [C.GE]: {
                        [x.MG]: {},
                        [x.DA]: {},
                        [x.pz]: {},
                        [x.pq]: {},
                        [x.j$]: {},
                        [x.kB]: {},
                        [x.qS]: {},
                        [x.tC]: {}
                    },
                    [C.uv]: {
                        [x.MG]: {},
                        [x.DA]: {},
                        [x.pz]: {},
                        [x.pq]: {},
                        [x.j$]: {},
                        [x.kB]: {},
                        [x.qS]: {},
                        [x.tC]: {}
                    },
                    [C.aR]: {
                        [x.MG]: {
                            clipPath: "polygon(100% 0, 0 100%, 0 0)"
                        },
                        [x.pz]: {
                            clipPath: "polygon(100% 100%, 0 0, 100% 0)"
                        },
                        [x.kB]: {
                            clipPath: "polygon(0 0, 0 100%, 100% 100%)"
                        },
                        [x.tC]: {
                            clipPath: "polygon(100% 100%, 0 100%, 100% 0)"
                        }
                    }
                },
                $ = ({
                    type: e,
                    direction: t,
                    dismissButtonMargin: n
                }) => {
                    var o, i;
                    const r = null != (o = null == n ? void 0 : n.top) ? o : V.Z.dismissButtonStyles.margin.top,
                        s = -1 * r,
                        a = -1 * (null != (i = null == n ? void 0 : n.right) ? i : V.Z.dismissButtonStyles.margin.right);
                    return {
                        [C.GE]: {
                            [x.MG]: {
                                bottom: s,
                                right: a
                            },
                            [x.DA]: {
                                bottom: s,
                                right: a
                            },
                            [x.pz]: {
                                bottom: s,
                                left: a
                            },
                            [x.pq]: {
                                bottom: s,
                                right: a
                            },
                            [x.j$]: {
                                bottom: s,
                                right: a
                            },
                            [x.kB]: {
                                top: s,
                                right: a
                            },
                            [x.qS]: {
                                top: s,
                                right: a
                            },
                            [x.tC]: {
                                top: s,
                                left: a
                            }
                        },
                        [C.uv]: {
                            [x.MG]: {
                                bottom: s,
                                right: a
                            },
                            [x.DA]: {
                                bottom: s,
                                right: a
                            },
                            [x.pz]: {
                                bottom: s,
                                left: a
                            },
                            [x.pq]: {
                                top: s,
                                right: a
                            },
                            [x.j$]: {
                                top: s,
                                left: a
                            },
                            [x.kB]: {
                                top: s,
                                right: a
                            },
                            [x.qS]: {
                                top: s,
                                right: a
                            },
                            [x.tC]: {
                                top: s,
                                left: a
                            }
                        },
                        [C.aR]: {
                            [x.MG]: {
                                top: r,
                                right: a
                            },
                            [x.pz]: {
                                top: r,
                                left: a
                            },
                            [x.kB]: {
                                bottom: r,
                                right: a
                            },
                            [x.tC]: {
                                bottom: r,
                                left: a
                            }
                        }
                    }[e][t]
                },
                F = ({
                    theme: e,
                    type: t,
                    direction: n
                }) => {
                    const o = Math.sqrt(e.size * e.size * 2) / 2,
                        i = Math.sqrt(e.size * e.size - o * o);
                    return {
                        [C.GE]: {
                            [x.DA]: {},
                            [x.pq]: {},
                            [x.j$]: {},
                            [x.qS]: {}
                        },
                        [C.uv]: {
                            [x.pq]: {},
                            [x.j$]: {}
                        },
                        [C.aR]: {
                            [x.MG]: {
                                width: Math.sqrt(e.size * e.size * 2),
                                transform: "rotate(-45deg)",
                                transformOrigin: "top left",
                                top: e.size / 2,
                                left: -1 * e.size / 2,
                                position: "relative",
                                height: i,
                                display: "flex",
                                flexDirection: "column-reverse",
                                alignItems: "center"
                            },
                            [x.pz]: {
                                width: Math.sqrt(e.size * e.size * 2),
                                transform: "rotate(45deg)",
                                transformOrigin: "top left",
                                top: -1 * e.size / 2,
                                left: e.size / 2,
                                position: "relative",
                                height: i,
                                display: "flex",
                                flexDirection: "column-reverse",
                                alignItems: "center"
                            },
                            [x.kB]: {
                                height: e.size - T,
                                width: Math.sqrt(e.size * e.size * 2),
                                transform: "rotate(45deg)",
                                transformOrigin: "top left"
                            },
                            [x.tC]: {
                                height: e.size - T,
                                width: Math.sqrt(e.size * e.size * 2),
                                position: "relative",
                                top: e.size,
                                left: 0,
                                transform: "rotate(-45deg)",
                                transformOrigin: "top left"
                            }
                        }
                    }[t][n] || {}
                },
                O = e => {
                    var t;
                    return Object.assign({
                        backgroundColor: e.backgroundColor
                    }, e.backgroundImage ? {
                        backgroundImage: e.backgroundImage && `url(${e.backgroundImage.url})`,
                        backgroundRepeat: "no-repeat",
                        backgroundSize: e.backgroundImage && ("custom" === e.backgroundImage.position ? `${e.backgroundImage.customWidth}px` : e.backgroundImage.position),
                        backgroundPositionX: e.backgroundImage && e.backgroundImage.alignment,
                        backgroundPositionY: (null == (t = e.backgroundImage) ? void 0 : t.verticalAlignment) || "center"
                    } : {})
                },
                Z = (0, E.iv)(_ || (_ = (e => e)
                    `
  > div {
    padding-bottom: 8px;
    padding-top: 8px;
  }
`));
            var A = n(5645),
                M = n.n(A),
                D = n(40549);
            const B = ["teaserType", "teaserDirection", "teaserDisplayOrder", "animatingOut", "endAnimationCallback", "formVersionCId", "style", "isA11y", "a11yTeaserId"],
                N = {
                    [C.GE]: {
                        CENTER_LEFT: "slideinup",
                        TOP: "slideinup",
                        BOTTOM: "slideindown",
                        CENTER_RIGHT: "slideinup"
                    },
                    [C.uv]: {
                        CENTER_LEFT: "slideinleft",
                        TOP: "slideinup",
                        BOTTOM: "slideindown",
                        CENTER_RIGHT: "slideinright"
                    },
                    [C.aR]: {
                        TOP_LEFT: "slideintopleft",
                        BOTTOM_LEFT: "slideinbottomleft",
                        TOP_RIGHT: "slideintopright",
                        BOTTOM_RIGHT: "slideinbottomright"
                    }
                },
                j = ({
                    teaserType: e,
                    teaserDirection: t,
                    animatingOut: n = !1,
                    isDesignWorkflow: o,
                    isFirstRender: i,
                    isA11y: r
                }) => {
                    const s = N[e],
                        a = s[Object.keys(s).find((e => t && t.startsWith(e)))];
                    let l = "0s",
                        d = "forwards";
                    return o ? l = "0.35s" : i && !n && (l = "2s", d = "both"), Object.assign({}, D.s, {
                        animationDelay: l,
                        animationFillMode: d,
                        animationDuration: ".4s",
                        animationName: `klaviyo-${a}`
                    }, n ? {
                        animationDirection: "reverse"
                    } : {
                        animationDirection: "normal"
                    }, r ? {
                        animationDelay: "0s",
                        animationDuration: "0s"
                    } : {})
                },
                R = e => {
                    let {
                        teaserType: t,
                        teaserDirection: n,
                        animatingOut: o = !1,
                        endAnimationCallback: a = (() => {}),
                        formVersionCId: l,
                        style: d = {},
                        isA11y: c,
                        a11yTeaserId: m
                    } = e, u = M()(e, B);
                    const [h, v] = (0, r.useState)(!1), y = (0, f.Z)((e => !!e.onsiteState.client.isDesignWorkflow)), b = (0, f.Z)((e => {
                        var t;
                        return null == (t = e.onsiteState.openFormVersions[l]) ? void 0 : t.teaserIsFirstRender
                    }));
                    (0, r.useEffect)((() => {
                        o && v(!1)
                    }), [o]);
                    const S = (0, r.useMemo)((() => y ? `${g.KI}:${g.s4}:${m}` : void 0), [y, m]);
                    return s().createElement(p.ZC, i()({
                        a11yIdentifier: S
                    }, u, {
                        onAnimationEnd: () => {
                            (0, I.fK)({
                                id: l,
                                changes: {
                                    teaserAnimationInProgress: !1
                                }
                            }), v(!0), a()
                        },
                        onAnimationStart: () => {
                            (0, I.ng)({
                                formVersionCId: l
                            }), o && (0, I.fK)({
                                id: l,
                                changes: {
                                    teaserAnimationInProgress: !0,
                                    formAnimationInProgress: !0
                                }
                            }), (0, I.fK)({
                                id: l,
                                changes: {
                                    hideTeaserBeforeAnimation: !1
                                }
                            })
                        },
                        style: Object.assign({
                            height: "100%",
                            width: "100%"
                        }, d, (!h || o) && j({
                            teaserType: t,
                            teaserDirection: n,
                            animatingOut: o,
                            isDesignWorkflow: y,
                            isFirstRender: !!b,
                            isA11y: c
                        }) || {})
                    }))
                };
            var P = n(62945),
                L = n(90307);
            var z = n(54228);
            var W = ({
                formVersionCId: e,
                className: t,
                designerFunctions: n,
                designerInfo: o,
                isA11y: c = !1,
                a11yTeaserId: h
            }) => {
                var v, E, V, _, A, M, D, B, N;
                const j = (0, f.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.closeModalWhenAnimationCompletes
                    })),
                    W = (0, f.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                    H = (0, f.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formVersionId
                    })),
                    U = (0, f.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formId
                    })),
                    q = (0, f.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.hideTeaserBeforeAnimation
                    })),
                    K = (0, f.Z)((t => {
                        var n;
                        return c && h ? h : null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.currentTeaserId
                    })),
                    G = (0, f.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.teaserAnimationInProgress
                    })),
                    Y = W && !(null == o || !o.isPartOfBoth),
                    X = W ? (null == o ? void 0 : o.mobileDesktopType) === g.Jq : (0, d.Z)(),
                    J = (0, f.Z)((e => {
                        const t = e.formsState.teasers ? Object.values(e.formsState.teasers).filter((e => (null == e ? void 0 : e.formVersionId) === H)) : [];
                        if (0 === t.length) return;
                        const n = "mobile" === (X ? "mobile" : "desktop") ? b.t5 : b.L9,
                            o = K ? t.find((e => (null == e ? void 0 : e.teaserId) === K)) : void 0;
                        if (o && !Y && (e => {
                                var t;
                                const o = null == e || null == (t = e.data) ? void 0 : t.deviceType;
                                return void 0 === o || o === b.Ep || o === n
                            })(o)) return o;
                        const i = t.find((e => {
                            var t;
                            return (null == e || null == (t = e.data) ? void 0 : t.deviceType) === n
                        }));
                        if (i) return i;
                        return t.find((e => {
                            var t, n;
                            return (null == e || null == (t = e.data) ? void 0 : t.deviceType) === b.Ep || void 0 === (null == e || null == (n = e.data) ? void 0 : n.deviceType)
                        }))
                    }), l.X),
                    Q = (0, f.Z)((e => {
                        const t = Object.values(e.onsiteState.triggerGroups).find((e => (null == e ? void 0 : e.formVersionId) === H));
                        return t && void 0 !== t[S.w1] || !1
                    })),
                    ee = null == J || null == (v = J.data) ? void 0 : v.showDismissButton,
                    te = (0, r.useRef)(null),
                    [ne, oe] = (0, r.useState)(!1),
                    ie = (0, r.useMemo)((() => W ? `${g.KI}:${g.s4}:${null==J?void 0:J.teaserId}` : void 0), [W, null == J ? void 0 : J.teaserId]),
                    [re, se] = (0, r.useState)(),
                    [ae, le] = (0, r.useState)(!1),
                    [de, ce] = (0, r.useState)(!1),
                    me = (0, r.useCallback)((() => {
                        ae && !W && (j || (0, I.$J)({
                            formVersionCId: e
                        }), le(!1))
                    }), [ae]);
                if ((0, r.useEffect)((() => {
                        se((0, a.Z)("teaser_animation_key"))
                    }), [null == J ? void 0 : J.type, null == J ? void 0 : J.direction]), (0, r.useEffect)((() => {
                        J && K && ne && !ae && !G && te.current && (te.current.focus(), oe(!1))
                    }), [e, K, G, ne, ae, J]), !J || !K && !G && !Y) return null;
                const ue = null == (E = J.data) || null == (E = E.styling) || null == (E = E.dismissButtonStyles) ? void 0 : E.margin,
                    fe = J.type === C.GE && ((null == (V = J.direction) ? void 0 : V.includes("TOP")) || (null == (_ = J.direction) ? void 0 : _.includes("BOTTOM"))) && X,
                    pe = (({
                        teaserStyling: e,
                        teaserType: t
                    }) => {
                        const n = C.ds[t];
                        return (0, P.Z)({}, Object.assign({}, L.al, {
                            size: n
                        }), e)
                    })({
                        teaserStyling: null == (A = J.data) ? void 0 : A.styling,
                        teaserType: J.type
                    }),
                    he = {
                        theme: pe,
                        type: J.type,
                        direction: J.direction
                    },
                    ve = Object.assign({
                        zIndex: W ? 0 : w.B
                    }, c ? {
                        transform: "scale(0.001)",
                        zIndex: 1
                    } : {}, {
                        position: W ? "absolute" : "fixed"
                    }, pe.dropShadow.enabled ? {
                        filter: `drop-shadow(0px 0px ${pe.dropShadow.blur}px ${pe.dropShadow.color})`
                    } : {}, (({
                        theme: e,
                        type: t,
                        direction: n
                    }) => {
                        const o = e.margin.left,
                            i = e.margin.top;
                        return {
                            [C.GE]: {
                                [x.MG]: {
                                    top: 0,
                                    left: 0,
                                    margin: `${i}px ${o}px`
                                },
                                [x.DA]: {
                                    top: 0,
                                    left: "50%",
                                    transform: `translate(calc(-50% - ${o}px))`,
                                    margin: `${i}px ${o}px`
                                },
                                [x.pz]: {
                                    top: 0,
                                    right: 0,
                                    margin: `${i}px ${o}px`
                                },
                                [x.pq]: {
                                    top: "50%",
                                    left: 0,
                                    transform: "rotate(-90deg) translate(-50%, 0)",
                                    transformOrigin: "top left",
                                    marginLeft: `${i}px`
                                },
                                [x.j$]: {
                                    top: "50%",
                                    right: 0,
                                    transform: "rotate(90deg) translate(50%, 0)",
                                    transformOrigin: "top right",
                                    marginRight: `${i}px`
                                },
                                [x.kB]: {
                                    bottom: 0,
                                    left: 0,
                                    margin: `${i}px ${o}px`
                                },
                                [x.qS]: {
                                    bottom: 0,
                                    left: "50%",
                                    transform: `translate(calc(-50% - ${o}px))`,
                                    margin: `${i}px ${o}px`
                                },
                                [x.tC]: {
                                    bottom: 0,
                                    right: 0,
                                    margin: `${i}px ${o}px`
                                }
                            },
                            [C.uv]: {
                                [x.MG]: {
                                    top: 0,
                                    left: 0,
                                    margin: `${i}px ${o}px`
                                },
                                [x.DA]: {
                                    top: 0,
                                    left: "50%",
                                    transform: `translate(calc(-50% - ${o}px))`,
                                    margin: `${i}px ${o}px`
                                },
                                [x.pz]: {
                                    top: 0,
                                    right: 0,
                                    margin: `${i}px ${o}px`
                                },
                                [x.pq]: {
                                    left: 0,
                                    margin: `${i}px ${o}px`,
                                    top: `calc(50% - ${i}px)`,
                                    transform: "translateY(-50%)"
                                },
                                [x.j$]: {
                                    right: 0,
                                    margin: `${i}px ${o}px`,
                                    top: `calc(50% - ${i}px)`,
                                    transform: "translateY(-50%)"
                                },
                                [x.kB]: {
                                    bottom: 0,
                                    left: 0,
                                    margin: `${i}px ${o}px`
                                },
                                [x.qS]: {
                                    bottom: 0,
                                    left: "50%",
                                    transform: `translate(calc(-50% - ${o}px))`,
                                    margin: `${i}px ${o}px`
                                },
                                [x.tC]: {
                                    bottom: 0,
                                    right: 0,
                                    margin: `${i}px ${o}px`
                                }
                            },
                            [C.aR]: {
                                [x.MG]: {
                                    top: 0,
                                    left: 0,
                                    height: e.size,
                                    width: e.size,
                                    margin: `${i}px ${o}px`
                                },
                                [x.pz]: {
                                    top: 0,
                                    right: 0,
                                    height: e.size,
                                    width: e.size,
                                    margin: `${i}px ${o}px`
                                },
                                [x.kB]: {
                                    bottom: 0,
                                    left: 0,
                                    height: e.size,
                                    width: e.size,
                                    margin: `${i}px ${o}px`
                                },
                                [x.tC]: {
                                    bottom: 0,
                                    right: 0,
                                    height: e.size,
                                    width: e.size,
                                    margin: `${i}px ${o}px`
                                }
                            }
                        }[t][n]
                    })(he), (({
                        theme: e,
                        type: t,
                        direction: n
                    }) => ({
                        [C.GE]: {
                            [x.MG]: {
                                width: e.size - T
                            },
                            [x.DA]: {
                                width: e.size - T
                            },
                            [x.pz]: {
                                width: e.size - T
                            },
                            [x.pq]: {
                                width: e.size - T
                            },
                            [x.j$]: {
                                width: e.size - T
                            },
                            [x.kB]: {
                                width: e.size - T
                            },
                            [x.qS]: {
                                width: e.size - T
                            },
                            [x.tC]: {
                                width: e.size - T
                            }
                        },
                        [C.uv]: {
                            [x.MG]: {
                                height: e.size - T,
                                width: e.size - T
                            },
                            [x.DA]: {
                                height: e.size - T,
                                width: e.size - T
                            },
                            [x.pz]: {
                                height: e.size - T,
                                width: e.size - T
                            },
                            [x.pq]: {
                                width: e.size - T,
                                height: e.size - T
                            },
                            [x.j$]: {
                                width: e.size - T,
                                height: e.size - T
                            },
                            [x.kB]: {
                                height: e.size - T,
                                width: e.size - T
                            },
                            [x.qS]: {
                                height: e.size - T,
                                width: e.size - T
                            },
                            [x.tC]: {
                                height: e.size - T,
                                width: e.size - T
                            }
                        },
                        [C.aR]: {
                            [x.MG]: {},
                            [x.pz]: {},
                            [x.kB]: {},
                            [x.tC]: {}
                        }
                    }[t][n] || {}))(he), fe ? {
                        width: `calc(100% - ${2*pe.margin.left}px)`
                    } : {}, q && W ? {
                        opacity: 0
                    } : {}),
                    ge = Object.assign({
                        overflow: "hidden",
                        boxSizing: "border-box"
                    }, k[J.type][J.direction] || {}, ((e, t, n) => {
                        const o = {};
                        switch (t) {
                            case C.GE:
                                o.borderRadius = ((e, t) => {
                                    const n = e.margin.top,
                                        o = e.margin.left;
                                    let [i, r, s, a] = [e.borderRadius, e.borderRadius, e.borderRadius, e.borderRadius];
                                    return null != t && t.includes("BOTTOM") && 0 === n && (s = 0, a = 0), null != t && t.includes("TOP") && 0 === n && (r = 0, i = 0), null != t && t.includes("LEFT") && 0 === o && (i = 0, a = 0), null != t && t.includes("RIGHT") && 0 === o && (r = 0, s = 0), null != t && t.includes("CENTER") && null != t && t.includes("LEFT") && 0 === n && (i = 0, r = 0), null != t && t.includes("CENTER") && null != t && t.includes("RIGHT") && 0 === n && (i = 0, r = 0), `${i}px ${r}px ${s}px ${a}px`
                                })(e, n);
                                break;
                            case C.uv:
                                o.borderRadius = "50%"
                        }
                        return o
                    })(pe, J.type, J.direction), J.type !== C.aR ? O(pe) : {}, C.GE === J.type ? {
                        minHeight: 50,
                        height: "100%",
                        padding: 8
                    } : {}, C.uv === J.type ? {
                        height: "100%",
                        padding: 8
                    } : {
                        height: "100%"
                    }, J.type === C.aR ? {
                        display: "block"
                    } : {
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "center"
                    }),
                    ye = () => {
                        le(!0), oe(!0)
                    },
                    Ie = W && (null == J ? void 0 : J.teaserId) && (null == o || null == (M = o.activeSidebar) ? void 0 : M.type) === g.KI && (null == o || null == (D = o.activeSidebar) ? void 0 : D.key) === J.teaserId,
                    be = W && (Ie || de);
                return s().createElement(p.ZC, {
                    className: m()(`kl-teaser-${U}`, t, {
                        [u.Z.outlineActive]: Ie,
                        [u.Z.outlineHover]: !Ie && de
                    }),
                    style: ve,
                    onMouseEnter: W ? () => {
                        ce(!0)
                    } : void 0,
                    onMouseLeave: W ? () => {
                        ce(!1)
                    } : void 0,
                    onClick: W ? () => {
                        W && n && null != J && J.teaserId && n.setActiveSidebar({
                            type: g.wO,
                            key: J.teaserId
                        })
                    } : void 0
                }, be && s().createElement(p.ZC, {
                    className: m()(u.Z.infoContainer, {
                        [u.Z.infoContainerActive]: Ie,
                        [u.Z.infoContainerHovering]: !Ie && de
                    })
                }, s().createElement(p.ZC, {
                    className: u.Z.infoRow
                }, s().createElement(p.Dr, {
                    className: u.Z.infoText
                }, X ? "Mobile Teaser" : "Desktop Teaser"))), s().createElement(R, {
                    key: re,
                    teaserType: J.type,
                    teaserDirection: J.direction,
                    teaserDisplayOrder: J.displayOrder,
                    animatingOut: G && !K || ae,
                    endAnimationCallback: me,
                    formVersionCId: e,
                    "data-testid": "animated-teaser",
                    isA11y: c,
                    a11yTeaserId: h
                }, s().createElement(p.Dr, i()({
                    ref: te,
                    a11yIdentifier: ie
                }, null != (B = J.data.content) && B.html ? {} : {
                    "aria-label": "Open Form"
                }, {
                    style: ge,
                    className: W ? "" : u.Z.pointer,
                    tabIndex: W ? -1 : 0,
                    role: W ? void 0 : "button",
                    onClick: W ? void 0 : ye,
                    onKeyDown: W ? void 0 : e => {
                        "Enter" !== e.key && " " !== e.key || W || (e.preventDefault(), ye())
                    }
                }), s().createElement(p.ZC, {
                    a11yIdentifier: ie,
                    style: Object.assign({}, F(he), J.type === C.aR ? O(pe) : {}),
                    className: J.type === C.aR ? Z : ""
                }, s().createElement(y, {
                    formVersionCId: e,
                    designerInfo: o,
                    teaserId: J.teaserId
                }))), (Q || ee) && !G && s().createElement(z.Z, {
                    buttonStyling: null == (N = J.data) || null == (N = N.styling) ? void 0 : N.dismissButtonStyles,
                    title: "Close teaser",
                    onClick: () => {
                        (0, I.YW)({
                            formVersionCId: e
                        })
                    },
                    positionalStyles: $(Object.assign({}, he, {
                        dismissButtonMargin: ue
                    })),
                    isTeaser: !0,
                    designerFunctions: n,
                    designerInfo: o
                })))
            }
        },
        22074: function(e, t, n) {
            var o = n(18359),
                i = n.n(o),
                r = n(7385),
                s = n(38612);
            t.Z = ({
                errorViewMessage: e,
                isEmbed: t = !1,
                isFullscreen: n = !1
            }) => i().createElement(s.ZC, {
                role: "status",
                "aria-live": "polite",
                style: Object.assign({
                    height: 165,
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    background: "#ffffff"
                }, t ? {
                    width: "100%"
                } : Object.assign({}, n ? {
                    width: "100%",
                    overflow: "auto",
                    height: "fit-content",
                    minHeight: "100%"
                } : {
                    width: 450
                }))
            }, i().createElement(s.ZC, {
                style: {
                    textAlign: "center",
                    width: 300
                }
            }, e || r.xl))
        },
        78315: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return z
                }
            });
            n(19986), n(92461), n(70818), n(39265), n(44159), n(60873), n(83362);
            var o = n(18359),
                i = n.n(o),
                r = n(23409),
                s = n(23034),
                a = n(87377),
                l = n(94756),
                d = n(85301),
                c = n(44397),
                m = n(67895),
                u = n.n(m);
            const f = "top",
                p = "bottom";
            var h = n(12083),
                v = n.n(h),
                g = n(62945),
                y = n(19604),
                I = n(68502),
                b = n(14500),
                S = n(38612),
                w = n(74729),
                C = n(49054),
                E = n(57511),
                x = n(89331),
                V = n(85747);
            const _ = {
                    right: "0 0 0 auto",
                    left: "0 auto 0 0",
                    center: "0 auto"
                },
                T = ({
                    children: e
                }) => e,
                k = V.Z;
            var $ = ({
                componentId: e,
                componentPosition: t,
                formVersionCId: n,
                rowDroppableHover: r,
                setDragState: a,
                dragFinished: l,
                designerFunctions: c,
                designerInfo: m,
                isA11y: f = !1
            }) => {
                var p;
                const [h, V] = (0, o.useState)(!1), $ = (0, o.useRef)(null), F = (0, I.Z)((t => t.formsState.components[e]), s.X), O = (0, I.Z)((e => !!e.onsiteState.client.isDesignWorkflow)), Z = (0, I.Z)(E.ek), A = (0, I.Z)((e => {
                    var t;
                    return null == (t = e.onsiteState.openFormVersions[n]) ? void 0 : t.currentViewId
                })), M = (0, I.Z)((t => A ? (0, x.su)(t, e, A) : {}), s.X), D = (0, I.Z)((e => A ? (0, E.l)(e, A) : {}), s.X), B = (0, I.Z)((t => {
                    var n, o;
                    const i = null == (n = t.formsState.components[e]) ? void 0 : n.actionId;
                    return t.formsState.actions && i ? null == (o = t.formsState.actions[i]) ? void 0 : o.actionType : void 0
                })), N = (0, o.useMemo)((() => O ? (null == m ? void 0 : m.mobileDesktopType) || d.q5 : (0, w.Z)()), [O, null == m ? void 0 : m.mobileDesktopType]), j = (null == m ? void 0 : m.activeComponentId) || (null == m ? void 0 : m.activeA11yComponentId), R = (0, o.useMemo)((() => {
                    var e;
                    return (0, g.Z)({}, D, M, {
                        [y.Z.THEME_KEY]: null == F || null == (e = F.data) ? void 0 : e.styling
                    })
                }), [D, M, null == F || null == (p = F.data) ? void 0 : p.styling]), P = (0, o.useMemo)((() => O ? `${d.f2}:${d.j1}:${e}` : void 0), [e, O]), L = (0, o.useMemo)((() => O ? `${d.f2}:${d.Pg}:${e}` : void 0), [e, O]), z = (0, o.useMemo)((() => {
                    if (!F) return null;
                    const t = b.c[F.componentType];
                    return t ? i().createElement(t, {
                        theme: R,
                        componentId: e,
                        formVersionCId: n,
                        itemId: e,
                        a11yIdentifierBlock: P,
                        a11yIdentifierStyles: L
                    }) : null
                }), [P, L, F, e, n, R]), W = j === e, H = Object.assign({
                    component: F
                }, O && !Z ? {
                    onClick: () => {
                        null == c || c.setActiveSidebar({
                            type: d.NV,
                            key: e
                        })
                    },
                    onMouseOver: () => {
                        l ? a(!1) : V(!0)
                    },
                    onMouseLeave: () => V(!1),
                    onDragStart: () => V(!1),
                    onDragEnd: () => {
                        a(!0)
                    },
                    ref: $
                } : {}), U = (0, C.C)(F, N, B);
                return F && U ? i().createElement(k, {
                    isIAMEditor: Z,
                    componentId: e,
                    componentRef: $
                }, (({
                    ref: o,
                    attributes: s,
                    listeners: a,
                    className: l
                }) => {
                    var d, p, g, I;
                    return i().createElement(S.ZC, u()({
                        a11yIdentifier: P,
                        style: Object.assign({
                            display: "flex",
                            justifyContent: "flex-start",
                            padding: `${R[y.Z.THEME_KEY].padding.top||0}px ${R[y.Z.THEME_KEY].padding.right||0}px ${R[y.Z.THEME_KEY].padding.bottom||0}px ${R[y.Z.THEME_KEY].padding.left||0}px`,
                            position: "relative"
                        }, R[y.Z.THEME_KEY].blockBackgroundColor ? {
                            backgroundColor: R[y.Z.THEME_KEY].blockBackgroundColor
                        } : {}, h ? {
                            cursor: "pointer"
                        } : {}, {
                            flex: !1 !== (null == F || null == (d = F.data) || null == (d = d.styling) ? void 0 : d.fullWidth) ? "1 0 0" : "0 1 auto"
                        }, !1 === (null == F || null == (p = F.data) || null == (p = p.styling) ? void 0 : p.fullWidth) && {
                            margin: _[null != (g = null == F || null == (I = F.data) ? void 0 : I.styling.alignment) ? g : "center"]
                        })
                    }, H, {
                        ref: Z ? o : $
                    }, s, a, {
                        "data-testid": "form-component",
                        className: v()({
                            notranslate: !1
                        }, l)
                    }), O && c && m && !f ? i().createElement(T, {
                        active: W,
                        componentId: e,
                        componentPosition: t,
                        componentRef: $.current,
                        formVersionCId: n,
                        isHovering: h,
                        rowDroppableHover: r,
                        setIsHovering: V,
                        designerFunctions: c,
                        designerInfo: m
                    }, z) : z)
                })) : null
            };
            var F = ({
                rowId: e,
                formVersionCId: t,
                designerFunctions: n,
                designerInfo: r,
                isA11y: a
            }) => {
                const l = (0, I.Z)((t => {
                        var n;
                        return (null == (n = t.formsState.rows[e]) ? void 0 : n.components) || []
                    }), s.X),
                    c = (0, I.Z)((e => e.onsiteState.client.isDesignWorkflow)),
                    [m, u] = (0, o.useState)(!1),
                    [h, v] = (0, o.useState)(!1),
                    [g, y] = (0, o.useState)(!1),
                    b = (m ? f : h && p) || !1,
                    w = (0, o.useMemo)((() => c ? `${d.Vs}:${d.ij}:${e}` : void 0), [c, e]);
                return l.length ? i().createElement(S.ZC, {
                    a11yIdentifier: w,
                    "data-testid": "form-row",
                    style: Object.assign({
                        display: "flex",
                        flexDirection: "row",
                        alignItems: "stretch",
                        position: "relative"
                    }, b ? Object.assign({}, "bottom" === b ? {
                        borderBottom: "2px",
                        borderBottomStyle: "solid",
                        borderBottomColor: "#2B98D3",
                        marginBottom: "-2px"
                    } : {
                        borderTop: "2px",
                        borderTopStyle: "solid",
                        borderTopColor: "#2B98D3",
                        marginTop: "-2px"
                    }) : {})
                }, l.map(((e, o) => i().createElement($, {
                    key: e,
                    componentId: e,
                    componentPosition: o,
                    formVersionCId: t,
                    rowDroppableHover: (e, t) => {
                        e === f ? u(t) : v(t)
                    },
                    setDragState: e => y(e),
                    dragFinished: g,
                    designerFunctions: n,
                    designerInfo: r,
                    isA11y: a
                }))), null) : null
            };
            const O = ({
                    children: e
                }) => e,
                Z = {
                    .5: "35%",
                    1: "50%",
                    2: "65%"
                };
            var A = ({
                    columnId: e,
                    formVersionCId: t,
                    formVersionId: n,
                    viewId: r,
                    sideImageExistsAndHidden: a,
                    isFullscreen: l,
                    designerFunctions: c,
                    designerInfo: m,
                    isA11y: f
                }) => {
                    var p, h, v, g, y;
                    const b = (0, o.useRef)(null),
                        [w, x] = (0, o.useState)(!1),
                        V = (0, I.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                        _ = (0, I.Z)((e => {
                            var t;
                            return null == (t = e.formsState.formVersions[n]) || null == (t = t.data) ? void 0 : t.sideImage
                        }), s.X),
                        T = (0, I.Z)((t => {
                            var n;
                            return (null == (n = t.formsState.columns[e]) ? void 0 : n.rows) || []
                        }), s.X),
                        k = (0, I.Z)((t => t.formsState.columns[e]), s.X),
                        $ = (0, I.Z)((e => (0, E.l)(e, r)), s.X),
                        A = (0, o.useMemo)((() => V ? `${d.PF}:${d.k_}:${e}` : void 0), [V, e]);
                    if (!k) return null;
                    const M = null == m ? void 0 : m.activeColumnId,
                        {
                            padding: D,
                            minimumHeight: B
                        } = $,
                        N = void 0 !== (null == (p = k.data) || null == (p = p.styling) ? void 0 : p.sizeMultiplier) && 0 === k.rows.length,
                        {
                            columnMargin: j,
                            columnPadding: R
                        } = ((e, t, n, o) => {
                            const i = {
                                    top: 0,
                                    left: 0,
                                    right: 0,
                                    bottom: 0
                                },
                                r = {
                                    top: 0,
                                    left: 0,
                                    right: 0,
                                    bottom: 0
                                };
                            return o || void 0 !== n && (e ? (i.top = t && t.top ? -1 * t.top : 0, i.bottom = t && t.bottom ? -1 * t.bottom : 0, 0 === n ? i.left = t && t.left ? -1 * t.left : 0 : 1 === n && (i.right = t && t.right ? -1 * t.right : 0)) : 0 === n ? r.left = (null == t ? void 0 : t.left) || 0 : 1 === n && (r.right = (null == t ? void 0 : t.right) || 0)), {
                                columnMargin: i,
                                columnPadding: r
                            }
                        })(N, D, null == _ ? void 0 : _.position, a),
                        P = null == (h = k.data) || null == (h = h.styling) ? void 0 : h.sizeMultiplier,
                        L = null == $ ? void 0 : $.size,
                        z = P && L ? ((e, t, n) => {
                            const o = e / (e + 1) * t;
                            return n ? o : t - o
                        })(P, L, N) : 0,
                        W = M === k.columnId,
                        H = (null == $ ? void 0 : $.borderStyle) && "none" !== (null == $ ? void 0 : $.borderStyle) && (null == $ ? void 0 : $.borderWidth) || 0,
                        U = null == (v = k.data) || null == (v = v.styling) ? void 0 : v.backgroundImage,
                        q = null == (g = k.data) || null == (g = g.styling) ? void 0 : g.backgroundColor,
                        K = Object.assign({}, V && N ? {
                            onClick: () => {
                                c && c.setActiveSidebar({
                                    type: d.aC,
                                    key: e
                                })
                            },
                            onMouseOver: () => {
                                x(!0)
                            },
                            onMouseLeave: () => x(!1),
                            ref: b
                        } : {}),
                        G = null == m ? void 0 : m.mobileDesktopType,
                        Y = (null == (y = k.rows) ? void 0 : y.length) > 0 || _ && (0, C.V)(_, V, G || d.q5, k),
                        X = N ? Object.assign({
                            borderColor: "transparent",
                            borderStyle: "solid",
                            borderWidth: $.borderWidth
                        }, 1 === (null == _ ? void 0 : _.position) ? {
                            borderBottomRightRadius: $.borderRadius,
                            borderTopRightRadius: $.borderRadius,
                            marginRight: l ? 0 : j.right - $.borderWidth,
                            borderLeft: 0
                        } : {
                            borderBottomLeftRadius: $.borderRadius,
                            borderTopLeftRadius: $.borderRadius,
                            marginLeft: l ? 0 : j.left - $.borderWidth,
                            borderRight: 0
                        }, {
                            marginBottom: l ? 0 : j.bottom - $.borderWidth,
                            marginTop: l ? 0 : j.top - $.borderWidth,
                            overflow: "hidden"
                        }) : {},
                        J = e => {
                            switch (e) {
                                case "center":
                                    return "center";
                                case "left":
                                case "top":
                                    return "start";
                                case "right":
                                case "bottom":
                                    return "end";
                                default:
                                    return
                            }
                        },
                        Q = e => {
                            switch (e) {
                                case "center":
                                    return "50%";
                                case "right":
                                case "top":
                                    return "0";
                                default:
                                    return
                            }
                        };
                    return Y ? i().createElement(S.ZC, u()({
                        a11yIdentifier: A,
                        title: N || null == U ? void 0 : U.altText,
                        style: Object.assign({
                            display: "flex",
                            flexDirection: "column",
                            width: z ? `${z}px` : "100%",
                            marginTop: `${j.top}px`,
                            marginBottom: `${j.bottom}px`,
                            marginLeft: `${j.left}px`,
                            marginRight: `${j.right}px`,
                            paddingTop: `${R.top}px`,
                            paddingBottom: `${R.bottom}px`,
                            paddingLeft: `${R.left}px`,
                            paddingRight: `${R.right}px`
                        }, X, {
                            backgroundColor: q
                        }, w && {
                            cursor: "pointer"
                        }, z && {
                            minWidth: `${z}px`
                        }, void 0 !== B && !l && {
                            minHeight: `${B}px`
                        }, !N && {
                            justifyContent: "center"
                        }, l && !N && {
                            margin: "0 auto",
                            minWidth: "100px",
                            maxWidth: `${L}px`,
                            width: `${L}px`
                        }, l && P && {
                            position: "relative",
                            maxWidth: Z[P],
                            width: "100%"
                        })
                    }, K), N && U && i().createElement(S.ZC, {
                        a11yIdentifier: A,
                        style: Object.assign({
                            width: "100%",
                            height: "100%",
                            position: "relative"
                        }, "custom" === (null == U ? void 0 : U.position) && (null == U ? void 0 : U.customWidth) < z && {
                            display: "flex",
                            justifyContent: J(null == U ? void 0 : U.alignment) || "center",
                            alignItems: J(null == U ? void 0 : U.verticalAlignment) || "center"
                        })
                    }, i().createElement(S.Ei, {
                        src: null == U ? void 0 : U.url,
                        alt: null == U ? void 0 : U.altText,
                        style: U && Object.assign({}, "custom" === (null == U ? void 0 : U.position) ? Object.assign({
                            width: `${null==U?void 0:U.customWidth}px`,
                            height: "auto"
                        }, (null == U ? void 0 : U.customWidth) > z && {
                            position: "absolute",
                            left: "left" === (null == U ? void 0 : U.alignment) ? 0 : void 0,
                            right: Q(null == U ? void 0 : U.alignment),
                            top: Q(null == U ? void 0 : U.verticalAlignment),
                            bottom: "bottom" === (null == U ? void 0 : U.verticalAlignment) ? 0 : void 0,
                            transform: `translate(${"center"===(null==U?void 0:U.alignment)?"50%":0}, ${"center"===(null==U?void 0:U.verticalAlignment)?"-50%":0})`
                        }) : {
                            width: "100%",
                            height: "100%",
                            objectFit: null == U ? void 0 : U.position,
                            objectPosition: `${(null==U?void 0:U.alignment)||"center"} ${(null==U?void 0:U.verticalAlignment)||"center"}`
                        })
                    })), i().createElement(O, {
                        backgroundColorExists: !!q,
                        backgroundImageExists: !!U,
                        calculatedWidth: z,
                        column: k,
                        isDesignWorkflow: V,
                        isHovering: w,
                        isSelected: W,
                        isSideImageColumn: N,
                        viewBorderWidth: H,
                        viewSize: L,
                        isFullscreen: l
                    }, null == T ? void 0 : T.map((e => i().createElement(F, {
                        key: e,
                        rowId: e,
                        formVersionCId: t,
                        designerFunctions: c,
                        designerInfo: m,
                        isA11y: f
                    }))))) : null
                },
                M = n(67555),
                D = n(61471),
                B = n(14377);
            let N, j = e => e;
            const R = {
                    left: {
                        float: "left"
                    },
                    center: {
                        margin: "0 auto"
                    },
                    right: {
                        float: "right"
                    }
                },
                P = (e, t, n) => t ? null != n && n.includes("BOTTOM") ? `${e}px ${e}px 0 0` : `0 0 ${e}px ${e}px` : `${e}px`;
            var L = ({
                    viewId: e,
                    isEmbed: t,
                    formVersionId: n,
                    formVersionCId: m,
                    isDocked: u,
                    formTypeDirection: f,
                    designerFunctions: p,
                    designerInfo: h,
                    isA11y: v
                }) => {
                    var g, y;
                    const b = (0, I.Z)((e => {
                            var t;
                            return null == (t = e.formsState.formVersions[n]) ? void 0 : t.formId
                        })),
                        w = (0, I.Z)((e => {
                            var t;
                            return null == (t = e.formsState.formVersions[n]) ? void 0 : t.formType
                        })),
                        x = (0, I.Z)((t => t.formsState.views[e] ? Object.values(t.formsState.columns).filter((e => !!e)).filter((n => {
                            var o;
                            return null == (o = t.formsState.views[e]) ? void 0 : o.columns.includes(n.columnId)
                        })).sort(((e, t) => e.position - t.position)) : []), s.X),
                        V = (0, I.Z)((e => {
                            const t = x.reduce(((e, t) => (t.rows.forEach((t => {
                                e.push(t)
                            })), e)), []).reduce(((t, n) => {
                                var o;
                                return null == (o = e.formsState.rows[n]) || o.components.forEach((e => {
                                    t.push(e)
                                })), t
                            }), []).map((t => e.formsState.components[t]));
                            return Object.values(e.formsState.actions || {}).filter((e => !!e && t.find((t => (null == t ? void 0 : t.actionId) === e.actionId && l.NB.has(e.actionType)))))
                        }), s.X),
                        _ = (0, I.Z)((t => (0, E.l)(t, e)), s.X),
                        T = (0, I.Z)((e => {
                            var t;
                            return null == (t = e.formsState.formVersions[n]) || null == (t = t.data) ? void 0 : t.sideImage
                        }), s.X),
                        k = (0, I.Z)((t => Object.values(t.formsState.columns).filter((t => (null == t ? void 0 : t.viewId) === e)).find((e => (null == e ? void 0 : e.position) === (null == T ? void 0 : T.position))))),
                        $ = null == T || null == (g = T.data) || null == (g = g.styling) ? void 0 : g.sizeMultiplier,
                        F = $ ? (0, M.Z)($, _.size) : 0,
                        O = (0, I.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                        Z = null == h ? void 0 : h.mobileDesktopType,
                        L = T && !(0, C.V)(T, O, Z || d.q5, k),
                        z = _.isReflow,
                        W = L ? _.size - F : void 0,
                        H = (0, o.useMemo)((() => O ? `${d.Sq}:${d.Pg}:${e}` : void 0), [O, e]),
                        U = w === D.DV && z ? {
                            minWidth: `${c.Gg}px`,
                            maxWidth: `${W||_.size}px`
                        } : {
                            width: `${W||_.size}px`,
                            minWidth: `${c.Gg}px`,
                            maxWidth: `${c.Ez}px`
                        };
                    let q;
                    return q = t ? _.isFullPageEmbed ? {
                        width: "100%",
                        overflow: "hidden",
                        height: "fit-content",
                        minHeight: "100%"
                    } : Object.assign({
                        width: "100%",
                        overflow: "visible"
                    }, _.isMaxWidth ? {
                        maxWidth: `${_.size}px`
                    } : {}, _.embedAlignment ? R[_.embedAlignment] : {}) : w !== D.UW && w !== D.Mk ? U : {
                        overflow: "auto",
                        height: "fit-content",
                        minHeight: "100%"
                    }, i().createElement(S.l0, {
                        a11yIdentifier: H,
                        "aria-live": "polite",
                        style: Object.assign({
                            display: "flex",
                            flexDirection: "row",
                            boxSizing: "border-box"
                        }, q, {
                            borderRadius: `${P(_.borderRadius,u,f)}`,
                            borderStyle: _.borderStyle,
                            borderWidth: `${_.borderWidth||0}px`,
                            borderColor: _.borderColor,
                            backgroundColor: _.backgroundColor,
                            backgroundImage: _.backgroundImage ? `url(${_.backgroundImage.url})` : void 0,
                            backgroundRepeat: "no-repeat",
                            backgroundSize: _.backgroundImage && ("custom" === _.backgroundImage.position ? `${_.backgroundImage.customWidth}px` : _.backgroundImage.position) || void 0,
                            backgroundPositionX: _.backgroundImage ? _.backgroundImage.alignment : void 0,
                            backgroundPositionY: (null == (y = _.backgroundImage) ? void 0 : y.verticalAlignment) || "center",
                            paddingTop: _.isFullPageEmbed ? 0 : `${_.padding.top}px`,
                            paddingRight: _.isFullPageEmbed ? 0 : `${_.padding.right}px`,
                            paddingBottom: _.isFullPageEmbed ? 0 : `${_.padding.bottom}px`,
                            paddingLeft: _.isFullPageEmbed ? 0 : `${_.padding.left}px`,
                            flex: 1
                        }),
                        className: `klaviyo-form klaviyo-form-version-cid_${m} ${(0,r.iv)(N||(N=j`
        &&& {
          [href]:focus-visible {
            outline-width: 2px;
            outline-style: auto;
            outline-color: ${0};
          }
        }
      `),_.focusColor)}`,
                        "data-testid": `klaviyo-form-${b}`,
                        noValidate: !0,
                        onSubmit: async e => {
                            if (e.preventDefault(), 1 !== V.length) return !1;
                            const t = V[0];
                            if (!t) return !1;
                            const {
                                actionId: n
                            } = t, o = (0, a.j)({
                                actionId: n,
                                formVersionCId: m,
                                getState: I.Z.getState
                            });
                            return await new o({
                                actionId: n,
                                formVersionCId: m,
                                getState: I.Z.getState
                            }).runAction(), !0
                        }
                    }, i().createElement(B.y, {
                        formType: w,
                        style: {
                            display: "flex"
                        }
                    }, x.map((t => i().createElement(A, {
                        key: t.columnId,
                        columnId: t.columnId,
                        formVersionCId: m,
                        formVersionId: n,
                        viewId: e,
                        sideImageExistsAndHidden: L,
                        isFullscreen: w === D.UW || _.isFullPageEmbed,
                        designerFunctions: p,
                        designerInfo: h,
                        isA11y: v
                    }))), i().createElement("input", {
                        style: {
                            display: "none"
                        },
                        type: "submit",
                        tabIndex: -1,
                        value: "Submit"
                    })))
                },
                z = L
        },
        88058: function(e, t, n) {
            n.r(t), n.d(t, {
                default: function() {
                    return X
                }
            });
            var o = n(23409),
                i = n(81955),
                r = n(18359),
                s = n.n(r),
                a = n(67895),
                l = n.n(a),
                d = (n(92461), n(70818), n(60873), n(61099), n(23034)),
                c = n(68502),
                m = n(61471),
                u = n(12616),
                f = (n(39265), n(85912)),
                p = n(42376),
                h = n(26178),
                v = n(47774),
                g = n(30847),
                y = n(38612);
            let I, b, S = e => e;
            var w = ({
                dynamicButtonId: e,
                a11yIdentifierBlock: t,
                onClick: n
            }) => {
                const i = (0, c.Z)((t => {
                        var n;
                        return t.formsState.dynamicButtons && (null == (n = t.formsState.dynamicButtons[e]) || null == (n = n.data) ? void 0 : n.label)
                    })),
                    a = (0, c.Z)((t => {
                        var n;
                        return t.formsState.dynamicButtons && (null == (n = t.formsState.dynamicButtons[e]) || null == (n = n.data) ? void 0 : n.textStyles)
                    })),
                    l = (0, c.Z)((t => {
                        var n;
                        return t.formsState.dynamicButtons && (null == (n = t.formsState.dynamicButtons[e]) || null == (n = n.data) ? void 0 : n.buttonStyles)
                    })),
                    d = (0, r.useMemo)((() => null != l && l.alignment ? "left" === (null == l ? void 0 : l.alignment) ? "justify-self: left; align-self: start;" : "right" === (null == l ? void 0 : l.alignment) ? "justify-self: right; align-self: end;" : "justify-self: center; align-self: center;" : "justify-self: center; align-self: center;"), [l]),
                    m = (0, r.useMemo)((() => {
                        var e, t, n, i, r, s, c, m, u, f, p, h, v, g, y, w, C, E, x, V;
                        return {
                            outerDiv: (0, o.iv)(I || (I = S `
        &&& {
          & {
            ${0}
          }
        }
      `), "fitToText" === (null == l ? void 0 : l.width) ? d : ""),
                            button: (0, o.iv)(b || (b = S `
        &&& {
          & {
            text-align: center;
            color: ${0};
            font-family: ${0};
            font-size: ${0}px;
            font-style: ${0};
            font-weight: ${0};
            letter-spacing: ${0}px;
            text-decoration: ${0};

            background-color: ${0};
            border-radius: ${0}px;
            height: ${0}px;

            width: ${0};
            ${0}
            cursor: pointer;

            ${0}

            ${0}
          }
        }
      `), null != (e = null == a ? void 0 : a.fontColor) ? e : "#FFFFFF", null != (t = null == a ? void 0 : a.fontFamily) ? t : "", null != (n = null == a ? void 0 : a.fontSize) ? n : 16, null != (i = null == a ? void 0 : a.fontStyle) ? i : "", null != (r = null == a ? void 0 : a.fontWeight) ? r : "", null != (s = null == a ? void 0 : a.letterSpacing) ? s : 0, null != (c = null == a ? void 0 : a.textDecoration) ? c : "", null != (m = null == l ? void 0 : l.color) ? m : "#000000", null != (u = null == l ? void 0 : l.borderRadius) ? u : 4, null != (f = null == l ? void 0 : l.height) ? f : 44, "fitToText" === (null == l ? void 0 : l.width) ? "fit-content" : "100%", "fitToText" === (null == l ? void 0 : l.width) ? "padding: 0 10px;" : "", null != l && null != (p = l.border) && p.enabled ? `\n                  border-style: ${null!=(h=null==l||null==(v=l.border)?void 0:v.style)?h:"solid"};\n                  border-width: ${null!=(g=null==l||null==(y=l.border)?void 0:y.width)?g:1}px;\n                  border-color: ${null!=(w=null==l||null==(C=l.border)?void 0:C.color)?w:"#000000"};\n                ` : "", null != l && null != (E = l.dropShadow) && E.enabled ? `\n                  filter: drop-shadow(0px 0px 15px ${null!=(x=null==l||null==(V=l.dropShadow)?void 0:V.color)?x:"#000000"});\n                ` : "")
                        }
                    }), [a, l, d]);
                return s().createElement(y.ZC, {
                    a11yIdentifier: t,
                    className: m.outerDiv
                }, s().createElement(y.zx, {
                    a11yIdentifier: t,
                    type: "button",
                    className: m.button,
                    onClick: n
                }, i))
            };
            var C = () => {
                    const e = (0, c.Z)((e => e.onsiteState.bisPortalConfig));
                    (0, r.useEffect)((() => {
                        e && !document.getElementById(g.M) && (0, h.m)()
                    }), [e]);
                    const t = (0, r.useCallback)((() => {
                        if (e) {
                            const t = c.Z.getState(),
                                n = t.onsiteState.client.klaviyoCompanyId;
                            if (n) {
                                const o = (0, f.Z)(),
                                    i = e.formVersionId,
                                    r = Object.values(t.formsState.formVersions).find((e => (null == e ? void 0 : e.formVersionId) === i)),
                                    s = null == r ? void 0 : r.formId;
                                s && (0, p.M)({
                                    metric: v.qA,
                                    formVersionCId: o,
                                    formId: s,
                                    companyId: n
                                })
                            }
                        }
                        null == e || null == e.onClick || e.onClick()
                    }), [e]);
                    if (!e) return null;
                    const n = document.getElementById(g.M);
                    return n ? s().createPortal(s().createElement(w, {
                        dynamicButtonId: e.dynamicButtonId,
                        a11yIdentifierBlock: `bis-button-${e.formVersionId}`,
                        onClick: t
                    }), n) : null
                },
                E = n(78315),
                x = n(22074),
                V = n(85301);
            var _ = e => {
                    const [t, n] = (0, r.useState)(!1), [o, i] = (0, r.useState)(!1), s = (0, r.useRef)(null);
                    return (0, r.useEffect)((() => {
                        const t = s.current,
                            r = new IntersectionObserver((e => {
                                const [t] = e;
                                n(t.isIntersecting), t.isIntersecting && !o && i(!0)
                            }), e);
                        return t && r.observe(t), () => {
                            t && r.unobserve(t)
                        }
                    }), [e, o]), [s, {
                        isInView: t,
                        hasBeenViewed: o
                    }]
                },
                T = n(57511);
            var k = ({
                    node: e,
                    formVersionCId: t,
                    designerFunctions: n,
                    designerInfo: o,
                    isA11y: i = !1,
                    a11yViewId: a
                }) => {
                    const [l, {
                        hasBeenViewed: d
                    }] = _({
                        threshold: .1
                    }), m = (0, c.Z)((e => {
                        var n;
                        return null == (n = e.onsiteState.openFormVersions[t]) ? void 0 : n.closed
                    })), u = (0, c.Z)((e => {
                        var n;
                        return null == (n = e.onsiteState.openFormVersions[t]) ? void 0 : n.formId
                    })), f = (0, c.Z)((e => {
                        var n;
                        return null == (n = e.onsiteState.openFormVersions[t]) ? void 0 : n.currentViewId
                    })), h = (0, c.Z)((e => {
                        var n;
                        return null == (n = e.onsiteState.openFormVersions[t]) ? void 0 : n.errorViewMessage
                    })), g = (0, c.Z)((e => {
                        var n;
                        return null == (n = e.onsiteState.openFormVersions[t]) ? void 0 : n.formVersionId
                    })), I = (0, c.Z)((e => e.onsiteState.client.klaviyoCompanyId));
                    (0, r.useEffect)((() => {
                        if (!d || !g) return;
                        const e = c.Z.getState(),
                            n = (0, T.Xk)(e, g);
                        n && ((0, p.M)({
                            metric: v.PZ,
                            formVersionCId: t,
                            logCustomEvent: !0,
                            formId: null != u ? u : "",
                            companyId: null != I ? I : "",
                            allowReTriggering: !1
                        }), (0, p.M)({
                            metric: v.n5,
                            formVersionCId: t,
                            logCustomEvent: !0,
                            formId: null != u ? u : "",
                            companyId: null != I ? I : "",
                            step_name: (0, T.E5)(e, n.viewId),
                            step_number: 1
                        }))
                    }), [u, t, d, I, g]);
                    const b = e || document.querySelector(`div.klaviyo-form-${u}.form-version-cid-${t}`),
                        S = (0, r.useMemo)((() => n ? `${V.Sq}:${V.Pg}:${f}` : void 0), [n, f]);
                    return b && !m ? (0, r.createPortal)(f && g ? s().createElement(s().Fragment, null, h ? s().createElement(x.Z, {
                        isEmbed: !0,
                        errorViewMessage: h
                    }) : s().createElement(y.ZC, {
                        ref: l,
                        a11yIdentifier: S,
                        style: Object.assign({
                            transform: "translate(0, 0)"
                        }, i ? {
                            position: "absolute",
                            transform: "scale(0.001)",
                            zIndex: 1
                        } : {})
                    }, s().createElement(E.Z, {
                        formVersionCId: t,
                        formVersionId: g,
                        viewId: a || f,
                        isEmbed: !0,
                        key: t,
                        designerFunctions: n,
                        designerInfo: o
                    }))) : null, b) : null
                },
                $ = n(67453);
            var F = n(46516).Z,
                O = n(49064);
            var Z, A, M, D, B, N, j = n(68973).Z;

            function R() {
                return R = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var o in n)({}).hasOwnProperty.call(n, o) && (e[o] = n[o])
                    }
                    return e
                }, R.apply(null, arguments)
            }
            var P, L = function(e) {
                return r.createElement("svg", R({
                    width: 167,
                    height: 182,
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg"
                }, e), Z || (Z = r.createElement("path", {
                    d: "M103.52 3.036C88.562 8.51 70.961 5.635 61.51 2.751c-1.859-.567-3.876-.444-5.586.478L5.884 30.212a6.744 6.744 0 0 0-3.122 8.281l7.907 21.32a6.744 6.744 0 0 0 6.323 4.4H27.06a6.744 6.744 0 0 1 6.744 6.743v96.876c0 2.882 1.827 5.464 4.59 6.286 34.048 10.129 71.284 4.898 89.945-.094 2.833-.757 4.708-3.363 4.708-6.294V70.956a6.744 6.744 0 0 1 6.744-6.744h10.067a6.744 6.744 0 0 0 6.323-4.398l7.884-21.256a6.743 6.743 0 0 0-3.192-8.317L109.514 3.316c-1.849-.97-4.033-.997-5.994-.28Z",
                    fill: "#E9E9E9"
                })), A || (A = r.createElement("path", {
                    d: "M55.124 1.746C57.272.587 59.76.456 62 1.139c9.305 2.839 26.483 5.603 40.94.315 2.339-.856 5.025-.853 7.356.369l51.359 26.925a8.429 8.429 0 0 1 3.989 10.397l-7.883 21.256a8.43 8.43 0 0 1-7.904 5.498h-10.067a5.058 5.058 0 0 0-5.058 5.058v96.773c0 3.644-2.34 6.956-5.958 7.923-18.824 5.035-56.403 10.333-90.862.081-3.515-1.046-5.795-4.314-5.795-7.902V70.957a5.058 5.058 0 0 0-5.058-5.058H16.992A8.43 8.43 0 0 1 9.089 60.4L1.18 39.08a8.43 8.43 0 0 1 3.902-10.351l50.04-26.983Zm5.893 2.618c-1.476-.45-3.022-.336-4.293.35L6.684 31.697a5.058 5.058 0 0 0-2.342 6.21l7.908 21.321a5.058 5.058 0 0 0 4.742 3.299H27.06a8.43 8.43 0 0 1 8.43 8.43v96.875c0 2.177 1.375 4.072 3.385 4.67 33.637 10.007 70.53 4.842 89.029-.106 2.046-.547 3.457-2.446 3.457-4.666V70.957a8.43 8.43 0 0 1 8.43-8.43h10.067a5.057 5.057 0 0 0 4.742-3.299l7.884-21.255a5.057 5.057 0 0 0-2.394-6.239L108.731 4.81c-1.368-.717-3.049-.768-4.632-.189-15.46 5.656-33.483 2.673-43.082-.256Z",
                    fill: "#FEFEFE"
                })), M || (M = r.createElement("path", {
                    d: "m47.798 7.494 8.058-3.172c27.568 8.906 44.674 2.115 52.591 0l9.33 3.172c-29.264 13.368-58.104 5.287-69.979 0ZM140.68 65.395l14.723-38.17 9.452 6.362-11.451 30.536-12.724 1.272ZM26.169 65.395l-13.572-38.17L.72 33.863l10.18 28.988 15.268 2.544Z",
                    fill: "#D5D5D6"
                })), D || (D = r.createElement("path", {
                    d: "M55.124 1.746C57.272.587 59.76.456 62 1.139c9.305 2.839 26.483 5.603 40.94.315 2.339-.856 5.025-.853 7.356.369l51.359 26.925a8.429 8.429 0 0 1 3.989 10.397l-7.883 21.256a8.43 8.43 0 0 1-7.904 5.498h-10.067a5.058 5.058 0 0 0-5.058 5.058v96.773c0 3.644-2.34 6.956-5.958 7.923-18.824 5.035-56.403 10.333-90.862.081-3.515-1.046-5.795-4.314-5.795-7.902V70.957a5.058 5.058 0 0 0-5.058-5.058H16.992A8.43 8.43 0 0 1 9.089 60.4L1.18 39.08a8.43 8.43 0 0 1 3.902-10.351l50.04-26.983Zm5.893 2.618c-1.476-.45-3.022-.336-4.293.35L6.684 31.697a5.058 5.058 0 0 0-2.342 6.21l7.908 21.321a5.058 5.058 0 0 0 4.742 3.299H27.06a8.43 8.43 0 0 1 8.43 8.43v96.875c0 2.177 1.375 4.072 3.385 4.67 33.637 10.007 70.53 4.842 89.029-.106 2.046-.547 3.457-2.446 3.457-4.666V70.957a8.43 8.43 0 0 1 8.43-8.43h10.067a5.057 5.057 0 0 0 4.742-3.299l7.884-21.255a5.057 5.057 0 0 0-2.394-6.239L108.731 4.81c-1.368-.717-3.049-.768-4.632-.189-15.46 5.656-33.483 2.673-43.082-.256Z",
                    fill: "#DEE2E4"
                })), B || (B = r.createElement("path", {
                    d: "M112.689 76.847c0 16.162-13.102 29.264-29.264 29.264-16.163 0-29.265-13.102-29.265-29.264s13.102-29.264 29.264-29.264c16.163 0 29.265 13.102 29.265 29.264Z",
                    fill: "#D5D5D6"
                })), N || (N = r.createElement("path", {
                    d: "M82.195 59.008c.388-1.193 2.075-1.193 2.463 0l3.334 10.261c.173.534.67.895 1.231.895h10.79c1.254 0 1.776 1.605.761 2.342l-8.729 6.342c-.454.33-.644.914-.47 1.448l3.334 10.26c.387 1.194-.978 2.186-1.993 1.448l-8.728-6.341a1.295 1.295 0 0 0-1.523 0l-8.728 6.341c-1.015.738-2.38-.254-1.993-1.447l3.334-10.261a1.295 1.295 0 0 0-.47-1.448l-8.729-6.342c-1.015-.737-.493-2.342.761-2.342h10.79c.56 0 1.058-.361 1.231-.895l3.334-10.261Z",
                    fill: "#FEFEFE"
                })))
            };

            function z() {
                return z = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var o in n)({}).hasOwnProperty.call(n, o) && (e[o] = n[o])
                    }
                    return e
                }, z.apply(null, arguments)
            }
            var W, H = function(e) {
                return r.createElement("svg", z({
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none",
                    viewBox: "0 0 24 24"
                }, e), P || (P = r.createElement("path", {
                    fill: "currentColor",
                    fillRule: "evenodd",
                    d: "M11 3a8 8 0 1 0 4.906 14.32l3.887 3.887 1.414-1.414-3.887-3.887A8 8 0 0 0 11 3Zm-6 8a6 6 0 1 1 12 0 6 6 0 0 1-12 0Z",
                    clipRule: "evenodd"
                })))
            };

            function U() {
                return U = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var o in n)({}).hasOwnProperty.call(n, o) && (e[o] = n[o])
                    }
                    return e
                }, U.apply(null, arguments)
            }
            var q = function(e) {
                return r.createElement("svg", U({
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none",
                    viewBox: "0 0 24 24"
                }, e), W || (W = r.createElement("path", {
                    fill: "currentColor",
                    fillRule: "evenodd",
                    d: "M2.5 3a1 1 0 0 1 1-1h3.28l.5 2h10.334c2.095 0 3.544 2.092 2.809 4.053L18.193 14H7.118l-.276.553A1 1 0 0 0 7.736 16H18.5a3 3 0 1 1-2.83 2h-5.34a3 3 0 1 1-4.94-1.131 2.984 2.984 0 0 1-.337-3.21L5.882 12h1.337l-2-8H3.5a1 1 0 0 1-1-1Zm16 15a1 1 0 1 0 0 2 1 1 0 0 0 0-2ZM7.78 6l1.5 6h7.527l1.743-4.649A1 1 0 0 0 17.614 6H7.781ZM6.5 19a1 1 0 1 1 2 0 1 1 0 0 1-2 0Z",
                    clipRule: "evenodd"
                })))
            };
            var K = ({
                dynamicButtonId: e
            }) => s().createElement("div", {
                style: {
                    zIndex: "1",
                    display: "flex",
                    flex: 1,
                    width: "100%",
                    alignItems: "flex-start",
                    justifyContent: "center",
                    padding: "96px 0px",
                    backgroundColor: "var(--color-surface-app-background)"
                }
            }, s().createElement("div", {
                style: {
                    display: "flex",
                    flex: 1,
                    flexDirection: "column",
                    width: "100%",
                    maxWidth: "880px",
                    overflow: "hidden",
                    borderRadius: "12px",
                    border: "1px solid var(--color-border-general-subtle)",
                    backgroundColor: "var(--color-surface-primary-base)"
                }
            }, s().createElement("div", {
                style: {
                    display: "flex",
                    width: "100%",
                    height: "60px",
                    alignItems: "center",
                    padding: "0px 24px",
                    backgroundColor: "var(--color-background-input-base)"
                }
            }, s().createElement("div", {
                style: {
                    width: "10%",
                    height: "16px",
                    borderRadius: "var(--unit-border-radius-sm)",
                    backgroundColor: "var(--color-background-neutral-subtle-base)"
                }
            })), s().createElement("div", {
                style: {
                    display: "flex",
                    flex: 1,
                    width: "100%",
                    padding: "16px 24px",
                    alignItems: "center",
                    gap: "12px",
                    backgroundColor: "var(--color-background-neutral-subtle-base)",
                    color: "var(--color-background-neutral-subtle-selected)"
                }
            }, s().createElement("div", {
                style: {
                    display: "flex",
                    height: "8px",
                    width: "44px",
                    borderRadius: "var(--unit-border-radius-lg)",
                    backgroundColor: "var(--color-background-neutral-subtle-focused)"
                }
            }), s().createElement("div", {
                style: {
                    display: "flex",
                    height: "8px",
                    width: "44px",
                    borderRadius: "var(--unit-border-radius-lg)",
                    backgroundColor: "var(--color-background-neutral-subtle-focused)"
                }
            }), s().createElement("div", {
                style: {
                    display: "flex",
                    height: "8px",
                    width: "44px",
                    borderRadius: "var(--unit-border-radius-lg)",
                    backgroundColor: "var(--color-background-neutral-subtle-focused)"
                }
            }), s().createElement("div", {
                style: {
                    display: "flex",
                    flex: 1,
                    flexGrow: "0.95"
                }
            }), s().createElement("span", {
                style: {
                    width: "20px",
                    height: "20px"
                }
            }, s().createElement(H, null)), s().createElement("span", {
                style: {
                    width: "20px",
                    height: "20px",
                    paddingRight: "5px"
                }
            }, s().createElement(q, null))), s().createElement("div", {
                style: {
                    display: "flex",
                    width: "100%"
                }
            }, s().createElement("div", {
                style: {
                    display: "flex",
                    flex: 1,
                    flexDirection: "row",
                    backgroundColor: "var(--color-background-input-base)"
                }
            }, s().createElement("div", {
                style: {
                    display: "flex",
                    flex: 1,
                    width: "100%",
                    padding: "48px 0 64px 48px",
                    alignItems: "center",
                    justifyContent: "center"
                }
            }, s().createElement("div", {
                style: {
                    padding: "48px",
                    borderRadius: "var(--unit-border-radius-xl)",
                    backgroundColor: "var(--color-background-neutral-subtle-base)"
                }
            }, s().createElement(L, null))), s().createElement("div", {
                style: {
                    display: "flex",
                    flex: 1,
                    flexDirection: "column",
                    padding: "48px 64px 24px 24px",
                    gap: "12px"
                }
            }, s().createElement("div", {
                style: {
                    display: "flex",
                    width: "100%",
                    height: "16px",
                    borderRadius: "var(--unit-border-radius-sm)",
                    backgroundColor: "var(--color-background-neutral-subtle-base)"
                }
            }, " "), s().createElement("div", {
                style: {
                    display: "flex",
                    width: "100%",
                    height: "16px",
                    borderRadius: "var(--unit-border-radius-sm)",
                    backgroundColor: "var(--color-background-neutral-subtle-base)"
                }
            }, " "), s().createElement("div", {
                style: {
                    display: "flex",
                    width: "30%",
                    height: "16px",
                    borderRadius: "var(--unit-border-radius-sm)",
                    backgroundColor: "var(--color-background-neutral-subtle-base)"
                }
            }, " "), s().createElement(w, {
                dynamicButtonId: e
            }))))));
            var G = ({
                formVersionCId: e,
                node: t,
                designerFunctions: n,
                designerInfo: o
            }) => {
                const i = (0, c.Z)((e => !!e.onsiteState.client.isDesignWorkflow)),
                    r = (0, c.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.formVersionId
                    })),
                    a = (0, c.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.currentTeaserId
                    })),
                    l = (0, c.Z)((t => {
                        var n;
                        return null == (n = t.onsiteState.openFormVersions[e]) ? void 0 : n.currentDynamicButtonId
                    })),
                    d = (0, c.Z)((e => (e.formsState.teasers ? Object.values(e.formsState.teasers).filter((e => (null == e ? void 0 : e.formVersionId) === r)) : []).length > 0));
                if (i && null === t) return null;
                const m = r => {
                    const c = s().createElement(j, {
                            formVersionCId: e,
                            closePortal: i ? () => {} : r,
                            designerFunctions: n,
                            designerInfo: o
                        }),
                        m = s().createElement(F, {
                            formVersionCId: e,
                            closePortal: i ? () => {} : r,
                            designerFunctions: n,
                            designerInfo: o,
                            portalNode: t
                        });
                    return i ? l ? s().createElement(K, {
                        dynamicButtonId: l
                    }) : a ? c : m : s().createElement(s().Fragment, null, d && c, m)
                };
                return s().createElement($.Z, {
                    key: e,
                    defaultOpen: !0,
                    onClose: () => {
                        const t = c.Z.getState().onsiteState.openFormVersions[e];
                        (0, O.zd)({
                            formVersionCId: e,
                            isTeaserDismissing: null == t ? void 0 : t.closeModalWhenAnimationCompletes
                        })
                    },
                    closeOnEsc: !i,
                    node: i ? t : void 0
                }, (({
                    closePortal: e,
                    portal: t
                }) => [t(m(e))]))
            };
            var Y = () => {
                const e = (0, c.Z)((e => Object.keys(e.onsiteState.openFormVersions)), d.X),
                    t = (0, c.Z)((e => Object.values(e.onsiteState.openFormVersions).filter((e => !!e)).filter((({
                        formVersionId: t
                    }) => {
                        var n;
                        return (null == (n = e.formsState.formVersions[t]) ? void 0 : n.formType) === m.LP
                    })).map((({
                        formVersionCId: e
                    }) => e))), d.X),
                    n = (0, c.Z)((e => {
                        const t = e.formsState.dynamicButtons;
                        return !!t && Object.values(t).some((e => (null == e ? void 0 : e.type) === u.I))
                    }), d.X);
                return s().createElement(r.Suspense, {
                    fallback: s().createElement("div", null)
                }, n && s().createElement(C, null), e.map((e => {
                    const n = {
                        formVersionCId: e
                    };
                    return t.includes(e) ? s().createElement(k, l()({
                        key: e
                    }, n)) : s().createElement(G, l()({
                        key: e
                    }, n))
                })))
            };
            (0, o.cY)(i.h);
            var X = () => {
                if (document.getElementById("dynamic-react-root")) return;
                const e = document.createElement("div");
                e.setAttribute("id", "dynamic-react-root"), document.body.appendChild(e), (0, r.render)(s().createElement(Y, null), e)
            }
        },
        40823: function(e, t, n) {
            n.d(t, {
                e: function() {
                    return V
                }
            });
            n(92461), n(44159), n(60873);
            var o = n(93111),
                i = n(2609),
                r = n(22982),
                s = n(42376),
                a = n(49064),
                l = n(68502),
                d = n(57511),
                c = n(10386);
            var m = n(13062),
                u = n(72626),
                f = n(24745),
                p = n(6138),
                h = n(24878),
                v = n(39355);
            const g = "form-view",
                y = "form-version";
            class I extends Error {
                constructor() {
                    super(), this.constructor = I, Object.setPrototypeOf(this, I.prototype), this.message = "No outcome_view_id return in in response from API"
                }
            }
            const b = ({
                    formVersionId: e,
                    formViewId: t,
                    profile: n,
                    companyId: o
                }) => {
                    const i = (({
                        formVersionId: e,
                        formViewId: t,
                        profile: n
                    }) => ({
                        data: {
                            type: "form-outcome-view",
                            attributes: {
                                profile: {
                                    data: {
                                        type: "profile",
                                        attributes: {
                                            email: n.email,
                                            phone_number: n.phoneNumber,
                                            _kx: n._kx
                                        }
                                    }
                                }
                            },
                            relationships: {
                                [y]: {
                                    data: {
                                        type: y,
                                        id: e
                                    }
                                },
                                [g]: {
                                    data: {
                                        type: g,
                                        id: t
                                    }
                                }
                            }
                        }
                    }))({
                        formVersionId: e,
                        formViewId: t,
                        profile: n
                    });
                    return (0, f.W)((() => ((e, t) => fetch(`https://a.klaviyo.com/client/form-outcome-views/?company_id=${e}`, {
                        method: "POST",
                        headers: Object.assign({
                            "Access-Control-Allow-Headers": "*",
                            "Content-Type": "application/json"
                        }, (0, u.h)(), {
                            revision: "2025-01-15"
                        }),
                        body: JSON.stringify(t)
                    }))(o, i)), 5, 1e3 + 1e3 * Math.random(), [429])
                },
                S = async e => {
                    var t;
                    let n;
                    const o = e => {
                        var t, o;
                        (t = e) instanceof CustomEvent && (null == (o = t.detail) ? void 0 : o.captchaUrl) && (window.DataDomeCaptchaDisplayed = !0, n = e.detail.captchaUrl)
                    };
                    window.addEventListener(v.Pp, o, !1), await (0, h.l)();
                    const i = await b(e);
                    if (window.removeEventListener(v.Pp, o, !1), n) throw new p.a({
                        captchaUrl: n
                    });
                    if (429 === i.status) throw new p.TT;
                    if (202 !== i.status) throw new I;
                    const r = await i.json();
                    if (null == r || null == (t = r.data) || null == (t = t.attributes) || !t.outcome_view_id) throw new I;
                    return r
                };
            var w = n(55306),
                C = n(89331),
                E = n(7385),
                x = n(47774);
            class V {
                constructor(e, t) {
                    this.openFormVersion = void 0, this.identifiers = void 0, this.profile = {}, this.openFormVersion = e, this.identifiers = t
                }
                checkForViewSideEffects(e) {
                    return {
                        componentSideEffects: this.getComponentSideEffects(e)
                    }
                }
                runViewSideEffects(e) {
                    return e.componentSideEffects.map((({
                        component: e,
                        viewIds: t
                    }) => this.handleComponentSideEffect({
                        component: e,
                        viewIds: t
                    })))
                }
                checkAndRunViewSideEffects(e) {
                    const t = this.checkForViewSideEffects(e);
                    return this.runViewSideEffects(t)
                }
                getComponentSideEffects({
                    state: e
                }) {
                    const t = this.openFormVersion.currentViewId,
                        n = (0, d.nC)(e, t);
                    return (0, o.Z)(n.map((t => {
                        if (!t) return null;
                        const n = (0, c.D)(e, t.componentId);
                        return n.length < 1 ? null : {
                            component: t,
                            viewIds: n
                        }
                    })))
                }
                handleComponentSideEffect({
                    component: e,
                    viewIds: t
                }) {
                    return "SPIN_TO_WIN" === e.componentType ? this.handleSpinToWin({
                        component: e,
                        viewIds: t
                    }) : console.warn(`Unhandled component type: ${e.componentType}`)
                }
                async handleSpinToWin({
                    component: e,
                    viewIds: t
                }) {
                    var n, o;
                    if ("SPIN_TO_WIN" !== e.componentType) throw new Error("Invalid component type");
                    const s = l.Z.getState(),
                        d = s.onsiteState.client.klaviyoCompanyId,
                        {
                            formVersionId: c,
                            currentViewId: u
                        } = this.openFormVersion,
                        f = (0, i.zy)();
                    if (this.profile = {
                            email: null != (n = this.identifiers.$email) ? n : f.$email,
                            phoneNumber: null != (o = this.identifiers.$phone_number) ? o : f.$phone_number,
                            _kx: f.$exchange_id
                        }, !d || !c || !u) return null;
                    try {
                        var p, h;
                        const e = await S({
                                companyId: d,
                                formVersionId: c,
                                formViewId: u,
                                profile: this.profile
                            }),
                            n = null == e || null == (p = e.data) || null == (p = p.attributes) ? void 0 : p.outcome_view_id,
                            o = null == e || null == (h = e.data) || null == (h = h.attributes) ? void 0 : h.coupon_code;
                        if (t.forEach((e => {
                                l.Z.setState((t => ((e, {
                                    parentViewId: t,
                                    childViewId: n
                                }) => t && n ? Object.assign({}, e, {
                                    onsiteState: Object.assign({}, e.onsiteState, {
                                        dynamicViewOverrides: Object.assign({}, e.onsiteState.dynamicViewOverrides, {
                                            [t]: n
                                        })
                                    })
                                }) : e)(t, {
                                    parentViewId: e,
                                    childViewId: n
                                })))
                            })), n) {
                            const e = (0, C.bc)(s, n);
                            o && e && l.Z.setState((t => (0, w.W)({
                                componentId: e,
                                couponCode: o
                            }, t))), this.trackOutcomeViewCalculation({
                                outcomeViewId: n,
                                couponCode: o
                            })
                        }
                        return new Promise((e => {
                            setTimeout((() => e()), m.Rd)
                        }))
                    } catch (e) {
                        return e instanceof Error && (0, r.T)(e, {
                            extra: {
                                companyId: d,
                                formVersionId: c,
                                formViewId: u,
                                profileIdentifiers: JSON.stringify(this.profile)
                            }
                        }), (0, a.Cm)({
                            id: this.openFormVersion.formVersionCId,
                            changes: {
                                errorViewMessage: E.xl
                            }
                        }), null
                    }
                }
                trackOutcomeViewCalculation({
                    outcomeViewId: e,
                    couponCode: t
                }) {
                    var n;
                    const o = l.Z.getState();
                    (0, s.M)(Object.assign({
                        metric: t ? x.JO : x.Q$,
                        formVersionCId: this.openFormVersion.formVersionCId,
                        formId: this.openFormVersion.formId,
                        companyId: null != (n = o.onsiteState.client.klaviyoCompanyId) ? n : "",
                        currentViewId: this.openFormVersion.currentViewId,
                        outcomeViewId: e
                    }, t && {
                        couponCode: t
                    }))
                }
            }
        },
        87377: function(e, t, n) {
            n.d(t, {
                j: function() {
                    return Ye
                }
            });
            var o = n(5645),
                i = n.n(o),
                r = n(94756),
                s = n(92719),
                a = n(43581);
            class l {
                constructor({
                    formVersionCId: e,
                    actionId: t,
                    getState: n
                }) {
                    this.currentHandlerStep = "INSTANTIATED", this.formActionType = void 0, this.actionId = void 0, this.formVersionCId = void 0, this.formAction = void 0, this.formId = void 0, this.companyId = void 0, this.messageBus = void 0, this.profileEvents = void 0;
                    const o = n();
                    this.actionId = t, this.formVersionCId = e, this.formAction = (o.formsState.actions || {})[t];
                    const i = o.onsiteState.openFormVersions[e];
                    if (this.messageBus = (0, a.c)(o), !i) throw new Error("Open Form Version does not exist");
                    this.formId = i.formId, this.companyId = o.onsiteState.client.klaviyoCompanyId, this.profileEvents = {
                        formSubmitted: null,
                        formCompleted: null
                    }
                }
                runAction() {
                    return this.currentHandlerStep = "PREHANDLER", new Promise((e => e())).then((e => this.__preHandler(e))).then((e => this.__identify(e))).then((e => this.__createProfileEvents(e))).then((e => (this.currentHandlerStep = "HANDLER", e))).then((e => this.__handler(e))).then((e => (this.currentHandlerStep = "POSTHANDLER", e))).then((e => this.__postHandler(e))).catch((e => this.__errorHandler(e)))
                }
                __preHandler(e) {}
                __handler(e) {}
                __postHandler(e) {}
                __errorHandler(e) {
                    (0, s.qB)(e.toString(), {
                        formActionType: this.formActionType,
                        currentHandlerStep: this.currentHandlerStep
                    })
                }
                __identify(e) {}
                __createProfileEvents(e) {}
            }
            l.formActionType = void 0;
            var d = n(49064);
            const c = ["isSubmit"];
            class m extends l {
                constructor(e) {
                    let {
                        isSubmit: t
                    } = e;
                    super(i()(e, c)), this.isSubmit = void 0, this.isSubmit = t, this.formActionType = r.Pj
                }
                __handler() {
                    return (0, d.fK)({
                        id: this.formVersionCId,
                        changes: {
                            logCloseMetric: !this.isSubmit
                        }
                    }), (0, d.et)({
                        formVersionCId: this.formVersionCId,
                        isSubmit: this.isSubmit
                    })
                }
            }
            m.formActionType = r.Pj;
            var u = m,
                f = n(39820),
                p = (n(78575), n(56220), n(22923), n(92461), n(70818), n(39265), n(63880), n(44159), n(60873), n(61099), n(2609)),
                h = n(24745),
                v = n(80975),
                g = n(71429),
                y = n(42376),
                I = n(72487),
                b = n(76419),
                S = n(61081),
                w = n(89331),
                C = n(99449),
                E = n(57511),
                x = n(47774),
                V = n(51950),
                _ = n(22027),
                T = n(7385),
                k = n(39355),
                $ = n(91342),
                F = n(29974),
                O = n(17859),
                Z = n(74729),
                A = n(6138),
                M = n(72012),
                D = n(20222),
                B = n(76101),
                N = (n(51778), n(70917), n(93677), n(84304), n(75723), n(20696), n(38528), n(72418), n(22982)),
                j = n(45641),
                R = n(40823);
            const P = e => e instanceof A.TT,
                L = new Set;
            var z = class extends l {
                    constructor(e) {
                        super(e), this.hiddenFieldsComponentId = void 0, this.getState = void 0, this.composedFields = void 0;
                        const t = e.getState();
                        this.getState = e.getState, this.hiddenFieldsComponentId = (0, w.cA)(t, e.actionId), this.composedFields = (0, C.$f)({
                            state: t,
                            formVersionCId: this.formVersionCId,
                            hiddenFieldsComponentId: this.hiddenFieldsComponentId,
                            formActionType: this.formAction.actionType
                        })
                    }
                    get smartOptInListRelationships() {
                        const e = this.getState(),
                            {
                                smartOptInData: t
                            } = e.onsiteState.client,
                            n = null == t ? void 0 : t.listId;
                        return n ? {
                            list: {
                                data: {
                                    type: _._,
                                    id: n
                                }
                            }
                        } : {}
                    }
                    get listRelationships() {
                        return this.formAction.listId ? {
                            list: {
                                data: {
                                    type: _._,
                                    id: this.formAction.listId
                                }
                            }
                        } : {}
                    }
                    get formRelationships() {
                        const e = this.getState().onsiteState.openFormVersions[this.formVersionCId];
                        return this.formId && null != e && e.formVersionId ? {
                            form: {
                                data: {
                                    type: "form",
                                    id: this.formId
                                }
                            },
                            "form-version": {
                                data: {
                                    type: "form-version",
                                    id: null == e ? void 0 : e.formVersionId
                                }
                            }
                        } : {}
                    }
                    async __preHandler() {
                        if (this.formAction.actionType && r.NB.has(this.formAction.actionType)) {
                            const e = await (0, d.eN)({
                                formVersionCId: this.formVersionCId
                            });
                            if (e && e.some((({
                                    valid: e
                                }) => !e))) throw new A.mN({
                                type: "form"
                            });
                            const t = this.getState(),
                                n = t.onsiteState.openFormVersions[this.formVersionCId];
                            if (null == n || !n.currentViewId) return !0;
                            const o = n.currentViewId;
                            if (L.has(o)) return !0;
                            const i = new R.e(n, this.composedFields).checkAndRunViewSideEffects({
                                state: t
                            });
                            return L.add(o), await Promise.allSettled(i), !0
                        }
                        return !0
                    }
                    __requestUniqueID() {
                        const e = {
                            companyId: this.companyId,
                            form_id: this.formId,
                            email: this.composedFields[V.HD]
                        };
                        (0, j.Y)("sms", e).then((({
                            data: {
                                uniqueId: e
                            }
                        }) => {
                            void 0 !== e && (0, S.UY)({
                                smsSubscriptionUniqueId: e
                            })
                        })).catch((() => {}))
                    }
                    __requestWhatsappUniqueID() {
                        const e = {
                            companyId: this.companyId,
                            form_id: this.formId,
                            email: this.composedFields[V.HD]
                        };
                        (0, j.Y)("whatsapp", e).then((({
                            data: {
                                uniqueId: e
                            }
                        }) => {
                            void 0 !== e && (0, S.UY)({
                                whatsappSubscriptionUniqueId: e
                            })
                        })).catch((() => {}))
                    }
                    __errorHandler(e) {
                        const {
                            composedFields: t,
                            formId: n,
                            companyId: o,
                            formAction: i
                        } = this;
                        if (l.prototype.__errorHandler.call(this, e), (e => [A.vS, A.mN, A.a, A.FR].some((t => e instanceof t)))(e)) throw e;
                        (0, d.Cm)({
                            id: this.formVersionCId,
                            changes: {
                                errorViewMessage: P(e) ? T.gl : T.xl
                            }
                        }), (0, y.M)({
                            metric: P(e) ? x.yH : x.DF,
                            formVersionCId: this.formVersionCId,
                            formId: n,
                            companyId: o,
                            submittedFields: t,
                            listId: null == i ? void 0 : i.listId,
                            isProgressEventError: (0, A.pS)(e),
                            errorName: e.name,
                            errorMessage: e.message
                        }), (0, A.pS)(e) || P(e) || (0, N.T)(e, {
                            tags: {
                                onSubmit: "True"
                            },
                            extra: {
                                submitAction: !0,
                                formId: this.formId,
                                companyId: this.companyId
                            }
                        })
                    }
                },
                W = n(12262),
                H = n(72543),
                U = n(10386),
                q = n(68502);
            var K = class extends z {
                    constructor(e) {
                        super(e), this.getState = void 0, this.getState = e.getState, this.__handler = this.__handler.bind(this), this.__postHandler = this.__postHandler.bind(this), this.__baseSubmitToList = this.__baseSubmitToList.bind(this), this.__createProfileEvents = this.__createProfileEvents.bind(this), this.saveProfileEventsToClass = this.saveProfileEventsToClass.bind(this)
                    }
                    submitMetric({
                        state: e,
                        isSubscribe: t = !1,
                        submitMetric: n = x.dm,
                        submitMetricActionType: o = "Submit Form"
                    }) {
                        const i = e.onsiteState.openFormVersions[this.formVersionCId];
                        if (!i) throw new Error("Open Form Version does not exist");
                        const {
                            currentViewId: r
                        } = i, s = (0, W.f8)(e, this.formVersionCId, t), a = (0, E.E5)(e, r), l = e.formsState.views[r], c = l ? (0, E.O)(e, l) : void 0, m = [(0, y.M)({
                            metric: x.AH,
                            formVersionCId: this.formVersionCId,
                            logCustomEvent: !0,
                            formId: this.formId,
                            companyId: this.companyId,
                            submittedFields: Object.assign({}, this.composedFields, {
                                $step_name: a
                            }),
                            step_name: a,
                            step_number: void 0 !== c ? c + 1 : c,
                            action_type: "Submit Step"
                        })];
                        if ((0, E.Qe)(e, r)) {
                            const t = this._trackSpinToWinSubmit(e, i, a, c);
                            t && m.push(t)
                        }
                        return (t || (0, C.Gt)(e, this.formVersionCId, s)) && m.push((0, y.M)({
                            metric: n,
                            logCustomEvent: !0,
                            formVersionCId: this.formVersionCId,
                            formId: this.formId,
                            companyId: this.companyId,
                            submittedFields: this.composedFields,
                            action_type: o
                        })), i && x.us.indexOf(s) < x.us.indexOf(i.topHierarchySubmitted) && (0, d.fK)({
                            id: this.formVersionCId,
                            changes: {
                                topHierarchySubmitted: s
                            }
                        }), Promise.all(m)
                    }
                    __identify() {
                        const e = (0, p.Un)();
                        let t;
                        const n = new Promise((e => {
                                t = e
                            })),
                            o = this.getState(),
                            i = (0, C.jo)(o, this.formVersionCId, void 0, this.composedFields);
                        let r = Object.assign({}, this.composedFields);
                        return i.opt_in_promotional_whatsapp && (r = Object.assign({}, r, {
                            opt_in_promotional_whatsapp: i.opt_in_promotional_whatsapp
                        }), delete r.opt_in_promotional_sms), delete r.opt_in_promotional_email, delete r.opt_in_code, !0 !== e ? Promise.resolve(null) : ((0, p.ro)({
                            fields: r,
                            relationships: this.formRelationships,
                            callback: () => (t(!0), !0)
                        }), n)
                    }
                    __handler() {
                        var e;
                        const t = this.getState(),
                            n = t.onsiteState.openFormVersions[this.formVersionCId];
                        if (!n) throw new Error("Open Form Version does not exist");
                        const {
                            formVersionId: o
                        } = n, i = Object.values(t.formsState.views).filter((e => (null == e ? void 0 : e.formVersionId) === o)).flatMap((e => e ? (0, E.nC)(t, e.viewId).map((e => e ? t.formsState.components[e.componentId] : void 0)) : [])), r = i.some((e => !!e && (0, w.FW)(t, e))), s = i.some((e => !!e && (0, w.wj)(t, e)));
                        r && this.composedFields[V.HD] && this.__requestUniqueID(), s && this.composedFields[V.HD] && this.__requestWhatsappUniqueID();
                        const a = (0, w.xU)(t, o),
                            l = void 0 !== (0, w.CW)(t, this.formVersionCId);
                        if (!(0, F.Z)(this.formActionType, this.composedFields, a, l)) return this.submitMetric({
                            state: t
                        }), void(0, b.$k)({
                            formId: this.formId,
                            successActionType: this.formAction.actionType
                        });
                        const d = (0, C.jo)(t, this.formVersionCId, void 0, this.composedFields);
                        return this.composedFields = Object.assign({}, this.composedFields, d || {}), null != (e = t.formsState.formVersions[o]) && e.data.storeUtmParams && (this.composedFields = Object.assign({}, this.composedFields, (0, O.Z)())), this.__submitToList()
                    }
                    async __postHandler(e) {
                        var t, n;
                        const o = this.getState(),
                            i = o.onsiteState.openFormVersions[this.formVersionCId];
                        if (!i) throw new Error("Open Form Version does not exist");
                        const {
                            formVersionId: r
                        } = i, s = (0, Z.Z)(), a = !(null == (t = o.onsiteState.createdProfileEvents[this.formId]) || !t.formSubmitted);
                        a || (0, W.LY)({
                            formId: this.formId,
                            formVersionId: r,
                            pageUrl: window.location.href,
                            deviceType: s,
                            hasSubmittedEventBeenCreated: a,
                            utmParams: (0, O.Z)()
                        });
                        const l = o.formsState.formVersions[r];
                        if (l) {
                            var d;
                            const e = (0, E.sb)(o, l.formVersionId, s, (0, C.wf)(o, this.formVersionCId)) === i.currentViewId,
                                t = !(null == (d = o.onsiteState.createdProfileEvents[this.formId]) || !d.formCompleted);
                            !t && e && (0, W.ej)({
                                state: q.Z.getState(),
                                formId: this.formId,
                                formVersionId: r,
                                pageUrl: window.location.href,
                                deviceType: s,
                                hasCompletedEventBeenCreated: t,
                                utmParams: (0, O.Z)()
                            })
                        }
                        const c = null == o || null == (n = o.onsiteState) || null == (n = n.formSettings) ? void 0 : n.shopifyVisitorApi;
                        if (null != e && e.status && (null == e ? void 0 : e.status) >= 200 && (null == e ? void 0 : e.status) < 300 && c && (0, B.h)()) {
                            const {
                                syncSMSConsent: e,
                                syncEmailConsent: t
                            } = c, {
                                [V.HD]: n,
                                [V.lL]: o
                            } = this.composedFields;
                            if (!n && !o) return;
                            const i = Object.assign({}, n && t ? {
                                email: n
                            } : {}, o && e ? {
                                phone: o
                            } : {});
                            (0, B.N)(i)
                        }
                    }
                    __submitHandlerCheck(e) {
                        const {
                            composedFields: t,
                            formId: n,
                            companyId: o,
                            formAction: i
                        } = this;
                        if (e !== _.Sz && e !== _.dl) throw (0, d.Cm)({
                            id: this.formVersionCId,
                            changes: {
                                errorViewMessage: T.xl
                            }
                        }), (0, y.M)({
                            metric: x.DF,
                            formVersionCId: this.formVersionCId,
                            formId: n,
                            companyId: o,
                            submittedFields: t,
                            listId: i.listId
                        }), new A.vS
                    }
                    __handlePassedCaptchaChallenge() {}
                    __handleSubmitToListError() {
                        const e = new AbortController,
                            {
                                signal: t
                            } = e;
                        window.addEventListener(k.H, (() => {
                            this.__handlePassedCaptchaChallenge(), (0, y.M)({
                                metric: x.uf,
                                formVersionCId: this.formVersionCId,
                                formId: this.formId,
                                companyId: this.companyId,
                                submittedFields: this.composedFields,
                                logTelemetric: !0
                            }), e.abort()
                        }), {
                            signal: t
                        }), window.addEventListener(k.vT, (() => {
                            new u({
                                actionId: this.actionId,
                                formVersionCId: this.formVersionCId,
                                getState: this.getState
                            }).runAction(), e.abort()
                        }), {
                            signal: t
                        }), (0, y.M)({
                            metric: x.Wx,
                            formVersionCId: this.formVersionCId,
                            formId: this.formId,
                            companyId: this.companyId,
                            submittedFields: this.composedFields,
                            logTelemetric: !0
                        })
                    }
                    __handleWAFRuleViolationError() {
                        (0, y.M)({
                            metric: x.wL,
                            formVersionCId: this.formVersionCId,
                            formId: this.formId,
                            companyId: this.companyId,
                            submittedFields: this.composedFields,
                            logTelemetric: !0
                        }), (0, d.Cm)({
                            id: this.formVersionCId,
                            changes: {
                                errorViewMessage: T.xl
                            }
                        })
                    }
                    __baseSubmitToList(e) {
                        const {
                            composedFields: t,
                            formId: n,
                            companyId: o
                        } = this, i = this.getState(), r = (0, C.io)(i, this.formVersionCId), s = this.__makePOSTBody({
                            composedFields: t,
                            requestOTPCode: r,
                            phoneInputConsentTypes: (0, w.CW)(i, this.formVersionCId)
                        });
                        if ((0, S.x7)(s), r) {
                            const e = t[V.lL],
                                n = this.formAction.listId,
                                o = t[V.Td] || t[V.HD];
                            if (e && n && "string" == typeof e) {
                                const {
                                    properties: i
                                } = this.buildProfileAttributes(t);
                                (0, S.N5)({
                                    phoneNumber: e,
                                    listId: n,
                                    email: "string" == typeof o ? o : void 0,
                                    properties: i || {}
                                })
                            }
                        }
                        return (0, h.W)((() => e(o, s)), 5, 1e3 + 1e3 * Math.random(), [429]).then((e => {
                            if (429 === e.status) throw new A.TT;
                            if (403 === e.status) throw new A.FR;
                            return e
                        })).then((e => {
                            if (e.status === _.Sz && this.formAction.actionType) {
                                const t = Object.fromEntries(Object.entries(this.profileEvents).filter((([, e]) => null !== e))),
                                    o = Object.keys(t);
                                if ((0, I.Z)(this.formId, o), o.length > 0) {
                                    const e = (0, H.iv)(H.yn),
                                        t = (null == e ? void 0 : e.submittedForms) || {},
                                        i = (null == e ? void 0 : e.completedForms) || {};
                                    try {
                                        (0, H.$T)(H.yn, Object.assign({}, e, {
                                            submittedForms: Object.assign({}, t, o.includes("formSubmitted") ? {
                                                [n]: (new Date).toISOString()
                                            } : {}),
                                            completedForms: Object.assign({}, i, o.includes("formCompleted") ? {
                                                [n]: (new Date).toISOString()
                                            } : {})
                                        }))
                                    } catch (e) {
                                        console.error("Error saving session storage", e)
                                    }
                                }
                                return (0, b.$k)({
                                    formId: n,
                                    successActionType: this.formAction.actionType
                                }), (0, M.n)(200, this.submitMetric({
                                    state: i,
                                    isSubscribe: !0
                                })).then((() => e)).catch((() => e))
                            }
                            return e
                        })).catch((e => {
                            if (e instanceof A.a) throw this.__handleSubmitToListError(), e;
                            if (e instanceof A.FR || (0, v.p)(e)) return this.__handleWAFRuleViolationError(), null;
                            throw e
                        }))
                    }
                    __submitToList() {
                        return this.__baseSubmitToList(f.Y)
                    }
                    __makePOSTBody({
                        composedFields: e,
                        requestOTPCode: t = !1,
                        phoneInputConsentTypes: n
                    }) {
                        const o = new Date,
                            i = "object" == typeof window.Shopify && window.Shopify.shop ? {
                                services: JSON.stringify({
                                    shopify: {
                                        source: "form"
                                    }
                                })
                            } : {},
                            r = Object.assign({}, e, i),
                            {
                                $exchange_id: s
                            } = (0, p.zy)(),
                            {
                                attributes: a,
                                properties: l,
                                customSource: d
                            } = this.buildProfileAttributes(r),
                            c = Object.values(this.profileEvents).filter((e => null !== e)),
                            {
                                listRelationships: m,
                                formRelationships: u
                            } = this,
                            f = Object.keys(m).length > 0 || Object.keys(u).length > 0;
                        return Object.assign({
                            data: Object.assign({
                                type: _.NR,
                                attributes: Object.assign({}, c.length > 0 ? {
                                    events: {
                                        data: c
                                    }
                                } : {}, {
                                    profile: {
                                        data: {
                                            type: _.cC,
                                            attributes: Object.assign({}, a, {
                                                subscriptions: Object.assign({}, a.email && "false" !== r.opt_in_promotional_email ? {
                                                    email: {
                                                        marketing: {
                                                            consent: "SUBSCRIBED"
                                                        }
                                                    }
                                                } : {}, this.calculateSmsSubscriptionsForStep({
                                                    attributes: a,
                                                    modifiedComposedFields: r,
                                                    phoneInputConsentTypes: n
                                                }), this.calculateWhatsAppSubscriptionsForStep({
                                                    attributes: a,
                                                    modifiedComposedFields: r,
                                                    phoneInputConsentTypes: n
                                                })),
                                                properties: Object.assign({}, l, {
                                                    $timezone_offset: -o.getTimezoneOffset() / 60
                                                }, s ? {
                                                    $exchange_id: s
                                                } : {})
                                            })
                                        }
                                    }
                                }, d ? {
                                    custom_source: d
                                } : {})
                            }, f ? {
                                relationships: Object.assign({}, m, u)
                            } : {})
                        }, t ? {
                            meta: {
                                send_otp_code: !0
                            }
                        } : {})
                    }
                    __createProfileEvents() {
                        const e = this.getState(),
                            t = e.onsiteState.openFormVersions[this.formVersionCId];
                        if (!t) throw new Error("Open Form Version does not exist");
                        const {
                            formVersionId: n
                        } = t, o = (0, w.xU)(e, n), i = void 0 !== (0, w.CW)(e, this.formVersionCId), r = (0, F.Z)(this.formActionType, this.composedFields, o, i), s = (0, p.pN)();
                        if (!r && !s) return;
                        const {
                            $exchange_id: a
                        } = (0, p.zy)();
                        s ? this.saveProfileEventsToClass(a) : this.saveProfileEventsToClass()
                    }
                    saveProfileEventsToClass(e) {
                        var t;
                        const n = this.getState(),
                            o = n.onsiteState.openFormVersions[this.formVersionCId];
                        if (!o) throw new Error("Open Form Version does not exist");
                        const {
                            formVersionId: i,
                            currentViewId: r
                        } = o, s = (0, E.QR)(n, i), a = s.length, l = !(null == (t = n.onsiteState.createdProfileEvents[this.formId]) || !t.formSubmitted), d = (0, Z.Z)(), c = n.formsState.formVersions[i], m = (0, H.iv)(H.yn), u = (null == m ? void 0 : m.submittedForms) || {}, f = (null == m ? void 0 : m.completedForms) || {}, p = l || this.formId in u ? null : (0, D.Z)({
                            exchangeId: e,
                            email: this.composedFields.$email,
                            phoneNumber: this.composedFields.$phone_number,
                            formId: this.formId,
                            formVersionId: i,
                            deviceType: d,
                            pageUrl: window.location.href,
                            metricName: "Form submitted by profile",
                            utmParams: (0, O.Z)()
                        }), h = (0, C.p$)({
                            state: n,
                            formVersionId: i,
                            deviceType: d
                        }), v = this.formId in f ? null : (0, D.Z)({
                            exchangeId: e,
                            email: this.composedFields.$email,
                            phoneNumber: this.composedFields.$phone_number,
                            formId: this.formId,
                            formVersionId: i,
                            deviceType: d,
                            pageUrl: window.location.href,
                            metricName: "Form completed by profile",
                            utmParams: (0, O.Z)(),
                            successStepName: h
                        });
                        2 === a && (this.profileEvents = {
                            formSubmitted: p,
                            formCompleted: v
                        });
                        const y = (c ? (0, E.sb)(n, c.formVersionId, d, (0, C.wf)(n, this.formVersionCId)) : void 0) === this.formAction.viewId,
                            I = s.find((({
                                viewId: e
                            }) => e === r));
                        if ((0, g.x)(I)) return;
                        const b = (0, E.ad)(n, I, d);
                        a > 2 && b.length > 1 && (this.profileEvents = Object.assign({}, this.profileEvents, {
                            formSubmitted: p
                        }), y && (this.profileEvents = Object.assign({}, this.profileEvents, {
                            formSubmitted: p,
                            formCompleted: v
                        }))), a > 2 && 1 === b.length && (this.profileEvents = Object.assign({}, this.profileEvents, {
                            formSubmitted: p,
                            formCompleted: v
                        }))
                    }
                    _trackSpinToWinSubmit(e, t, n, o) {
                        var i;
                        const r = (0, E.Qe)(e, t.currentViewId);
                        if (!r) return null;
                        const s = (0, E.Tf)(e, t.formVersionId);
                        if (!s) return null;
                        const a = (0, U.L)(e, s),
                            l = null == (i = r.data.wheelLogic.slices.find((e => e.childViewId === a))) ? void 0 : i.probability;
                        return (0, y.M)({
                            metric: x.nn,
                            formVersionCId: this.formVersionCId,
                            formId: this.formId,
                            companyId: this.companyId,
                            step_name: n,
                            step_number: void 0 !== o ? o + 1 : o,
                            componentId: r.componentId,
                            overrideViewId: a,
                            outcomeProbability: l
                        })
                    }
                    buildProfileAttributes(e) {
                        let t = Object.assign({}, e);
                        const n = {};
                        let o;
                        return "email" in e && (n.email = e.email, delete t.email), "$email" in e && (n.email = e.$email, delete t.$email), "sms_consent" in e && (e.sms_consent && (n.phone_number = e.$phone_number, delete t.$phone_number), delete t.sms_consent), "opt_in_promotional_email" in e && delete t.opt_in_promotional_email, "opt_in_promotional_sms" in e && delete t.opt_in_promotional_sms, "opt_in_code" in e && delete t.opt_in_code, "whatsapp_consent" in e && (e.whatsapp_consent && (n.phone_number = e.$phone_number, delete t.$phone_number), delete t.whatsapp_consent), "sentIdentifiers" in e && (t = Object.assign({}, t, e.sentIdentifiers), delete t.sentIdentifiers), V.XK.forEach((n => {
                            if (e[n]) {
                                const i = e[n];
                                o = Array.isArray(i) ? 1 === i.length ? i[0] : i.join(", ") : i, delete t[n]
                            }
                        })), {
                            attributes: n,
                            properties: t,
                            customSource: o
                        }
                    }
                    calculateSmsSubscriptionsForStep({
                        attributes: e,
                        modifiedComposedFields: t,
                        phoneInputConsentTypes: n
                    }) {
                        if (!e.phone_number) return {};
                        switch (null == n ? void 0 : n.sms) {
                            case $.E3.PROMOTIONAL:
                                return "false" === t.opt_in_promotional_sms ? {} : {
                                    sms: {
                                        marketing: {
                                            consent: "SUBSCRIBED"
                                        }
                                    }
                                };
                            case $.E3.TRANSACTIONAL:
                                return {
                                    sms: {
                                        transactional: {
                                            consent: "SUBSCRIBED"
                                        }
                                    }
                                };
                            case $.E3.SINGLE_STEP_TRANSACTIONAL_PROMOTIONAL:
                                return {
                                    sms: Object.assign({
                                        transactional: {
                                            consent: "SUBSCRIBED"
                                        }
                                    }, "true" === t.opt_in_promotional_sms ? {
                                        marketing: {
                                            consent: "SUBSCRIBED"
                                        }
                                    } : {})
                                };
                            case $.E3.MULTI_STEP_TRANSACTIONAL_PROMOTIONAL:
                                return {
                                    sms: {
                                        transactional: {
                                            consent: "SUBSCRIBED"
                                        }
                                    }
                                };
                            default:
                                return {}
                        }
                    }
                    calculateWhatsAppSubscriptionsForStep({
                        attributes: e,
                        modifiedComposedFields: t,
                        phoneInputConsentTypes: n
                    }) {
                        if (!e.phone_number) return {};
                        switch (null == n ? void 0 : n.whatsApp) {
                            case $.E3.PROMOTIONAL:
                                return "false" === t.opt_in_promotional_whatsapp ? {} : {
                                    whatsapp: {
                                        marketing: {
                                            consent: "SUBSCRIBED"
                                        }
                                    }
                                };
                            case $.E3.TRANSACTIONAL:
                                return {
                                    whatsapp: {
                                        transactional: {
                                            consent: "SUBSCRIBED"
                                        }
                                    }
                                };
                            case $.E3.SINGLE_STEP_TRANSACTIONAL_PROMOTIONAL:
                                return {
                                    whatsapp: Object.assign({
                                        transactional: {
                                            consent: "SUBSCRIBED"
                                        }
                                    }, "true" === t.opt_in_promotional_whatsapp ? {
                                        marketing: {
                                            consent: "SUBSCRIBED"
                                        }
                                    } : {})
                                };
                            case $.E3.MULTI_STEP_TRANSACTIONAL_PROMOTIONAL:
                                return {
                                    whatsapp: {
                                        transactional: {
                                            consent: "SUBSCRIBED"
                                        }
                                    }
                                };
                            default:
                                return {}
                        }
                    }
                },
                G = n(87467),
                Y = n(36947),
                X = n(16506),
                J = n(94841),
                Q = n(36679);
            const ee = async (e, t, n, o, i, r, a) => {
                var l, c;
                const m = (0, E.QE)(e, a);
                let u = (0, E.Tf)(e, a);
                if ((0, s.Cw)("requestShopPayShow", {
                        firstViewId: m,
                        successViewId: u
                    }), !u) return !1;
                const f = (0, U.L)(e, u);
                f && (u = f, (0, s.Cw)("requestShopPayShow", {
                    overrideSuccessViewId: f
                }));
                const p = (0, E.I_)(e, u);
                var h;
                null != p && null != (l = p[0]) && l.viewId && (u = null == p || null == (h = p[0]) ? void 0 : h.viewId, (0, s.Cw)("requestShopPayShow", {
                    skippedDynamicViewCalculation: !0,
                    overrideSuccessViewId: u
                }));
                const v = (0, E.nC)(e, u).find((e => e && (0, w.J6)(e))),
                    g = (0, w.Mh)(e, a, [$.Tg.SMS]) || (0, w.K1)(e, a),
                    I = (null == v ? void 0 : v.data.couponType) === X.$i.STATIC ? null == v || null == (c = v.data.couponData) ? void 0 : c.text : await (0, d.zS)({
                        formVersionCId: r
                    });
                if ((0, s.Cw)("requestShopPayShow", {
                        hasCouponComponent: void 0 !== v,
                        listId: g,
                        discountCode: I
                    }), v && g && "string" == typeof I) {
                    let e, a = !0;
                    const l = new Promise((t => {
                        e = t, setTimeout((() => {
                            a && t(!0)
                        }), 5e3)
                    }));
                    return (0, Q.AN)(o, i, g, t, I, (() => {
                        a = !1, (0, S.UY)({
                            showingShopLogin: J.K.SHOWING
                        })
                    }), (() => {
                        e(!0), ((e, t) => {
                            (0, d.Cm)({
                                id: e,
                                changes: {
                                    currentViewId: t
                                }
                            })
                        })(r, n)
                    }), ((t, n) => {
                        e(!n), ((e, t, n, o, i, r) => {
                            (0, s.Cw)("onShopPayComplete"), r && (0, d.Cm)({
                                id: n,
                                changes: {
                                    currentViewId: o
                                }
                            }), (0, S.UY)({
                                showingShopLogin: J.K.CLOSED
                            }), i && e && (0, y.M)({
                                metric: i,
                                formVersionCId: n,
                                formId: t,
                                companyId: e
                            })
                        })(i, o, r, u, t, n)
                    }), (() => {
                        e(!1), ((e, t) => {
                            (0, s.Cw)("onShopPayRestart"), t ? ((0, d.Cm)({
                                id: e,
                                changes: {
                                    currentViewId: t
                                }
                            }), (0, S.UY)({
                                showingShopLogin: J.K.NEVER_SHOWN
                            })) : (0, S.UY)({
                                showingShopLogin: J.K.CLOSED
                            })
                        })(r, null != m ? m : void 0)
                    })), l
                }
                return !1
            };
            class te extends z {
                constructor(e) {
                    super(e), this.getState = void 0, this.getState = e.getState, this.__handler = this.__handler.bind(this), this._checkAndRemoveRedirectToInboxBtns = this._checkAndRemoveRedirectToInboxBtns.bind(this)
                }
                async __handler() {
                    var e;
                    const t = this.getState(),
                        n = t.onsiteState.openFormVersions[this.formVersionCId];
                    if (!n || !this.formAction.viewId) return null;
                    if ((0, Y.mn)(t, n.formVersionId) && this.formAction.viewId && (0, Y.ac)(t, this.formVersionCId, this.formAction.viewId)) {
                        const e = (0, Y.Bu)(t, this.formVersionCId);
                        (0, Y.rm)(e, this.companyId, t, this.formVersionCId, this.formAction.viewId, d.fK)
                    }
                    let o = this.formAction.viewId;
                    if (null != (e = t.onsiteState.dynamicViewOverrides) && e[o] && (o = (0, U.L)(t, o) || this.formAction.viewId), (0, C.wf)(t, this.formVersionCId) && "string" == typeof this.composedFields[V.HD]) {
                        if (!await ee(t, this.composedFields[V.HD], o, this.formId, this.companyId, this.formVersionCId, n.formVersionId)) return
                    }
                    return this._checkAndRemoveRedirectToInboxBtns(n.formVersionId, o), (0, d.Cm)({
                        id: this.formVersionCId,
                        changes: {
                            currentViewId: o
                        }
                    })
                }
                _checkAndRemoveRedirectToInboxBtns(e, t) {
                    const n = this.getState(),
                        o = (0, E.Tf)(n, e);
                    o && o === t && (0, G.A)(this.companyId, this.formId, this.formVersionCId, o)
                }
            }
            te.formActionType = r.hL;
            var ne = te;
            class oe extends K {
                constructor(e) {
                    super(e), this.getState = void 0, this.getState = e.getState, this.__preHandler = this.__preHandler.bind(this), this.__postHandler = this.__postHandler.bind(this), this.__handlePassedCaptchaChallenge = this.__handlePassedCaptchaChallenge.bind(this)
                }
                async __postHandler(e) {
                    super.__postHandler(e);
                    if (!this.getState().onsiteState.openFormVersions[this.formVersionCId] || !this.formAction.viewId) return null;
                    e && this.__submitHandlerCheck(e.status);
                    return new ne({
                        actionId: this.actionId,
                        formVersionCId: this.formVersionCId,
                        getState: this.getState
                    }).runAction()
                }
                __submitToList() {
                    return this.__baseSubmitToList(f.s)
                }
                __handlePassedCaptchaChallenge() {
                    new oe({
                        actionId: this.actionId,
                        formVersionCId: this.formVersionCId,
                        getState: this.getState
                    }).runAction()
                }
            }
            oe.formActionType = r.p;
            var ie = oe,
                re = (n(26650), n(91977));
            const se = ["isSubmit"];
            class ae extends l {
                constructor(e) {
                    var t, n;
                    let {
                        isSubmit: o
                    } = e, s = i()(e, se);
                    super(s), this.redirectUrl = void 0, this.newWindow = void 0, this.isSubmit = void 0, this.getState = void 0, this.redirectUrl = (null == (t = this.formAction.data) ? void 0 : t.redirectUrl) || "about:blank", this.newWindow = !(null == (n = this.formAction.data) || !n.newWindow) && this.formAction.actionType === r.$b, this.isSubmit = !!o, this.formActionType = r.$b, this.getState = s.getState, this.__handler = this.__handler.bind(this)
                }
                __redirectUrl() {
                    const e = this.redirectUrl.replace(/^javascript:/, "");
                    if (this.newWindow && this.formAction.actionType === r.$b) {
                        const t = window.open(e, "_blank");
                        null == t || t.focus()
                    } else(0, re.Z)(e)
                }
                __handler() {
                    const {
                        formId: e,
                        newWindow: t,
                        formVersionCId: n
                    } = this;
                    this.formAction.actionType === r.$b && (0, b.$k)({
                        formId: e,
                        successActionType: r.$b
                    });
                    const o = this.getState(),
                        i = o.onsiteState.openFormVersions[n];
                    if (!i) throw new Error("Open Form Version does not exist");
                    const s = i.sentSubmitMetric,
                        a = o.formsState.views[i.currentViewId],
                        l = a ? (0, E.O)(o, a) : void 0,
                        {
                            formVersionId: d
                        } = i,
                        c = o.formsState.formVersions[d],
                        m = (0, Z.Z)(),
                        u = (0, E.QR)(o, d).length,
                        f = c ? (0, E.sb)(o, c.formVersionId, m, (0, C.wf)(o, this.formVersionCId)) : void 0;
                    t || 1 !== u || f !== (null == a ? void 0 : a.viewId) || this.isSubmit || s || ((0, W.LY)({
                        formId: this.formId,
                        formVersionId: d,
                        pageUrl: window.location.href,
                        deviceType: m,
                        hasSubmittedEventBeenCreated: !1,
                        utmParams: (0, O.Z)()
                    }), (0, W.ej)({
                        state: q.Z.getState(),
                        formId: this.formId,
                        formVersionId: d,
                        pageUrl: window.location.href,
                        deviceType: m,
                        hasCompletedEventBeenCreated: !1,
                        utmParams: (0, O.Z)()
                    }));
                    const p = Promise.allSettled([(0, y.M)({
                        metric: x.nR,
                        logTelemetric: !this.isSubmit && !s,
                        logCustomEvent: !0,
                        formVersionCId: this.formVersionCId,
                        formId: this.formId,
                        companyId: this.companyId,
                        action_type: "Go to URL",
                        destination_url: this.redirectUrl
                    }), (0, y.M)({
                        metric: x._5,
                        logTelemetric: !this.isSubmit,
                        logCustomEvent: !0,
                        formVersionCId: this.formVersionCId,
                        formId: this.formId,
                        companyId: this.companyId,
                        action_type: "Go to URL",
                        destination_url: this.redirectUrl,
                        step_number: l ? l + 1 : void 0,
                        step_name: a ? (0, E.E5)(o, a.viewId) : void 0
                    })]);
                    return t ? (this.__redirectUrl(), p) : (0, M.n)(200, p).then((() => this.__redirectUrl())).catch((() => this.__redirectUrl()))
                }
            }
            ae.formActionType = r.$b;
            var le = ae,
                de = n(47474),
                ce = n(68371),
                me = n(85301);
            class ue extends l {
                constructor(e) {
                    super(e), this.getState = void 0, this.formActionType = r.Cd, this.getState = e.getState, this.__handler = this.__handler.bind(this)
                }
                __handler() {
                    var e, t;
                    const n = this.getState(),
                        {
                            previousFormSubmitBody: o
                        } = n.onsiteState.client,
                        i = (null == o ? void 0 : o.data.attributes.profile.data.attributes[V.Td]) || (null == o || null == (e = o.data.attributes.profile.data.attributes.properties) ? void 0 : e[V.HD]),
                        r = null == o || null == (t = o.data) || null == (t = t.relationships) || null == (t = t.list) || null == (t = t.data) ? void 0 : t.id;
                    if (!i || !r || !(0, ce.q)(n, r)) throw (0, y.M)({
                        metric: x.Yu,
                        logCustomEvent: !0,
                        formVersionCId: this.formVersionCId,
                        formId: this.formId,
                        companyId: this.companyId,
                        userEmail: i,
                        listId: r
                    }), new Error("Cannot redirect to inbox. Email address and list ID must both be present.");
                    const {
                        senderEmail: a,
                        subject: l
                    } = (0, ce.U)(n, r), d = (0, Z.Z)() === me.Jq, c = (0, de.qV)({
                        userEmail: i,
                        subject: l,
                        senderEmail: a
                    }), {
                        link: m,
                        provider: u
                    } = c || {};
                    if ((0, y.M)({
                            metric: x.t2,
                            logCustomEvent: !0,
                            formVersionCId: this.formVersionCId,
                            formId: this.formId,
                            companyId: this.companyId,
                            userEmail: i,
                            listId: r,
                            sniper_link: m,
                            emailProvider: u
                        }), m) {
                        const e = window.open(m, "_blank");
                        null == e || e.focus()
                    } else(0, s.qB)(`Could not generate sniper link. User email: ${i}. List ID: ${r}. isMobileDevice: ${d}. subject: ${l}. senderEmail: ${a}`)
                }
            }
            ue.formActionType = r.Cd;
            var fe = ue;
            class pe extends K {
                constructor(e) {
                    super(e), this.getState = void 0, this.getState = e.getState, this.__postHandler = this.__postHandler.bind(this), this.__handlePassedCaptchaChallenge = this.__handlePassedCaptchaChallenge.bind(this)
                }
                __postHandler(e) {
                    return super.__postHandler(e), e && this.__submitHandlerCheck(e.status), new Promise((e => {
                        if (this.composedFields.$email || this.composedFields.$phone_number) {
                            let t = 5;
                            const n = setInterval((() => {
                                ((0, p.pN)() || 0 === t) && (clearInterval(n), e(!0)), t -= 1
                            }), 600)
                        }
                        e(!0)
                    })).then((() => {
                        const {
                            formVersionCId: e,
                            actionId: t
                        } = this;
                        return new le({
                            actionId: t,
                            formVersionCId: e,
                            getState: this.getState,
                            isSubmit: !0
                        }).runAction()
                    }))
                }
                __submitToList() {
                    return this.__baseSubmitToList(f.s)
                }
                __handlePassedCaptchaChallenge() {
                    new pe({
                        actionId: this.actionId,
                        formVersionCId: this.formVersionCId,
                        getState: this.getState
                    }).runAction()
                }
            }
            pe.formActionType = r.uo;
            var he = pe;
            class ve extends K {
                constructor(e) {
                    super(e), this.getState = void 0, this.getState = e.getState, this.__postHandler = this.__postHandler.bind(this), this.__handlePassedCaptchaChallenge = this.__handlePassedCaptchaChallenge.bind(this)
                }
                __postHandler(e) {
                    super.__postHandler(e), e && this.__submitHandlerCheck(e.status);
                    const {
                        formVersionCId: t,
                        actionId: n
                    } = this;
                    return new u({
                        actionId: n,
                        formVersionCId: t,
                        getState: this.getState,
                        isSubmit: !0
                    }).runAction()
                }
                __submitToList() {
                    return this.__baseSubmitToList(f.s)
                }
                __handlePassedCaptchaChallenge() {
                    new ve({
                        actionId: this.actionId,
                        formVersionCId: this.formVersionCId,
                        getState: this.getState
                    }).runAction()
                }
            }
            ve.formActionType = r.Ry;
            var ge = ve;
            const ye = (e, t) => {
                    const n = e.onsiteState.openFormVersions[t];
                    if (!n) throw new Error("Open Form Version does not exist");
                    const {
                        formVersionId: o
                    } = n;
                    return (0, w.l1)(e, o, me.Jq).find((e => e.componentType === V.Ys))
                },
                Ie = new Date("1/1/1900");

            function be(e) {
                return e && 6 === e.length
            }
            class Se extends l {
                constructor(e) {
                    var t, n, o;
                    super(e), this.toPhoneNumber = void 0, this.hiddenFieldsComponentId = void 0, this.optInMessage = void 0, this.optInKeyword = void 0, this.getState = void 0, this.hiddenFieldsComponentId = (0, w.cA)(e.getState(), e.actionId), this.toPhoneNumber = null == (t = this.formAction.data) ? void 0 : t.toPhoneNumber, this.optInMessage = (null == (n = this.formAction.data) ? void 0 : n.optInMessage) || "Send this text to subscribe to SMS updates!", this.optInKeyword = (null == (o = this.formAction.data) ? void 0 : o.optInKeyword) || "JOIN", this.formActionType = r.T5, this.getState = e.getState, this.__preHandler = this.__preHandler.bind(this), this.__handler = this.__handler.bind(this)
                }
                async __preHandler() {
                    const e = this.getState(),
                        t = ye(e, this.formVersionCId);
                    if (void 0 !== t) {
                        var n;
                        const e = null == (n = await (0, d.eN)({
                            formVersionCId: this.formVersionCId
                        })) ? void 0 : n.filter((e => e.componentId === t.componentId));
                        if (e && e.some((({
                                valid: e
                            }) => !e))) throw new A.mN({
                            type: "form"
                        })
                    }
                    return !0
                }
                __handler() {
                    const e = this.getState(),
                        t = ((e, t, n) => {
                            const o = ye(e, t);
                            if (o && void 0 !== (r = o).data.format && void 0 !== r.data.delimiter) {
                                var i;
                                const o = (0, C.$f)({
                                        state: e,
                                        formVersionCId: t,
                                        hiddenFieldsComponentId: n
                                    }),
                                    r = (null == (i = e.onsiteState.openFormVersions[t]) || null == (i = i.sentIdentifiers) ? void 0 : i[V.vC]) || o[V.vC];
                                if (!r || "string" != typeof r) return;
                                const s = new Date(r).getTime() - Ie.getTime();
                                return Math.round(s / 864e5).toString(36)
                            }
                            var r
                        })(e, this.formVersionCId, this.hiddenFieldsComponentId),
                        n = e.onsiteState.client.smsSubscriptionUniqueId,
                        o = ((e, t, n) => be(t) && n ? `${e}:${t}:${n}` : n ? `${e}:$kbday:${n}` : be(t) ? `${e}:${t}` : `${e}`)(this.optInKeyword, n, t),
                        i = `sms:${this.toPhoneNumber}?&body=${encodeURIComponent(`${this.optInMessage} (ref:${o})`)}`;
                    (0, b.$k)({
                        formId: this.formId,
                        successActionType: r.T5
                    }), (0, d.et)({
                        formVersionCId: this.formVersionCId,
                        isSubmit: !0
                    });
                    const s = (0, W.f8)(e, this.formVersionCId, !0),
                        a = e.onsiteState.openFormVersions[this.formVersionCId],
                        l = a ? e.formsState.views[a.currentViewId] : void 0,
                        c = [];
                    if ((0, C.Gt)(e, this.formVersionCId, s) && c.push((0, y.M)({
                            metric: x.FB,
                            logCustomEvent: !0,
                            formVersionCId: this.formVersionCId,
                            formId: this.formId,
                            companyId: this.companyId,
                            action_type: "Subscribe Via SMS",
                            sms_keyword: this.optInKeyword,
                            destination_url: i
                        })), l) {
                        var m;
                        const t = null != (m = (0, E.O)(e, l)) ? m : l.position;
                        c.push((0, y.M)({
                            metric: x.AH,
                            formVersionCId: this.formVersionCId,
                            logCustomEvent: !0,
                            formId: this.formId,
                            companyId: this.companyId,
                            step_number: t + 1,
                            step_name: (0, E.E5)(e, l.viewId),
                            action_type: "Subscribe Via SMS"
                        }))
                    }
                    const u = Promise.allSettled(c);
                    return (0, M.n)(200, u).then((() => (0, re.Z)(i))).catch((() => (0, re.Z)(i)))
                }
            }
            Se.formActionType = r.T5;
            var we = Se;
            class Ce extends l {
                constructor(e) {
                    var t, n, o;
                    super(e), this.whatsappToPhoneNumber = void 0, this.hiddenFieldsComponentId = void 0, this.whatsappOptInMessage = void 0, this.whatsappOptInKeyword = void 0, this.getState = void 0, this.hiddenFieldsComponentId = (0, w.cA)(e.getState(), e.actionId), this.whatsappToPhoneNumber = null == (t = this.formAction.data) ? void 0 : t.whatsappToPhoneNumber, this.whatsappOptInMessage = (null == (n = this.formAction.data) ? void 0 : n.whatsappOptInMessage) || "Send this text to subscribe to WhatsApp updates!", this.whatsappOptInKeyword = (null == (o = this.formAction.data) ? void 0 : o.whatsappOptInKeyword) || "JOIN", this.getState = e.getState, this.__handler = this.__handler.bind(this)
                }
                __handler() {
                    const e = this.getState(),
                        t = e.onsiteState.client.whatsappSubscriptionUniqueId,
                        n = ((e, t) => t ? `${e}:${t}` : `${e}`)(this.whatsappOptInKeyword, t),
                        o = `https://wa.me/${this.whatsappToPhoneNumber}?text=${encodeURIComponent(`${this.whatsappOptInMessage} (ref:${n})`)}`;
                    (0, b.$k)({
                        formId: this.formId,
                        successActionType: r.p4
                    }), (0, d.et)({
                        formVersionCId: this.formVersionCId,
                        isSubmit: !0
                    });
                    const i = (0, W.f8)(e, this.formVersionCId, !0),
                        s = e.onsiteState.openFormVersions[this.formVersionCId],
                        a = s ? e.formsState.views[s.currentViewId] : void 0,
                        l = [];
                    if ((0, C.Gt)(e, this.formVersionCId, i) && l.push((0, y.M)({
                            metric: x.X7,
                            logCustomEvent: !0,
                            formVersionCId: this.formVersionCId,
                            formId: this.formId,
                            companyId: this.companyId,
                            action_type: "Subscribe Via WhatsApp",
                            whatsapp_keyword: this.whatsappOptInKeyword,
                            destination_url: o
                        })), a) {
                        var c;
                        const t = null != (c = (0, E.O)(e, a)) ? c : a.position;
                        l.push((0, y.M)({
                            metric: x.AH,
                            formVersionCId: this.formVersionCId,
                            logCustomEvent: !0,
                            formId: this.formId,
                            companyId: this.companyId,
                            step_number: t + 1,
                            step_name: (0, E.E5)(e, a.viewId),
                            action_type: "Subscribe Via WhatsApp"
                        }))
                    }
                    const m = Promise.allSettled(l);
                    return (0, M.n)(200, m).then((() => (0, re.Z)(o))).catch((() => (0, re.Z)(o)))
                }
            }
            Ce.formActionType = r.p4;
            var Ee = Ce,
                xe = n(46456);
            let Ve, _e = !1;
            class Te extends z {
                constructor(e) {
                    super(e), this.isSubmit = void 0, this.getState = void 0, this.isSubmit = !1, this.formActionType = r.WP, this.getState = e.getState, Ve = null, _e || (_e = !0, this.startTimer()), this.__handler = this.__handler.bind(this)
                }
                startTimer() {
                    Ve = setTimeout((() => {
                        Ve = null
                    }), 5e3)
                }
                __handler() {
                    if (null !== Ve) return (0, s.qB)("ResendOptInCodeAction - Resend opt in code action is currently debouncing."), Promise.resolve();
                    this.startTimer();
                    const e = this.getState(),
                        {
                            smartOptInData: t,
                            previousFormSubmitBody: n
                        } = e.onsiteState.client;
                    if (null == t || !t.phoneNumber || null == t || !t.listId) throw new Error("Cannot resend opt in code. Smart Opt-In data with phone number and list id not found.");
                    const {
                        phoneNumber: o,
                        email: i
                    } = t, r = (0, xe.Z)(null == n ? void 0 : n.data.attributes.profile.data.attributes.properties) ? null == n ? void 0 : n.data.attributes.profile.data.attributes.properties : {}, a = {
                        [V.HO]: o,
                        properties: r
                    };
                    return i && (a.properties = Object.assign({}, a.properties, {
                        [V.HD]: i
                    })), (0, y.M)({
                        metric: x.Eo,
                        formVersionCId: this.formVersionCId,
                        formId: this.formId,
                        companyId: this.companyId,
                        submittedFields: a
                    }), (0, f.Y)(this.companyId, {
                        data: {
                            type: _.NR,
                            attributes: {
                                profile: {
                                    data: {
                                        type: _.cC,
                                        attributes: a
                                    }
                                }
                            },
                            relationships: Object.assign({}, this.smartOptInListRelationships, this.formRelationships)
                        },
                        meta: {
                            send_otp_code: !0
                        }
                    })
                }
            }
            Te.formActionType = r.WP;
            var ke = Te,
                $e = n(70510),
                Fe = n(87100),
                Oe = n(72626),
                Ze = n(24878);
            var Ae = n(32962);
            const Me = ["isSubmit"];
            class De extends K {
                constructor(e) {
                    let t = i()(e, Me);
                    super(t), this.isSubmit = void 0, this.getState = void 0, this.isSubmit = !0, this.formActionType = r.Kc, this.getState = t.getState, this.__handler = this.__handler.bind(this), this.__postHandler = this.__postHandler.bind(this), this.__submitSuccessMetrics = this.__submitSuccessMetrics.bind(this)
                }
                __handler() {
                    const e = this.getState();
                    if (!e.onsiteState.openFormVersions[this.formVersionCId]) throw new Error("Open Form Version does not exist");
                    const {
                        smartOptInData: t
                    } = e.onsiteState.client, n = null == t ? void 0 : t.phoneNumber, o = this.composedFields[V.My];
                    if (!n || !o || "string" != typeof n || "string" != typeof o) throw new Error(`Cannot submit opt in code. Smart Opt-In phone number and token must both be present: ${JSON.stringify({phoneNumber:n,token:o})}`);
                    return (0, h.W)((() => (async ({
                        companyId: e,
                        phoneNumber: t,
                        token: n
                    }) => (await (0, Ze.l)(), (0, Fe.Z)(`https://a.klaviyo.com/client/otp-verify?company_id=${e}`, {
                        method: "POST",
                        headers: Object.assign({
                            "Access-Control-Allow-Headers": "*",
                            "Content-Type": "application/json"
                        }, (0, Oe.h)()),
                        body: JSON.stringify({
                            token: n,
                            channel: "sms",
                            destination: t,
                            company_id: e
                        })
                    })))({
                        companyId: this.companyId,
                        phoneNumber: n,
                        token: o
                    })), 5, 1e3 + 1e3 * Math.random(), [429]).then((e => {
                        if (429 === e.status) throw new A.TT;
                        return e
                    })).then((t => {
                        var n;
                        const {
                            formVersionCId: o
                        } = this, i = null == (n = e.onsiteState.openFormVersions[o]) ? void 0 : n.formVersionId;
                        if (t.status === _.ke && i) {
                            const t = (0, $e.G)(e, i)[0],
                                n = (0, E.nC)(e, t).find((e => (null == e ? void 0 : e.componentType) === V.eC));
                            if (n) throw (0, d.hX)({
                                componentId: null == n ? void 0 : n.componentId,
                                formVersionCId: o,
                                violation: {
                                    componentId: null == n ? void 0 : n.componentId,
                                    valid: !1,
                                    validationErrorType: Ae.pv
                                }
                            }), new A.mN({
                                type: Ae.pv
                            })
                        }
                        return t
                    })).then((e => e.status === _.dl && this.formAction.actionType ? ((0, b.$k)({
                        formId: this.formId,
                        successActionType: this.formAction.actionType
                    }), (0, M.n)(200, this.__submitSuccessMetrics()).then((() => e)).catch((() => e))) : e))
                }
                async __postHandler(e) {
                    super.__postHandler(e);
                    if (!this.getState().onsiteState.openFormVersions[this.formVersionCId] || !this.formAction.viewId) return null;
                    if ((null == e ? void 0 : e.status) === _.ke) return null;
                    e && this.__submitHandlerCheck(e.status);
                    return new ne({
                        actionId: this.actionId,
                        formVersionCId: this.formVersionCId,
                        getState: this.getState
                    }).runAction()
                }
                async __submitSuccessMetrics() {
                    const e = this.getState();
                    this.submitMetric({
                        state: e,
                        isSubscribe: !0
                    });
                    return (0, y.M)({
                        metric: x.Jv,
                        logCustomEvent: !0,
                        formVersionCId: this.formVersionCId,
                        formId: this.formId,
                        companyId: this.companyId,
                        submittedFields: this.composedFields,
                        action_type: "Submit Form"
                    })
                }
            }
            De.formActionType = r.Kc;
            var Be = De;
            const Ne = ["isSubmit"];
            class je extends l {
                constructor(e) {
                    var t, n, o;
                    let r = i()(e, Ne);
                    super(r), this.formIdToOpen = void 0, this.closeSourceForm = void 0, this.isSubmit = void 0, this.getState = void 0, this.onRenderForms = void 0, this.formIdToOpen = null == (t = this.formAction.data) ? void 0 : t.formIdToOpen, this.closeSourceForm = null != (n = null == (o = this.formAction.data) ? void 0 : o.closeSourceForm) && n, this.getState = r.getState, this.onRenderForms = r.onRenderForms, this.__openFormVersion = this.__openFormVersion.bind(this), this.__handler = this.__handler.bind(this)
                }
                __openFormVersion() {
                    if (this.closeSourceForm && (0, d.et)({
                            formVersionCId: this.formVersionCId
                        }), !this.formIdToOpen) return void console.error("No form to open specified.");
                    const e = this.getState().formsState.forms[this.formIdToOpen];
                    null != e && e.liveFormVersion ? (0, d.f7)({
                        formVersionId: null == e ? void 0 : e.liveFormVersion,
                        onRenderForms: this.onRenderForms,
                        allowReTriggering: !0
                    }) : console.error(`Form with formId: ${this.formIdToOpen} does not have a live form version. Please check the form configuration.`)
                }
                __handler() {
                    const {
                        formId: e,
                        formVersionCId: t
                    } = this;
                    this.formAction.actionType === r.y6 && (0, b.$k)({
                        formId: e,
                        successActionType: r.y6
                    });
                    const n = this.getState().onsiteState.openFormVersions[t];
                    if (!n) throw new Error("Open Form Version does not exist");
                    const o = n.sentSubmitMetric,
                        i = Promise.allSettled([(0, y.M)({
                            metric: x.qo,
                            logTelemetric: !this.isSubmit && !o,
                            logCustomEvent: !0,
                            formVersionCId: this.formVersionCId,
                            formId: this.formId,
                            companyId: this.companyId,
                            action_type: "Open Form",
                            form_to_open: this.formIdToOpen
                        })]);
                    return (0, M.n)(200, i).then((() => this.__openFormVersion())).catch((() => this.__openFormVersion()))
                }
            }
            je.formActionType = r.y6;
            var Re = je;
            const Pe = ["$phone_number"];
            class Le extends K {
                constructor(e) {
                    super(e), this.getState = void 0, this.__submitHandler = (e, t) => {
                        var n, o;
                        const r = this.getState(),
                            s = r.onsiteState.openFormVersions[this.formVersionCId];
                        let a = t;
                        if (void 0 === s) throw new Error("Expected open form version");
                        const l = (0, w.CW)(r, this.formVersionCId),
                            {
                                phoneNumberConsentChannels: d,
                                apiCallChannelSettings: c
                            } = this.__buildChannelSettings(l),
                            m = (0, w.Mh)(r, s.formVersionId, d);
                        if (void 0 === m) throw new Error("Expected list ID");
                        const u = null == (n = t.data.attributes.profile.data.attributes.properties) ? void 0 : n.$phone_number;
                        if (void 0 === u) throw new Error("Expected phone number for SMS promotional opt in action");
                        const p = null != (o = t.data.attributes.profile.data.attributes.properties) ? o : {},
                            h = i()(p, Pe);
                        return a = Object.assign({}, t, {
                            data: Object.assign({}, t.data, {
                                attributes: {
                                    profile: Object.assign({}, t.data.attributes.profile, {
                                        data: Object.assign({}, t.data.attributes.profile.data, {
                                            attributes: Object.assign({}, t.data.attributes.profile.data.attributes, {
                                                properties: h,
                                                phone_number: u,
                                                subscriptions: Object.assign({}, t.data.attributes.profile.data.attributes.email ? {
                                                    email: {
                                                        marketing: {
                                                            consent: "SUBSCRIBED"
                                                        }
                                                    }
                                                } : {}, c)
                                            })
                                        })
                                    })
                                },
                                relationships: Object.assign({
                                    list: {
                                        data: {
                                            type: _._,
                                            id: m
                                        }
                                    }
                                }, this.formRelationships)
                            })
                        }), (0, f.Y)(e, a)
                    }, this.formActionType = r.pt, this.getState = e.getState, this.__submitHandler = this.__submitHandler.bind(this), this.__postHandler = this.__postHandler.bind(this)
                }
                __submitToList() {
                    return this.__baseSubmitToList(this.__submitHandler)
                }
                async __postHandler(e) {
                    super.__postHandler(e);
                    if (!this.getState().onsiteState.openFormVersions[this.formVersionCId] || !this.formAction.viewId) return null;
                    e && this.__submitHandlerCheck(e.status);
                    const t = this.formAction.viewId;
                    return (0, d.Cm)({
                        id: this.formVersionCId,
                        changes: {
                            currentViewId: t
                        }
                    })
                }
                __buildChannelSettings(e) {
                    const t = [],
                        n = {},
                        o = {
                            sms: $.Tg.SMS,
                            whatsapp: $.Tg.WHATSAPP
                        };
                    return Object.entries(o).forEach((([o, i]) => {
                        const r = null == e ? void 0 : e[i];
                        if (r === $.E3.MULTI_STEP_TRANSACTIONAL_PROMOTIONAL) t.push(i), n[o] = {
                            marketing: {
                                consent: "SUBSCRIBED"
                            }
                        };
                        else if (r) throw new Error(`Expected consent type to be ${$.E3.MULTI_STEP_TRANSACTIONAL_PROMOTIONAL} but got ${JSON.stringify(e)}`)
                    })), {
                        phoneNumberConsentChannels: t,
                        apiCallChannelSettings: n
                    }
                }
            }
            Le.formActionType = r.pt;
            var ze = Le;
            class We extends K {
                constructor(e) {
                    super(e), this.getState = void 0, this.getState = e.getState, this.__handler = this.__handler.bind(this), this.__postHandler = this.__postHandler.bind(this)
                }
                __submitToList() {
                    return this.__baseSubmitToList(f.s)
                }
                __storeCurrentStepData() {
                    const e = this.getState().onsiteState.openFormVersions[this.formVersionCId];
                    if (!e) return;
                    const t = Object.assign({}, e.accumulatedFormData, this.composedFields);
                    (0, d.fK)({
                        id: this.formVersionCId,
                        changes: {
                            accumulatedFormData: t
                        }
                    })
                }
                async __handler() {
                    const e = this.getState(),
                        t = e.onsiteState.openFormVersions[this.formVersionCId];
                    if (!t) throw new Error("Open Form Version does not exist");
                    this.__storeCurrentStepData();
                    const n = (0, Y.Bu)(e, this.formVersionCId, this.composedFields),
                        o = !!n.$phone_number,
                        i = !!n.opt_in_promotional_email && "true" === n.opt_in_promotional_email;
                    (0, s.qB)("Back-in-stock submit check", {
                        hasPhoneFromAnyStep: o,
                        hasEmailOptInFromAnyStep: i,
                        opt_in_promotional_email: n.opt_in_promotional_email
                    });
                    const r = o || i;
                    let a;
                    if ((0, s.qB)("Back-in-stock debug - shouldSubmitToList:", {
                            shouldSubmitToList: r
                        }), r) {
                        const e = this.composedFields,
                            t = "true" === n.opt_in_promotional_email;
                        this.composedFields = Object.assign({}, n, {
                            opt_in_promotional_email: t ? "true" : "false",
                            [V.eQ]: o ? "true" : "false"
                        }), a = super.__handler() || Promise.resolve(null), this.composedFields = e
                    } else a = Promise.resolve(null);
                    t.sentBackInStockSubmitMetric || ((0, y.M)({
                        metric: x.x_,
                        formVersionCId: this.formVersionCId,
                        formId: this.formId,
                        companyId: this.companyId,
                        submittedFields: n,
                        logCustomEvent: !0,
                        logTelemetric: !0
                    }), (0, d.fK)({
                        id: this.formVersionCId,
                        changes: {
                            sentBackInStockSubmitMetric: !0
                        }
                    }));
                    const l = (0, E.E5)(e, t.currentViewId),
                        c = e.formsState.views[t.currentViewId],
                        m = c ? (0, E.O)(e, c) : void 0;
                    return (0, y.M)({
                        metric: x.U9,
                        formVersionCId: this.formVersionCId,
                        formId: this.formId,
                        companyId: this.companyId,
                        submittedFields: Object.assign({}, n, {
                            $step_name: l
                        }),
                        step_name: l,
                        step_number: void 0 !== m ? m + 1 : m,
                        logCustomEvent: !0,
                        logTelemetric: !0
                    }), a
                }
                async __postHandler(e) {
                    super.__postHandler(e), e && this.__submitHandlerCheck(e.status);
                    if (!this.getState().onsiteState.openFormVersions[this.formVersionCId] || !this.formAction.viewId) return null;
                    return new ne({
                        actionId: this.actionId,
                        formVersionCId: this.formVersionCId,
                        getState: this.getState
                    }).runAction()
                }
                __makePOSTBody({
                    composedFields: e,
                    requestOTPCode: t = !1,
                    phoneInputConsentTypes: n
                }) {
                    const o = super.__makePOSTBody({
                        composedFields: e,
                        requestOTPCode: t,
                        phoneInputConsentTypes: n
                    });
                    if (e.$phone_number) {
                        const e = o.data.attributes.profile.data.attributes.subscriptions;
                        return Object.assign({}, o, {
                            data: Object.assign({}, o.data, {
                                attributes: Object.assign({}, o.data.attributes, {
                                    profile: Object.assign({}, o.data.attributes.profile, {
                                        data: Object.assign({}, o.data.attributes.profile.data, {
                                            attributes: Object.assign({}, o.data.attributes.profile.data.attributes, {
                                                subscriptions: Object.assign({}, e, {
                                                    sms: {
                                                        marketing: {
                                                            consent: "SUBSCRIBED"
                                                        }
                                                    }
                                                })
                                            })
                                        })
                                    })
                                })
                            })
                        })
                    }
                    return o
                }
            }
            We.formActionType = r.r8;
            var He = We;
            class Ue extends l {
                constructor(e) {
                    var t, n;
                    super(e), this.deepLinkUrl = void 0, this.deepLinkUrl = null != (t = null == (n = this.formAction.data) ? void 0 : n.deepLinkUrl) ? t : "", this.formActionType = Ue.formActionType
                }
                async __handler() {
                    var e;
                    return await (0, M.n)(200, Promise.allSettled([(0, y.M)({
                        metric: x.VJ,
                        logTelemetric: !0,
                        logCustomEvent: !0,
                        formVersionCId: this.formVersionCId,
                        formId: this.formId,
                        companyId: this.companyId,
                        action_type: "Go to Deep Link URL",
                        destination_url: this.deepLinkUrl
                    })])).catch((() => {})), (0, b.$k)({
                        formId: this.formId,
                        successActionType: r.eZ
                    }), (0, d.fK)({
                        id: this.formVersionCId,
                        changes: {
                            logCloseMetric: !1
                        }
                    }), null == (e = this.messageBus) || e.emit("openDeepLink", {
                        ios: this.deepLinkUrl,
                        android: this.deepLinkUrl
                    }), (0, d.et)({
                        formVersionCId: this.formVersionCId,
                        isSubmit: !0
                    })
                }
            }
            Ue.formActionType = r.eZ;
            var qe = Ue;
            const Ke = {
                    [qe.formActionType]: qe
                },
                Ge = Object.assign({
                    [u.formActionType]: u,
                    [ie.formActionType]: ie,
                    [ne.formActionType]: ne,
                    [le.formActionType]: le,
                    [fe.formActionType]: fe,
                    [ge.formActionType]: ge,
                    [he.formActionType]: he,
                    [we.formActionType]: we,
                    [Ee.formActionType]: Ee,
                    [ke.formActionType]: ke,
                    [Be.formActionType]: Be,
                    [Re.formActionType]: Re,
                    [ze.formActionType]: ze,
                    [He.formActionType]: He
                }, Ke),
                Ye = ({
                    actionId: e,
                    getState: t
                }) => {
                    var n;
                    const o = t(),
                        i = o.formsState.actions ? null == (n = o.formsState.actions[e]) ? void 0 : n.actionType : void 0;
                    return Ge[i]
                }
        },
        32962: function(e, t, n) {
            n.d(t, {
                pv: function() {
                    return o
                }
            });
            const o = "invalidCode"
        },
        30847: function(e, t, n) {
            n.d(t, {
                M: function() {
                    return m
                },
                displayBackInStockButtonHandler: function() {
                    return f
                }
            });
            n(92461), n(70818), n(39265), n(60873), n(61099);
            var o = n(92719),
                i = n(22982),
                r = n(85912),
                s = n(42376),
                a = n(26178),
                l = n(68502),
                d = n(12616),
                c = n(47774);
            const m = "klaviyo-bis-button-container",
                u = async ({
                    formId: e,
                    formVersionId: t,
                    openForm: r,
                    foundDynamicButtonId: s,
                    normalizedFormData: d
                }) => {
                    let c, u, f;
                    try {
                        var p, h;
                        const v = await (async e => {
                            const t = (await Promise.all([n.e(2462), n.e(8760), n.e(8257)]).then(n.bind(n, 47072))).createInitializer().getPlatform();
                            if (!t) return (0, o.mm)(`Back in Stock: Platform adapter not available. Button will not be placed. formVersionId: ${e}`), null;
                            const i = t.getButtonPlacementInfo();
                            return i && i.button && i.container ? i : ((0, o.mm)(`Back in Stock: Target button or container NOT FOUND via platform adapter. Button will not be placed. formVersionId: ${e}`), null)
                        })(t);
                        if (!v) return null;
                        const {
                            button: g,
                            container: y
                        } = v;
                        f = g;
                        const I = null == (p = d.data.dynamicButtons) || null == (p = p[s]) ? void 0 : p.data,
                            b = null == I ? void 0 : I.display;
                        await (async e => {
                            if (null == e || !e.fontFamily) return;
                            const t = e.fontFamily.split(",").map((e => e.trim())).filter(Boolean);
                            if (0 === t.length) return;
                            const o = e.fontWeight,
                                r = "string" == typeof o ? parseInt(o, 10) : o,
                                s = r ? [r] : [400, 500, 600, 700];
                            try {
                                const {
                                    waitForFontFamilies: e
                                } = await Promise.resolve().then(n.bind(n, 27883));
                                await e(t, {
                                    weights: s
                                })
                            } catch (e) {
                                const t = e instanceof Error ? e : new Error(String(e));
                                (0, i.T)(t, {
                                    tags: {
                                        feature: "bis-font-loading"
                                    },
                                    extra: {
                                        message: "Failed to wait for button fonts"
                                    }
                                })
                            }
                        })(null == I ? void 0 : I.textStyles);
                        const S = document.createElement("div");
                        S.id = m, S.style.marginBottom = "10px", "fitToText" !== (null == I || null == (h = I.buttonStyles) ? void 0 : h.width) && (S.style.flex = "1"), "NEXT_TO" !== b && (c = g.style.getPropertyValue("display"), u = g.style.getPropertyPriority("display"), g.style.setProperty("display", "none", "important"));
                        const w = l.Z.getState().onsiteState.client.klaviyoCompanyId;
                        return (0, o.mm)(`Back in Stock: Button placement for formVersionId: ${t}, companyId: ${w}`), (({
                            targetSoldOutButton: e,
                            parentOfSoldOutButtonFromPlatform: t,
                            containerDiv: n,
                            displaySetting: i,
                            formVersionId: r,
                            onContainerRemoved: s
                        }) => {
                            if (!t.contains(e)) throw (0, o.mm)(`Back in Stock: targetSoldOutButton is not a child of parentOfSoldOutButton. Cannot place button. formVersionId: ${r}`), new Error("targetSoldOutButton not a child of parentOfSoldOutButton during BIS button placement"); {
                                const t = e.parentElement;
                                if (!t) throw (0, o.mm)(`Back in Stock: targetSoldOutButton for formVersionId: ${r} has no direct parent. Button cannot be placed.`), new Error(`targetSoldOutButton for formVersionId: ${r} has no direct parent.`);
                                "NEXT_TO" !== i ? t.insertBefore(n, e) : e.insertAdjacentElement("afterend", n), new MutationObserver(((e, t) => {
                                    for (const o of e)
                                        if ("childList" === o.type && Array.from(o.removedNodes).some((e => e === n))) {
                                            s(), t.disconnect();
                                            break
                                        }
                                })).observe(t, {
                                    childList: !0
                                })
                            }
                        })({
                            targetSoldOutButton: g,
                            parentOfSoldOutButtonFromPlatform: y,
                            containerDiv: S,
                            displaySetting: b,
                            formVersionId: t,
                            onContainerRemoved: () => {
                                void 0 !== c && (g.style.setProperty("display", c, u), "" === c && g.style.removeProperty("display"))
                            }
                        }), (({
                            foundDynamicButtonId: e,
                            formVersionId: t,
                            openForm: n,
                            formId: i
                        }) => {
                            if ((0, o.mm)(`Preparing to render BackInStockButtonComponent via portal for formVersionId: ${t}.`), "function" != typeof a.C) throw (0, o.mm)(`Back in Stock: setBISPortalConfig is not a function for formVersionId: ${t}.`), new Error(`setBISPortalConfig function is not available or not imported correctly for formId: ${i}, formVersionId: ${t}`);
                            (0, a.C)({
                                dynamicButtonId: e,
                                formVersionId: t,
                                onClick: n
                            }), (0, o.mm)(`Back in Stock: Requested Notify Me button for formVersionId: ${t} to be rendered via portal.`)
                        })({
                            foundDynamicButtonId: s,
                            formVersionId: t,
                            openForm: r,
                            formId: e
                        }), S
                    } catch (n) {
                        const r = n instanceof Error ? n : new Error(String(n));
                        return f && void 0 !== c && (f.style.setProperty("display", c, u), "" === c && f.style.removeProperty("display")), (0, i.T)(r, {
                            tags: {
                                handler: "createPlatformSpecificContainer"
                            },
                            extra: {
                                formId: e,
                                formVersionId: t,
                                foundDynamicButtonId: s
                            }
                        }), (0, o.mm)(`Back in Stock: Error creating platform specific container for formVersionId: ${t}. Error: ${r.message}`), null
                    }
                },
                f = async ({
                    formId: e,
                    formVersionId: t,
                    normalizedFormData: n,
                    openForm: a
                }) => {
                    if (document.getElementById(m))(0, o.mm)(`Back in Stock: Container ${m} already exists. Skipping for formVersionId: ${t}.`);
                    else try {
                        if (null == n || !n.data) return void(0, o.mm)("Back in Stock: normalizedFormData or its data is missing. Cannot place button.", {
                            formId: e,
                            formVersionId: t
                        });
                        const {
                            dynamicButtons: i
                        } = n.data;
                        if (!i) return void(0, o.mm)(`Back in Stock: No dynamicButtons in normalizedFormData for formId: ${e}, formVersionId: ${t}.`);
                        const m = Object.keys(i).find((e => {
                            const n = i[e];
                            return (null == n ? void 0 : n.formVersionId) === t && (null == n ? void 0 : n.type) === d.I
                        }));
                        if (!m) return void(0, o.mm)(`Back in Stock: No matching dynamic button for formVersionId: ${t}.`);
                        if (await u({
                                formId: e,
                                formVersionId: t,
                                openForm: a,
                                foundDynamicButtonId: m,
                                normalizedFormData: n
                            })) {
                            const n = l.Z.getState().onsiteState.client.klaviyoCompanyId;
                            if (n) {
                                const i = (0, r.Z)();
                                (0, o.mm)(`Back in Stock: Button successfully placed for formVersionId: ${t}, logging placed metric.`), (0, s.M)({
                                    metric: c.MD,
                                    formVersionCId: i,
                                    formId: e,
                                    companyId: n
                                })
                            }
                        }
                    } catch (n) {
                        const r = n instanceof Error ? n : new Error(String(n));
                        (0, i.T)(r, {
                            tags: {
                                handler: "displayBackInStockButtonHandler",
                                point: "dynamicButtonsAccess"
                            },
                            extra: {
                                formId: e,
                                formVersionId: t
                            }
                        }), (0, o.mm)(`Back in Stock: Error in displayBackInStockButtonHandler for formVersionId: ${t}. Error: ${r.message}`)
                    }
                }
        },
        91977: function(e, t) {
            t.Z = e => {
                window.location.assign(e)
            }
        },
        26178: function(e, t, n) {
            n.d(t, {
                C: function() {
                    return i
                },
                m: function() {
                    return r
                }
            });
            var o = n(68502);
            const i = e => {
                    o.Z.setState((t => Object.assign({}, t, {
                        onsiteState: Object.assign({}, t.onsiteState, {
                            bisPortalConfig: e
                        })
                    })))
                },
                r = () => {
                    o.Z.setState((e => Object.assign({}, e, {
                        onsiteState: Object.assign({}, e.onsiteState, {
                            bisPortalConfig: void 0
                        })
                    })))
                }
        },
        87467: function(e, t, n) {
            n.d(t, {
                A: function() {
                    return m
                }
            });
            n(22923), n(92461), n(70818), n(60873);
            var o = n(47474),
                i = n(68502),
                r = n(51950),
                s = n(94756),
                a = n(47774),
                l = n(68371),
                d = n(42376),
                c = n(57511);
            const m = (e, t, n, m) => {
                var u, f;
                const p = i.Z.getState(),
                    h = (p.formsState.actions ? Object.values(p.formsState.actions) : []).filter((e => (null == e ? void 0 : e.actionType) === s.Cd)).map((e => null == e ? void 0 : e.actionId));
                if (0 === h.length) return;
                const v = (0, c.nC)(p, m).filter((e => e && "BUTTON" === e.componentType && e.actionId && h.includes(e.actionId))).map((e => null == e ? void 0 : e.componentId));
                if (0 === v.length) return;
                const {
                    previousFormSubmitBody: g
                } = p.onsiteState.client, y = null == g || null == (u = g.data) || null == (u = u.relationships) || null == (u = u.list) || null == (u = u.data) ? void 0 : u.id, I = (null == g ? void 0 : g.data.attributes.profile.data.attributes[r.Td]) || (null == g || null == (f = g.data.attributes.profile.data.attributes.properties) ? void 0 : f[r.HD]), b = (0, o.Wt)(I || ""), S = Object.entries(p.formsState.components).filter((([, e]) => !v.includes(null == e ? void 0 : e.componentId)));
                I && y && (0, l.q)(p, y) && b || ((0, d.M)({
                    metric: a.kM,
                    formVersionCId: n,
                    formId: t,
                    companyId: e,
                    userEmail: I,
                    listId: y,
                    emailProvider: b
                }), i.Z.setState((e => Object.assign({}, e, {
                    formsState: Object.assign({}, e.formsState, {
                        components: Object.fromEntries(S)
                    })
                }))))
            }
        },
        68371: function(e, t, n) {
            n.d(t, {
                U: function() {
                    return o
                },
                q: function() {
                    return i
                }
            });
            const o = ({
                    onsiteState: e
                }, t) => {
                    var n, o;
                    return {
                        senderEmail: null == (n = e.companySenderSettings) ? void 0 : n.emailAddress,
                        subject: null == (o = e.companySenderSettings) || null == (o = o.emailSettings) || null == (o = o[t]) ? void 0 : o.subject
                    }
                },
                i = ({
                    onsiteState: e
                }, t) => {
                    var n;
                    return !(null == (n = e.companySenderSettings) || null == (n = n.emailSettings) || !n[t])
                }
        },
        70510: function(e, t, n) {
            n.d(t, {
                G: function() {
                    return i
                }
            });
            n(92461), n(70818);
            var o = n(57511);
            const i = (e, t) => {
                const n = e.formsState.formVersions[t];
                return (null == n ? void 0 : n.views.filter((t => (0, o.Sz)(e, t)))) || []
            }
        },
        40549: function(e, t, n) {
            n.d(t, {
                s: function() {
                    return o
                }
            });
            const o = {
                animationTimingFunction: "ease",
                animationPlayState: "running",
                animationDelay: "0s",
                animationIterationCount: 1,
                animationFillMode: "forwards"
            }
        },
        12616: function(e, t, n) {
            n.d(t, {
                I: function() {
                    return o
                }
            });
            const o = "BACK_IN_STOCK_OPEN"
        },
        9655: function(e, t, n) {
            n.d(t, {
                B: function() {
                    return o
                }
            });
            const o = 9e4
        },
        68414: function(e, t, n) {
            n.d(t, {
                A: function() {
                    return i
                },
                p: function() {
                    return o
                }
            });
            const o = "teaser",
                i = "component"
        },
        20222: function(e, t) {
            t.Z = ({
                email: e,
                exchangeId: t,
                phoneNumber: n,
                metricName: o,
                formId: i,
                formVersionId: r,
                pageUrl: s,
                deviceType: a,
                utmParams: l,
                isClientEvent: d = !1,
                successStepName: c
            }) => {
                if (!e && !n && !t) return null;
                const m = {
                    form: {
                        data: {
                            id: i,
                            type: "form"
                        }
                    },
                    "form-version": {
                        data: {
                            id: r,
                            type: "form-version"
                        }
                    }
                };
                return {
                    type: "event",
                    attributes: {
                        metric: {
                            data: {
                                type: "metric",
                                attributes: {
                                    name: o,
                                    service: "api"
                                }
                            }
                        },
                        profile: {
                            data: {
                                type: "profile",
                                attributes: {
                                    email: e,
                                    phone_number: n,
                                    properties: {
                                        $email: e,
                                        $phone_number: n,
                                        $exchange_id: t
                                    },
                                    _kx: t
                                }
                            }
                        },
                        properties: Object.assign({
                            form_id: i,
                            form_version_id: r,
                            page: s,
                            device_type: a,
                            $use_ip: !0,
                            $is_session_activity: !0,
                            $is_client_event: d
                        }, c ? {
                            $success_step_name: c
                        } : {}, l)
                    },
                    relationships: m
                }
            }
        },
        67555: function(e, t) {
            t.Z = (e, t) => e / (e + 1) * t
        },
        29974: function(e, t, n) {
            var o = n(94756),
                i = n(51950);
            t.Z = (e, t, n, r) => e === o.pt || !!t[i.HD] || !!t[i.lL] && n && r
        },
        45641: function(e, t, n) {
            n.d(t, {
                Y: function() {
                    return r
                }
            });
            var o = n(34560),
                i = n(87100);
            const r = (e, t) => {
                const n = {
                        method: "POST",
                        headers: {
                            "content-type": "application/json",
                            "Access-Control-Allow-Origin": "*"
                        },
                        body: JSON.stringify((0, o.Y)(t))
                    },
                    r = (0, i.Z)((e => `https://a.klaviyo.com/ajax/${e}/subscribe_unique_id`)(e), n).then((e => {
                        if (e.status >= 500) throw Error(`Error sending request: ${e.url}`);
                        return e
                    }));
                return r.then((e => e.json())).then((e => (0, o._)(e)))
            }
        },
        76101: function(e, t, n) {
            n.d(t, {
                h: function() {
                    return o
                },
                N: function() {
                    return i
                }
            });
            const o = () => {
                    var e, t;
                    return !(null == (e = window.Shopify) || null == (e = e.analytics) || !e.visitor) && "function" == typeof(null == (t = window.Shopify) || null == (t = t.analytics) ? void 0 : t.visitor)
                },
                i = ({
                    email: e,
                    phone: t
                }) => {
                    if ((e || t) && o()) {
                        var n;
                        let o = {};
                        return e && (o = Object.assign({}, o, {
                            email: e
                        })), t && (o = Object.assign({}, o, {
                            phone: t
                        })), null == (n = window.Shopify) || null == (n = n.analytics) ? void 0 : n.visitor(o, {
                            appId: "123074"
                        })
                    }
                    return !1
                }
        }
    }
]);