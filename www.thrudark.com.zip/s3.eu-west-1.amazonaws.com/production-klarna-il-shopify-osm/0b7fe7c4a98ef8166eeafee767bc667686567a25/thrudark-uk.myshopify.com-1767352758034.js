window.klarna_OSMP = window.klarna_OSMP || {};
window.klarna_OSMP.placements = [{
    "id": 54022,
    "name": "Product Page",
    "data_key": "credit-promotion-auto-size",
    "data_preloaded": "false",
    "placement_page": "product",
    "anchor_element": ".prd-Details_Klarna",
    "padding_top": true,
    "padding_bottom": true,
    "padding_left": false,
    "padding_right": false,
    "justification": "center",
    "theme": "default",
    "static_page": null,
    "data_locale": "en-GB",
    "position": "above",
    "install_method": "css",
    "locale_option": "geolocation",
    "honor_storefront_locale": true,
    "country": "GB",
    "countries": null,
    "type": "dynamic"
}];
(() => {
    var t = {
            573: t => {
                (() => {
                    "use strict";
                    var e, a = {};
                    e = a, Object.defineProperty(e, "__esModule", {
                        value: !0
                    }), e.SHOPIFY_THEME_APP_EXTENSION_ID = e.SHOPIFY_CLIENT_ID = e.DEVELOPMENT_PATH_PREFIX = e.GEOSERVICE_URL = e.APP_URL = e.NODE_ENV = void 0, e.NODE_ENV = "production", e.APP_URL = "https://skosm.klarna.com", e.GEOSERVICE_URL = `${e.APP_URL}/geolocation/v1`, e.DEVELOPMENT_PATH_PREFIX = "", e.SHOPIFY_CLIENT_ID = "4439684aa13a71f0befb66b3a308e7d4", e.SHOPIFY_THEME_APP_EXTENSION_ID = "b95936a9-74b6-4a95-8103-6a1b6459c25e", t.exports = a
                })()
            }
        },
        e = {};

    function a(r) {
        var n = e[r];
        if (void 0 !== n) return n.exports;
        var o = e[r] = {
            exports: {}
        };
        return t[r](o, o.exports, a), o.exports
    }(() => {
        "use strict";
        var t = a(573);
        const e = (...t) => {
                console.log("[klarna-osm]", ...t)
            },
            r = t => new Promise((e => setTimeout(e, t))),
            n = () => {
                if (!(document.currentScript instanceof HTMLScriptElement)) return "unknown";
                const t = document.currentScript.src.split("/").at(-3);
                return `${"0.0.0"===t?"local:":""}${t}` || "unknown"
            },
            o = () => Array.from(document.getElementsByTagName("klarna-placement"));
        class i {
            constructor() {
                this.store = null
            }
            async getStore() {
                return this.store || this.fetchStore()
            }
            async fetchStore() {
                const t = i.constructUrl(),
                    e = await fetch(t.toString(), {
                        headers: {
                            "x-app-blocks-version": n()
                        }
                    });
                return this.store = await e.json(), this.store
            }
            static constructUrl() {
                var e;
                const a = window.location.hostname,
                    r = null === (e = window.Shopify) || void 0 === e ? void 0 : e.shop,
                    n = a !== r ? a : "",
                    o = new URL(`${t.DEVELOPMENT_PATH_PREFIX}/app-blocks/v1/store`, t.APP_URL);
                return o.searchParams.set("defaultDomain", r), o.searchParams.set("customDomain", n), o
            }
        }
        async function c() {
            var t;
            const e = await fetch("/cart.json");
            if (!e.ok) throw new Error;
            return null !== (t = (await e.json()).total_price) && void 0 !== t ? t : 0
        }
        const s = {
                "Europe/Vienna": "AT",
                "Australia/Lord_Howe": "AU",
                "Antarctica/Macquarie": "AU",
                "Australia/Hobart": "AU",
                "Australia/Currie": "AU",
                "Australia/Melbourne": "AU",
                "Australia/Sydney": "AU",
                "Australia/Broken_Hill": "AU",
                "Australia/Brisbane": "AU",
                "Australia/Lindeman": "AU",
                "Australia/Adelaide": "AU",
                "Australia/Darwin": "AU",
                "Australia/Perth": "AU",
                "Australia/Eucla": "AU",
                "Europe/Brussels": "BE",
                "America/St_Johns": "CA",
                "America/Halifax": "CA",
                "America/Glace_Bay": "CA",
                "America/Moncton": "CA",
                "America/Goose_Bay": "CA",
                "America/Blanc-Sablon": "CA",
                "America/Toronto": "CA",
                "America/Nipigon": "CA",
                "America/Thunder_Bay": "CA",
                "America/Iqaluit": "CA",
                "America/Pangnirtung": "CA",
                "America/Resolute": "CA",
                "America/Atikokan": "CA",
                "America/Rankin_Inlet": "CA",
                "America/Winnipeg": "CA",
                "America/Rainy_River": "CA",
                "America/Regina": "CA",
                "America/Swift_Current": "CA",
                "America/Edmonton": "CA",
                "America/Cambridge_Bay": "CA",
                "America/Yellowknife": "CA",
                "America/Inuvik": "CA",
                "America/Creston": "CA",
                "America/Dawson_Creek": "CA",
                "America/Vancouver": "CA",
                "America/Whitehorse": "CA",
                "America/Dawson": "CA",
                "Europe/Zurich": "CH",
                "Europe/Prague": "CZ",
                "Europe/Berlin": "DE",
                "Europe/Busingen": "DE",
                "Europe/Copenhagen": "DK",
                "Europe/Madrid": "ES",
                "Africa/Ceuta": "ES",
                "Atlantic/Canary": "ES",
                "Europe/Helsinki": "FI",
                "Europe/Paris": "FR",
                "Europe/Budapest": "HU",
                "Europe/Rome": "IT",
                "America/Mexico_City": "MX",
                "America/Cancun": "MX",
                "America/Merida": "MX",
                "America/Monterrey": "MX",
                "America/Matamoros": "MX",
                "America/Mazatlan": "MX",
                "America/Chihuahua": "MX",
                "America/Ojinaga": "MX",
                "America/Hermosillo": "MX",
                "America/Tijuana": "MX",
                "America/Santa_Isabel": "MX",
                "America/Bahia_Banderas": "MX",
                "Europe/Amsterdam": "NL",
                "Arctic/Longyearbyen": "NO",
                "Europe/Oslo": "NO",
                "Europe/Warsaw": "PL",
                "Europe/Lisbon": "PT",
                "Atlantic/Madeira": "PT",
                "Atlantic/Azores": "PT",
                "Europe/Stockholm": "SE",
                "Europe/Bratislava": "SK"
            },
            l = "klarnaosm_user_locale";
        class u {
            static getCountryFromTimeZone() {
                var t;
                const {
                    timeZone: a
                } = Intl.DateTimeFormat().resolvedOptions(), r = null !== (t = s[a]) && void 0 !== t ? t : null;
                return r || e("[getCountryFromTimeZone] unsupported country or time zone", {
                    timeZone: a
                }), r
            }
            static async fetchUserCountry() {
                let a = u.getCachedUsersCountry();
                if (a) return e("Found users country in cache"), a;
                try {
                    const e = new AbortController;
                    setTimeout((() => e.abort()), 1500);
                    const r = window.location.hostname,
                        o = Shopify.shop,
                        i = r !== o ? r : "",
                        c = new URL(t.GEOSERVICE_URL);
                    c.searchParams.set("defaultDomain", o), c.searchParams.set("customDomain", i);
                    const s = await fetch(c, {
                        signal: e.signal,
                        headers: {
                            "x-app-blocks-version": n()
                        }
                    });
                    if (!s.ok) throw new Error(s.statusText);
                    a = (await s.json()).country
                } catch (a) {
                    return e("[getUsersCountry] Failed", a), e("[getUsersCountry] trying to parse from time zone"), this.getCountryFromTimeZone()
                }
                return a && u.setCachedUsersCountry(a), a
            }
            static getCachedUsersCountry() {
                return localStorage.getItem(l) || null
            }
            static setCachedUsersCountry(t) {
                e("Setting users country to cache", t), localStorage.setItem(l, t)
            }
            constructor(t) {
                this.midLocales = null != t ? t : {}
            }
            static findLocale(t, a, r) {
                var n, o;
                if (t) {
                    e("[getMatchingLocale] Valid locales for users country", t);
                    const i = null !== (n = t[0]) && void 0 !== n ? n : null;
                    let c = "";
                    if (a && "undefined" != typeof Shopify ? (c = Shopify.locale, e("[getMatchingLocale] Using Shopify.locale", c)) : navigator.language && (c = navigator.language.slice(0, 2), e("[getMatchingLocale] Using browser language", c)), c) {
                        const e = t.find((t => t.startsWith(c)));
                        if (e) return e
                    }
                    return r && null !== (o = t.find((t => t.startsWith("en")))) && void 0 !== o ? o : i
                }
                return null
            }
            getMatchingLocale(t, a, r) {
                if (!t || !this.midLocales) return e("[getMatchingLocale] Invalid data", t, this.midLocales), null;
                e("[getMatchingLocale] Available countries for merchant", r);
                const n = this.getFilteredLocales(r);
                e("[getMatchingLocale] Valid locales for merchant", n);
                const o = null == n ? void 0 : n[t];
                return u.findLocale(o, a, !0)
            }
            getFilteredLocales(t) {
                if (!t) return this.midLocales;
                const e = new Set(t);
                return Object.keys(this.midLocales).reduce(((t, a) => {
                    var r;
                    return e.has(a) && (t[a] = null !== (r = this.midLocales[a]) && void 0 !== r ? r : []), t
                }), {})
            }
            getMatchingLocaleWithMidLocales(t, a) {
                var r;
                if (!t || !this.midLocales || 0 === Object.keys(this.midLocales).length) return e("[getMatchingLocale] Invalid data", t, this.midLocales), null;
                const n = this.getMidLocales(t);
                if (!n) return e(`[getMatchingLocale] Country ${t} not in MID Locales`), null;
                e("[getMatchingLocale] Available languages for merchant", n);
                const o = null !== (r = n[0]) && void 0 !== r ? r : null,
                    i = n.find((t => t.startsWith(a)));
                if (i) return e("[getMatchingLocale] Found matching locale", i), i;
                const c = n.find((t => t.startsWith("en")));
                return c ? (e("[getMatchingLocale] Found matching locale (defaulted to English)", c), c) : o
            }
            getMidLocales(t) {
                return "NO" === t && this.midLocales[t] && this.midLocales[t].includes("no-NO") && !this.midLocales[t].includes("nb-NO") && this.midLocales[t].push("nb-NO"), this.midLocales[t]
            }
        }
        const d = u;
        class h {
            constructor(t) {
                this.store = t
            }
            inject() {
                if (!this.isOSMScriptAlreadyInjected()) try {
                    this.injectKlarnaOSMScriptTag(), e("Klarna OSM Script Tag has been added successfully")
                } catch (t) {
                    e("Could not add script element", t)
                }
            }
            isOSMScriptAlreadyInjected() {
                return null !== document.getElementById("klarna-osm-script-tag")
            }
            logIfEmptyClientId() {
                this.store.client_id || e("Creating OSM script element without data-client-id. This will cause placements not to show up. Check your configuration of Klarna OSM on the Klarna Merchant Portal.")
            }
            injectKlarnaOSMScriptTag() {
                const t = this.createKlarnaOSMScriptTag(),
                    e = document.querySelector("body");
                e.insertBefore(t, e.children[0])
            }
            createKlarnaOSMScriptTag() {
                this.logIfEmptyClientId();
                const t = document.createElement("script"),
                    e = this.store.playground_active ? "playground" : "production";
                return t.id = "klarna-osm-script-tag", t.async = !0, t.setAttribute("data-environment", e), t.src = "https://js.klarna.com/web-sdk/v1/klarna.js", t.setAttribute("data-client-id", this.store.client_id), t
            }
        }
        class m {
            static getVariantIdFromQueryString() {
                const t = new URLSearchParams(window.location.search).get("variant");
                return t ? Number.parseInt(t, 10) : null
            }
            constructor(t, e) {
                this.store = t, this.productVariants = e, this.localeService = new d(t.mid_locales)
            }
            async init() {
                var t;
                window.klarna_OSMP = window.klarna_OSMP || {}, window.klarna_OSMP.updaterId = null !== (t = window.klarna_OSMP.updaterId) && void 0 !== t ? t : 0, this.injectOnSiteScript(), await this.initPurchaseAmountIfCartOrProductPage(), this.listenForInputChange()
            }
            injectOnSiteScript() {
                new h(this.store).inject()
            }
            async initPurchaseAmountIfCartOrProductPage() {
                ["cart", "product"].includes(this.currentPageType) && await this.updatePurchaseAmount()
            }
            listenForInputChange() {
                "cart" === this.currentPageType && this.updatePlacementsOnDomMutations(), "product" === this.currentPageType && new MutationObserver((t => {
                    o().forEach((t => {
                        const a = String(this.getDataPurchaseAmount() || 0),
                            r = t.getAttribute("data-purchase-amount");
                        a !== t.getAttribute("data-purchase-amount") && (e(`amount changed from ${r} to ${a}`), t.setAttribute("data-purchase-amount", a))
                    }))
                })).observe(document.body, {
                    childList: !0,
                    subtree: !0
                })
            }
            updatePlacementsOnDomMutations() {
                new MutationObserver(function(t) {
                    let e = !1;
                    return function() {
                        e || (e = !0, t(), setTimeout((() => {
                            e = !1
                        }), 1e3))
                    }
                }((async () => {
                    window.klarna_OSMP.updaterId += 1;
                    const t = window.klarna_OSMP.updaterId,
                        e = [void 0, void 0, await c()];
                    let a = 5;
                    const n = async () => {
                        const t = await c();
                        return !!e.some((e => e !== t)) && (await this.updatePurchaseAmount(t), e.shift(), e.push(t), !0)
                    };
                    for (; a > 0 && t === window.klarna_OSMP.updaterId;) a -= 1, await r(1e3), await n()
                }))).observe(document.body, {
                    childList: !0,
                    subtree: !0
                })
            }
            async updatePurchaseAmount(t = "") {
                const a = o();
                let r = t;
                r || ("cart" === this.currentPageType ? r = await c() : "product" === this.currentPageType && (r = this.getDataPurchaseAmount())), e("Updating placements with new amount", {
                    placements: a,
                    purchaseAmount: r
                }), a.forEach((t => {
                    t.setAttribute("data-purchase-amount", String(r))
                }))
            }
        }
        const p = [".product-form", ".price", ".product__title", ".shopify-payment-button", ".add-to-cart", ".product-form__submit", ".product-form__payment-container", ".product__form", ".product-price", ".product__price", ".product-add-to-cart", ".product-single__add-to-cart", ".btn--shopify-payment-btn", ".product-action-flex", "#product-add-to-cart", ".shopify-product-form", ".product-single__form", ".current_price", ".product-details__form", ".product-detail", "form.price", "*:not(style,script)[data-shopify]", ".product-single__description", ".product-title", ".product-description", ".product-single__desc", ".product-main__information", ".product-variants", ".main-price", '*:not(style,script)[data-action="add-to-cart"]', ".ProductMeta__Description", ".ProductMeta__TaxNotice", '*:not(style,script)[itemprop="offers"]'],
            g = [".cart__footer", ".cart__blocks", ".totals", ".cart__checkout-button", ".cart-totals", ".cart__footer__text", ".cart__submit-controls", ".cart__subtotal-container", ".cart__subtotal", ".cart-bottom", ".cart_bottom", ".cart__buttons", ".cart-meta", ".cart-total-bottom", ".subtotal_amount", ".subtotal__container", ".cart-price", ".cart__checkout-wrapper", ".cart__row", ".cart-subtotal__price", ".cart-recap__checkout", ".hulkapps-cart-original-total", ".cart-total-price", ".checkout-buttons", ".Cart__Total", ".js-cart_subtotal", ".secondary_button"],
            f = ["h1", "h2", "h3", "h4", "h5", ".h1", ".h2", ".h3", ".h4", ".h5", "body"];
        const y = [
                ["/products/", "product"],
                ["/collections", "collections"],
                ["/pages/", "static"],
                ["/cart", "cart"],
                ["/checkouts", "checkout"]
            ],
            A = {
                product: "product",
                home: "home",
                collection: "collections",
                page: "static"
            };
        class _ extends m {
            constructor(t) {
                var a, r, n, o;
                super(t, null !== (o = null === (n = null === (r = null === (a = window.ShopifyAnalytics) || void 0 === a ? void 0 : a.meta) || void 0 === r ? void 0 : r.product) || void 0 === n ? void 0 : n.variants) && void 0 !== o ? o : []), this.usersCountry = null, this.placements = window.klarna_OSMP.placements, window.klarna_OSMP = window.klarna_OSMP || {}, this.currentPageType = (() => {
                    if ((() => {
                            var t, e, a;
                            const r = null === (t = window.Shopify) || void 0 === t ? void 0 : t.routes;
                            let n = null !== (a = null !== (e = null == r ? void 0 : r.root) && void 0 !== e ? e : null == r ? void 0 : r.root_url) && void 0 !== a ? a : "";
                            return n.length > 1 && (null == n ? void 0 : n.endsWith("/")) && (n = n.slice(0, -1)), window.location.pathname === n
                        })()) return "home";
                    const t = (() => {
                            for (const [t, e] of y)
                                if (window.location.pathname.includes(t)) return e;
                            return ""
                        })(),
                        e = (() => {
                            var t, e, a;
                            const r = null === (a = null === (e = null === (t = window.ShopifyAnalytics) || void 0 === t ? void 0 : t.meta) || void 0 === e ? void 0 : e.page) || void 0 === a ? void 0 : a.pageType;
                            return (r ? A[r] : "") || ""
                        })();
                    return t || e
                })(), e("Current page type:", this.currentPageType)
            }
            async init() {
                e("Initializing Klarna On-Site Messaging"), window.Shopify && window.ShopifyAnalytics || e("Shopify objects are missing. It may cause unwanted behavior."), this.isValidDataAndCurrency() ? (this.placements.some((t => "geolocation" === t.locale_option)) && (this.usersCountry = await d.fetchUserCountry(), e("Using geolocation, got users country:", this.usersCountry)), this.injectPlacements(), await super.init()) : e("Exiting due to invalid configuration.")
            }
            isValidDataAndCurrency() {
                return this.placements && this.store ? !!(t => {
                    var a, r, n, o;
                    if (!window.Shopify) return !0;
                    const i = null === (r = null === (a = window.Shopify) || void 0 === a ? void 0 : a.currency) || void 0 === r ? void 0 : r.active,
                        c = null === (o = null === (n = window.Shopify) || void 0 === n ? void 0 : n.Checkout) || void 0 === o ? void 0 : o.currency,
                        s = i || c;
                    return e(`Selected currency: ${s}`), e(`Shop currency: ${t}`), t === s
                })(this.store.currency) || (e("Selected currency not supported"), !1) : (e("Insufficient data to initialize placements"), !1)
            }
            findCurrentPage() {
                let t = this.currentPageType;
                return "static" === t && (t = window.location.pathname), e(`Page detected: ${t}`), t
            }
            injectPlacement(t, a, r) {
                var n, o, i, c, s, l, u, d, h;
                let m = t.placement_page;
                if ("static" === this.currentPageType && (m = `${(null===(o=null===(n=window.Shopify)||void 0===n?void 0:n.routes)||void 0===o?void 0:o.root)||"/"}pages/${t.static_page}`), r === m) {
                    e("-----------------"), e(`Attempting to install placement '${t.name}' using ${t.install_method}`);
                    try {
                        const r = `margin: ${[t.padding_top,t.padding_right,t.padding_bottom,t.padding_left].map((t=>t?"1em":"0")).join(" ")}`;
                        let n = null;
                        "right" === t.justification ? n = "display: flex; justify-content: flex-end;" : "center" === t.justification && (n = "display: flex; justify-content: center;");
                        let o = null;
                        if ("geolocation" === t.locale_option) {
                            if (t.countries && !t.countries.find((t => t === this.usersCountry)) || "EUR" !== this.store.currency && this.usersCountry !== t.country) return e(`Ad is not supported for this user's country: ${this.usersCountry}, countries for this placement: ${null!==(c=null===(i=t.countries)||void 0===i?void 0:i.join(", "))&&void 0!==c?c:t.country}`), !1;
                            o = this.localeService.getMatchingLocale(this.usersCountry, t.honor_storefront_locale, t.countries)
                        } else if ("auto" === t.locale_option && this.store.mid_locales) {
                            const a = null === (s = window.Shopify) || void 0 === s ? void 0 : s.locale,
                                {
                                    country: r,
                                    data_locale: n
                                } = t,
                                i = this.store.mid_locales[r];
                            e("auto locale selection:", {
                                locales: i,
                                shopLocale: a,
                                country: r,
                                dataLocale: n,
                                midLocales: this.store.mid_locales
                            }), i && (o = null !== (d = null !== (u = null !== (l = i.find((t => t.startsWith(a)))) && void 0 !== l ? l : i.find((t => n === t))) && void 0 !== u ? u : i[0]) && void 0 !== d ? d : null)
                        }
                        const m = o || t.data_locale;
                        e("Got matching locale:", o), e("Using locale:", m);
                        const y = document.createElement("klarna-placement");
                        "product" === this.currentPageType && 0 === (this.getDataPurchaseAmount() || 0) && "dynamic" === t.type ? (e("Using fallback placement", this.store.fallback_placement), y.setAttribute("data-key", this.store.fallback_placement)) : y.setAttribute("data-key", t.data_key), y.setAttribute("data-purchase-amount", String(this.getDataPurchaseAmount() || 0)), y.setAttribute("data-preloaded", "true"), y.setAttribute("data-locale", m), y.setAttribute("data-integration-style", "vintage"), "dark" !== t.theme && "custom" !== t.theme || y.setAttribute("data-theme", t.theme);
                        const A = document.createElement("div");
                        A.setAttribute("style", r), A.appendChild(y);
                        const _ = function(t) {
                            const e = document.querySelector(t);
                            if (!e) throw new Error(`Anchor not found for selector: ${t}`);
                            return e
                        }(function(t) {
                            return "autopicker" === t.install_method ? function(t) {
                                const a = [..."cart" === t ? g : p, ...f].find((t => document.querySelector(t))) || "h1";
                                return e("Picked anchor:", a), a
                            }(t.placement_page) : t.anchor_element
                        }(t));
                        if (null === (h = _.parentNode) || void 0 === h || h.insertBefore(A, _), e("Placement injected at element", _), this.watchForRemoval(y, a), n && A.querySelector("klarna-placement")) {
                            const t = A.querySelector("klarna-placement");
                            if (!t) return e("Failed to find klarna-placement element"), !1;
                            t.setAttribute("style", n)
                        }
                        return y
                    } catch (a) {
                        e(`Failed to insert placement for placement id ${t.id}(${t.anchor_element})`, a)
                    }
                }
                return !1
            }
            injectPlacements() {
                let t = 0,
                    a = 0;
                const r = this.findCurrentPage();
                this.placements.forEach(((e, n) => {
                    this.injectPlacement(e, n, r) ? t += 1 : a += 1
                })), e(`Loaded: ${t}. Failed: ${a}`)
            }
            getDataPurchaseAmount() {
                return this.getSelectedVariantPrice() || _.getFirstVariantPrice()
            }
            getSelectedVariantPrice() {
                var t;
                const e = m.getVariantIdFromQueryString();
                if (e) {
                    const a = null === (t = this.productVariants) || void 0 === t ? void 0 : t.find((t => t.id === e));
                    return a ? Number(a.price) : 0
                }
                return 0
            }
            static getFirstVariantPrice() {
                var t, e, a;
                const r = null === (a = null === (e = null === (t = window.ShopifyAnalytics) || void 0 === t ? void 0 : t.meta) || void 0 === e ? void 0 : e.product) || void 0 === a ? void 0 : a.variants[0];
                return r ? Number(r.price) : 0
            }
            watchForRemoval(t, a) {
                const r = new WeakSet;
                let n = t;
                do {
                    r.add(n), n = n.parentElement
                } while (n);
                const o = new MutationObserver((n => {
                    n.forEach((n => {
                        n.removedNodes.forEach((n => {
                            r.has(n) && !document.body.contains(t) && (e("placement was removed, reinserting..."), o.disconnect(), this.reinsertPlacement(a))
                        }))
                    }))
                }));
                document.body.contains(t) ? o.observe(document.body, {
                    childList: !0,
                    subtree: !0
                }) : (e("Reinserting placement before observer attached"), this.reinsertPlacement(a))
            }
            reinsertPlacement(t) {
                const a = this.placements[t];
                if (!a) throw new Error("Index out of bounds for placements array");
                this.injectPlacement(a, t, this.findCurrentPage()) ? (super.updatePurchaseAmount(), e("finished reinserting placement")) : e("failed to reinsert placement")
            }
        }(async () => {
            if (!window.klarna_OSMP.isOSMLoaded) {
                window.klarna_OSMP.isOSMLoaded = !0;
                const t = new i,
                    e = await t.getStore(),
                    a = new _(e);
                await a.init()
            }
        })()
    })()
})();