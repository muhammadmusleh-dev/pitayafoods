(function() {
    // if (window.location.href.includes("onbuy") && [null, false, "false"].includes(localStorage.getItem("shopboxBeta"))) {
    //   return;
    // }

    // onbuy bot detection
    if (window.location.href.includes("onbuy")) {
        const userAgent = navigator.userAgent.toLowerCase();
        const isBot =
            // google bot list from gpt
            /googlebot|google-structured-data-testing-tool|google-site-verification|adsbot-google|mediapartners-google|apis-google|googleadservices|googleadsense|google-read-aloud|google-adwords|feedfetcher-google/i.test(
                userAgent
            ) ||
            // crawler list from gpt
            /bot|crawler|spider|crawling|headless|scraper|slurp|bingbot|yandexbot|facebookexternalhit|twitterbot|linkedinbot|whatsapp|telegrambot|skypebot|applebot|baiduspider|duckduckbot|ia_archiver|mj12bot|dotbot|ahrefsbot|semrushbot|moz\.com|majestic|screaming frog|sitebulb/i.test(
                userAgent
            );

        if (isBot) {
            return;
        }
    }

    let svelteURL = "https://app.shopbox.ai/sbmain.min.js";

    // Check if beta branch is needed
    if ([true, "true"].includes(localStorage.getItem("shopboxBeta"))) {
        console.log("running on shopbox beta");
        svelteURL = "https://main.shopbox-widgets-storybook.pages.dev/sbmain.js";
    }

    let existingScript = document.querySelector(`script[src="${svelteURL}"]`);
    if (existingScript) {
        existingScript.remove();
    }

    var script = document.createElement("script");
    script.type = "text/javascript";
    script.async = true;
    script.src = svelteURL;

    document.getElementsByTagName("body")[0].appendChild(script);
})();