class Quickview extends Wishlist {
    constructor() {
        super();
        this.qvButton = window.iWishData.qv_button;
        this.qvWrapper = window.iWishData.qv_wrapper;
        this.qvCloseButton = window.iWishData.qv_close_button;
        this.quickviewCnt = 1;
        this.qvDelay = typeof window.iWishData.qv_delay !== 'undefined' && window.iWishData.qv_delay != '' ? window.iWishData.qv_delay : 1000;
    }

    setiwishCheck(currentQVbtn) {
        let iwishAdd = this.findAncestor(currentQVbtn, ".iWishAddColl");
        if (iwishAdd) {
            iwishAdd.classList.add("iwishcheck");
        }
    }

    closeQuickview() {
        // remove click event of current checkiwish before checkIwishColl() call
        let iwishcheck = document.querySelectorAll(".iwishcheck");
        if (iwishcheck.length) {
            iwishcheck.forEach(el1 => {
                el1.removeEventListener('click', this.checkIwishColl());
            });
        }
    }

    initQuickview(currentQVbtn = '') {
        // iWishAdd click
        if (document.querySelectorAll(this.qvWrapper).length > 0) {
            if (this.logs) {
                console.log(this.qvWrapper + ' length :: ' + document.querySelectorAll(this.qvWrapper).length);
            }

            let qvWrapper = document.querySelector(this.qvWrapper);
            let iWishAddElm = qvWrapper.querySelectorAll('.iWishAdd');
            if (!iWishAddElm) {
                if (this.logs) {
                    console.log('iWishAddElm not found...');
                }
                return false;
            }
            iWishAddElm.forEach(elm => {
                if (elm.innerHTML == '') {
                    elm.innerHTML = window.iWishData.iwish_add_txt;
                }
                // add click event
                this.iwishAddClick(elm);
            });

            // checkiwish on load
            let selectorElm = qvWrapper.querySelectorAll(this.varSelector);
            selectorElm.forEach(el => {
                this.checkIwish(el);
            });

            // checkiwish on variant change
            if (this.optSelector == '') {
                selectorElm.forEach(el => el.addEventListener('change', event => {
                    this.checkIwish(el);
                }));
            } else {
                let selectorElm2 = qvWrapper.querySelectorAll(this.optSelector);
                selectorElm2.forEach(el => el.addEventListener('change', event => {
                    setTimeout(() => {
                        let el2 = this.findAncestor(el, this.varSelector);
                        this.checkIwish(el2);
                    }, this.checkiwishDelay);
                }));
            }

            // check iwish after qv close
            if (this.qvCloseButton != '') {
                let qvCloseButtons = this.qvCloseButton.split(", ");

                qvCloseButtons.forEach(el => {
                    if (document.querySelectorAll(el).length) {
                        let qvClose = document.querySelector(el);
                        qvClose.addEventListener('click', event => {
                            if (this.logs) {
                                console.log('qvCloseButton clicked : ' + el);
                            }
                            this.closeQuickview();
                        });
                    }

                });
            }

            // qv callback
            if (typeof iWishinitQvFn !== 'undefined' && typeof iWishinitQvFn === 'function') {
                iWishinitQvFn();
            }
        } else {
            // exit if qvWrapper not found
            if (this.quickviewCnt > 3) {
                if (this.logs) {
                    console.log(this.qvWrapper + ' not found');
                }
                return false;
            }

            //call initQuickview again if qvWrapper not found (3 times)
            setTimeout(() => {
                this.quickviewCnt += 1;
                this.initQuickview();
            }, this.qvDelay);
        }
    }

    init() {
        if (this.logs) {
            console.log('iWishQV.init..');
        }
        if (typeof window.iWishData.qv_button !== 'undefined' && window.iWishData.qv_button != '') {
            var qvBtnElm = document.querySelectorAll(this.qvButton);
            qvBtnElm.forEach(el => el.addEventListener('click', event => {
                // reset quickviewCnt
                this.quickviewCnt = 1;

                setTimeout(() => {
                    if (this.logs) {
                        console.log('iwish.qv_button clicked');
                    }

                    //set iwishcheck class to .iWishAddColl for current grid element
                    this.setiwishCheck(el);

                    // call after quickview open
                    this.initQuickview();
                }, this.qvDelay);
            }));
        }
    }
}

var iWishQV = new Quickview();
(function() {
    if (typeof window.iWishData.qv_button !== 'undefined' && window.iWishData.qv_button != '') {
        try {
            let iwishQVInitDelay = typeof window.iWishData.init_delay !== 'undefined' && window.iWishData.init_delay != '' ? window.iWishData.init_delay : 100;
            setTimeout(() => {
                iWishQV.init();
            }, iwishQVInitDelay);
        } catch (err) {
            if (this.logs) {
                console.log("iWish Quick View Error :: ", err);
            }
        }
    }
    /*function asyncLoad() {
		if(typeof window.iWishData.qv_button !== 'undefined' && window.iWishData.qv_button != '') {
			try {
				let iwishQVInitDelay = typeof window.iWishData.init_delay !== 'undefined' && window.iWishData.init_delay!='' ? window.iWishData.init_delay : 100;
				setTimeout(() => {
					iWishQV.init();
				}, iwishQVInitDelay);
			} catch(err) {
				console.log("iWish Quick View Error :: ",err)
			}
		}
	};  
	if(window.attachEvent) {
		window.attachEvent('onload', asyncLoad);
	} else {
		window.addEventListener('load', asyncLoad, false);
	}*/
})();