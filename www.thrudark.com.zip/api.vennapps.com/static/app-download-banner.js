! function() {
    const e = navigator.userAgent.toLowerCase(),
        t = /iPhone|Android|webOS|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent),
        n = (/(iphone)/i.test(e), /android/i.test(e)),
        i = undefined != typeof window && window.Shopify ? .designMode;
    let a = !1;
    if (!i && t && ! function hasVennAppsChannel() {
            return 'venn_apps' === new URLSearchParams(window.location.search).get('sales_channel')
        }() && ! function isWebView(e = navigator.userAgent) {
            return !(!/wv/.test(e) && !/Android.*Version\/[0-9]\.[0-9]/i.test(e)) || !(!/(iPhone|iPad|iPod)/.test(e) || /Safari/.test(e))
        }()) {
        0;
        0;
        window.addEventListener('load', (function() {
            shouldLoadDeeplinkBanner() && function generateDeeplinkBanner() {
                a = !0;
                const e = document.createElement('div');
                e.id = 'venn-deeplink-banner';
                applyStyles(e, {
                    backgroundColor: '#000000',
                    display: 'none',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    position: 'fixed',
                    bottom: '30px',
                    left: '0',
                    right: '0',
                    margin: '0 auto',
                    paddingTop: '12px',
                    paddingLeft: '12px',
                    paddingRight: '12px',
                    paddingBottom: '12px',
                    boxSizing: 'border-box',
                    zIndex: '2147483647',
                    boxShadow: '0px 4px 10px 1px rgba(0, 0, 0, 0.10)',
                    borderRadius: '15px',
                    height: 'auto',
                    width: 'calc(100% - 60px)',
                    maxWidth: '600px',
                    transform: 'translateX(-50%)',
                    left: '50%'
                });
                const t = document.createElement('div');
                t.className = 'venn-left-content';
                applyStyles(t, {
                    display: 'flex',
                    alignItems: 'center',
                    flex: '1'
                });
                const i = document.createElement('div');
                i.className = 'venn-left-content-logo-container';
                i.style.display = 'flex';
                i.style.flex = 'none';
                i.style.alignItems = 'center';
                i.style.marginTop = '0px';
                i.style.marginLeft = '0px';
                i.style.marginRight = '0px';
                i.style.marginBottom = '0px';
                const o = document.createElement('img');
                o.id = 'venn-app-icon';
                o.src = 'https://cdn.shopify.com/s/files/1/0591/0164/2941/files/1759314261-thrudark.png?v=1759314263';
                applyStyles(o, {
                    borderRadius: '5px',
                    width: '50px',
                    height: '50px',
                    marginTop: '0px',
                    marginLeft: '0px',
                    marginRight: '10px',
                    marginBottom: '0px',
                    boxShadow: '0px 1px 5px 1px rgba(0, 0, 0, 0.10)'
                });
                const p = document.createElement('div');
                p.className = 'venn-left-content-text';
                applyStyles(p, {
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '7px'
                });
                const l = document.createElement('h3');
                l.id = 'venn-app-title';
                l.textContent = 'Download app';
                const s = {
                    color: '#ffffff',
                    fontFamily: 'system-ui, -apple-system, sans-serif',
                    fontSize: {
                        unit: 'px',
                        value: 13
                    },
                    fontStyle: 'normal',
                    fontWeight: '600',
                    letterSpacing: {
                        unit: 'pt',
                        value: .03
                    },
                    lineHeight: {
                        unit: 'px',
                        value: 15
                    }
                };
                applyStyles(l, s);
                l.style.margin = '0';
                l.style.fontSize = `${s.fontSize.value}${s.fontSize.unit}`;
                l.style.lineHeight = `${s.lineHeight.value}${s.lineHeight.unit}`;
                l.style.letterSpacing = `${s.letterSpacing.value}${s.letterSpacing.unit}`;
                const r = document.createElement('p');
                r.id = 'venn-app-subtitle';
                r.textContent = 'Exclusive in-app shopping experience';
                const d = {
                    color: '#ffffff',
                    fontFamily: 'system-ui, -apple-system, sans-serif',
                    fontSize: {
                        unit: 'px',
                        value: 11
                    },
                    fontStyle: 'normal',
                    fontWeight: '400',
                    letterSpacing: {
                        unit: 'px',
                        value: 0
                    },
                    lineHeight: {
                        unit: 'px',
                        value: 13
                    }
                };
                applyStyles(r, d);
                r.style.margin = '0';
                r.style.fontSize = `${d.fontSize.value}${d.fontSize.unit}`;
                r.style.lineHeight = `${d.lineHeight.value}${d.lineHeight.unit}`;
                r.style.letterSpacing = `${d.letterSpacing.value}${d.letterSpacing.unit}`;
                const c = document.createElement('div');
                c.className = 'venn-right-content';
                applyStyles(c, {
                    display: 'flex',
                    alignItems: 'center'
                }); {
                    const e = document.createElement('img');
                    e.id = 'venn-store-banner';
                    if (n) {
                        e.src = 'https://firebasestorage.googleapis.com/v0/b/venn-prod-70222.appspot.com/o/static%2Fplaystore-icon.png?alt=media&token=99727153-393e-4e3b-8054-e635d161db0b';
                        e.title = 'Play Store'
                    } else {
                        e.src = 'https://firebasestorage.googleapis.com/v0/b/venn-prod-70222.appspot.com/o/static%2Fappstore-icon.png?alt=media&token=0b243992-925f-4c09-a068-183a30501851';
                        e.title = 'App Store'
                    }
                    applyStyles(e, {
                        width: '88px',
                        height: 'auto',
                        marginTop: '0px',
                        marginLeft: '0px',
                        marginRight: '0px',
                        marginBottom: '0px',
                        borderRadius: '0px',
                        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)'
                    });
                    c.appendChild(e)
                }
                const u = document.createElement('div');
                u.id = 'venn-close-button';
                applyStyles(u, {
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    backgroundColor: '#ffffff',
                    width: '30px',
                    height: '30px',
                    borderRadius: '50%',
                    cursor: 'pointer',
                    position: 'absolute',
                    top: '-12px',
                    right: '-12px',
                    zIndex: '2147483648',
                    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                    padding: '0'
                });
                const g = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
                g.setAttribute('viewBox', '0 0 24 24');
                g.setAttribute('width', '20px');
                g.setAttribute('height', '20px');
                g.style.userSelect = 'none';
                g.style.pointerEvents = 'none';
                const m = document.createElementNS('http://www.w3.org/2000/svg', 'path');
                m.setAttribute('d', 'M18 6L6 18M6 6l12 12');
                m.setAttribute('stroke', '#000000');
                m.setAttribute('stroke-width', '2');
                m.setAttribute('stroke-linecap', 'round');
                m.setAttribute('stroke-linejoin', 'round');
                m.setAttribute('fill', 'none');
                g.appendChild(m);
                u.appendChild(g);
                i.appendChild(o);
                p.appendChild(l);
                p.appendChild(r);
                t.appendChild(i);
                t.appendChild(p);
                e.appendChild(t);
                e.appendChild(c);
                e.appendChild(u);
                document.body.appendChild(e);
                e.addEventListener('click', handleBannerClick);
                u.addEventListener('click', hideDeeplinkBanner);
                setTimeout((() => {
                    e && (e.style.display = 'flex')
                }), 0)
            }()
        }))
    }

    function shouldLoadDeeplinkBanner() {
        if (a) return !1;
        return ! function getLocalStorage(e) {
            const t = localStorage.getItem(e);
            if (!t) return null;
            const n = JSON.parse(t);
            if ((new Date).getTime() > n.timestamp) {
                localStorage.removeItem(e);
                return null
            }
            return n.value
        }('hideDeeplinkBanner')
    }

    function applyStyles(e, t) {
        Object.keys(t).forEach((n => {
            t[n] && 'object' != typeof t[n] && (e.style[n] = t[n])
        }))
    }

    function handleBannerClick(e) {
        if (!['venn-deeplink-banner', 'venn-app-icon', 'venn-app-title', 'venn-app-subtitle', 'venn-store-banner', 'venn-app-store-button'].includes(e.target.id)) return;
        const t = n ? 'https://play.google.com/store/apps/details?id=com.vennapps.thrudark' : 'https://apps.apple.com/us/app/thrudark/id6743804008';
        window.open(t, '_self')
    }

    function hideDeeplinkBanner(e) {
        if (!e.target.closest('#venn-close-button')) return;
        const t = document.getElementById('venn-deeplink-banner');
        if (t) {
            t.style.display = 'none';
            ! function setLocalStorage(e, t, n) {
                const i = {
                    value: t,
                    timestamp: (new Date).getTime() + 24 * n * 60 * 60 * 1e3
                };
                localStorage.setItem(e, JSON.stringify(i))
            }('hideDeeplinkBanner', 'true', 30)
        }
    }
}();