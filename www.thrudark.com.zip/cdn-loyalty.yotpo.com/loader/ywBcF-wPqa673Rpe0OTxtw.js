(function() {
    if (window.swellConfig) {
        throw new Error('Yotpo Loyalty SDK loader script already loaded');
    }

    window.swellConfig = {
        loaded: false,
        storage: null,
        overlayEl: null,
        popupEl: null,
        embeddedPopupEl: null,
        overflowDefault: "visible",
        transformDefault: "",
        rewardsTransformDefault: "",
        shown: false,
        fonts: {},
        isPOS: window.swellPOS,
        isLightspeedPOS: window.swellLightspeedPOS,
        popupsByType: {},
        popupByType: {},
        activeTabConfigs: [],
        localization: JSON.parse("{}"),
        activePopups: JSON.parse("[]"),
        activeCampaigns: JSON.parse("[{\"id\":1435403,\"created_at\":\"2024-02-22T13:19:33.000Z\",\"updated_at\":\"2025-11-26T10:07:07.000Z\",\"reward_points\":1,\"goal_purchases\":null,\"goal_spend_cents\":100,\"min_spend_cents\":0,\"min_purchases\":null,\"active\":true,\"activated_at\":\"2024-02-22T13:19:33.000Z\",\"days_since_last_purchase\":null,\"headline\":null,\"perks_expire_after_hours\":null,\"expired\":false,\"expired_at\":null,\"expires_at\":null,\"type\":\"PointsForPurchasesCampaign\",\"name\":\"Points for Purchases\",\"short_description\":\"Get X Points Per Dollar Spent\",\"description\":\"Customers earn points for making purchases in your store.\",\"avatar\":\"spend.png\",\"consumer_name\":\"Get X Points Per Dollar Spent\",\"fa_icon\":\"fa-dollar\",\"box_color\":\"secundary\",\"username\":null,\"share_text\":null,\"entity_id\":null,\"hashtags\":null,\"url\":null,\"question\":null,\"answer\":null,\"perk_body\":\"Earn 1 point for every \$1 spent\",\"completed_perk_body\":\"Earn 1 point for every \$1 spent\",\"archived\":false,\"referral_host\":\"http://rwrd.io\",\"referral_requirement\":\"create an account and make a purchase\",\"referral_body\":\"makes a purchase\",\"display_order\":1,\"minutes_between_actions\":null,\"max_perks_total\":null,\"max_spend_cents\":null,\"action_name\":null,\"max_perks_per_user\":null,\"action_requirement\":null,\"action_description\":null,\"min_actions_required\":0,\"merchant_id\":181547,\"referral_reward_points\":null,\"default_share_text\":\"These guys are great! Get a discount using my code\",\"minutes_between_perks\":null,\"default_email_subject\":\"Discount to a Store You\'ll Love!\",\"default_email_body\":null,\"redemption_option_id\":null,\"referral_redemption_option_id\":null,\"reward_text\":\"1 point for every £1 spent\",\"icon\":\"fa-dollar\",\"cta_text\":\"\",\"default_share_text_header\":\"Earn A Discount When You Shop Today!\",\"reward_type\":\"fixed_amount\",\"reward_product_id_map\":\"\",\"reward_percentage\":10,\"use_oauth\":false,\"days_until_next_action\":\"You\'re eligible to participate again in *|days|* days.\",\"hours_until_next_action\":\"You\'re eligible to participate again in *|hours|* hours.\",\"already_completed\":\"Looks like you\'ve already completed this offer!\",\"completed_action\":null,\"delay_reward\":true,\"delay_reward_days\":30,\"require_product_by_ids\":null,\"require_product_by_tags\":null,\"require_product_by_types\":null,\"referral_link_expiration_hours\":null,\"referral_link_expiration_reminder_hours\":null,\"action_filter\":null,\"extra_copy1\":\"\",\"extra_copy2\":null,\"extra_copy3\":null,\"share_header\":null,\"product_map_strategy\":\"sum_quantity\",\"image_id\":null,\"exclude_customer_tags\":true,\"customer_tags\":null,\"campaign_tiers\":[],\"required_order_comparison\":\"exactly\",\"required_order_count\":null,\"referral_query_params\":null,\"referral_redirect_url\":null,\"facebook_description\":null,\"product_restrictions_reward\":\"entire_cart\",\"exclude_order_tags\":true,\"order_tags\":null,\"ask_year\":false,\"default_sms_text\":\"Hey, want \${discount_amount} to \${company_name}? I thought you\'d like them. Here\'s my link: \${referral_link}\",\"referral_auto_apply_coupon\":true,\"use_account_creation_date\":false,\"custom_url\":null,\"use_custom_url\":false,\"prettyGoalSpend\":\"\$1\",\"prettyReward\":\"\$0\",\"prettyMinSpend\":\"\$0\",\"perksLeft\":0,\"mandatoryProductIds\":null,\"title\":\"Made a purchase\",\"details\":\"Earn 1 point for every £1 spent\",\"unrendered_title\":\"Made a purchase\",\"unrendered_details\":\"Earn 1 point for every £1 spent\",\"share_image_url\":null,\"background_image_url\":null},{\"id\":1477871,\"created_at\":\"2024-06-05T13:10:40.000Z\",\"updated_at\":\"2024-06-05T13:10:40.000Z\",\"reward_points\":100,\"goal_purchases\":null,\"goal_spend_cents\":null,\"min_spend_cents\":0,\"min_purchases\":null,\"active\":true,\"activated_at\":\"2024-06-05T13:10:40.000Z\",\"days_since_last_purchase\":null,\"headline\":null,\"perks_expire_after_hours\":null,\"expired\":false,\"expired_at\":null,\"expires_at\":null,\"type\":\"BirthdayCampaign\",\"name\":\"Birthday Reward\",\"short_description\":\"Reward users on their birthday\",\"description\":\"Reward customers annually on their birthday.\",\"avatar\":\"birthday.png\",\"consumer_name\":\"Happy Birthday\",\"fa_icon\":\"fa-birthday-cake\",\"box_color\":\"primary\",\"username\":null,\"share_text\":null,\"entity_id\":null,\"hashtags\":null,\"url\":null,\"question\":null,\"answer\":null,\"perk_body\":\"Earn 100 points on your birthday\",\"completed_perk_body\":\"\",\"archived\":false,\"referral_host\":\"http://rwrd.io\",\"referral_requirement\":\"\",\"referral_body\":\"\",\"display_order\":5,\"minutes_between_actions\":null,\"max_perks_total\":null,\"max_spend_cents\":null,\"action_name\":null,\"max_perks_per_user\":null,\"action_requirement\":null,\"action_description\":null,\"min_actions_required\":1,\"merchant_id\":181547,\"referral_reward_points\":null,\"default_share_text\":\"These guys are great! Get a discount using my code\",\"minutes_between_perks\":null,\"default_email_subject\":\"Discount to a Store You\'ll Love!\",\"default_email_body\":null,\"redemption_option_id\":null,\"referral_redemption_option_id\":null,\"reward_text\":\"100 points\",\"icon\":\"fa-star\",\"cta_text\":\"\",\"default_share_text_header\":\"Earn A Discount When You Shop Today!\",\"reward_type\":\"fixed_amount\",\"reward_product_id_map\":null,\"reward_percentage\":10,\"use_oauth\":false,\"days_until_next_action\":\"You\'re eligible to participate again in *|days|* days.\",\"hours_until_next_action\":\"You\'re eligible to participate again in *|hours|* hours.\",\"already_completed\":\"Looks like you\'ve already completed this offer!\",\"completed_action\":null,\"delay_reward\":false,\"delay_reward_days\":14,\"require_product_by_ids\":null,\"require_product_by_tags\":null,\"require_product_by_types\":null,\"referral_link_expiration_hours\":null,\"referral_link_expiration_reminder_hours\":null,\"action_filter\":null,\"extra_copy1\":\"\",\"extra_copy2\":\"Thanks! We\'re looking forward to helping you celebrate :)\",\"extra_copy3\":\"January,February,March,April,May,June,July,August,September,October,November,December\",\"share_header\":null,\"product_map_strategy\":\"maximum\",\"image_id\":null,\"exclude_customer_tags\":true,\"customer_tags\":null,\"campaign_tiers\":[\"27864\"],\"required_order_comparison\":null,\"required_order_count\":null,\"referral_query_params\":null,\"referral_redirect_url\":null,\"facebook_description\":null,\"product_restrictions_reward\":\"entire_cart\",\"exclude_order_tags\":true,\"order_tags\":null,\"ask_year\":false,\"default_sms_text\":\"Hey, want \${discount_amount} to \${company_name}? I thought you\'d like them. Here\'s my link: \${referral_link}\",\"referral_auto_apply_coupon\":true,\"use_account_creation_date\":false,\"custom_url\":null,\"use_custom_url\":false,\"prettyGoalSpend\":\"\$0\",\"prettyReward\":\"£0\",\"prettyMinSpend\":\"£0\",\"perksLeft\":0,\"mandatoryProductIds\":null,\"title\":\"Birthday reward (Black Ops Lifetime)\",\"details\":\"Earn 100 points on your birthday\",\"unrendered_title\":\"Birthday reward (Black Ops Lifetime)\",\"unrendered_details\":\"Earn 100 points on your birthday\",\"share_image_url\":null,\"background_image_url\":null}]"),
        activeRedemptionOptions: JSON.parse("[]"),
        activePosRedemptionOptions: JSON.parse("[]"),
        activeVipTiers: JSON.parse("[{\"id\":25918,\"merchant_id\":181547,\"name\":\"TIER 2\",\"description\":\"Reach 500 Points\",\"points_multiplier\":\"1.0\",\"currency\":\"USD\",\"rank\":1,\"redemption_option_id\":null,\"reward_points\":0,\"earned_title\":\"*|tier_name|* secured\",\"background_image_id\":null,\"type\":\"VipTier\",\"prettyAmountSpent\":\"£0\",\"multipliedCampaigns\":[],\"regain_points_earned\":500,\"regain_amount_spent_cents\":0,\"regain_purchases_made\":0,\"regain_referrals_completed\":0,\"regain_requirements_needed\":\"all_requirements\",\"points_earned\":500,\"amount_spent_cents\":0,\"purchases_made\":0,\"referrals_completed\":0,\"requirements_needed\":\"all_requirements\",\"retain_points_earned\":500,\"retain_amount_spent_cents\":0,\"retain_purchases_made\":0,\"retain_referrals_completed\":0,\"retain_requirements_needed\":\"all_requirements\",\"background_image_url\":null},{\"id\":25919,\"merchant_id\":181547,\"name\":\"TIER 1\",\"description\":\"Reach 1,500 Points\",\"points_multiplier\":\"1.0\",\"currency\":\"USD\",\"rank\":2,\"redemption_option_id\":null,\"reward_points\":0,\"earned_title\":\"*|tier_name|* secured\",\"background_image_id\":null,\"type\":\"VipTier\",\"prettyAmountSpent\":\"£0\",\"multipliedCampaigns\":[],\"regain_points_earned\":1500,\"regain_amount_spent_cents\":0,\"regain_purchases_made\":0,\"regain_referrals_completed\":0,\"regain_requirements_needed\":\"all_requirements\",\"points_earned\":1500,\"amount_spent_cents\":0,\"purchases_made\":0,\"referrals_completed\":0,\"requirements_needed\":\"all_requirements\",\"retain_points_earned\":1500,\"retain_amount_spent_cents\":0,\"retain_purchases_made\":0,\"retain_referrals_completed\":0,\"retain_requirements_needed\":\"all_requirements\",\"background_image_url\":null},{\"id\":25920,\"merchant_id\":181547,\"name\":\"BLACK OPS\",\"description\":\"Reach 3,000 Points\",\"points_multiplier\":\"1.0\",\"currency\":\"USD\",\"rank\":3,\"redemption_option_id\":null,\"reward_points\":0,\"earned_title\":\"*|tier_name|* secured\",\"background_image_id\":null,\"type\":\"VipTier\",\"prettyAmountSpent\":\"£0\",\"multipliedCampaigns\":[],\"regain_points_earned\":3000,\"regain_amount_spent_cents\":0,\"regain_purchases_made\":0,\"regain_referrals_completed\":0,\"regain_requirements_needed\":\"all_requirements\",\"points_earned\":3000,\"amount_spent_cents\":0,\"purchases_made\":0,\"referrals_completed\":0,\"requirements_needed\":\"all_requirements\",\"retain_points_earned\":1500,\"retain_amount_spent_cents\":0,\"retain_purchases_made\":0,\"retain_referrals_completed\":0,\"retain_requirements_needed\":\"all_requirements\",\"background_image_url\":null},{\"id\":27864,\"merchant_id\":181547,\"name\":\"BLACK OPS (Lifetime)\",\"description\":\"Invite Only\",\"points_multiplier\":\"1.0\",\"currency\":\"USD\",\"rank\":4,\"redemption_option_id\":null,\"reward_points\":0,\"earned_title\":\"Earned Tier *|tier_name|*\",\"background_image_id\":null,\"type\":\"VipTier\",\"prettyAmountSpent\":\"£0\",\"multipliedCampaigns\":[],\"regain_points_earned\":1,\"regain_amount_spent_cents\":0,\"regain_purchases_made\":0,\"regain_referrals_completed\":0,\"regain_requirements_needed\":\"all_requirements\",\"points_earned\":900000,\"amount_spent_cents\":0,\"purchases_made\":0,\"referrals_completed\":0,\"requirements_needed\":\"all_requirements\",\"retain_points_earned\":1,\"retain_amount_spent_cents\":0,\"retain_purchases_made\":0,\"retain_referrals_completed\":0,\"retain_requirements_needed\":\"all_requirements\",\"background_image_url\":null},{\"id\":32927,\"merchant_id\":181547,\"name\":\"TIER 3\",\"description\":\"Reach 1 Point\",\"points_multiplier\":\"1.0\",\"currency\":\"USD\",\"rank\":0,\"redemption_option_id\":null,\"reward_points\":0,\"earned_title\":\"*|tier_name|* secured\",\"background_image_id\":null,\"type\":\"VipTier\",\"prettyAmountSpent\":\"£0\",\"multipliedCampaigns\":[],\"regain_points_earned\":1,\"regain_amount_spent_cents\":0,\"regain_purchases_made\":0,\"regain_referrals_completed\":0,\"regain_requirements_needed\":\"all_requirements\",\"points_earned\":1,\"amount_spent_cents\":0,\"purchases_made\":0,\"referrals_completed\":0,\"requirements_needed\":\"all_requirements\",\"retain_points_earned\":1,\"retain_amount_spent_cents\":0,\"retain_purchases_made\":0,\"retain_referrals_completed\":0,\"retain_requirements_needed\":\"all_requirements\",\"background_image_url\":null}]"),
        activeVariableRedemptionOptions: JSON.parse("[]"),
        activeNonVariableRedemptionOptions: JSON.parse("[]"),
        activeReferralCampaign: null,
        hasActiveReferralModule: true,
        newsletterSignupCampaign: JSON.parse("null"),
        variableRedemptionOption: null,
        merchant: JSON.parse("{\"store_account_login_url\":\"//thrudark.com/account/login\",\"store_account_registration_url\":\"//thrudark.com/account/register\",\"force_store_accounts\":true,\"company_name\":\"ThruDark\",\"description\":null,\"id\":181547,\"platform\":\"shopify\",\"currency\":{\"cents\":1,\"currency_iso\":\"GBP\"}}"),
        customer: {
            point_redemptions: [],
            perks: [],
            action_history_items: [],
            points_balance: 0,
            referral_code: "",
            tags: []
        },
        swellAccount: {
            id: null,
            email: null,
            authToken: null
        },
        pointRedemptions: [],
        onPageLoadPopupConfig: null,
        onExitIntentPopupConfig: null,
        rewardsTabEl: null,
        rewardsPopupEl: null,
        rewardsIframeEl: null,
        rewardsPopupConfig: null,
        currentView: null,
        currentEmbeddedView: null,
        swellApiHost: "https://loyalty.yotpo.com",
        unauthenticatedUserActionURL: "https://loyalty.yotpo.com/api/v1/popup_user_actions",
        authenticatedUserActionURL: "https://loyalty.yotpo.com/api/v1/user_actions",
        logPopupActionURL: "https://loyalty.yotpo.com/api/v1/popup_actions",
        logShareActionURL: "https://loyalty.yotpo.com/api/v1/share_actions",
        merchantId: "181547",
        merchantGuid: "ywBcF-wPqa673Rpe0OTxtw",
        merchantThirdPartyPluginUrl: "",
        merchantEmailLogoUrl: "/assets/email-logo.png",
        programLive: true,
        programLocked: false,
        platform: "shopify",
        forceStoreAccounts: true,
        crossOriginStoreAccounts: false,
        shopifyHost: "",
        website: "http://thrudark.com",
        planType: "PLATINUM",
        excludeCustomerTags: true,
        customerTags: "",
        validFonts: ["abel", "abril fatface", "amatic sc", "bangers", "bitter", "cambay", "cabin sketch", "dancing script", "droid sans", "inconsolata", "indie flower", "josefin slob", "lato", "montserrat", "multi", "old standard tt", "open sans", "oswald", "overlock", "pacifico", "quantico", "questrial", "quicksand", "raleway", "roboto", "source sans pro", "tangerine"],
        oauthAppId: "6xs003b5vNi8YBSTFs8X0W7rB1A",
        secLevel: 0,
        facebookAppId: "1647129615540489",
        bigcommerceClientId: "2941qmei2tfnac1aanjwhv3h7gotf74",
        includeStorefrontStylesheets: false,
        includePosAdjustPointBalance: true,
        apiEndpoint: ""
    };


    var script = document.createElement('script');
    script.type = 'text/javascript';

    script.src = "//cdn-swell-assets.yotpo.com/app.v1.0.368.js";

    try {
        if (localStorage) {
            var customScriptURL = localStorage.getItem("swell-custom-script-url");
            if (customScriptURL) {
                script.src = customScriptURL;
            }
        }
    } catch (e) {}

    document.head.appendChild(script);

})();