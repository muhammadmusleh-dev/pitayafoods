function t(t2, n2, e2) {
    return n2 in t2 ? Object.defineProperty(t2, n2, {
        value: e2,
        enumerable: true,
        configurable: true,
        writable: true
    }) : t2[n2] = e2, t2;
}

function n(t2, n2) {
    var e2 = Object.keys(t2);
    if (Object.getOwnPropertySymbols) {
        var r2 = Object.getOwnPropertySymbols(t2);
        n2 && (r2 = r2.filter(function(n3) {
            return Object.getOwnPropertyDescriptor(t2, n3).enumerable;
        })), e2.push.apply(e2, r2);
    }
    return e2;
}

function e(e2) {
    for (var r2 = 1; r2 < arguments.length; r2++) {
        var i2 = arguments[r2] != null ? arguments[r2] : {};
        r2 % 2 ? n(Object(i2), true).forEach(function(n2) {
            t(e2, n2, i2[n2]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e2, Object.getOwnPropertyDescriptors(i2)) : n(Object(i2)).forEach(function(t2) {
            Object.defineProperty(e2, t2, Object.getOwnPropertyDescriptor(i2, t2));
        });
    }
    return e2;
}

function r(t2) {
    return function(t3) {
        if (Array.isArray(t3))
            return i(t3);
    }(t2) || function(t3) {
        if (typeof Symbol != "undefined" && Symbol.iterator in Object(t3))
            return Array.from(t3);
    }(t2) || function(t3, n2) {
        if (!t3)
            return;
        if (typeof t3 == "string")
            return i(t3, n2);
        var e2 = Object.prototype.toString.call(t3).slice(8, -1);
        e2 === "Object" && t3.constructor && (e2 = t3.constructor.name);
        if (e2 === "Map" || e2 === "Set")
            return Array.from(t3);
        if (e2 === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(e2))
            return i(t3, n2);
    }(t2) || function() {
        throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
    }();
}

function i(t2, n2) {
    (n2 == null || n2 > t2.length) && (n2 = t2.length);
    for (var e2 = 0, r2 = new Array(n2); e2 < n2; e2++)
        r2[e2] = t2[e2];
    return r2;
}

function o(t2) {
    var n2, i2, o2, a2, f, s, l, d, h, v, p, m, b, g, w, y, M, O, S, A, j, k, x, P, E, T, D, C, L, V, X, Y, z, H, I = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {},
        q = "data-keen-slider-moves",
        F = "data-keen-slider-v",
        W = [],
        _ = null,
        N = false,
        R = false,
        U = 0,
        $ = [];

    function B(t3, n3, e2) {
        var r2 = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : {};
        t3.addEventListener(n3, e2, r2), W.push([t3, n3, e2, r2]);
    }

    function G(t3) {
        if (O && S === Z(t3) && ft()) {
            var e2 = nt(t3).x;
            if (!rt(t3) && P)
                return K(t3);
            P && (Nt(), A = e2, P = false), t3.cancelable && t3.preventDefault();
            var r2 = A - e2;
            E += Math.abs(r2), !T && E > 5 && (T = true, n2.setAttribute(q, true)), Yt(x(r2, Jt) * (lt() ? -1 : 1), t3.timeStamp), A = e2;
        }
    }

    function J(t3) {
        O || !ft() || et(t3.target) || (O = true, P = true, S = Z(t3), T = false, E = 0, rt(t3), pt(), M = v, A = nt(t3).x, Yt(0, t3.timeStamp), ut("dragStart"));
    }

    function K(t3) {
        O && S === Z(t3, true) && ft() && (n2.removeAttribute(q), O = false, gt(), ut("dragEnd"));
    }

    function Q(t3) {
        return t3.changedTouches;
    }

    function Z(t3) {
        var n3 = arguments.length > 1 && arguments[1] !== void 0 && arguments[1],
            e2 = n3 ? Q(t3) : tt(t3);
        return e2 ? e2[0] ? e2[0].identifier : "error" : "default";
    }

    function tt(t3) {
        return t3.targetTouches;
    }

    function nt(t3) {
        var n3 = tt(t3);
        return {
            x: ht() ? n3 ? n3[0].screenY : t3.pageY : n3 ? n3[0].screenX : t3.pageX,
            timestamp: t3.timeStamp
        };
    }

    function et(t3) {
        return t3.hasAttribute(y.preventEvent);
    }

    function rt(t3) {
        var n3 = tt(t3);
        if (!n3)
            return true;
        var e2 = n3[0],
            r2 = ht() ? e2.clientY : e2.clientX,
            i3 = ht() ? e2.clientX : e2.clientY,
            o3 = j !== void 0 && k !== void 0 && Math.abs(k - i3) <= Math.abs(j - r2);
        return j = r2, k = i3, o3;
    }

    function it(t3) {
        ft() && O && t3.preventDefault();
    }

    function ot() {
        B(window, "orientationchange", Dt), B(window, "resize", function() {
            return Tt();
        }), B(n2, "dragstart", function(t3) {
            ft() && t3.preventDefault();
        }), B(n2, "mousedown", J), B(y.cancelOnLeave ? n2 : window, "mousemove", G), y.cancelOnLeave && B(n2, "mouseleave", K), B(window, "mouseup", K), B(n2, "touchstart", J, {
            passive: true
        }), B(n2, "touchmove", G, {
            passive: false
        }), B(n2, "touchend", K, {
            passive: true
        }), B(n2, "touchcancel", K, {
            passive: true
        }), B(window, "wheel", it, {
            passive: false
        });
    }

    function at() {
        W.forEach(function(t3) {
            t3[0].removeEventListener(t3[1], t3[2], t3[3]);
        }), W = [];
    }

    function ut(t3) {
        y[t3] && y[t3](Jt);
    }

    function ct() {
        return y.centered;
    }

    function ft() {
        return i2 !== void 0 ? i2 : y.controls;
    }

    function st() {
        return y.loop && o2 > 1;
    }

    function lt() {
        return y.rtl;
    }

    function dt() {
        return !y.loop && y.rubberband;
    }

    function ht() {
        return !!y.vertical;
    }

    function vt() {
        D = window.requestAnimationFrame(mt);
    }

    function pt() {
        D && (window.cancelAnimationFrame(D), D = null), C = null;
    }

    function mt(t3) {
        C || (C = t3);
        var n3 = t3 - C,
            e2 = bt(n3);
        if (n3 >= V)
            return Yt(L - Y, false), H ? H() : void ut("afterChange");
        var r2 = zt(e2);
        if (r2 === 0 || st() || dt() || z) {
            if (r2 !== 0 && dt() && !z)
                return St();
            Y += e2, Yt(e2, false), vt();
        } else
            Yt(e2 - r2, false);
    }

    function bt(t3) {
        return L * X(t3 / V) - Y;
    }

    function gt() {
        switch (ut("beforeChange"), y.mode) {
            case "free":
                Mt();
                break;
            case "free-snap":
                Ot();
                break;
            case "snap":
            default:
                wt();
        }
    }

    function wt() {
        yt((l === 1 && p !== 0 ? M : v) + Math.sign(p));
    }

    function yt(t3, n3) {
        var e2 = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : y.duration,
            r2 = arguments.length > 3 && arguments[3] !== void 0 && arguments[3],
            i3 = arguments.length > 4 && arguments[4] !== void 0 && arguments[4],
            o3 = function(t4) {
                return 1 + --t4 * t4 * t4 * t4 * t4;
            };
        At(Ft(t3 = qt(t3, r2, i3)), e2, o3, n3);
    }

    function Mt() {
        if (b === 0)
            return !(!zt(0) || st()) && yt(v);
        var t3 = y.friction / Math.pow(Math.abs(b), -0.5);
        At(Math.pow(b, 2) / t3 * Math.sign(b), 6 * Math.abs(b / t3), function(t4) {
            return 1 - Math.pow(1 - t4, 5);
        });
    }

    function Ot() {
        if (b === 0)
            return yt(v);
        var t3 = y.friction / Math.pow(Math.abs(b), -0.5),
            n3 = Math.pow(b, 2) / t3 * Math.sign(b),
            e2 = 6 * Math.abs(b / t3),
            r2 = (U + n3) / (s / l);
        At((p === -1 ? Math.floor(r2) : Math.ceil(r2)) * (s / l) - U, e2, function(t4) {
            return 1 - Math.pow(1 - t4, 5);
        });
    }

    function St() {
        if (pt(), b === 0)
            return yt(v, true);
        var t3 = 0.04 / Math.pow(Math.abs(b), -0.5),
            n3 = Math.pow(b, 2) / t3 * Math.sign(b),
            e2 = function(t4) {
                return --t4 * t4 * t4 + 1;
            },
            r2 = b;
        At(n3, 3 * Math.abs(r2 / t3), e2, true, function() {
            At(Ft(qt(v)), 500, e2, true);
        });
    }

    function At(t3, n3, e2, r2, i3) {
        pt(), L = t3, Y = 0, V = n3, X = e2, z = r2, H = i3, C = null, vt();
    }

    function jt(e2) {
        var r2 = u(t2);
        r2.length && (n2 = r2[0], Tt(e2), ot(), ut("mounted"));
    }

    function kt() {
        var t3, n3 = I.breakpoints || [];
        for (var r2 in n3)
            window.matchMedia(r2).matches && (t3 = r2);
        if (t3 === _)
            return true;
        var i3 = (_ = t3) ? n3[_] : I;
        i3.breakpoints && _ && delete i3.breakpoints, y = e(e(e({}, Gt), I), i3), N = true, h = null, ut("optionsChanged"), Et();
    }

    function xt(t3) {
        if (typeof t3 == "function")
            return t3();
        var n3 = y.autoAdjustSlidesPerView;
        n3 || (o2 = Math.max(t3, o2));
        var e2 = st() && n3 ? o2 - 1 : o2;
        return c(t3, 1, Math.max(e2, 1));
    }

    function Pt() {
        kt(), R = true, ut("created");
    }

    function Et(t3, n3) {
        t3 && (I = t3), n3 && (_ = null), Ct(), jt(n3);
    }

    function Tt(t3) {
        var e2 = window.innerWidth;
        if (kt() && (e2 !== h || t3)) {
            h = e2;
            var r2 = y.slides;
            typeof r2 == "number" ? (f = null, o2 = r2) : (f = u(r2, n2), o2 = f ? f.length : 0);
            var i3 = y.dragSpeed;
            x = typeof i3 == "function" ? i3 : function(t4) {
                return t4 * i3;
            }, s = ht() ? n2.offsetHeight : n2.offsetWidth, l = xt(y.slidesPerView), d = c(y.spacing, 0, s / (l - 1) - 1), s += d, a2 = ct() ? (s / 2 - s / l / 2) / s : 0, Vt();
            var p2 = !R || N && y.resetSlide ? y.initial : v;
            Bt(st() ? p2 : Ht(p2)), ht() && n2.setAttribute(F, true), N = false;
        }
    }

    function Dt(t3) {
        Tt(), setTimeout(Tt, 500), setTimeout(Tt, 2e3);
    }

    function Ct() {
        at(), Xt(), n2 && n2.hasAttribute(F) && n2.removeAttribute(F), ut("destroyed");
    }

    function Lt() {
        f && f.forEach(function(t3, n3) {
            var e2 = g[n3].distance * s - n3 * (s / l - d / l - d / l * (l - 1)),
                r2 = ht() ? 0 : e2,
                i3 = ht() ? e2 : 0,
                o3 = "translate3d(".concat(r2, "px, ").concat(i3, "px, 0)");
            t3.style.transform = o3, t3.style["-webkit-transform"] = o3;
        });
    }

    function Vt() {
        f && f.forEach(function(t3) {
            var n3 = "calc(".concat(100 / l, "% - ").concat(d / l * (l - 1), "px)");
            ht() ? (t3.style["min-height"] = n3, t3.style["max-height"] = n3) : (t3.style["min-width"] = n3, t3.style["max-width"] = n3);
        });
    }

    function Xt() {
        if (f) {
            var t3 = ["transform", "-webkit-transform"];
            t3 = [].concat(r(t3), ht ? ["min-height", "max-height"] : ["min-width", "max-width"]), f.forEach(function(n3) {
                t3.forEach(function(t4) {
                    n3.style.removeProperty(t4);
                });
            });
        }
    }

    function Yt(t3) {
        var n3 = !(arguments.length > 1 && arguments[1] !== void 0) || arguments[1],
            e2 = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : Date.now();
        _t(t3, e2), n3 && (t3 = Ut(t3)), U += t3, Rt();
    }

    function zt(t3) {
        var n3 = s * (o2 - 1 * (ct() ? 1 : l)) / l,
            e2 = U + t3;
        return e2 > n3 ? e2 - n3 : e2 < 0 ? e2 : 0;
    }

    function Ht(t3) {
        return c(t3, 0, o2 - 1 - (ct() ? 0 : l - 1));
    }

    function It() {
        var t3 = Math.abs(w),
            n3 = U < 0 ? 1 - t3 : t3;
        return {
            direction: p,
            progressTrack: n3,
            progressSlides: n3 * o2 / (o2 - 1),
            positions: g,
            position: U,
            speed: b,
            relativeSlide: (v % o2 + o2) % o2,
            absoluteSlide: v,
            size: o2,
            slidesPerView: l,
            widthOrHeight: s
        };
    }

    function qt(t3) {
        var n3 = arguments.length > 1 && arguments[1] !== void 0 && arguments[1],
            e2 = arguments.length > 2 && arguments[2] !== void 0 && arguments[2];
        return st() ? n3 ? Wt(t3, e2) : t3 : Ht(t3);
    }

    function Ft(t3) {
        return -(-s / l * t3 + U);
    }

    function Wt(t3, n3) {
        var e2 = (v % o2 + o2) % o2,
            r2 = e2 < (t3 = (t3 % o2 + o2) % o2) ? -e2 - o2 + t3 : -(e2 - t3),
            i3 = e2 > t3 ? o2 - e2 + t3 : t3 - e2,
            a3 = n3 ? Math.abs(r2) <= i3 ? r2 : i3 : t3 < e2 ? r2 : i3;
        return v + a3;
    }

    function _t(t3, n3) {
        clearTimeout(m);
        var e2 = Math.sign(t3);
        if (e2 !== p && Nt(), p = e2, $.push({
                distance: t3,
                time: n3
            }), m = setTimeout(function() {
                $ = [], b = 0;
            }, 50), ($ = $.slice(-6)).length <= 1 || p === 0)
            return b = 0;
        var r2 = $.slice(0, -1).reduce(function(t4, n4) {
                return t4 + n4.distance;
            }, 0),
            i3 = $[$.length - 1].time,
            o3 = $[0].time;
        b = c(r2 / (i3 - o3), -10, 10);
    }

    function Nt() {
        $ = [];
    }

    function Rt() {
        w = st() ? U % (s * o2 / l) / (s * o2 / l) : U / (s * o2 / l), $t();
        for (var t3 = [], n3 = 0; n3 < o2; n3++) {
            var e2 = (1 / o2 * n3 - (w < 0 && st() ? w + 1 : w)) * o2 / l + a2;
            st() && (e2 += e2 > (o2 - 1) / l ? -o2 / l : e2 < -o2 / l + 1 ? o2 / l : 0);
            var r2 = 1 / l,
                i3 = e2 + r2,
                u2 = i3 < r2 ? i3 / r2 : i3 > 1 ? 1 - (i3 - 1) * l / 1 : 1;
            t3.push({
                portion: u2 < 0 || u2 > 1 ? 0 : u2,
                distance: lt() ? -1 * e2 + 1 - r2 : e2
            });
        }
        g = t3, Lt(), ut("move");
    }

    function Ut(t3) {
        if (st())
            return t3;
        var n3 = zt(t3);
        if (!dt())
            return t3 - n3;
        if (n3 === 0)
            return t3;
        var e2;
        return t3 * (e2 = n3 / s, (1 - Math.abs(e2)) * (1 - Math.abs(e2)));
    }

    function $t() {
        var t3 = Math.round(U / (s / l));
        t3 !== v && (!st() && (t3 < 0 || t3 > o2 - 1) || (v = t3, ut("slideChanged")));
    }

    function Bt(t3) {
        ut("beforeChange"), Yt(Ft(t3), false), ut("afterChange");
    }
    var Gt = {
            autoAdjustSlidesPerView: true,
            centered: false,
            breakpoints: null,
            controls: true,
            dragSpeed: 1,
            friction: 25e-4,
            loop: false,
            initial: 0,
            duration: 500,
            preventEvent: "data-keen-slider-pe",
            slides: ".keen-slider__slide",
            vertical: false,
            resetSlide: false,
            slidesPerView: 1,
            spacing: 0,
            mode: "snap",
            rtl: false,
            rubberband: true,
            cancelOnLeave: true
        },
        Jt = {
            controls: function(t3) {
                i2 = t3;
            },
            destroy: Ct,
            refresh: function(t3) {
                Et(t3, true);
            },
            next: function() {
                yt(v + 1, true);
            },
            prev: function() {
                yt(v - 1, true);
            },
            moveToSlide: function(t3, n3) {
                yt(t3, true, n3);
            },
            moveToSlideRelative: function(t3) {
                var n3 = arguments.length > 1 && arguments[1] !== void 0 && arguments[1],
                    e2 = arguments.length > 2 ? arguments[2] : void 0;
                yt(t3, true, e2, true, n3);
            },
            resize: function() {
                Tt(true);
            },
            details: function() {
                return It();
            },
            options: function() {
                var t3 = e({}, y);
                return delete t3.breakpoints, t3;
            }
        };
    return Pt(), Jt;
}

function a(t2) {
    return Array.prototype.slice.call(t2);
}

function u(t2) {
    var n2 = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : document;
    return typeof t2 == "function" ? a(t2()) : typeof t2 == "string" ? a(n2.querySelectorAll(t2)) : t2 instanceof HTMLElement != false ? [t2] : t2 instanceof NodeList != false ? t2 : [];
}

function c(t2, n2, e2) {
    return Math.min(Math.max(t2, n2), e2);
}
Math.sign || (Math.sign = function(t2) {
    return (t2 > 0) - (t2 < 0) || +t2;
});
export default o;