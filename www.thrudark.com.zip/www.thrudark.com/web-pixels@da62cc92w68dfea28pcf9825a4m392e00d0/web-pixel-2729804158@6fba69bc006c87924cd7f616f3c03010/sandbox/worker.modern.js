importScripts('https://www.thrudark.com/cdn/wpm/sda62cc92w68dfea28pcf9825a4m392e00d0m.js');
globalThis.shopify = self.webPixelsManager.createShopifyExtend('2729804158', 'APP');
importScripts('/web-pixels/strict/app/web-pixel-2729804158@6fba69bc006c87924cd7f616f3c03010.js');