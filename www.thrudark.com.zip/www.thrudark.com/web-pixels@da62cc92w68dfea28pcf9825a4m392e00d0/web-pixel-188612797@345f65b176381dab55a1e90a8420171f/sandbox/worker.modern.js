importScripts('https://www.thrudark.com/cdn/wpm/sda62cc92w68dfea28pcf9825a4m392e00d0m.js');
globalThis.shopify = self.webPixelsManager.createShopifyExtend('188612797', 'APP');
importScripts('/web-pixels/strict/app/web-pixel-188612797@345f65b176381dab55a1e90a8420171f.js');