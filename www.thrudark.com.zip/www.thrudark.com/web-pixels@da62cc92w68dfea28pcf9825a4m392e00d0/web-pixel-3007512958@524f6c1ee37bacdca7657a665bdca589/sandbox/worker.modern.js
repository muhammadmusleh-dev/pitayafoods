importScripts('https://www.thrudark.com/cdn/wpm/sda62cc92w68dfea28pcf9825a4m392e00d0m.js');
globalThis.shopify = self.webPixelsManager.createShopifyExtend('3007512958', 'APP');
importScripts('/web-pixels/strict/app/web-pixel-3007512958@524f6c1ee37bacdca7657a665bdca589.js');