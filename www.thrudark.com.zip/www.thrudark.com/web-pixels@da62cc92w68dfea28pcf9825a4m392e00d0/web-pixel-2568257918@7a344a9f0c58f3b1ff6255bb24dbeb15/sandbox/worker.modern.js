importScripts('https://www.thrudark.com/cdn/wpm/sda62cc92w68dfea28pcf9825a4m392e00d0m.js');
globalThis.shopify = self.webPixelsManager.createShopifyExtend('2568257918', 'APP');
importScripts('/web-pixels/strict/app/web-pixel-2568257918@7a344a9f0c58f3b1ff6255bb24dbeb15.js');