(() => {
    var tr = Object.defineProperty,
        rr = Object.defineProperties;
    var nr = Object.getOwnPropertyDescriptors;
    var Xe = Object.getOwnPropertySymbols;
    var or = Object.prototype.hasOwnProperty,
        ir = Object.prototype.propertyIsEnumerable;
    var Qe = (t, e, r) => e in t ? tr(t, e, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: r
        }) : t[e] = r,
        S = (t, e) => {
            for (var r in e || (e = {})) or.call(e, r) && Qe(t, r, e[r]);
            if (Xe)
                for (var r of Xe(e)) ir.call(e, r) && Qe(t, r, e[r]);
            return t
        },
        G = (t, e) => rr(t, nr(e));
    var a = (t, e, r) => new Promise((n, o) => {
        var s = l => {
                try {
                    c(r.next(l))
                } catch (u) {
                    o(u)
                }
            },
            i = l => {
                try {
                    c(r.throw(l))
                } catch (u) {
                    o(u)
                }
            },
            c = l => l.done ? n(l.value) : Promise.resolve(l.value).then(s, i);
        c((r = r.apply(t, e)).next())
    });
    var Ze = "WebPixel::Render";
    var Me = t => shopify.extend(Ze, t);
    var U = class {
        constructor(e) {
            this.headers = new Headers({
                "Access-Control-Allow-Origin": "*",
                "Content-Type": "application/json"
            });
            this.baseURL = e
        }
        buildUrl(e) {
            return `${this.baseURL}${e}`
        }
        handleResponse(e, r = !1) {
            let n = e.headers.get("X-Vwo-Campaigns") || void 0;
            if (e.headers.has("X-Error-Message")) {
                let o = e.headers.get("X-Error-Message");
                return e.text().then(() => ({
                    isSuccess: !1,
                    data: null,
                    errorMessage: o,
                    httpStatusCode: e.status,
                    xVwoCampaigns: n
                }))
            }
            return e.ok ? e.status === 204 ? e.text().then(() => ({
                isSuccess: !0,
                data: null,
                errorMessage: null,
                httpStatusCode: e.status,
                xVwoCampaigns: n
            })) : r ? Promise.resolve({
                isSuccess: !0,
                data: null,
                errorMessage: null,
                httpStatusCode: e.status,
                xVwoCampaigns: n
            }) : e.json().then(o => ({
                isSuccess: !0,
                data: o.data,
                errorMessage: null,
                httpStatusCode: e.status,
                xVwoCampaigns: n
            })) : e.json().then(o => ({
                isSuccess: !1,
                data: null,
                errorMessage: o.errorMessage,
                httpStatusCode: e.status,
                xVwoCampaigns: n
            }))
        }
        handleError(e) {
            var r;
            return e.name === "AbortError" ? {
                isSuccess: !1,
                data: null,
                errorMessage: "Request was cancelled",
                httpStatusCode: 499
            } : {
                isSuccess: !1,
                data: null,
                errorMessage: e.message,
                httpStatusCode: ((r = e.response) == null ? void 0 : r.status) || -1
            }
        }
        get(e, r, n = !1, o) {
            return a(this, null, function*() {
                try {
                    let s = this.buildUrl(e),
                        i = yield fetch(s, S({
                            headers: r != null ? r : {}
                        }, o && {
                            signal: o
                        }));
                    return this.handleResponse(i, n)
                } catch (s) {
                    return this.handleError(s)
                }
            })
        }
        post(e, r, n, o) {
            return a(this, null, function*() {
                try {
                    let s = this.buildUrl(e),
                        i = yield fetch(s, S({
                            method: "POST",
                            headers: G(S({}, n), {
                                "Content-Type": "application/json",
                                "Access-Control-Allow-Origin": "*"
                            }),
                            body: JSON.stringify(r)
                        }, o && {
                            signal: o
                        }));
                    return this.handleResponse(i)
                } catch (s) {
                    return this.handleError(s)
                }
            })
        }
        put(e, r) {
            return a(this, null, function*() {
                try {
                    let n = this.buildUrl(e),
                        o = yield fetch(n, {
                            method: "PUT",
                            headers: {
                                "Content-Type": "application/json",
                                "Access-Control-Allow-Origin": "*"
                            },
                            body: JSON.stringify(r)
                        });
                    return this.handleResponse(o)
                } catch (n) {
                    return this.handleError(n)
                }
            })
        }
        delete(e) {
            return a(this, null, function*() {
                try {
                    let r = this.buildUrl(e),
                        n = yield fetch(r, {
                            method: "DELETE",
                            headers: {
                                "Content-Type": "application/json",
                                "Access-Control-Allow-Origin": "*"
                            }
                        });
                    return this.handleResponse(n)
                } catch (r) {
                    return this.handleError(r)
                }
            })
        }
    };
    var J = "8.55.0";
    var M = globalThis;

    function pe(t, e, r) {
        let n = r || M,
            o = n.__SENTRY__ = n.__SENTRY__ || {},
            s = o[J] = o[J] || {};
        return s[t] || (s[t] = e())
    }
    var Ee = typeof __SENTRY_DEBUG__ == "undefined" || __SENTRY_DEBUG__;
    var sr = "Sentry Logger ",
        et = ["debug", "info", "warn", "error", "log", "assert", "trace"],
        tt = {};

    function ar(t) {
        if (!("console" in M)) return t();
        let e = M.console,
            r = {},
            n = Object.keys(tt);
        n.forEach(o => {
            let s = tt[o];
            r[o] = e[o], e[o] = s
        });
        try {
            return t()
        } finally {
            n.forEach(o => {
                e[o] = r[o]
            })
        }
    }

    function cr() {
        let t = !1,
            e = {
                enable: () => {
                    t = !0
                },
                disable: () => {
                    t = !1
                },
                isEnabled: () => t
            };
        return Ee ? et.forEach(r => {
            e[r] = (...n) => {
                t && ar(() => {
                    M.console[r](`${sr}[${r}]:`, ...n)
                })
            }
        }) : et.forEach(r => {
            e[r] = () => {}
        }), e
    }
    var Q = pe("logger", cr);

    function Z() {
        return ge(M), M
    }

    function ge(t) {
        let e = t.__SENTRY__ = t.__SENTRY__ || {};
        return e.version = e.version || J, e[J] = e[J] || {}
    }
    var ur = Object.prototype.toString;

    function lr(t, e) {
        return ur.call(t) === `[object ${e}]`
    }

    function rt(t) {
        return lr(t, "Object")
    }

    function nt(t) {
        return !!(t && t.then && typeof t.then == "function")
    }

    function ot(t, e, r) {
        try {
            Object.defineProperty(t, e, {
                value: r,
                writable: !0,
                configurable: !0
            })
        } catch (n) {
            Ee && Q.log(`Failed to add non-enumerable property "${e}" to object`, t)
        }
    }
    var it = 1e3;

    function Pe() {
        return Date.now() / it
    }

    function dr() {
        let {
            performance: t
        } = M;
        if (!t || !t.now) return Pe;
        let e = Date.now() - t.now(),
            r = t.timeOrigin == null ? e : t.timeOrigin;
        return () => (r + t.now()) / it
    }
    var st = dr(),
        Ie, Qn = (() => {
            let {
                performance: t
            } = M;
            if (!t || !t.now) {
                Ie = "none";
                return
            }
            let e = 3600 * 1e3,
                r = t.now(),
                n = Date.now(),
                o = t.timeOrigin ? Math.abs(t.timeOrigin + r - n) : e,
                s = o < e,
                i = t.timing && t.timing.navigationStart,
                l = typeof i == "number" ? Math.abs(i + r - n) : e,
                u = l < e;
            return s || u ? o <= l ? (Ie = "timeOrigin", t.timeOrigin) : (Ie = "navigationStart", i) : (Ie = "dateNow", n)
        })();

    function Y() {
        let t = M,
            e = t.crypto || t.msCrypto,
            r = () => Math.random() * 16;
        try {
            if (e && e.randomUUID) return e.randomUUID().replace(/-/g, "");
            e && e.getRandomValues && (r = () => {
                let n = new Uint8Array(1);
                return e.getRandomValues(n), n[0]
            })
        } catch (n) {}
        return ("10000000100040008000" + 1e11).replace(/[018]/g, n => (n ^ (r() & 15) >> n / 4).toString(16))
    }

    function at(t, e = {}) {
        if (e.user && (!t.ipAddress && e.user.ip_address && (t.ipAddress = e.user.ip_address), !t.did && !e.did && (t.did = e.user.id || e.user.email || e.user.username)), t.timestamp = e.timestamp || st(), e.abnormal_mechanism && (t.abnormal_mechanism = e.abnormal_mechanism), e.ignoreDuration && (t.ignoreDuration = e.ignoreDuration), e.sid && (t.sid = e.sid.length === 32 ? e.sid : Y()), e.init !== void 0 && (t.init = e.init), !t.did && e.did && (t.did = `${e.did}`), typeof e.started == "number" && (t.started = e.started), t.ignoreDuration) t.duration = void 0;
        else if (typeof e.duration == "number") t.duration = e.duration;
        else {
            let r = t.timestamp - t.started;
            t.duration = r >= 0 ? r : 0
        }
        e.release && (t.release = e.release), e.environment && (t.environment = e.environment), !t.ipAddress && e.ipAddress && (t.ipAddress = e.ipAddress), !t.userAgent && e.userAgent && (t.userAgent = e.userAgent), typeof e.errors == "number" && (t.errors = e.errors), e.status && (t.status = e.status)
    }

    function Le() {
        return Y()
    }

    function Ue() {
        return Y().substring(16)
    }

    function Fe(t, e, r = 2) {
        if (!e || typeof e != "object" || r <= 0) return e;
        if (t && e && Object.keys(e).length === 0) return t;
        let n = S({}, t);
        for (let o in e) Object.prototype.hasOwnProperty.call(e, o) && (n[o] = Fe(n[o], e[o], r - 1));
        return n
    }
    var Ne = "_sentrySpan";

    function Ge(t, e) {
        e ? ot(t, Ne, e) : delete t[Ne]
    }

    function Be(t) {
        return t[Ne]
    }
    var pr = 100,
        Ke = class t {
            constructor() {
                this._notifyingListeners = !1, this._scopeListeners = [], this._eventProcessors = [], this._breadcrumbs = [], this._attachments = [], this._user = {}, this._tags = {}, this._extra = {}, this._contexts = {}, this._sdkProcessingMetadata = {}, this._propagationContext = {
                    traceId: Le(),
                    spanId: Ue()
                }
            }
            clone() {
                let e = new t;
                return e._breadcrumbs = [...this._breadcrumbs], e._tags = S({}, this._tags), e._extra = S({}, this._extra), e._contexts = S({}, this._contexts), this._contexts.flags && (e._contexts.flags = {
                    values: [...this._contexts.flags.values]
                }), e._user = this._user, e._level = this._level, e._session = this._session, e._transactionName = this._transactionName, e._fingerprint = this._fingerprint, e._eventProcessors = [...this._eventProcessors], e._requestSession = this._requestSession, e._attachments = [...this._attachments], e._sdkProcessingMetadata = S({}, this._sdkProcessingMetadata), e._propagationContext = S({}, this._propagationContext), e._client = this._client, e._lastEventId = this._lastEventId, Ge(e, Be(this)), e
            }
            setClient(e) {
                this._client = e
            }
            setLastEventId(e) {
                this._lastEventId = e
            }
            getClient() {
                return this._client
            }
            lastEventId() {
                return this._lastEventId
            }
            addScopeListener(e) {
                this._scopeListeners.push(e)
            }
            addEventProcessor(e) {
                return this._eventProcessors.push(e), this
            }
            setUser(e) {
                return this._user = e || {
                    email: void 0,
                    id: void 0,
                    ip_address: void 0,
                    username: void 0
                }, this._session && at(this._session, {
                    user: e
                }), this._notifyScopeListeners(), this
            }
            getUser() {
                return this._user
            }
            getRequestSession() {
                return this._requestSession
            }
            setRequestSession(e) {
                return this._requestSession = e, this
            }
            setTags(e) {
                return this._tags = S(S({}, this._tags), e), this._notifyScopeListeners(), this
            }
            setTag(e, r) {
                return this._tags = G(S({}, this._tags), {
                    [e]: r
                }), this._notifyScopeListeners(), this
            }
            setExtras(e) {
                return this._extra = S(S({}, this._extra), e), this._notifyScopeListeners(), this
            }
            setExtra(e, r) {
                return this._extra = G(S({}, this._extra), {
                    [e]: r
                }), this._notifyScopeListeners(), this
            }
            setFingerprint(e) {
                return this._fingerprint = e, this._notifyScopeListeners(), this
            }
            setLevel(e) {
                return this._level = e, this._notifyScopeListeners(), this
            }
            setTransactionName(e) {
                return this._transactionName = e, this._notifyScopeListeners(), this
            }
            setContext(e, r) {
                return r === null ? delete this._contexts[e] : this._contexts[e] = r, this._notifyScopeListeners(), this
            }
            setSession(e) {
                return e ? this._session = e : delete this._session, this._notifyScopeListeners(), this
            }
            getSession() {
                return this._session
            }
            update(e) {
                if (!e) return this;
                let r = typeof e == "function" ? e(this) : e,
                    [n, o] = r instanceof K ? [r.getScopeData(), r.getRequestSession()] : rt(r) ? [e, e.requestSession] : [],
                    {
                        tags: s,
                        extra: i,
                        user: c,
                        contexts: l,
                        level: u,
                        fingerprint: g = [],
                        propagationContext: p
                    } = n || {};
                return this._tags = S(S({}, this._tags), s), this._extra = S(S({}, this._extra), i), this._contexts = S(S({}, this._contexts), l), c && Object.keys(c).length && (this._user = c), u && (this._level = u), g.length && (this._fingerprint = g), p && (this._propagationContext = p), o && (this._requestSession = o), this
            }
            clear() {
                return this._breadcrumbs = [], this._tags = {}, this._extra = {}, this._user = {}, this._contexts = {}, this._level = void 0, this._transactionName = void 0, this._fingerprint = void 0, this._requestSession = void 0, this._session = void 0, Ge(this, void 0), this._attachments = [], this.setPropagationContext({
                    traceId: Le()
                }), this._notifyScopeListeners(), this
            }
            addBreadcrumb(e, r) {
                let n = typeof r == "number" ? r : pr;
                if (n <= 0) return this;
                let o = S({
                    timestamp: Pe()
                }, e);
                return this._breadcrumbs.push(o), this._breadcrumbs.length > n && (this._breadcrumbs = this._breadcrumbs.slice(-n), this._client && this._client.recordDroppedEvent("buffer_overflow", "log_item")), this._notifyScopeListeners(), this
            }
            getLastBreadcrumb() {
                return this._breadcrumbs[this._breadcrumbs.length - 1]
            }
            clearBreadcrumbs() {
                return this._breadcrumbs = [], this._notifyScopeListeners(), this
            }
            addAttachment(e) {
                return this._attachments.push(e), this
            }
            clearAttachments() {
                return this._attachments = [], this
            }
            getScopeData() {
                return {
                    breadcrumbs: this._breadcrumbs,
                    attachments: this._attachments,
                    contexts: this._contexts,
                    tags: this._tags,
                    extra: this._extra,
                    user: this._user,
                    level: this._level,
                    fingerprint: this._fingerprint || [],
                    eventProcessors: this._eventProcessors,
                    propagationContext: this._propagationContext,
                    sdkProcessingMetadata: this._sdkProcessingMetadata,
                    transactionName: this._transactionName,
                    span: Be(this)
                }
            }
            setSDKProcessingMetadata(e) {
                return this._sdkProcessingMetadata = Fe(this._sdkProcessingMetadata, e, 2), this
            }
            setPropagationContext(e) {
                return this._propagationContext = S({
                    spanId: Ue()
                }, e), this
            }
            getPropagationContext() {
                return this._propagationContext
            }
            captureException(e, r) {
                let n = r && r.event_id ? r.event_id : Y();
                if (!this._client) return Q.warn("No client configured on scope - will not capture exception!"), n;
                let o = new Error("Sentry syntheticException");
                return this._client.captureException(e, G(S({
                    originalException: e,
                    syntheticException: o
                }, r), {
                    event_id: n
                }), this), n
            }
            captureMessage(e, r, n) {
                let o = n && n.event_id ? n.event_id : Y();
                if (!this._client) return Q.warn("No client configured on scope - will not capture message!"), o;
                let s = new Error(e);
                return this._client.captureMessage(e, r, G(S({
                    originalException: e,
                    syntheticException: s
                }, n), {
                    event_id: o
                }), this), o
            }
            captureEvent(e, r) {
                let n = r && r.event_id ? r.event_id : Y();
                return this._client ? (this._client.captureEvent(e, G(S({}, r), {
                    event_id: n
                }), this), n) : (Q.warn("No client configured on scope - will not capture event!"), n)
            }
            _notifyScopeListeners() {
                this._notifyingListeners || (this._notifyingListeners = !0, this._scopeListeners.forEach(e => {
                    e(this)
                }), this._notifyingListeners = !1)
            }
        },
        K = Ke;

    function ct() {
        return pe("defaultCurrentScope", () => new K)
    }

    function ut() {
        return pe("defaultIsolationScope", () => new K)
    }
    var je = class {
        constructor(e, r) {
            let n;
            e ? n = e : n = new K;
            let o;
            r ? o = r : o = new K, this._stack = [{
                scope: n
            }], this._isolationScope = o
        }
        withScope(e) {
            let r = this._pushScope(),
                n;
            try {
                n = e(r)
            } catch (o) {
                throw this._popScope(), o
            }
            return nt(n) ? n.then(o => (this._popScope(), o), o => {
                throw this._popScope(), o
            }) : (this._popScope(), n)
        }
        getClient() {
            return this.getStackTop().client
        }
        getScope() {
            return this.getStackTop().scope
        }
        getIsolationScope() {
            return this._isolationScope
        }
        getStackTop() {
            return this._stack[this._stack.length - 1]
        }
        _pushScope() {
            let e = this.getScope().clone();
            return this._stack.push({
                client: this.getClient(),
                scope: e
            }), e
        }
        _popScope() {
            return this._stack.length <= 1 ? !1 : !!this._stack.pop()
        }
    };

    function ee() {
        let t = Z(),
            e = ge(t);
        return e.stack = e.stack || new je(ct(), ut())
    }

    function gr(t) {
        return ee().withScope(t)
    }

    function mr(t, e) {
        let r = ee();
        return r.withScope(() => (r.getStackTop().scope = t, e(t)))
    }

    function lt(t) {
        return ee().withScope(() => t(ee().getIsolationScope()))
    }

    function dt() {
        return {
            withIsolationScope: lt,
            withScope: gr,
            withSetScope: mr,
            withSetIsolationScope: (t, e) => lt(e),
            getCurrentScope: () => ee().getScope(),
            getIsolationScope: () => ee().getIsolationScope()
        }
    }

    function Ve(t) {
        let e = ge(t);
        return e.acs ? e.acs : dt()
    }

    function He() {
        let t = Z();
        return Ve(t).getCurrentScope()
    }

    function Ye() {
        let t = Z();
        return Ve(t).getIsolationScope()
    }

    function pt(t) {
        if (t) return hr(t) ? {
            captureContext: t
        } : Sr(t) ? {
            captureContext: t
        } : t
    }

    function hr(t) {
        return t instanceof K || typeof t == "function"
    }
    var fr = ["user", "level", "extra", "contexts", "tags", "fingerprint", "requestSession", "propagationContext"];

    function Sr(t) {
        return Object.keys(t).some(e => fr.includes(e))
    }

    function Te(t, e) {
        return He().captureException(t, pt(e))
    }

    function we(t, e) {
        Ye().setTag(t, e)
    }
    var P = (t, e) => {
            try {
                we(t, e)
            } catch (r) {
                console.error("Error setting tag in Sentry", r)
            }
        },
        E = (t, e) => {
            try {
                Te(t, e)
            } catch (r) {
                console.error("Error sending exception to Sentry", r)
            }
        };
    var Ae = class {
        constructor(e) {
            this.customDimensionPrefix = "cd";
            this.trackerKey = "tid";
            this.clientIdKey = "sid";
            this.titleKey = "ti";
            this.shippingCountryKey = "co";
            this.envKey = "e";
            this.hcKey = "hc";
            this.logKey = "log";
            this.merchantKey = "m";
            this.cdnUrlKey = "cdu";
            this.pixelResKey = "f";
            this.domainRefererKey = "dr";
            this.dimensionsKey = "dims";
            this.tKey = "t";
            this.categoryKey = "c";
            this.actionKey = "a";
            this.labelKey = "l";
            this.pathKey = "p";
            this.jsonKey = "j";
            this.browserLanguageKey = "ul";
            this.screenResolutionKey = "sr";
            this.userAgentKey = "uafvl";
            this.checkoutServiceUrl = "https://checkout-service-qa.bglobale.com/api/v1/";
            this.gaUrl = e.url, this.data = e
        }
        init() {}
        sendBrowsingEvent(o, s) {
            return a(this, arguments, function*(e, r, n = 1) {
                r.size === 0 && (r = new Map);
                try {
                    r.set(this.tKey, "Browsing Start"), r.set(this.pathKey, encodeURIComponent(e.urlPath)), r.set(this.browserLanguageKey, encodeURIComponent(e.language)), r.set(this.screenResolutionKey, encodeURIComponent(e.screenResolution)), r.set(this.userAgentKey, encodeURIComponent(e.userAgent)), yield this.buildBrowsingUrl(r)
                } catch (i) {
                    E(i, {
                        data: "Error sending event"
                    })
                }
            })
        }
        sendEvent(o, s) {
            return a(this, arguments, function*(e, r, n = 1) {
                r.size === 0 && (r = new Map);
                try {
                    r.set(this.tKey, "ev"), r.set(this.categoryKey, encodeURIComponent(e.category)), r.set(this.actionKey, encodeURIComponent(e.action)), r.set(this.labelKey, encodeURIComponent(e.label)), e.json && r.set(this.jsonKey, encodeURIComponent(JSON.stringify(e.json))), yield this.buildUrlByTrackers(r)
                } catch (i) {
                    E(i, {
                        data: "Error sending event"
                    })
                }
            })
        }
        buildUrlByTrackers(e) {
            return a(this, null, function*() {
                let r = Array.from(this.data.measurementIds);
                for (let n of r) {
                    let o = "",
                        s = n[0];
                    o = yield this.buildUrlWithParams(s, e, o), new U(this.gaUrl).get(`/collectCheckout${o}`, void 0, !0).then(c => {}).catch(c => {
                        E("Analytics Error in .get(`/collectCheckout) for url: " + o), E(c)
                    })
                }
            })
        }
        buildBrowsingUrl(e) {
            return a(this, null, function*() {
                let r = "";
                r = yield this.buildUrlWithParams(null, e, r), new U(this.gaUrl).get(`/set${r}`, void 0, !0).then(o => {}).catch(o => {
                    E("Analytics Error in .get(`/set) for url: " + r), E(o)
                })
            })
        }
        identify(e, r) {}
        sendPageView(e, r) {
            return a(this, null, function*() {
                r.size === 0 && (r = new Map), r.set(this.tKey, "pv"), r.set(this.pathKey, encodeURIComponent(e.path)), yield this.buildUrlByTrackers(r)
            })
        }
        buildCustomDimensions() {
            let e = [];
            for (let [r, n] of Object.entries(this.data.dimensions)) {
                let o = this.customDimensionPrefix + r,
                    s = encodeURIComponent(n.toString()),
                    i = {
                        [o]: s
                    };
                e.push(i)
            }
            return JSON.stringify(e)
        }
        buildUrlWithParams(o, s) {
            return a(this, arguments, function*(e, r, n = this.gaUrl) {
                var c, l, u, g, p;
                let i = this.buildCustomDimensions();
                return e && (n = this.addQueryParam(this.trackerKey, this.data.measurementIds.get(e), n)), n = this.addQueryParam(this.clientIdKey, this.data.clientId, n), n = this.addQueryParam(this.titleKey, encodeURIComponent(this.data.title), n), n = this.addQueryParam(this.shippingCountryKey, (l = (c = this.data.shippingCountry) != null ? c : this.data.billingCountry) != null ? l : "", n), n = this.addQueryParam(this.envKey, this.data.cdnUrl ? this.data.cdnUrl.toLowerCase().indexOf("dev.") > -1 ? "live" : "local" : "", n), n = this.addQueryParam(this.hcKey, "0", n), n = this.addQueryParam(this.logKey, "false", n), n = this.addQueryParam(this.merchantKey, (g = (u = this.data.merchantId) == null ? void 0 : u.toString()) != null ? g : "", n), n = this.addQueryParam(this.cdnUrlKey, (p = this.data.cdnUrl) != null ? p : "empty_cdu", n), n = this.addQueryParam(this.pixelResKey, "gleTags.handlePixelResponse", n), n = this.addQueryParam(this.domainRefererKey, this.data.domainReferer, n), n = this.addQueryParam(this.dimensionsKey, i, n), Array.from(r).forEach(_ => {
                    n = this.addQueryParam(_[0], _[1], n)
                }), n
            })
        }
        addQueryParam(e, r, n) {
            let o = n.indexOf("?") != -1 ? "&" : "?";
            return n = n + o + e + "=" + r, n
        }
    };

    function b(t, e, r) {
        if (t && t.has(e)) {
            let n = t.get(e);
            return typeof n == "string" && typeof r == "number" ? Number(n) : n
        } else return r
    }
    var me = class t {
        constructor() {
            this.merchantId = 0;
            this.cdnUrl = "";
            this.domainReferer = "";
            this.title = "";
            this.dimensions = new Array
        }
        adapt(e, r = new Map) {
            let n = new t;
            if (e && e !== null) {
                n.userData = e.userData, n.url = e.gaUrl, n.measurementIds = new Map;
                let o = b(r, "browsingClientId", "");
                o || (o = b(r, "clientId", "")), n.clientId = o, e.checkoutTrackerId && n.measurementIds.set(1, e.checkoutTrackerId), e.browsingTrackerId && n.measurementIds.set(2, e.browsingTrackerId), n.merchantId = b(r, "merchantId", 0), n.environment = b(r, "environment", "0"), n.billingCountry = b(r, "billingCountry", "0"), n.shippingCountry = b(r, "shippingCountry", "0"), n.shippingStateCode = b(r, "shippingStateCode", "0"), n.cultureCode = b(r, "cultureCode", "0"), n.amount = b(r, "amount", "0"), n.webStoreCode = b(r, "webStoreCode", "0"), n.applePay = b(r, "applePay", "0"), n.siteId = b(r, "siteId", "0"), n.isTokenEnabled = b(r, "isTokenEnabled", "0"), n.status = b(r, "status", ""), n.isOperatedCountry = b(r, "isOperatedCountry", "0"), n.cdnUrl = e.cdnUrl, n.dimensions = e.dimensions, n.domainReferer = e.domainReferer, n.title = b(r, "title", "")
            }
            return n
        }
    };
    var te = class {
        constructor(e, r, n = new Map) {
            this.enabledAnalyticTypes = new Array;
            this._instances = {};
            this.googleAnalyticsData = new me;
            this.props = new Map;
            this.geData = new me;
            this.data = e, this.props = n, this.enabledAnalyticTypes = r, this.initAll()
        }
        initAll() {
            var e;
            (e = this.enabledAnalyticTypes) == null || e.forEach(r => {
                switch (r) {
                    case 1:
                        this.geData = this.googleAnalyticsData.adapt(this.data, this.props), this._instances[1] = new Ae(this.geData), this._instances[1].init();
                        break;
                    case 2:
                        break;
                    case 3:
                        break;
                    default:
                        break
                }
            })
        }
        isEnabled(e) {
            return this.enabledAnalyticTypes.includes(e)
        }
        sendEvent(o, s) {
            return a(this, arguments, function*(e, r, n = new Map) {
                this.isEnabled(e) && (yield this._instances[e].sendEvent(r, n))
            })
        }
        sendBrowsingEvent(o, s) {
            return a(this, arguments, function*(e, r, n = new Map) {
                this.isEnabled(e) && (yield this._instances[e].sendBrowsingEvent(r, n))
            })
        }
        sendPageView(o, s) {
            return a(this, arguments, function*(e, r, n = new Map) {
                this.isEnabled(e) && (yield this._instances[e].sendPageView(r, n))
            })
        }
    };
    var re = class {};
    var z = class {
        constructor(e) {
            this.name = e
        }
    };
    var ne = class extends z {
        constructor(e, r, n, o, s) {
            super(e), this.category = r, this.action = n, this.label = o, this.json = s
        }
    };
    var $ = "GE_UTM_PARAMS",
        oe = "GlobalE_Analytics_UTMs",
        ht = "GE_UTM_PARAMS_RAW",
        he = "GE_META_PARAMS",
        qe = "BF_CONSENT_PARAM",
        ft = "GlobalE_Analytics_GoogleAds";
    var St = "borderfree",
        yt = "borderfree.com",
        fe = {
            FLID: {
                urlParam: "GEflid",
                cookieName: "_fbc"
            },
            FP: {
                urlParam: "GEfp",
                cookieName: "_fbp"
            }
        },
        _t = "bf_consent",
        Et = "directToCheckout",
        It = "directToCheckoutEnabled",
        Tt = "clientId",
        j = "IsMerchantOperatedByGE",
        Je = "GE_SHIPPING_OPTIONS";

    function wt() {
        let t = "0123456789abcdef";
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, r => {
            let n = Math.floor(Math.random() * 16),
                o = r === "x" ? n : n & 3 | 8;
            return t[o]
        })
    }

    function At() {
        let t = "0123456789abcdef";
        return "x".repeat(32).replace(/[x]/g, r => {
            let o = Math.floor(Math.random() * 16);
            return t[o]
        })
    }
    var x = t => String(t).toLowerCase() === "true";
    var Ct = "GEMPFCS";

    function Ce(t, e, r, n = !1) {
        return a(this, null, function*() {
            let o = yield t.cookie.get(e);
            if (o) try {
                let i = Ur(o);
                return i && i.sid && i.expiry ? i.sid : o
            } catch (i) {
                E(i)
            }
            return yield Lr(t, e, r, n)
        })
    }

    function Lr(t, e, r, n = !1) {
        return a(this, null, function*() {
            try {
                let o = new Date,
                    s = {
                        sid: Fr(r),
                        expiry: new Date(o.getTime() + 30 * 6e4).toISOString()
                    };
                return n || (yield t.cookie.set(e, JSON.stringify(s))), s.sid
            } catch (o) {
                return E(o), ""
            }
        })
    }

    function Ur(t) {
        try {
            let e = JSON.parse(t);
            if (e && typeof e == "object" && "sid" in e) return e
        } catch (e) {
            E(e)
        }
        return null
    }

    function Fr(t) {
        let e = function(c, l) {
                return Math.floor(Math.random() * (l - c + 1) + c)
            },
            o = e(1e8, 999999999),
            s = e(1e8, 999999999);
        return o + "." + s + "." + t
    }

    function ie(f, I, N, D, k, R, m, T) {
        return a(this, arguments, function*(t, e, r, n, o, s, i, c, l = new Map, u, g, p = new Map, _, y, d) {
            var de;
            if (!n || !o) return {
                initData: t,
                instance: e
            };
            let h = new U(n),
                A = `/Shopify/analytics/${r}/${o}/${s}?checkoutId=${i}&clientId=${c}`;
            p && p.forEach((B, Oe) => A += `&${Oe}=${B}`), _ && (A += `&sdkClientId=${_}`), y && (A += `&sdkSessionId=${y}`), d && d.forEach((B, Oe) => A += `&${Oe}=${B}`);
            let O = yield h.get(A).then(B => B).catch(B => {
                P("GEAnaliticsURL", A), E(B, {
                    data: "Analytic Error C1 GetConfiguration"
                })
            }), L = (de = O == null ? void 0 : O.data) != null ? de : null, q = new te(L, [r], l);
            return u(L), g(q), {
                initData: L,
                instance: q
            }
        })
    }

    function se(t, e, r, n, o, s) {
        return a(this, null, function*() {
            let i = new Map;
            i.set("clientId", e.clientId), i.set("browsingClientId", r), i.set("merchantId", n.toString()), Nr(i, e, o, s), i.set("webStoreCode", ""), i.set("applePay", ""), i.set("siteId", ""), i.set("isTokenEnabled", ""), i.set("status", ""), i.set("isOperatedCountry", ""), i.set("title", e.context.document.title);
            try {
                let c = yield t.sessionStorage.getItem("VWO_VARIATION");
                if (c) {
                    let l = JSON.parse(c);
                    l.campaignKey && i.set("vwoCampaignKey", l.campaignKey), l.variation && i.set("vwoVariation", l.variation)
                }
            } catch (c) {}
            return i
        })
    }

    function Nr(t, e, r, n) {
        var s;
        let o = e.data;
        o || (o = e.customData), r((s = o.checkout.shippingAddress.countryCode) != null ? s : o.checkout.billingAddress.countryCode), n(o.checkout.token), t.set("billingCountry", o.checkout.billingAddress.countryCode), t.set("shippingCountry", o.checkout.shippingAddress.countryCode), t.set("shippingStateCode", ""), t.set("amount", o.checkout.totalPrice.amount)
    }

    function xe(t) {
        return a(this, null, function*() {
            let e = yield t.sessionStorage.getItem(Ct);
            return e === null || e === "1"
        })
    }

    function xt(t) {
        return a(this, null, function*() {
            return yield t.sessionStorage.setItem(Ct, "0"), !0
        })
    }

    function ae(t, e) {
        return a(this, null, function*() {
            let r = new Map,
                n = "GE_UTM_PARAMS",
                o = null;
            try {
                let s = yield t.localStorage.getItem(n);
                if (s) {
                    let i = JSON.parse(s);
                    i && typeof i.value == "string" && jr(i) && (o = i.value)
                }
            } catch (s) {
                E(s)
            }
            if (!o) try {
                o = yield t.sessionStorage.getItem(n)
            } catch (s) {
                E(s)
            }
            if (o) try {
                let s = o.split("&").reduce((i, c) => {
                    let [l, u] = c.split("=");
                    return i[l] = u, i
                }, {});
                r.set("utmSource", s.utm_source), r.set("utmMedium", s.utm_medium), r.set("utmCampaign", s.utm_campaign), Kr(s, r)
            } catch (s) {
                E(s)
            }
            return yield Gr(t, r), x(e == null ? void 0 : e.BfGoogleAdsEnabled) && (yield Br(t, r)), r
        })
    }

    function Se(t, e) {
        return a(this, null, function*() {
            if (!t) return null;
            let r = new Map;
            try {
                let n = yield t.sessionStorage.getItem("VWO_VARIATION");
                if (!n) return null;
                let o = JSON.parse(n);
                return o.campaignKey && r.set("CampaignName", o.campaignKey), o.variation && r.set("Variation", o.variation), e && r.set("CheckoutId", e), r
            } catch (n) {
                return E(n), null
            }
        })
    }

    function ce(t) {
        let e = new Map;
        if (t != null && t.has("utmSource") && e.set("cs", t.get("utmSource")), t != null && t.has("utmMedium") && e.set("cm", t.get("utmMedium")), t != null && t.has("utmCampaign") && e.set("cn", t.get("utmCampaign")), t != null && t.has("GEflid") && e.set("GEflid", t.get("GEflid")), t != null && t.has("GEfp") && e.set("GEfp", t.get("GEfp")), t != null && t.has("bfDirectToCheckout") || t != null && t.has("bfDirectToCheckoutEnabled") || t != null && t.has("bfClientId")) {
            let r = {
                borderfreeProperties: {
                    [Et]: t.get("bfDirectToCheckout"),
                    [It]: t.get("bfDirectToCheckoutEnabled"),
                    [Tt]: t.get("bfClientId")
                }
            };
            e.set("j", JSON.stringify(r))
        }
        return t != null && t.has("gclid") && e.set("gclid", t.get("gclid")), e
    }

    function ue(t, e, r) {
        return a(this, null, function*() {
            let n = yield Se(e, r), o = n ? Object.fromEntries(n) : {};
            if (Object.keys(o).length > 0)
                if (t.has("j")) try {
                    let s = JSON.parse(t.get("j")),
                        i = S(S({}, s), o);
                    t.set("j", JSON.stringify(i))
                } catch (s) {} else t.set("j", JSON.stringify(o))
        })
    }

    function le(t, e, r) {
        return a(this, null, function*() {
            yield t.sessionStorage.setItem(e, r)
        })
    }

    function bt(t, e) {
        return a(this, null, function*() {
            return (yield t.sessionStorage.getItem(e)) === "true"
        })
    }

    function Gr(t, e) {
        return a(this, null, function*() {
            try {
                let r = yield t.sessionStorage.getItem(he);
                if (r) {
                    let n = JSON.parse(r);
                    n.GEflid && e.set("GEflid", n.GEflid), n.GEfp && e.set("GEfp", n.GEfp)
                }
            } catch (r) {
                E(r)
            }
        })
    }

    function Br(t, e) {
        return a(this, null, function*() {
            let r = "bfgclid";
            try {
                let n = yield t.localStorage.getItem(ft);
                if (n) {
                    let o = JSON.parse(n);
                    o[r] ? e.set("gclid", o[r]) : o.gclid && e.set("gclid", o.gclid)
                }
            } catch (n) {
                E(n)
            }
        })
    }

    function Kr(t, e) {
        let r = t.bf_direct_to_checkout,
            n = t.bf_direct_to_checkout_enabled,
            o = t.bf_client_id;
        r && e.set("bfDirectToCheckout", r), n && e.set("bfDirectToCheckoutEnabled", n), o && e.set("bfClientId", o)
    }

    function jr(t) {
        if (!t || typeof t != "object") return !1;
        let e = new Date(t.expiry).getTime(),
            r = new Date().getTime();
        return !isNaN(e) && r < e
    }
    var $e = {
        source: "direct",
        medium: "(none)",
        campaign: "(not-set)"
    };

    function vt({
        utmSource: t = null,
        utmMedium: e = null,
        utmCampaign: r = null,
        expiry: n = null
    }, {
        bfDirectToCheckout: o,
        bfDirectToCheckoutEnabled: s,
        bfClientId: i
    }) {
        let c = [],
            l = t || e || r,
            u = l ? t : $e.source,
            g = l ? e : $e.medium,
            p = l ? r : $e.campaign;
        u && c.push(`utm_source=${u}`), g && c.push(`utm_medium=${g}`), p && c.push(`utm_campaign=${p}`), o && c.push(`bf_direct_to_checkout=${o}`), s && c.push(`bf_direct_to_checkout_enabled=${s}`), i && c.push(`bf_client_id=${i}`);
        let _ = c.join("&");
        if (!n) return _;
        let y = {
            value: _
        };
        return y.expiry = new Date(n).toISOString(), JSON.stringify(y)
    }

    function be(t, e) {
        return a(this, null, function*() {
            let r = yield t.getItem($);
            if (!r) return {
                bfDirectToCheckout: null,
                bfDirectToCheckoutEnabled: null,
                bfClientId: null
            };
            if (e == 1) try {
                let n = JSON.parse(r);
                if (n != null && n.value) return ve(n.value)
            } catch (n) {
                console.error("Error parsing stored params:", n)
            }
            return ve(r)
        })
    }

    function Dt(t) {
        return a(this, null, function*() {
            return (yield t.localStorage.getItem($)) ? be(t.localStorage, 1) : be(t.sessionStorage, 0)
        })
    }

    function ve(t) {
        let e = new URLSearchParams(t);
        return {
            bfDirectToCheckout: e.get("bf_direct_to_checkout"),
            bfDirectToCheckoutEnabled: e.get("bf_direct_to_checkout_enabled"),
            bfClientId: e.get("bf_client_id")
        }
    }

    function De(t, e) {
        return a(this, null, function*() {
            try {
                let r, n = yield t.localStorage.getItem(oe), o = t.localStorage;
                if (r = 1, n || (n = yield t.sessionStorage.getItem(oe), o = t.sessionStorage, r = 0), !n) return;
                let s = JSON.parse(n),
                    i = ve(e.context.document.location.search),
                    c = i != null && i.bfDirectToCheckout || i != null && i.bfDirectToCheckoutEnabled || i != null && i.bfClientId ? i : yield be(o, r), l = vt(s, c);
                yield o.setItem($, l)
            } catch (r) {
                E(r, {
                    data: "web-pixel Error processing UTM parameters:"
                })
            }
        })
    }

    function kt(t, e) {
        return a(this, null, function*() {
            try {
                let r = yield t.localStorage.getItem($);
                r || (r = yield t.sessionStorage.getItem($)), r || (yield De(t, e))
            } catch (r) {
                E(r, {
                    data: "web-pixel Error processing UTM parameters:"
                })
            }
        })
    }
    var v = [];
    for (let t = 0; t < 256; ++t) v.push((t + 256).toString(16).slice(1));

    function Hr(t, e = 0) {
        return (v[t[e + 0]] + v[t[e + 1]] + v[t[e + 2]] + v[t[e + 3]] + "-" + v[t[e + 4]] + v[t[e + 5]] + "-" + v[t[e + 6]] + v[t[e + 7]] + "-" + v[t[e + 8]] + v[t[e + 9]] + "-" + v[t[e + 10]] + v[t[e + 11]] + v[t[e + 12]] + v[t[e + 13]] + v[t[e + 14]] + v[t[e + 15]]).toLowerCase()
    }
    var ze, Yr = new Uint8Array(16);

    function qr() {
        if (!ze) {
            if (typeof crypto > "u" || !crypto.getRandomValues) throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
            ze = crypto.getRandomValues.bind(crypto)
        }
        return ze(Yr)
    }
    var Jr = typeof crypto < "u" && crypto.randomUUID && crypto.randomUUID.bind(crypto),
        Rt = {
            randomUUID: Jr
        };

    function $r(t, e, r) {
        if (Rt.randomUUID && !e && !t) return Rt.randomUUID();
        t = t || {};
        let n = t.random || (t.rng || qr)();
        if (n[6] = n[6] & 15 | 64, n[8] = n[8] & 63 | 128, e) {
            r = r || 0;
            for (let o = 0; o < 16; ++o) e[r + o] = n[o];
            return e
        }
        return Hr(n)
    }
    var zr = $r;

    function Ot() {
        return zr()
    }
    var ye = class {
            constructor(t, e, r, n, o, s, i, c) {
                this.eventName = t, this.timestamp = e, this.clientId = r, this.sessionId = n, this.merchantId = o, this.shopperCountryCode = s, this.category = i, this.cdn = c, this.isSdk = !0
            }
        },
        Wr = class extends ye {
            constructor(t, e, r, n, o, s, i, c, l, u, g, p, _, y, d, f, I) {
                super("Page View", t, e, r, n, o, s, i), this.timestamp = t, this.clientId = e, this.sessionId = r, this.merchantId = n, this.shopperCountryCode = o, this.category = s, this.cdn = i, this.pageUrl = c, this.pageTitle = l, this.screenResolution = u, this.userAgent = g, this.referrer = p, this.utmSource = _, this.utmMedium = y, this.utmCampaign = d, this.utmTerm = f, this.utmContent = I
            }
        },
        Xr = class extends ye {
            constructor(t, e, r, n, o, s, i, c, l, u, g, p, _, y, d, f, I) {
                super("Browsing Start", t, e, r, n, o, s, i), this.timestamp = t, this.clientId = e, this.sessionId = r, this.merchantId = n, this.shopperCountryCode = o, this.category = s, this.cdn = i, this.pageUrl = c, this.pageTitle = l, this.screenResolution = u, this.userAgent = g, this.referrer = p, this.utmSource = _, this.utmMedium = y, this.utmCampaign = d, this.utmTerm = f, this.utmContent = I
            }
        },
        We = class extends Error {
            constructor(t) {
                super(`The "${t}" is not supported.`)
            }
        };

    function w(t) {
        return {
            toBeDefined(e) {
                if (t == null || typeof t == "string" && t.trim() === "") throw new Error(e != null ? e : "The value is not defined.");
                return t
            },
            toThrowNotSupported(e) {
                throw new We(e)
            }
        }
    }
    var Qr = new Set(["com", "org", "net", "edu", "gov", "uk", "co.uk", "org.uk", "gov.uk", "ac.uk", "au", "com.au", "net.au", "org.au", "co.nz", "com.sg", "com.br", "jp", "co.jp", "ne.jp", "or.jp", "go.jp", "de", "fr", "us", "ca", "cn", "com.cn", "net.cn", "org.cn", "co.kr", "or.kr", "go.kr", "in", "co.in", "net.in", "org.in", "firm.in", "gen.in", "ind.in"]);

    function Mt(t) {
        let e = t.split(".").filter(Boolean);
        if (e.length < 2) return t;
        let r = e.slice(-2).join("."),
            n = e.slice(-3).join(".");
        return Qr.has(r) && e.length >= 3 ? `.${n}` : `.${r}`
    }
    var Zr = class {
            constructor(t) {
                this.window = w(t).toBeDefined("The window object is required to construct DefaultBrowserAccessor."), this.sessionStorageAsyncWrapper = {
                    getItem: e => Promise.resolve(this.window.sessionStorage.getItem(e)),
                    setItem: (e, r) => Promise.resolve(this.window.sessionStorage.setItem(e, r)),
                    removeItem: e => Promise.resolve(this.window.sessionStorage.removeItem(e))
                }, this.localStorageAsyncWrapper = {
                    getItem: e => Promise.resolve(this.window.localStorage.getItem(e)),
                    setItem: (e, r) => Promise.resolve(this.window.localStorage.setItem(e, r)),
                    removeItem: e => Promise.resolve(this.window.localStorage.removeItem(e))
                }, this.cookieStorageAsyncWrapper = {
                    getItem: e => {
                        let r = e + "=",
                            n = this.window.document.cookie.split(";").map(o => o.trim()).find(o => o.startsWith(r));
                        return Promise.resolve(n ? n.substring(r.length) : null)
                    },
                    setItem: (e, r) => {
                        this.window.document.cookie = `${e}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/; domain=.${this.window.document.domain}`;
                        let n = Mt(this.window.location.hostname),
                            o = new Date(Date.now() + 2 * 365 * 24 * 60 * 60 * 1e3).toUTCString();
                        return this.window.document.cookie = `${e}=${encodeURIComponent(r)}; expires=${o}; path=/; domain=${n}`, Promise.resolve()
                    },
                    removeItem: e => {
                        let r = Mt(this.window.location.hostname);
                        return this.window.document.cookie = `${e}=;expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;domain=${r}`, Promise.resolve()
                    }
                }
            }
            getPageUrl() {
                return this.window.location.href
            }
            getPageTitle() {
                return this.window.document.title
            }
            getScreenResolution() {
                return `${this.window.screen.width}x${this.window.screen.height}`
            }
            getUserAgent() {
                return this.window.navigator.userAgent
            }
            getReferrer() {
                return this.window.document.referrer
            }
            get sessionStorage() {
                return this.sessionStorageAsyncWrapper
            }
            get localStorage() {
                return this.localStorageAsyncWrapper
            }
            get cookieStorage() {
                return this.cookieStorageAsyncWrapper
            }
            createTrackingPixel(t) {
                let e = this.window.document.createElement("img");
                e.width = 1, e.height = 1, e.src = t
            }
            createIFrame(t, e, r, n) {
                let o = this.window.document.getElementById(e.attributes.id);
                o || (o = this.window.document.createElement("iframe"), o.setAttribute("id", e.attributes.id), o.setAttribute("title", e.attributes.title), o.setAttribute("width", e.attributes.width), o.setAttribute("height", e.attributes.height), o.style.display = "none", this.window.document.getElementsByTagName("body")[0].appendChild(o)), o.setAttribute("src", t)
            }
        },
        en = class {
            constructor(t, e, r) {
                this._sessionStorage = w(t).toBeDefined(), this._localStorage = w(e).toBeDefined(), this._cookieStorage = w(r).toBeDefined()
            }
            getPageUrl() {}
            getPageTitle() {}
            getScreenResolution() {}
            getUserAgent() {}
            getReferrer() {}
            get sessionStorage() {
                return this._sessionStorage
            }
            get localStorage() {
                return this._localStorage
            }
            get cookieStorage() {
                return this._cookieStorage
            }
            createTrackingPixel(t) {}
            createIFrame(t, e, r, n) {}
        },
        F = "GlobalE_Analytics_UTMs",
        Pt = "utm_source",
        Lt = "utm_medium",
        Ut = "utm_campaign",
        Ft = "utm_term",
        Nt = "utm_content",
        tn = class {
            constructor(t, e, r) {
                var n, o, s;
                this.browser = w(t).toBeDefined("The IBrowserAccessor implementation is required to construct UtmHandler."), this.logger = w(e).toBeDefined("The ILogger implementation is required to construct UtmHandler."), this.FT_3DA = (n = r == null ? void 0 : r.FT_3DA) != null ? n : !0, this.FT_3DA_UTM_SOURCE_LIST = (o = r == null ? void 0 : r.FT_3DA_UTM_SOURCE_LIST) != null ? o : ["borderfree"], this.FT_3DA_STORAGE_LIFETIME = (s = r == null ? void 0 : r.FT_3DA_STORAGE_LIFETIME) != null ? s : 4320
            }
            handle(t) {
                return a(this, null, function*() {
                    let e = this.getUtmParams(t),
                        r = yield this.selectStorageStrategy().execute(e);
                    this.utmSource = r.utmSource, this.utmMedium = r.utmMedium, this.utmCampaign = r.utmCampaign, this.utmTerm = r.utmTerm, this.utmContent = r.utmContent
                })
            }
            getUtmParams(t) {
                var p, _, y;
                let e = "direct",
                    r = "(none)",
                    n = "(not-set)";
                try {
                    if (o(t)) return i(t);
                    if (s(t)) return t;
                    let d = new URL(this.browser.getPageUrl());
                    return {
                        utmSource: (p = d.searchParams.get(Pt)) != null ? p : l(this.browser),
                        utmMedium: (_ = d.searchParams.get(Lt)) != null ? _ : u(this.browser),
                        utmCampaign: (y = d.searchParams.get(Ut)) != null ? y : g(),
                        utmTerm: d.searchParams.get(Ft),
                        utmContent: d.searchParams.get(Nt)
                    }
                } catch (d) {
                    return this.logger.writeErrorLog({
                        method: "UtmHandler::getUtmParams()",
                        message: d.message,
                        errorMessage: d.message,
                        errorStackTrace: d.stackTrace
                    }), {
                        utmSource: e,
                        utmMedium: r,
                        utmCampaign: n,
                        utmTerm: null,
                        utmContent: null
                    }
                }

                function o(d) {
                    return typeof d == "string"
                }

                function s(d) {
                    return typeof d == "object" && d !== null && "utmSource" in d && "utmMedium" in d && "utmCampaign" in d && typeof d.utmSource == "string" && typeof d.utmMedium == "string" && typeof d.utmCampaign == "string"
                }

                function i(d) {
                    let f = new URLSearchParams(d);
                    return {
                        utmSource: f.get(Pt),
                        utmMedium: f.get(Lt),
                        utmCampaign: f.get(Ut),
                        utmTerm: f.get(Ft),
                        utmContent: f.get(Nt)
                    }
                }

                function c(d) {
                    return d
                }

                function l(d) {
                    let f = d.getReferrer();
                    return f ? f.includes("google") ? "google" : f.includes("borderfree") ? "borderfree" : f : e
                }

                function u(d) {
                    let f = d.getReferrer();
                    return f ? f.includes("google") ? "organic" : "referral" : r
                }

                function g() {
                    return n
                }
            }
            selectStorageStrategy() {
                return this.FT_3DA ? new rn(this.browser, this.FT_3DA_UTM_SOURCE_LIST, this.FT_3DA_STORAGE_LIFETIME) : new nn(this.browser)
            }
        },
        rn = class {
            constructor(t, e, r) {
                this.browser = w(t).toBeDefined("The IBrowserAccessor implementation is required to construct DefaultStorageStrategy."), this.FT_3DA_UTM_SOURCE_LIST = e, this.FT_3DA_STORAGE_LIFETIME = r
            }
            execute(t) {
                return a(this, null, function*() {
                    let e = Date.now(),
                        r = this.FT_3DA_UTM_SOURCE_LIST.includes(t.utmSource),
                        n = yield this.browser.localStorage.getItem(F);
                    if (n) try {
                        let o = JSON.parse(n);
                        if (o.expiry && e < o.expiry) return r && (o.expiry = e + this.FT_3DA_STORAGE_LIFETIME * 6e4, yield this.browser.localStorage.setItem(F, JSON.stringify(o))), o;
                        yield this.browser.localStorage.removeItem(F)
                    } catch (o) {
                        yield this.browser.localStorage.removeItem(F)
                    }
                    if (r) {
                        let o = G(S({}, t), {
                            expiry: e + this.FT_3DA_STORAGE_LIFETIME * 6e4
                        });
                        return yield this.browser.localStorage.setItem(F, JSON.stringify(o)), yield this.browser.sessionStorage.removeItem(F), o
                    } else {
                        let o = yield this.browser.sessionStorage.getItem(F);
                        if (o === null) return yield this.browser.sessionStorage.setItem(F, JSON.stringify(t)), t;
                        try {
                            return JSON.parse(o)
                        } catch (s) {
                            return yield this.browser.sessionStorage.removeItem(F), null
                        }
                    }
                })
            }
        },
        nn = class {
            constructor(t) {
                this.browser = w(t).toBeDefined("The IBrowserAccessor implementation is required to construct DefaultStorageStrategy.")
            }
            execute(t) {
                return a(this, null, function*() {
                    let e = yield this.browser.sessionStorage.getItem(F);
                    if (e === null) return yield this.browser.sessionStorage.setItem(F, JSON.stringify(t)), t;
                    try {
                        return JSON.parse(e)
                    } catch (r) {
                        return yield this.browser.sessionStorage.removeItem(F), null
                    }
                })
            }
        },
        jt = class {
            constructor() {}
            get(t) {
                return a(this, null, function*() {
                    return yield(yield fetch(t, {
                        method: "GET",
                        headers: {
                            "Content-Type": "application/json"
                        }
                    })).json()
                })
            }
            post(t, e) {
                return a(this, null, function*() {
                    return yield(yield fetch(t, {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(e)
                    })).json()
                })
            }
        },
        on = class {
            constructor(t, e) {
                this.http = e, this.cdn = t
            }
            send(t) {
                return a(this, null, function*() {
                    yield this.http.post(this.cdn, t)
                })
            }
        },
        sn = class {
            constructor(t, e) {
                this.cdn = w(t).toBeDefined("The CDN is required to initialize TrackingPixelEventSender."), this.browser = w(e).toBeDefined("The IBrowserAccessor implementation is required to initialize TrackingPixelEventSender.")
            }
            send(t) {
                let e = new URL("/client", this.cdn);
                for (let r in t) {
                    let n = t[r];
                    n != null && (n && typeof n == "object" && (n = JSON.stringify(n)), e.searchParams.append(Vt.map(r), n))
                }
                return this.browser.createTrackingPixel(e.toString()), Promise.resolve()
            }
        },
        Vt = class {
            static map(t) {
                switch (t) {
                    case "eventName":
                        return "e";
                    case "timestamp":
                        return "t";
                    case "clientId":
                        return "cid";
                    case "sessionId":
                        return "sid";
                    case "merchantId":
                        return "mid";
                    case "shopperCountryCode":
                        return "scc";
                    case "category":
                        return "c";
                    case "cdn":
                        return "cdn";
                    case "pageUrl":
                        return "p";
                    case "pageTitle":
                        return "pt";
                    case "screenResolution":
                        return "sr";
                    case "userAgent":
                        return "ua";
                    case "referrer":
                        return "ref";
                    case "utmSource":
                        return "utm_source";
                    case "utmMedium":
                        return "utm_medium";
                    case "utmCampaign":
                        return "utm_campaign";
                    case "utmTerm":
                        return "utm_term";
                    case "utmContent":
                        return "utm_content";
                    default:
                        return t
                }
            }
        },
        an = class {
            constructor(t, e) {
                var r;
                this.url = w(t).toBeDefined("The URL of the logging server is required to initialize DataTrackingServiceLogger."), this.http = (r = e == null ? void 0 : e.http) != null ? r : new jt
            }
            writeLog(t, e = 3) {
                return a(this, null, function*() {
                    try {
                        let r = {
                            severity: e
                        };
                        typeof t == "string" ? r.message = t : r = S(S({}, r), t), yield this.http.post(this.url, r)
                    } catch (r) {
                        console.error(`DataTrackingServiceLogger::writeLog() - error occured: ${r.message}`, r)
                    }
                })
            }
            writeDebugLog(t) {
                return a(this, null, function*() {
                    return this.writeLog(t, 1)
                })
            }
            writeVerboseLog(t) {
                return a(this, null, function*() {
                    return this.writeLog(t, 2)
                })
            }
            writeInfoLog(t) {
                return a(this, null, function*() {
                    return this.writeLog(t, 3)
                })
            }
            writeWarningLog(t) {
                return a(this, null, function*() {
                    return this.writeLog(t, 4)
                })
            }
            writeErrorLog(t) {
                return a(this, null, function*() {
                    return this.writeLog(t, 5)
                })
            }
            writeCriticalLog(t) {
                return a(this, null, function*() {
                    return this.writeLog(t, 6)
                })
            }
        },
        Gt = class {
            constructor() {
                this.logs = [], this.logsLimit = 100
            }
            writeLog(t, e = 3) {
                return a(this, null, function*() {
                    try {
                        let r = {
                            timestamp: Date.now(),
                            severity: e
                        };
                        return typeof t == "string" ? r.message = t : r = S(S({}, r), t), this.logs.push(r), this.logs.length > this.logsLimit && this.logs.shift(), Promise.resolve()
                    } catch (r) {}
                })
            }
            writeDebugLog(t) {
                return a(this, null, function*() {
                    return this.writeLog(t, 1)
                })
            }
            writeVerboseLog(t) {
                return a(this, null, function*() {
                    return this.writeLog(t, 2)
                })
            }
            writeInfoLog(t) {
                return a(this, null, function*() {
                    return this.writeLog(t, 3)
                })
            }
            writeWarningLog(t) {
                return a(this, null, function*() {
                    return this.writeLog(t, 4)
                })
            }
            writeErrorLog(t) {
                return a(this, null, function*() {
                    return this.writeLog(t, 5)
                })
            }
            writeCriticalLog(t) {
                return a(this, null, function*() {
                    return this.writeLog(t, 6)
                })
            }
        },
        cn = class {
            constructor(t) {
                this.debugOnly = t != null ? t : !1
            }
            writeLog(t, e = 3) {
                return a(this, null, function*() {
                    try {
                        if (this.debugOnly) console.debug(t);
                        else switch (e) {
                            case 1:
                                console.debug(t);
                                break;
                            case 2:
                                console.trace(t);
                                break;
                            case 3:
                                console.info(t);
                                break;
                            case 4:
                                console.warn(t);
                                break;
                            case 5:
                                console.error(t);
                                break;
                            case 6:
                                console.error(t);
                                break;
                            default:
                                break
                        }
                        return Promise.resolve()
                    } catch (r) {}
                })
            }
            writeDebugLog(t) {
                return a(this, null, function*() {
                    return this.writeLog(t, 1)
                })
            }
            writeVerboseLog(t) {
                return a(this, null, function*() {
                    return this.writeLog(t, 2)
                })
            }
            writeInfoLog(t) {
                return a(this, null, function*() {
                    return this.writeLog(t, 3)
                })
            }
            writeWarningLog(t) {
                return a(this, null, function*() {
                    return this.writeLog(t, 4)
                })
            }
            writeErrorLog(t) {
                return a(this, null, function*() {
                    return this.writeLog(t, 5)
                })
            }
            writeCriticalLog(t) {
                return a(this, null, function*() {
                    return this.writeLog(t, 6)
                })
            }
        },
        un = class extends ye {
            constructor(t, e, r, n, o, s, i, c, l, u, g, p, _, y) {
                super("Checkout Start", t, e, r, n, o, s, i), this.timestamp = t, this.clientId = e, this.sessionId = r, this.merchantId = n, this.shopperCountryCode = o, this.category = s, this.cdn = i, this.checkoutToken = c, this.userAgent = l, this.utmSource = u, this.utmMedium = g, this.utmCampaign = p, this.utmTerm = _, this.utmContent = y
            }
        },
        ln = class extends ye {
            constructor(t, e, r, n, o, s, i, c, l, u, g, p, _, y, d, f) {
                super(t, e, r, n, o, s, i, c), this.eventName = t, this.timestamp = e, this.clientId = r, this.sessionId = n, this.merchantId = o, this.shopperCountryCode = s, this.category = i, this.cdn = c, this.checkoutToken = l, this.userAgent = u, this.utmSource = g, this.utmMedium = p, this.utmCampaign = _, this.utmTerm = y, this.utmContent = d, this.data = f
            }
        },
        dn = class extends ye {
            constructor(t, e, r, n, o, s, i, c, l, u, g, p, _, y, d, f, I, N, D) {
                super(t, e, r, n, o, s, i, c), this.eventName = t, this.timestamp = e, this.clientId = r, this.sessionId = n, this.merchantId = o, this.shopperCountryCode = s, this.category = i, this.cdn = c, this.pageUrl = l, this.pageTitle = u, this.screenResolution = g, this.userAgent = p, this.referrer = _, this.utmSource = y, this.utmMedium = d, this.utmCampaign = f, this.utmTerm = I, this.utmContent = N, this.data = D
            }
        },
        pn = class {
            constructor(t, e) {
                this.cdn = w(t).toBeDefined("The CDN is required to initialize ShopifyFetchEventSender."), this.http = w(e).toBeDefined("The IHttp implementation is required to initialize ShopifyFetchEventSender")
            }
            send(t) {
                let e = new URL("/client", this.cdn);
                for (let r in t) {
                    let n = t[r];
                    n != null && (n && typeof n == "object" && (n = JSON.stringify(n)), e.searchParams.append(Vt.map(r), n))
                }
                return this.http.get(e.toString())
            }
        },
        gn = class {
            constructor(t, e) {
                this.browser = t, this.logger = e
            }
            saveData(t, e) {
                return a(this, null, function*() {
                    var r;
                    try {
                        let n = JSON.stringify(e);
                        yield Promise.all([this.browser.localStorage.setItem(t, n), this.browser.cookieStorage.setItem(t, n)])
                    } catch (n) {
                        throw (r = this.logger) == null || r.writeErrorLog({
                            method: "DataStorageManager::saveData()",
                            message: n.message,
                            errorMessage: n.stack || n.message
                        }), new Error(`Failed to save data: ${n.message}`)
                    }
                })
            }
            loadData(t) {
                return a(this, null, function*() {
                    var n, o;
                    let e = null,
                        r = null;
                    try {
                        let s = yield this.browser.cookieStorage.getItem(t);
                        if (s) {
                            let i = decodeURIComponent(s);
                            e = JSON.parse(i)
                        }
                    } catch (s) {
                        (n = this.logger) == null || n.writeWarningLog({
                            method: "DataStorageManager::loadData()",
                            message: "Failed to parse cookie data.",
                            errorMessage: s.message
                        })
                    }
                    try {
                        let s = yield this.browser.localStorage.getItem(t);
                        s && (r = JSON.parse(s))
                    } catch (s) {
                        (o = this.logger) == null || o.writeWarningLog({
                            method: "DataStorageManager::loadData()",
                            message: "Failed to parse localStorage data.",
                            errorMessage: s.message
                        })
                    }
                    return this.getFreshestValidSnapshot(e, r)
                })
            }
            clearData(t) {
                return a(this, null, function*() {
                    var e;
                    try {
                        yield Promise.all([this.browser.localStorage.removeItem(t), this.browser.cookieStorage.removeItem(t)])
                    } catch (r) {
                        throw (e = this.logger) == null || e.writeErrorLog({
                            method: "DataStorageManager::clearData()",
                            message: "Failed to clear data.",
                            errorMessage: r.message
                        }), new Error(`Failed to clear data: ${r.message}`)
                    }
                })
            }
            getFreshestValidSnapshot(t, e) {
                if (t && e) {
                    let r = t == null ? void 0 : t.dataUpdatedAt,
                        n = e == null ? void 0 : e.dataUpdatedAt;
                    if (r && n) return r > n ? t : e
                }
                return t != null ? t : e
            }
        },
        W = "GlobalE_Analytics_GoogleAds",
        Bt = "gclid",
        Kt = "bfgclid",
        mn = class {
            get googleClickId() {
                return this.isBorderfreeGoogleClickId ? this.bfgclid : this.gclid
            }
            get isBorderfreeGoogleClickId() {
                return this.bfIsEnabled && this.bfgclid
            }
            constructor(t, e, r) {
                var n, o;
                this.browser = w(t).toBeDefined("The IBrowserAccessor implementation is required to construct GoogleAdsHandler."), this.logger = w(e).toBeDefined("The ILogger implementation is required to construct GoogleAdsHandler."), this.bfIsEnabled = (n = r == null ? void 0 : r.bfGoogleAdsEnabled) != null ? n : !0, this.bfLifetimeInDays = (o = r == null ? void 0 : r.bfGoogleAdsLifetimeInDays) != null ? o : 30
            }
            handle(t) {
                return a(this, null, function*() {
                    let e = this.parseUrl(t),
                        r = yield this.selectStorageStrategy().execute(e);
                    this.gclid = r.gclid, this.bfgclid = r.bfgclid
                })
            }
            parseUrl(t) {
                let e = {
                    gclid: null,
                    bfgclid: null
                };
                try {
                    if (r(t)) return n(t);
                    if (o(t)) return t;
                    let i = new URL(this.browser.getPageUrl());
                    e.gclid = i.searchParams.get(Bt), e.bfgclid = i.searchParams.get(Kt)
                } catch (i) {
                    this.logger.writeErrorLog({
                        method: "GoogleAdsHandler::parseUrl()",
                        message: i.message,
                        errorMessage: i.message,
                        errorStackTrace: i.stackTrace
                    })
                }
                return e;

                function r(i) {
                    return typeof i == "string"
                }

                function n(i) {
                    let c = new URLSearchParams(i);
                    return {
                        gclid: c.get(Bt),
                        bfgclid: c.get(Kt)
                    }
                }

                function o(i) {
                    return typeof i == "object" && i !== null && "gclid" in i && "bfgclid" in i && typeof i.gclid == "string" && typeof i.bfgclid == "string"
                }

                function s(i) {
                    return i
                }
            }
            selectStorageStrategy() {
                return this.bfIsEnabled ? new fn(this.browser, this.bfLifetimeInDays) : new hn(this.browser)
            }
        },
        hn = class {
            constructor(t) {
                this.browser = w(t).toBeDefined("The IBrowserAccessor implementation is required to construct DefaultStorageStrategy.")
            }
            execute(t) {
                return a(this, null, function*() {
                    try {
                        if (t.gclid) {
                            let e = {
                                    gclid: t.gclid,
                                    expiry: Date.now() + 2592e6
                                },
                                r = JSON.stringify(e);
                            return yield this.browser.localStorage.setItem(W, r), {
                                gclid: e.gclid,
                                bfgclid: null
                            }
                        } else {
                            let e = yield this.browser.localStorage.getItem(W), r = JSON.parse(e);
                            return r != null && r.expiry && r.expiry < Date.now() ? (yield this.browser.localStorage.removeItem(W), {
                                gclid: null,
                                bfgclid: null
                            }) : {
                                gclid: r == null ? void 0 : r.gclid,
                                bfgclid: null
                            }
                        }
                    } catch (e) {
                        return {
                            gclid: null,
                            bfgclid: null
                        }
                    }
                })
            }
        },
        fn = class {
            constructor(t, e) {
                this.browser = w(t).toBeDefined("The IBrowserAccessor implementation is required to construct BorderfreeStorageStrategy."), this.bfLifetimeInDays = e
            }
            execute(t) {
                return a(this, null, function*() {
                    try {
                        if (t.bfgclid) {
                            let e = {
                                    bfgclid: t.bfgclid,
                                    expiry: Date.now() + this.bfLifetimeInDays * 24 * 60 * 60 * 1e3
                                },
                                r = JSON.stringify(e);
                            return yield this.browser.localStorage.setItem(W, r), {
                                gclid: null,
                                bfgclid: t.bfgclid
                            }
                        } else {
                            let e = yield this.browser.localStorage.getItem(W), r = JSON.parse(e);
                            if (r != null && r.expiry && r.expiry < Date.now()) yield this.browser.localStorage.removeItem(W);
                            else {
                                if (r != null && r.bfgclid) return {
                                    gclid: null,
                                    bfgclid: r.bfgclid
                                };
                                if (r != null && r.gclid) return {
                                    gclid: r.gclid,
                                    bfgclid: null
                                }
                            }
                            if (t.gclid) {
                                let n = {
                                        gclid: t.gclid,
                                        expiry: Date.now() + 2592e6
                                    },
                                    o = JSON.stringify(n);
                                return yield this.browser.localStorage.setItem(W, o), {
                                    gclid: n.gclid,
                                    bfgclid: null
                                }
                            } else return {
                                gclid: null,
                                bfgclid: null
                            }
                        }
                    } catch (e) {
                        return {
                            gclid: null,
                            bfgclid: null
                        }
                    }
                })
            }
        },
        Ht = class {
            constructor(t, e) {
                this.ANALYTICS_STORAGE_KEY = "GlobalE_Analytics", this.eventQueue = [], this.isConfigurationLoaded = !1, this.isInitialized = !1, this.FT_3DA = !0, this.FT_3DA_UTM_SOURCE_LIST = ["borderfree"], this.FT_3DA_STORAGE_LIFETIME = 4320, this.FT_BF_GOOGLE_ADS = !1, this.FT_BF_GOOGLE_ADS_LIFETIME = 30, this.ExpirationTime = 30, this.DATA_TRACKING_SERVICE_API_URL = "https://utils-qa.bglobale.com", this.MONOLITH_API_URL = "https://qa.bglobale.com", this.http = t != null ? t : new jt, this.logger = e != null ? e : new Gt
            }
            get ClientId() {
                return this.clientId
            }
            get SessionId() {
                return this.sessionId
            }
            get UtmSource() {
                return this.utms.utmSource
            }
            get UtmMedium() {
                return this.utms.utmMedium
            }
            get UtmCampaign() {
                return this.utms.utmCampaign
            }
            get googleClickId() {
                var t;
                return (t = this.googleAds) == null ? void 0 : t.googleClickId
            }
            get isBorderfreeGoogleClickId() {
                var t;
                return (t = this.googleAds) == null ? void 0 : t.isBorderfreeGoogleClickId
            }
            loadConfigurationSnapshot() {
                return a(this, null, function*() {
                    try {
                        let t = yield this.dataStorageManager.loadData(this.ANALYTICS_STORAGE_KEY);
                        if (t === null) {
                            this.logger.writeInfoLog({
                                method: "AnalyticsSDK::loadConfigurationSnapshot()",
                                message: "Snapshot is not found in Local Storage"
                            });
                            return
                        }
                        this.merchantId = w(t.merchantId).toBeDefined("Snapshot integrity violated. The `merchantId` is missing."), this.shopperCountryCode = t.shopperCountryCode, this.cdn = w(t.cdn).toBeDefined("Snapshot integrity violated. The `cdn` is missing."), this.clientId = w(t.clientId).toBeDefined("Snapshot integrity violated. The `clientId` is missing."), this.sessionId = t.sessionId, this.sessionIdExpiry = t.sessionIdExpiry, this.eventSendingStrategy = t.configurations.eventSendingStrategy, this.FT_3DA = t.featureToggles.FT_3DA, this.FT_3DA_UTM_SOURCE_LIST = t.featureToggles.FT_3DA_UTM_SOURCE_LIST, this.FT_3DA_STORAGE_LIFETIME = t.featureToggles.FT_3DA_STORAGE_LIFETIME, this.FT_BF_GOOGLE_ADS = t.featureToggles.FT_BF_GOOGLE_ADS, this.FT_BF_GOOGLE_ADS_LIFETIME = t.featureToggles.FT_BF_GOOGLE_ADS_LIFETIME, this.lockBrowsingStartOnSessionId = t.lockBrowsingStartOnSessionId, this.lockCheckoutStartOnSessionId = t.lockCheckoutStartOnSessionId, this.dataUpdatedAt = t.dataUpdatedAt, this.dataLayer = t.dataLayer, this.isConfigurationLoaded = !0
                    } catch (t) {
                        this.logger.writeWarningLog({
                            method: "AnalyticsSDK::loadConfigurationSnapshot()",
                            message: t.message,
                            errorMessage: t.message
                        })
                    }
                })
            }
            saveConfigurationSnapshot() {
                return a(this, null, function*() {
                    let t = {
                        merchantId: this.merchantId,
                        shopperCountryCode: this.shopperCountryCode,
                        cdn: this.cdn,
                        clientId: this.clientId,
                        sessionId: this.sessionId,
                        sessionIdExpiry: this.sessionIdExpiry,
                        configurations: {
                            eventSendingStrategy: this.eventSendingStrategy
                        },
                        featureToggles: {
                            FT_3DA: this.FT_3DA,
                            FT_3DA_UTM_SOURCE_LIST: this.FT_3DA_UTM_SOURCE_LIST,
                            FT_3DA_STORAGE_LIFETIME: this.FT_3DA_STORAGE_LIFETIME,
                            FT_BF_GOOGLE_ADS: this.FT_BF_GOOGLE_ADS,
                            FT_BF_GOOGLE_ADS_LIFETIME: this.FT_BF_GOOGLE_ADS_LIFETIME
                        },
                        lockBrowsingStartOnSessionId: this.lockBrowsingStartOnSessionId,
                        lockCheckoutStartOnSessionId: this.lockCheckoutStartOnSessionId,
                        dataUpdatedAt: Date.now(),
                        dataLayer: this.dataLayer
                    };
                    yield this.dataStorageManager.saveData(this.ANALYTICS_STORAGE_KEY, t)
                })
            }
            loadConfigurationFromServer() {
                return a(this, null, function*() {
                    try {
                        let t = new URL(`merchant/analytics/sdk/init/${this.merchantId}/${this.shopperCountryCode}`, this.cdn);
                        t.searchParams.append("merchantId", this.merchantId);
                        let e = yield this.http.get(t.toString());
                        this.FT_3DA = e.FT_UtmReplaceSessionStorageWithCookies, this.FT_3DA_UTM_SOURCE_LIST = e.UtmAcceptableUtmSourceList, this.FT_3DA_STORAGE_LIFETIME = e.UtmParamsCookieLifetimeInMinutes, this.FT_BF_GOOGLE_ADS = e.BfGoogleAdsEnabled, this.FT_BF_GOOGLE_ADS_LIFETIME = e.BfGoogleAdsLifetimeInDays
                    } catch (t) {
                        this.logger.writeErrorLog({
                            method: "AnalyticsSDK::loadMerchantConfiguration()",
                            message: t.message,
                            errorMessage: t.message
                        })
                    }
                })
            }
            setClientId(t) {
                t ? this.clientId = t : this.clientId || (this.clientId = Ot())
            }
            setSessionId(t) {
                let e = Date.now();
                if (t && (!this.sessionId || this.sessionId !== t)) {
                    this.sessionId = t, this.sessionIdExpiry = e + this.ExpirationTime * 60 * 1e3;
                    return
                }
            }
            setShopperCountryCode(t) {
                this.shopperCountryCode = t
            }
            defineBrowserAccessor(t) {
                if (t.browser === void 0 || t.browser === null) throw new Error("The configuration.browser property should be defined.");
                if (e(t.browser)) this.browser = new Zr(t.browser);
                else if (r(t.browser)) this.browser = new en(t.browser.sessionStorage, t.browser.localStorage, t.browser.cookieStorage);
                else throw new Error("The provided configuration.browser is not supported (could be missing required properties of any of supported types).");

                function e(n) {
                    return typeof n == "object" && n !== null && "document" in n
                }

                function r(n) {
                    return typeof n == "object" && n !== null && "localStorage" in n && "sessionStorage" in n && "cookieStorage" in n
                }
            }
            defineEventSender(t) {
                switch (this.eventSendingStrategy = t.eventSendingStrategy || 0, this.eventSendingStrategy) {
                    case 0:
                        this.eventSender = new sn(this.DATA_TRACKING_SERVICE_API_URL, this.browser);
                        break;
                    case 1:
                        this.eventSender = new pn(this.DATA_TRACKING_SERVICE_API_URL, this.http);
                        break;
                    case 2:
                        this.eventSender = new on(this.DATA_TRACKING_SERVICE_API_URL, this.http);
                        break;
                    case 3:
                        this.eventSender = t.eventSender;
                        break;
                    default:
                        throw new We(`enum value ${this.eventSendingStrategy}`)
                }
            }
            defineLogger(t) {
                var e;
                switch (this.loggingStrategy = (e = t.loggingStrategy) != null ? e : 0, this.loggingStrategy) {
                    case 0:
                        this.logger = new Gt;
                        break;
                    case 1:
                        this.logger = new cn;
                        break;
                    case 2:
                        this.logger = new an(new URL("logger", this.DATA_TRACKING_SERVICE_API_URL).toString(), {
                            http: this.http
                        });
                        break;
                    default:
                        throw new We("Custom logger currently not supported.")
                }
            }
            defineUtmParametersHandler() {
                this.utms = new tn(this.browser, this.logger, {
                    FT_3DA: this.FT_3DA,
                    FT_3DA_UTM_SOURCE_LIST: this.FT_3DA_UTM_SOURCE_LIST,
                    FT_3DA_STORAGE_LIFETIME: this.FT_3DA_STORAGE_LIFETIME
                })
            }
            defineGoogleAdsHandler() {
                this.googleAds = new mn(this.browser, this.logger, {
                    bfGoogleAdsEnabled: this.FT_BF_GOOGLE_ADS,
                    bfGoogleAdsLifetimeInDays: this.FT_BF_GOOGLE_ADS_LIFETIME
                })
            }
            defineDataStorageManager() {
                this.dataStorageManager = new gn(this.browser, this.logger)
            }
            updateSession(t) {
                return a(this, null, function*() {
                    (this.sessionId === void 0 || this.sessionIdExpiry < t) && (this.sessionId = Ot()), this.sessionIdExpiry = t + this.ExpirationTime * 60 * 1e3, yield this.saveConfigurationSnapshot()
                })
            }
            queueEventSending(t, e) {
                this.eventQueue.push({
                    functionName: t,
                    arguments: e
                })
            }
            queueEventDequeue() {
                for (; this.eventQueue.length > 0;) {
                    let t = this.eventQueue.pop();
                    if (t && t.arguments) {
                        let e = Array.prototype.slice.call(t.arguments);
                        this[t.functionName](...e)
                    } else this.logger.writeInfoLog("Arguments are undefined or missing for this event")
                }
            }
            init(t, e, r) {
                return a(this, null, function*() {
                    this.merchantId = w(t).toBeDefined("The merchantId is required to load configuration."), this.shopperCountryCode = w(e).toBeDefined("The shopper country is required to load configuration."), this.cdn = w(r == null ? void 0 : r.cdn).toBeDefined("The CDN currently is required to load configuration. (should be changed in 2025 Q1)"), this.defineBrowserAccessor(r), this.defineLogger(r), this.defineEventSender(r), this.defineDataStorageManager(), yield this.loadConfigurationSnapshot(), (!this.isConfigurationLoaded || this.shopperCountryCode !== e) && (this.setShopperCountryCode(e), yield this.loadConfigurationFromServer()), this.defineUtmParametersHandler(), this.defineGoogleAdsHandler(), this.setClientId(r.clientId), this.setSessionId(r.sessionId), this.userAgent = this.browser.getUserAgent(), this.screenResolution = this.browser.getScreenResolution(), yield this.utms.handle(r.utms), yield this.googleAds.handle(r.googleAds), yield this.saveConfigurationSnapshot(), this.isInitialized = !0, this.queueEventDequeue()
                })
            }
            setMerchantCountryCode(t) {
                return a(this, null, function*() {
                    this.shopperCountryCode = w(t).toBeDefined("The shopperCountryCode is required to setup Analytics SDK."), yield this.saveConfigurationSnapshot()
                })
            }
            setDataLayer(t) {
                return a(this, null, function*() {
                    this.dataLayer = t, yield this.saveConfigurationSnapshot()
                })
            }
            sendBrowsingStartEvent() {
                return a(this, arguments, function*() {
                    try {
                        if (!this.isInitialized) {
                            this.queueEventSending(this.sendBrowsingStartEvent.name, arguments);
                            return
                        }
                        let t = Date.now();
                        if (yield this.updateSession(t), this.sessionId === this.lockBrowsingStartOnSessionId) return !1;
                        this.lockBrowsingStartOnSessionId = this.sessionId, yield this.saveConfigurationSnapshot();
                        let e = new Xr(t, this.clientId, this.sessionId, this.merchantId, this.shopperCountryCode, "Browsing Funnel", this.cdn, this.browser.getPageUrl(), this.browser.getPageTitle(), this.screenResolution, this.userAgent, this.browser.getReferrer(), this.utms.utmSource, this.utms.utmMedium, this.utms.utmCampaign, this.utms.utmTerm, this.utms.utmContent);
                        return yield this.eventSender.send(e), !0
                    } catch (t) {
                        this.logger.writeErrorLog({
                            method: "AnalyticsSDK::sendBrowsingStartEvent()",
                            message: t.message,
                            errorMessage: t.message
                        })
                    }
                })
            }
            sendPageViewEvent() {
                return a(this, arguments, function*() {
                    try {
                        if (!this.isInitialized) {
                            this.queueEventSending(this.sendPageViewEvent.name, arguments);
                            return
                        }
                        let t = Date.now();
                        yield this.updateSession(t);
                        let e = new Wr(t, this.clientId, this.sessionId, this.merchantId, this.shopperCountryCode, "Browsing Funnel", this.cdn, this.browser.getPageUrl(), this.browser.getPageTitle(), this.screenResolution, this.userAgent, this.browser.getReferrer(), this.utms.utmSource, this.utms.utmMedium, this.utms.utmCampaign, this.utms.utmTerm, this.utms.utmContent);
                        yield this.eventSender.send(e)
                    } catch (t) {
                        this.logger.writeErrorLog({
                            method: "AnalyticsSDK::sendPageViewEvent()",
                            message: t.message,
                            errorMessage: t.message
                        })
                    }
                })
            }
            sendBrowsingFunnelEvent(r, n) {
                return a(this, arguments, function*(t, e) {
                    try {
                        if (!this.isInitialized) {
                            this.queueEventSending(this.sendBrowsingFunnelEvent.name, arguments);
                            return
                        }
                        let o = Date.now();
                        yield this.updateSession(o);
                        let s = new dn(t, o, this.clientId, this.sessionId, this.merchantId, this.shopperCountryCode, "Browsing Funnel", this.cdn, this.browser.getPageUrl(), this.browser.getPageTitle(), this.screenResolution, this.userAgent, this.browser.getReferrer(), this.utms.utmSource, this.utms.utmMedium, this.utms.utmCampaign, this.utms.utmTerm, this.utms.utmContent, e);
                        yield this.eventSender.send(s)
                    } catch (o) {
                        this.logger.writeErrorLog({
                            method: "AnalyticsSDK::sendBrowsingFunnelEvent()",
                            message: o.message,
                            errorMessage: o.message
                        })
                    }
                })
            }
            sendCheckoutStartEvent(e) {
                return a(this, arguments, function*(t) {
                    try {
                        if (!this.isInitialized) {
                            this.queueEventSending(this.sendCheckoutStartEvent.name, arguments);
                            return
                        }
                        let r = Date.now();
                        if (yield this.updateSession(r), this.sessionId === this.lockCheckoutStartOnSessionId) return !1;
                        this.lockCheckoutStartOnSessionId = this.sessionId, yield this.saveConfigurationSnapshot();
                        let n = new un(r, this.clientId, this.sessionId, this.merchantId, this.shopperCountryCode, "Checkout Funnel", this.cdn, t, this.userAgent, this.utms.utmSource, this.utms.utmMedium, this.utms.utmCampaign, this.utms.utmTerm, this.utms.utmContent);
                        yield this.eventSender.send(n)
                    } catch (r) {
                        this.logger.writeErrorLog({
                            method: "AnalyticsSDK::sendCheckoutStartEvent()",
                            message: r.message,
                            errorMessage: r.message
                        })
                    }
                })
            }
            sendCheckoutFunnelEvent(n, o, s) {
                return a(this, arguments, function*(t, e, r) {
                    try {
                        if (!this.isInitialized) {
                            this.queueEventSending(this.sendCheckoutFunnelEvent.name, arguments), this.logger.writeDebugLog("Exit sendCheckoutFunnelEvent without sending CheckoutFunnelEvent");
                            return
                        }
                        let i = Date.now();
                        yield this.updateSession(i);
                        let c = new ln(e, i, this.clientId, this.sessionId, this.merchantId, this.shopperCountryCode, "Checkout Funnel", this.cdn, t, this.userAgent, this.utms.utmSource, this.utms.utmMedium, this.utms.utmCampaign, this.utms.utmTerm, this.utms.utmContent, S(S({}, this.dataLayer), r));
                        this.logger.writeDebugLog("Sending CheckoutFunnelEvent"), yield this.eventSender.send(c)
                    } catch (i) {
                        this.logger.writeErrorLog({
                            method: "AnalyticsSDK::sendCheckoutFunnelEvent()",
                            message: i.message,
                            errorMessage: i.message
                        })
                    }
                })
            }
        };

    function Yt(t, e) {
        return a(this, null, function*() {
            try {
                let n = new URLSearchParams(t.context.document.location.search).get(_t);
                n === "true" && (yield e.sessionStorage.setItem(qe, n))
            } catch (r) {
                console.error("Error in borderfree consent:", r)
            }
        })
    }

    function V(t, e) {
        return a(this, null, function*() {
            try {
                return (yield t.sessionStorage.getItem(qe)) || (e == null ? void 0 : e.analyticsProcessingAllowed) && (e == null ? void 0 : e.marketingAllowed) && (e == null ? void 0 : e.saleOfDataAllowed)
            } catch (r) {
                return console.error(r, {
                    data: "Error checking consent status"
                }), !1
            }
        })
    }
    var H = (t, e, r, n, o = null, s = null) => a(null, null, function*() {
            var u, g, p, _, y, d;
            let i, c = (u = n.data) != null ? u : n.customData,
                l = (d = (p = (g = c == null ? void 0 : c.checkout) == null ? void 0 : g.shippingAddress) == null ? void 0 : p.countryCode) != null ? d : (y = (_ = c == null ? void 0 : c.checkout) == null ? void 0 : _.billingAddress) == null ? void 0 : y.countryCode;
            try {
                i = new Ht;
                let f = S(S({
                    cdn: e,
                    clientId: s,
                    browser: {
                        localStorage: r.localStorage,
                        sessionStorage: r.sessionStorage,
                        cookieStorage: {
                            getItem: I => r.cookie.get(I),
                            setItem: (I, N) => r.cookie.set(I, N),
                            removeItem: I => Promise.resolve()
                        }
                    },
                    eventSendingStrategy: 1
                }, o && {
                    utms: o
                }), o && {
                    googleAds: o
                });
                return yield i.init(t, l != null ? l : "UA", f), i
            } catch (f) {
                E(f, {
                    data: "web-pixel INIT Error checking Sentry setting:"
                })
            }
        }),
        qt = (t, e, r, n, o) => a(null, null, function*() {
            try {
                let s;
                if (x(o == null ? void 0 : o.FT_IsAnalyticsSDKEnabled)) s = yield H(n, r, t, e, e.context.document.location.search);
                else {
                    let i = yield Ce(t, "GLBE_SESS_ID", n, !0);
                    s = yield H(n, r, t, e, e.context.document.location.search, i)
                }
                return yield De(t, e), yield Yt(e, t), s
            } catch (s) {
                E(s, {
                    data: "web-pixel Error handle Analytics data"
                })
            }
        });
    var ke = class extends z {
        constructor(e, r, n, o, s) {
            super(e), this.urlPath = r, this.language = n, this.screenResolution = o, this.userAgent = s
        }
    };
    var Jt = (t, e, r, n, o, s, i, c, l, u, g, p, _, y) => a(null, null, function*() {
        let d = t.customData.checkout.isMerchantOperatedByGE;
        if (yield le(e, n, d), (yield xe(e)) && d) {
            let f = "",
                I = "",
                k = yield se(e, t, u, l, T => {
                    P("countryCode", T), I = T
                }, T => {
                    P("checkoutId", T), f = T
                }), R = yield ae(e, r), m = ce(R);
            yield ue(m, e, f), o.forEach(T => a(null, null, function*() {
                var C, O, L, q, de, B;
                let h = yield ie(s, i, T, c, l, I, f, u, k, g, p, R, _, y);
                g(h.initData), p(h.instance);
                let A = new ke("Browsing start", (O = (C = t.context.window) == null ? void 0 : C.location) == null ? void 0 : O.href, (L = t.context.navigator) == null ? void 0 : L.language, `${(q=t.context.window.screen)==null?void 0:q.width}x${(de=t.context.window.screen)==null?void 0:de.height}`, (B = t.context.navigator) == null ? void 0 : B.userAgent);
                yield h.instance.sendBrowsingEvent(T, A, m)
            }))
        }
    });
    var Sn = "started",
        $t = (t, e, r, n, o, s, i, c, l, u, g, p, _, y) => a(null, null, function*() {
            let d = t.customData.checkout.isMerchantOperatedByGE;
            if (yield le(e, n, d), (yield xe(e)) && d) {
                let f = "",
                    I = "",
                    k = yield se(e, t, u, l, h => {
                        P("countryCode", h), I = h
                    }, h => {
                        P("checkoutId", h), f = h
                    }), R = yield ae(e, r), m = yield Se(e, f), T = ce(R);
                yield ue(T, e, f), o.forEach(h => a(null, null, function*() {
                    let A = yield ie(s, i, h, c, l, I, f, u, k, g, p, R, _, y, m);
                    A.initData && (yield xt(e)), g(A.initData), p(A.instance);
                    let C = new ne("checkout_started", Re, Sn, "checkout_started");
                    yield A.instance.sendEvent(h, C, T)
                }))
            }
        });
    var yn = "completed",
        X = (t, e, r, n, o, s, i, c, l, u, g, p, _, y, d, f) => a(null, null, function*() {
            if (yield bt(n, s)) {
                let N = "",
                    D = "",
                    m = yield se(n, t, p, g, C => {
                        P("countryCode", C), D = C
                    }, C => {
                        P("checkoutId", C), N = C
                    }), T = yield ae(n, o), h = yield Se(n, N), A = ce(T);
                yield ue(A, n, N), i.forEach(C => a(null, null, function*() {
                    var q;
                    let O = yield ie(c, l, C, u, g, D, N, p, m, _, y, T, d, f, h);
                    _(O.initData), y(O.instance);
                    let L = new ne(e, Re, yn, r, (q = t.customData) == null ? void 0 : q.payload);
                    yield O.instance.sendEvent(C, L, A)
                }))
            }
        });

    function zt(t, e) {
        return a(this, null, function*() {
            try {
                if (yield e.sessionStorage.getItem(he)) return;
                let {
                    flid: n,
                    fp: o
                } = yield _n(t, e);
                (n || o) && En(n, o, e)
            } catch (r) {
                console.error("Error in Facebook tracking:", r)
            }
        })
    }

    function _n(t, e) {
        return a(this, null, function*() {
            let r = new URLSearchParams(t.context.document.location.search),
                n = r.get(fe.FLID.urlParam),
                o = r.get(fe.FP.urlParam);
            if (!n) {
                let s = yield e.cookie.get(fe.FLID.cookieName);
                s && (n = s)
            }
            if (!o) {
                let s = yield e.cookie.get(fe.FP.cookieName);
                s && (o = s)
            }
            return {
                flid: n,
                fp: o
            }
        })
    }

    function En(t, e, r) {
        let n = {};
        t && (n.GEflid = t), e && (n.GEfp = e), Object.keys(n).length > 0 && r.sessionStorage.setItem(he, JSON.stringify(n))
    }
    var Wt = {
        SAVE_FORTER_TOKEN_PATH: "/Shopify/save-forter-token"
    };
    var In = "https://cdn3.forter.com/events",
        Tn = "https://d219vqw0x87vje.cloudfront.net/ZXZlbnRz";

    function Xt(t, e, r, n) {
        return a(this, null, function*() {
            let o = {
                    user: [
                        [t]
                    ],
                    bcn: wt(),
                    si: e
                },
                s = {
                    body: JSON.stringify(o),
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    }
                },
                i = {
                    forterToken: r,
                    paymentAttemptId: t.text
                },
                c = new U(n),
                l = Wt.SAVE_FORTER_TOKEN_PATH,
                u = c.post(l, i).then(p => p).catch(p => {
                    P("GESaveForterToken", l), E(p, {
                        data: "Analytic Error C1 SaveForterToken"
                    })
                }),
                [g] = yield Promise.all([self.fetch(In, s).then(() => !0).catch(p => (E(p), !1)), u]);
            g || (yield self.fetch(Tn, s))
        })
    }
    var Qt = (t, e, r, n, o, s, i, c, l, u, g) => a(null, null, function*() {
        var _;
        let p = self.debug ? "TEST ATTEMPT ID" : (_ = t == null ? void 0 : t.customData) == null ? void 0 : _.PaymentAttemptId.toString();
        p || E("Attempt ID not found");
        try {
            let y = Date.now();
            yield Xt({
                action: "merchantSessionIdFound",
                url: i,
                refer: s,
                start: r,
                text: p,
                userAgent: o,
                end: y,
                duration: y - r,
                id: 1,
                user: e,
                site: n
            }, n, c, l), u(null)
        } catch (y) {
            E(y), g(y)
        }
    });
    var Zt = (t, e) => {
        try {
            let r = t.context.document.location.search;
            r.includes("utm_") && e.sessionStorage.setItem(ht, r)
        } catch (r) {}
    };

    function er(t, e, r) {
        return a(this, null, function*() {
            if (!t || !e || !r) return;
            let n = new U(t);
            try {
                let o = `/Shopify/analytics/saveClientIds/${e}`;
                return yield n.post(o, r)
            } catch (o) {
                E(o, {
                    data: "Error saving client IDs:"
                })
            }
        })
    }

    function _e(t, e, r, n) {
        return a(this, null, function*() {
            try {
                let o = yield r.localStorage.getItem(oe);
                if (o || (o = yield r.sessionStorage.getItem(oe)), o) {
                    let s = JSON.parse(o);
                    if (s.utmSource === St || s.utmSource === yt) {
                        let i = n.data;
                        i != null || (i = n.customData);
                        let c = {
                            checkoutId: i.checkout.token,
                            sdkClientId: null,
                            sdkSessionId: null,
                            utmSource: s.utmSource,
                            utmMedium: s.utmMedium,
                            utmCampaign: s.utmCampaign
                        };
                        er(t, e, c)
                    }
                }
            } catch (o) {
                E(o, {
                    data: "web-pixel Error processing UTM parameters:"
                })
            }
        })
    }

    function wn(t) {
        return a(this, null, function*() {
            let e = yield t.cookie.get("forterToken");
            e || (e = [At(), Date.now(), "", "", "", ""].join("_"), yield t.cookie.set("forterToken", e));
            let r = "",
                n = e.split("_");
            return n && (r = n[0]), {
                forterToken: e,
                userId: r
            }
        })
    }

    function An(t, e, r, n, o, s) {
        return a(this, null, function*() {
            let i = yield wn(e), c = n.navigator.userAgent, l = n.window.location.href, u = n.document.referrer, g = i.forterToken, p = i.userId;
            yield new Promise((_, y) => {
                r.subscribe(self.debug ? "page_viewed" : "ge_payment_loaded", d => a(null, null, function*() {
                    return yield Qt(d, p, t, o, c, u, l, g, s, _, y)
                }))
            })
        })
    }
    var Re = "checkout",
        Cn = i => a(null, [i], function*({
            analytics: t,
            browser: e,
            settings: r,
            init: n,
            _pixelInfo: o,
            customerPrivacy: s
        }) {
            let c = n.customerPrivacy;
            s.subscribe("visitorConsentCollected", D => {
                c = D.customerPrivacy
            }), t.subscribe("page_viewed", D => a(null, null, function*() {
                yield qt(e, D, p, u, r), Zt(D, e);
                let k = yield V(e, c);
                x(r == null ? void 0 : r.BorderfreeMetaCAPIEnabled) && k && zt(D, e)
            }));
            let l = "checkout-one",
                u = r == null ? void 0 : r.merchantId,
                g = r == null ? void 0 : r.baseApiUrl,
                p = r == null ? void 0 : r.CDNUrl,
                _ = "GLBE_SESS_ID",
                y = "",
                d = [1],
                f = new re,
                I = new te(f, d);
            if ((o ? o.surface : l) === l) {
                let D = r == null ? void 0 : r.siteId;
                D === void 0 || D.length != 12, An(Date.now(), e, t, n.context, D, g).then().catch(m => {}), y = yield Ce(e, _, u);
                let k = m => {
                        f = m
                    },
                    R = m => {
                        I = m
                    };
                t.subscribe("globale_checkout_started", m => a(null, null, function*() {
                    if (!(yield V(e, c))) {
                        _e(g, u, e, m);
                        return
                    }
                    let h = yield H(u, p, e, m);
                    yield kt(e, m);
                    let C = (yield Dt(e)).bfDirectToCheckout === "yes";
                    x(r == null ? void 0 : r.FT_IsAnalyticsSDKEnabled) && (C && (yield h.sendBrowsingStartEvent()), yield h.sendCheckoutStartEvent(m.customData.checkout.token)), x(r == null ? void 0 : r.FT_IsLegacyAnalyticsSDKEnabled) && (C && (yield Jt(m, e, r, j, d, f, I, g, u, y, k, R, h.ClientId, h.SessionId)), yield $t(m, e, r, j, d, f, I, g, u, y, k, R, h.ClientId, h.SessionId))
                })), t.subscribe("checkout_address_info_submitted", m => a(null, null, function*() {
                    if (!(yield V(e, c))) {
                        _e(g, u, e, m);
                        return
                    }
                    let h = yield H(u, p, e, m);
                    x(r == null ? void 0 : r.FT_IsAnalyticsSDKEnabled) && (yield h.sendCheckoutFunnelEvent(m.data.checkout.token, "checkout_address_info_submitted")), x(r == null ? void 0 : r.FT_IsLegacyAnalyticsSDKEnabled) && (yield X(m, "checkout_address_info_submitted", "checkout_address_info_submitted", e, r, j, d, f, I, g, u, y, k, R, h.ClientId, h.SessionId))
                })), t.subscribe("checkout_shipping_info_submitted", m => a(null, null, function*() {
                    if (!(yield V(e, c))) {
                        _e(g, u, e, m);
                        return
                    }
                    let h = yield H(u, p, e, m);
                    x(r == null ? void 0 : r.FT_IsAnalyticsSDKEnabled) && (yield h.sendCheckoutFunnelEvent(m.data.checkout.token, "checkout_shipping_info_submitted")), x(r == null ? void 0 : r.FT_IsLegacyAnalyticsSDKEnabled) && (yield X(m, "checkout_shipping_info_submitted", "checkout_shipping_info_submitted", e, r, j, d, f, I, g, u, y, k, R, h.ClientId, h.SessionId))
                })), t.subscribe("payment_info_submitted", m => a(null, null, function*() {
                    if (!(yield V(e, c))) {
                        _e(g, u, e, m);
                        return
                    }
                    let h = yield H(u, p, e, m);
                    x(r == null ? void 0 : r.FT_IsAnalyticsSDKEnabled) && (yield h.sendCheckoutFunnelEvent(m.data.checkout.token, "payment_info_submitted")), x(r == null ? void 0 : r.FT_IsLegacyAnalyticsSDKEnabled) && (yield X(m, "payment_info_submitted", "payment_info_submitted", e, r, j, d, f, I, g, u, y, k, R, h.ClientId, h.SessionId))
                })), t.subscribe("checkout_completed", m => a(null, null, function*() {
                    if (!(yield V(e, c))) return;
                    let h = yield H(u, p, e, m);
                    x(r == null ? void 0 : r.FT_IsAnalyticsSDKEnabled) && (yield h.sendCheckoutFunnelEvent(m.data.checkout.token, "checkout_completed")), x(r == null ? void 0 : r.FT_IsLegacyAnalyticsSDKEnabled) && (yield X(m, "checkout_completed", "checkout_completed", e, r, j, d, f, I, g, u, y, k, R, h.ClientId, h.SessionId))
                })), t.subscribe("shipping_options_available", m => a(null, null, function*() {
                    if (!(yield V(e, c))) return;
                    let h = yield H(u, p, e, m), A = yield e.sessionStorage.getItem(Je), C = JSON.stringify(m.customData.payload);
                    (!A || A !== C) && (x(r == null ? void 0 : r.FT_IsAnalyticsSDKEnabled) && (yield h.sendCheckoutFunnelEvent(m.customData.checkout.token, "Shipping Options Available")), x(r == null ? void 0 : r.FT_IsLegacyAnalyticsSDKEnabled) && (yield X(m, "Shipping Options Available", "Shipping Options Available", e, r, j, d, f, I, g, u, y, k, R, h.ClientId, h.SessionId)), e.sessionStorage.setItem(Je, C))
                })), t.subscribe("vwo_variation_assigned", m => a(null, null, function*() {
                    let {
                        campaignKey: T,
                        variation: h
                    } = m.customData.data || {};
                    if (!T || !h || !(yield V(e, c)) || (yield e.sessionStorage.getItem("VWO_VARIATION"))) return;
                    let O = {
                        campaignKey: T,
                        variation: h
                    };
                    yield e.sessionStorage.setItem("VWO_VARIATION", JSON.stringify(O));
                    let L = yield H(u, p, e, m);
                    x(r == null ? void 0 : r.FT_IsAnalyticsSDKEnabled) && O && (yield L.sendCheckoutFunnelEvent(m.customData.checkout.token, "VWO Variation Assigned", {
                        "VWO Campaign Name": O.campaignKey,
                        "VWO Variation Name": O.variation
                    })), x(r == null ? void 0 : r.FT_IsLegacyAnalyticsSDKEnabled) && (yield X(m, "vwo_variation_assigned", "vwo_variation_assigned", e, r, j, d, f, I, g, u, y, k, R, L.ClientId, L.SessionId))
                })), t.subscribe("is_merchant_operated_by_ge_changed", m => a(null, null, function*() {
                    if (!(yield V(e, c))) return;
                    let h = m.customData.isMerchantOperatedByGE;
                    yield le(e, j, h)
                }))
            }
        });
    Me(Cn);
})();