(() => {
    var $e = Object.create;
    var H = Object.defineProperty;
    var Be = Object.getOwnPropertyDescriptor;
    var Je = Object.getOwnPropertyNames,
        ne = Object.getOwnPropertySymbols,
        He = Object.getPrototypeOf,
        se = Object.prototype.hasOwnProperty,
        qe = Object.prototype.propertyIsEnumerable;
    var ie = (t, e, r) => e in t ? H(t, e, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: r
        }) : t[e] = r,
        ae = (t, e) => {
            for (var r in e || (e = {})) se.call(e, r) && ie(t, r, e[r]);
            if (ne)
                for (var r of ne(e)) qe.call(e, r) && ie(t, r, e[r]);
            return t
        };
    var l = (t, e) => () => (t && (e = t(t = 0)), e);
    var je = (t, e) => () => (e || t((e = {
        exports: {}
    }).exports, e), e.exports);
    var We = (t, e, r, o) => {
        if (e && typeof e == "object" || typeof e == "function")
            for (let n of Je(e)) !se.call(t, n) && n !== r && H(t, n, {
                get: () => e[n],
                enumerable: !(o = Be(e, n)) || o.enumerable
            });
        return t
    };
    var Ke = (t, e, r) => (r = t != null ? $e(He(t)) : {}, We(e || !t || !t.__esModule ? H(r, "default", {
        value: t,
        enumerable: !0
    }) : r, t));
    var s = (t, e, r) => new Promise((o, n) => {
        var a = u => {
                try {
                    c(r.next(u))
                } catch (p) {
                    n(p)
                }
            },
            i = u => {
                try {
                    c(r.throw(u))
                } catch (p) {
                    n(p)
                }
            },
            c = u => u.done ? o(u.value) : Promise.resolve(u.value).then(a, i);
        c((r = r.apply(t, e)).next())
    });
    var ce, ue = l(() => {
        ce = "WebPixel::Render"
    });
    var q, le = l(() => {
        ue();
        q = t => shopify.extend(ce, t)
    });
    var pe = l(() => {
        le()
    });
    var ge = l(() => {
        pe()
    });
    var g, v = l(() => {
        "use strict";
        g = class {
            constructor(e) {
                this.browser = e
            }
            refreshCookies(n, a) {
                return s(this, arguments, function*(e, r, o = new Date) {
                    let c = (yield this.browser.cookie.get()).split("; ");
                    for (let u of c) {
                        let p = u.split("=")[0];
                        r.some(m => p.startsWith(m)) && (yield this.refreshCookie(p, e, o))
                    }
                })
            }
            getAllAwcCookieValues(e) {
                return s(this, null, function*() {
                    let r = yield this.browser.cookie.get();
                    if (!r) return "";
                    let o = r.split("; "),
                        n = [];
                    return e.forEach(a => {
                        n = n.concat(o.filter(i => i.startsWith(a)))
                    }), n.map(a => a.split("=")[1]).join(",")
                })
            }
            getCookieValue(e) {
                return s(this, null, function*() {
                    return yield this.browser.cookie.get(e)
                })
            }
            setCookie(a, i, c) {
                return s(this, arguments, function*(e, r, o, n = new Date) {
                    if (!e || !o || !r || !n) return;
                    let u = new Date;
                    u.setTime(n.getTime() + 365 * 24 * 60 * 60 * 1e3);
                    let p = r + `;expires=${u.toUTCString()};path=/;domain=${o}`;
                    yield this.browser.cookie.set(e, p)
                })
            }
            setCookieWithCustomExpiration(e, r, o, n) {
                return s(this, null, function*() {
                    if (!e || !o || !n || !r) throw new Error("Invalid cookie parameters");
                    let a = r + `;expires=${n.toUTCString()};path=/;domain=${o}`;
                    yield this.browser.cookie.set(e, a)
                })
            }
            refreshCookie(n, a) {
                return s(this, arguments, function*(e, r, o = new Date) {
                    let i = yield this.getCookieValue(e);
                    i && (yield this.setCookie(e, i, r, o))
                })
            }
        }
    });
    var de = l(() => {
        "use strict"
    });
    var U, me, b, fe = l(() => {
        "use strict";
        v();
        de();
        U = "_aw_ca", me = "returning=1", b = class t {
            static setCookie(e, r) {
                return s(this, null, function*() {
                    let o = new Date;
                    yield new g(e).setCookie(U, me, r, o)
                })
            }
            static isCookieSet(e) {
                return s(this, null, function*() {
                    return (yield new g(e).getCookieValue(U)) === me
                })
            }
            static getCustomerAcquisition(e, r, o) {
                return s(this, null, function*() {
                    var n, a;
                    try {
                        return (o == null ? void 0 : o.isFirstOrder) != null ? o.isFirstOrder ? "NEW" : "RETURNING" : (yield t.isCookieSet(e)) ? "RETURNING" : ((a = (n = r.data) == null ? void 0 : n.customer) == null ? void 0 : a.ordersCount) != null ? r.data.customer.ordersCount === 0 ? "NEW" : r.data.customer.ordersCount > 0 ? "RETURNING" : "" : ""
                    } catch (i) {
                        return ""
                    }
                })
            }
        }
    });
    var xe = l(() => {
        "use strict"
    });
    var j, M, W = l(() => {
        "use strict";
        j = class t {
            constructor() {}
            static calculateAmount(e) {
                let r = 0;
                var o = this.getPreparedItemDetails(e.lineItems);
                for (let n of o) r += n.itemNetPrice * n.quantity;
                return t.roundToFixedCommercially(r).toFixed(2)
            }
            static roundToFixedCommercially(e) {
                return Math.round(e * 100) / 100
            }
            static getPreparedItemDetails(e) {
                if (!e) return [];
                for (var r = [], o = 0; o < e.length; o++) {
                    var n = Number(e[o].variant.price.amount),
                        a = n * e[o].quantity;
                    if (e[o].discountAllocations && e[o].discountAllocations.length > 0) {
                        for (var i = 0, c = 0; c < e[o].discountAllocations.length; c++) i += Number(e[o].discountAllocations[c].amount.amount);
                        a -= i, n -= i / e[o].quantity
                    }
                    r.push({
                        productId: e[o].variant.product.id,
                        title: e[o].variant.product.title,
                        itemNetPrice: t.roundToFixedCommercially(n),
                        lineNetPrice: t.roundToFixedCommercially(a),
                        quantity: e[o].quantity,
                        sku: e[o].variant.sku
                    })
                }
                return r
            }
        }, M = j
    });
    var Ge, K, he, Ce = l(() => {
        "use strict";
        Ge = "DISCOUNT_CODE", K = class {
            constructor() {}
            static getVoucherFromCheckout(e) {
                if (e.discountApplications && e.discountApplications.length > 0) {
                    for (let r of e.discountApplications)
                        if (r.type === Ge && r.title) return r.title
                }
                return ""
            }
        }, he = K
    });

    function ye(t, e) {
        return s(this, null, function*() {
            let r = new g(e.browser),
                o = Pe(t.context.document.location.search, "awc");
            if (o) {
                let a = o.split("_");
                if (a.length === 3) {
                    let i = `${X}${a[0]}`;
                    yield r.setCookie(i, o, t.context.document.location.hostname, e.now)
                }
            } else yield r.refreshCookies(t.context.document.location.hostname, [X, we], e.now);
            let n = Pe(t.context.document.location.search, "source");
            if (n) {
                let a = `${n}|${(e.now.getTime()+31536e6)/1e3|0}`;
                yield r.setCookie(Y, a, t.context.document.location.hostname, e.now)
            } else yield r.refreshCookie(Y, t.context.document.location.hostname, e.now);
            yield r.refreshCookie(U, t.context.document.location.hostname, e.now)
        })
    }

    function Ee(t, e) {
        return s(this, null, function*() {
            var r, o, n, a;
            try {
                let i = (n = (o = (r = t.context) == null ? void 0 : r.document) == null ? void 0 : o.location) == null ? void 0 : n.hostname,
                    c = Ze(t);
                ((a = c.data.checkout.order) == null ? void 0 : a.id) !== void 0 ? yield Qe(c, e): console.warn("checkout-event", "order.id is undefined"), yield b.setCookie(e.browser, i)
            } catch (i) {}
        })
    }

    function Qe(t, e) {
        return s(this, null, function*() {
            let r = e.settings,
                o = yield ze(t, e.browser, r, e.init, e.additionalCheckoutParameters), n = `${Ye}?${new URLSearchParams(o)}`;
            if (yield fetch(n, {
                    method: "POST",
                    keepalive: !0,
                    credentials: "include"
                }), r.originalNetwork === "sas") {
                let i = `${Xe}?${new URLSearchParams(o)}`;
                yield fetch(i, {
                    method: "POST",
                    keepalive: !0,
                    credentials: "include"
                })
            }
            if (typeof G == "string" && G.length > 10) {
                let i = `${G}?${new URLSearchParams(o)}`;
                yield fetch(i, {
                    method: "POST",
                    keepalive: !0,
                    credentials: "include"
                })
            }
        })
    }

    function ze(t, e, r, o, n) {
        return s(this, null, function*() {
            var C, P, w, y, E, k, S;
            let a = new g(e),
                c = ((C = yield a.getCookieValue(Y)) != null ? C : "").split("|")[0],
                u = (yield a.getAllAwcCookieValues([X, we])) || "",
                p = t.data.checkout,
                m = (w = (P = p.order) == null ? void 0 : P.id) != null ? w : "";
            m.match(/[^0-9]/) && (m = m.replace(/[^0-9]/g, ""));
            let h = M.calculateAmount(p),
                _ = (E = (y = p.subtotalPrice) == null ? void 0 : y.currencyCode) != null ? E : "",
                O = he.getVoucherFromCheckout(p),
                N = yield b.getCustomerAcquisition(e, o, (S = (k = p.order) == null ? void 0 : k.customer) != null ? S : void 0), f = {
                    tt: "ns",
                    tv: "2",
                    ch: c,
                    cks: u,
                    merchant: r.advertiserId.toString(),
                    amount: h,
                    parts: `DEFAULT:${h}`,
                    ref: m,
                    vc: O,
                    cr: _,
                    customeracquisition: N,
                    p1: r.appVersion.toString(),
                    p2: m,
                    p3: "px",
                    cons: "1"
                };
            return n && Object.entries(n).forEach(([I, R]) => {
                f[I] = R
            }), typeof r.customTransactionTag != "undefined" && r.customTransactionTag !== null && (f.p6 = r.customTransactionTag.toString()), f
        })
    }

    function ke(t) {
        return !(!t || !t.advertiserId || !t.appVersion || !t.shopDomain)
    }

    function Ze(t) {
        if (t.context && delete t.context, t.data && t.data.checkout) {
            let e = t.data.checkout;
            e.billingAddress = null, e.phone = null, e.email = null, e.shippingAddress = null
        }
        return t
    }

    function Pe(t, e) {
        return new URLSearchParams(t).get(e) || void 0
    }
    var Y, X, we, Ye, Xe, G, Se = l(() => {
        "use strict";
        fe();
        xe();
        W();
        v();
        Ce();
        Y = "_aw_channel", X = "_awc_", we = "_aw_m_", Ye = "https://www.awin1.com/sread.img", Xe = "https://www.shareasale.com/sread.php", G = "https://www.awinblackfriday.com/sread.php"
    });
    var V, d, L = l(() => {
        "use strict";
        V = class V {
            static sendErrorLog(e, r, o, n) {
                return this.sendLog({
                    severity: "error",
                    source: {
                        app: "shopify-pixel-extension",
                        category: e
                    },
                    body: ae({
                        message: r,
                        error: o.message
                    }, n)
                })
            }
            static sendLog(e) {
                return s(this, null, function*() {
                    yield fetch(V.DEBUG_ENDPOINT, {
                        method: "POST",
                        keepalive: !0,
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(e)
                    })
                })
            }
        };
        V.DEBUG_ENDPOINT = "https://www.wepowerconnections.com/dbg";
        d = V
    });

    function rt(t) {
        let e = t.split("-"),
            r = e.length - 1;
        return e[r] = (parseInt(e[r]) + 1).toString(), e.join("-")
    }

    function ot(t, e) {
        return s(this, null, function*() {
            try {
                let r = yield e.getCookieValue(t);
                return r ? JSON.parse(r) : void 0
            } catch (r) {
                throw new Error(`[JourneyPath] Error parsing journey cookie:${r}`)
            }
        })
    }
    var et, F, tt, ve = l(() => {
        "use strict";
        v();
        L();
        et = "_aw_j_", F = {
            name: "JourneyPath",
            priority: 100,
            checkoutCompleted: (t, e) => s(null, null, function*() {
                return tt(t, e)
            })
        }, tt = (t, e) => s(null, null, function*() {
            let r = t.settings,
                o = `${et}${r.advertiserId}`;
            try {
                let n = new g(t.browser),
                    a = e.context.document.location.hostname,
                    i = yield ot(o, n);
                if (!i) return t;
                let c = i.id;
                if (t.additionalCheckoutParameters.j = c, c) {
                    let u = JSON.parse(JSON.stringify(i));
                    c = rt(c), u.id = c, yield n.setCookieWithCustomExpiration(o, JSON.stringify(u), a, new Date(i.expiration * 1e3))
                }
            } catch (n) {
                d.sendErrorLog("JourneyPath plugin", "checkoutHandler failed", n, {
                    cookieName: o
                })
            }
            return t
        })
    });
    var be = l(() => {
        "use strict";
        ve()
    });
    var Q, Ae, Te = l(() => {
        "use strict";
        Q = "lantern", Ae = "https://lantern.roeye.com/track.php"
    });

    function A() {
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, t => {
            let e = Math.random() * 16 | 0;
            return (t === "x" ? e : e & 3 | 8).toString(16)
        })
    }

    function z(t) {
        let r = /Order\/(\d+)/.exec(t);
        return r ? r[1] : t
    }
    var Z = l(() => {
        "use strict"
    });

    function _e(t, e) {
        return s(this, null, function*() {
            let r = A();
            try {
                let o = new g(t),
                    n = new Date;
                return n.setTime(n.getTime() + 720 * 60 * 60 * 1e3), yield o.setCookieWithCustomExpiration(Q, r, e, n), r
            } catch (o) {
                return
            }
        })
    }

    function it(t, e) {
        return s(this, null, function*() {
            var o, n, a;
            let r = (a = (n = (o = e.context) == null ? void 0 : o.document) == null ? void 0 : n.location) == null ? void 0 : a.hostname;
            try {
                let c = yield new g(t.browser).getCookieValue(Q);
                if (!c) {
                    let u = yield _e(t.browser, r);
                    return u || (d.sendErrorLog("RoEyeSingleView", "Failed to save fingerprint cookie", new Error("Cookie creation failed"), {}), A())
                }
                return c
            } catch (i) {
                d.sendErrorLog("RoEyeSingleView", "Error getting/creating fingerprint", i, {});
                let c = yield _e(t.browser, r);
                return c || A()
            }
        })
    }

    function st(a) {
        return s(this, arguments, function*({
            fingerprint: t,
            referrerFull: e,
            currentUrl: r,
            userAgent: o,
            data: n
        }) {
            try {
                let i = new URLSearchParams;
                i.append("fingerprint", t), i.append("referrer", e), i.append("landingpage", r), i.append("useragent", o);
                for (let u in n) i.append(u, String(n[u]));
                let c = `${Ae}?${i.toString()}`;
                return yield fetch(c, {
                    method: "GET",
                    keepalive: !0,
                    mode: "no-cors"
                }), !0
            } catch (i) {
                return d.sendErrorLog("RoEyeSingleView", "Error sending tracking", i, {
                    fingerprint: t
                }), !1
            }
        })
    }
    var $, nt, Oe = l(() => {
        "use strict";
        L();
        W();
        v();
        Te();
        Z();
        $ = {
            name: "RoEyeSingleView",
            priority: 100,
            checkoutCompleted: (t, e) => s(null, null, function*() {
                return nt(t, e)
            })
        }, nt = (t, e) => s(null, null, function*() {
            var r, o, n, a, i, c, u, p, m, h, _, O, N, f, C, P, w, y, E, k, S, I, R, ee, te, re;
            try {
                let D = t.settings;
                if (!D.advertiserId) return d.sendErrorLog("RoEyeSingleView", "No advertiser ID available, tracking aborted", new Error("Advertiser ID missing"), {
                    event: "checkout_completed"
                }), t;
                let oe = D.advertiserId,
                    Ue = (n = (o = (r = e.data) == null ? void 0 : r.checkout) == null ? void 0 : o.order) != null && n.id ? z(e.data.checkout.order.id) : "!missing",
                    Me = parseFloat(M.calculateAmount((a = e.data) == null ? void 0 : a.checkout)),
                    Ve = (p = (u = (c = (i = e.data) == null ? void 0 : i.checkout) == null ? void 0 : c.totalPrice) == null ? void 0 : u.currencyCode) != null ? p : "USD",
                    Le = {
                        site: oe,
                        order_id: Ue,
                        order_value: Me,
                        order_currency: Ve,
                        lantern_type: "conversion",
                        action_tracker_id: oe
                    },
                    J = {
                        referrerFull: (_ = (h = (m = e.context) == null ? void 0 : m.document) == null ? void 0 : h.referrer) != null ? _ : "",
                        referrerHost: (C = (f = (N = (O = e.context) == null ? void 0 : O.document) == null ? void 0 : N.referrer) == null ? void 0 : f.split("/")[2]) != null ? C : "",
                        currentUrl: (E = (y = (w = (P = e.context) == null ? void 0 : P.document) == null ? void 0 : w.location) == null ? void 0 : y.href) != null ? E : "",
                        currentHost: (R = (I = (S = (k = e.context) == null ? void 0 : k.document) == null ? void 0 : S.location) == null ? void 0 : I.hostname) != null ? R : "",
                        userAgent: (re = (te = (ee = e.context) == null ? void 0 : ee.navigator) == null ? void 0 : te.userAgent) != null ? re : ""
                    },
                    Fe = yield it(t, e);
                return yield st({
                    fingerprint: Fe,
                    referrerFull: J.referrerFull,
                    currentUrl: J.currentUrl,
                    userAgent: J.userAgent,
                    data: Le
                }), t
            } catch (D) {
                return d.sendErrorLog("RoEyeSingleView", "Error in checkoutHandler", D, {
                    event: "checkout_completed"
                }), t
            }
        })
    });
    var Ne = l(() => {
        "use strict";
        Oe();
        Z()
    });
    var T, Ie = l(() => {
        "use strict";
        L();
        T = class t {
            constructor() {
                this.plugins = []
            }
            static getInstance() {
                return t.instance || (t.instance = new t), t.instance
            }
            registerPlugin(e) {
                this.plugins.push(e)
            }
            createContext(e) {
                return {
                    browser: e.browser,
                    settings: e.settings,
                    init: e.init,
                    additionalCheckoutParameters: {},
                    now: new Date
                }
            }
            executePluginHandler(e, r, o, n) {
                return s(this, null, function*() {
                    try {
                        if (r) return yield r(o, n)
                    } catch (a) {
                        d.sendErrorLog("PluginManager", "Error executing plugin", a, {
                            plugin: e.name
                        })
                    }
                    return o
                })
            }
            executePageViewPlugins(e, r) {
                return s(this, null, function*() {
                    let o = e;
                    for (let n of this.plugins) o = yield this.executePluginHandler(n, n.pageView, o, r);
                    return o
                })
            }
            executeCheckoutPlugins(e, r) {
                return s(this, null, function*() {
                    let o = e;
                    for (let n of this.plugins) o = yield this.executePluginHandler(n, n.checkoutCompleted, o, r);
                    return o
                })
            }
        }
    });
    var Re = l(() => {
        "use strict";
        be();
        Ne();
        Ie()
    });
    var De = je(B => {
        "use strict";
        ge();
        Se();
        Re();
        var x = T.getInstance();
        q(t => s(null, null, function*() {
            ke(t.settings) && (x.registerPlugin(F), x.registerPlugin($), t.analytics.subscribe("page_viewed", e => s(null, null, function*() {
                let r = x.createContext(t),
                    o = yield x.executePageViewPlugins(r, e);
                yield ye(e, o)
            })), t.analytics.subscribe("checkout_completed", e => s(null, null, function*() {
                let r = x.createContext(t),
                    o = yield x.executeCheckoutPlugins(r, e);
                yield Ee(e, o)
            })))
        }))
    });
    var gr = Ke(De());
})();