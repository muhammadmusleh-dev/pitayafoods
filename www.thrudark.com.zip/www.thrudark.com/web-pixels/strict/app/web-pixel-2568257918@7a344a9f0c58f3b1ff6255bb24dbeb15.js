(() => {
    var c = "WebPixel::Render";
    var r = e => shopify.extend(c, e);
    var p = new Set(["alert_displayed", "cart_viewed", "checkout_address_info_submitted", "checkout_completed", "checkout_contact_info_submitted", "checkout_shipping_info_submitted", "checkout_started", "collection_viewed", "page_viewed", "payment_info_submitted", "product_added_to_cart", "product_removed_from_cart", "product_viewed", "search_submitted", "ui_extension_errored"]);
    r(({
        analytics: e,
        browser: i,
        init: n,
        settings: t
    }) => {
        let d = t.webhookEndpoint,
            s = new Set(t.includedEvents.split(","));
        p.forEach(o => {
            s.has(o) && e.subscribe(o, a => {
                _(o, a, d)
            })
        })
    });

    function _(e, i, n) {
        let t = new Headers;
        t.append("Content-Type", "application/json"), fetch(n, {
            method: "POST",
            keepalive: !0,
            body: JSON.stringify({
                webPixelEventType: e,
                data: i
            }),
            headers: t
        })
    }
})();