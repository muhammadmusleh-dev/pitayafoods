(() => {
    var ft = Object.create;
    var $ = Object.defineProperty;
    var gt = Object.getOwnPropertyDescriptor;
    var vt = Object.getOwnPropertyNames;
    var ht = Object.getPrototypeOf,
        kt = Object.prototype.hasOwnProperty;
    var S = (t, a) => () => (t && (a = t(t = 0)), a);
    var yt = (t, a) => () => (a || t((a = {
        exports: {}
    }).exports, a), a.exports);
    var wt = (t, a, i, c) => {
        if (a && typeof a == "object" || typeof a == "function")
            for (let e of vt(a)) !kt.call(t, e) && e !== i && $(t, e, {
                get: () => a[e],
                enumerable: !(c = gt(a, e)) || c.enumerable
            });
        return t
    };
    var At = (t, a, i) => (i = t != null ? ft(ht(t)) : {}, wt(a || !t || !t.__esModule ? $(i, "default", {
        value: t,
        enumerable: !0
    }) : i, t));
    var p = (t, a, i) => new Promise((c, e) => {
        var d = r => {
                try {
                    n(i.next(r))
                } catch (o) {
                    e(o)
                }
            },
            l = r => {
                try {
                    n(i.throw(r))
                } catch (o) {
                    e(o)
                }
            },
            n = r => r.done ? c(r.value) : Promise.resolve(r.value).then(d, l);
        n((i = i.apply(t, a)).next())
    });
    var J, Q = S(() => {
        J = "WebPixel::Render"
    });
    var F, Y = S(() => {
        Q();
        F = t => shopify.extend(J, t)
    });
    var Z = S(() => {
        Y()
    });
    var K = S(() => {
        Z()
    });

    function Tt(t) {
        if (!t) return "";
        if (t.startsWith("GS1")) {
            var a = t.split(".");
            return a.length > 2 ? a[2] : ""
        } else if (t.startsWith("GS2")) {
            var i = ".s",
                c = t.indexOf(i);
            if (c === -1) return "";
            var e = c + i.length,
                d = t.indexOf("$", e);
            return t.substring(e, d > -1 ? d : t.length)
        }
        return ""
    }
    var tt, xt, E, H, rt, L, P, Ct, Et, b, W, at, z, et, V, O = S(() => {
        "use strict";
        tt = () => Math.random().toString(36).substring(2), xt = () => tt() + tt(), E = (t, a, i) => {
            let c = new Date;
            c.setTime(c.getTime() + 31536e6);
            var e = "expires=" + c.toUTCString();
            i.cookie.set(a + "=" + t + "; " + e + "; path=/")
        }, H = null, rt = t => p(null, null, function*() {
            return H || (H = p(null, null, function*() {
                try {
                    var a = yield t.localStorage.getItem("connect_cid");
                    if (a && a !== "" || (a = yield t.localStorage.getItem("connect_cid"), a && a !== "")) return a;
                    var i = yield t.cookie.get("connect_cid");
                    if (i && i !== "") return yield t.localStorage.setItem("connect_cid", i), i;
                    var c = xt();
                    return E(c, "connect_cid", t), yield t.localStorage.setItem("connect_cid", c), c
                } finally {
                    H = null
                }
            }), H)
        }), L = (t, a) => p(null, null, function*() {
            var i = yield a.cookie.get(t);
            return i
        }), P = () => Math.floor(Date.now() / 1e3), Ct = t => p(null, null, function*() {
            var a = yield L("latestETMSec", t), i = P();
            if (!a || a === "") return E(i, "latestETMSec", t), 1;
            var c = i - a;
            return c === 0 ? 1 : c
        });
        Et = (t, a) => p(null, null, function*() {
            return new Promise(i => p(null, null, function*() {
                var c = yield L("_fbc", a);
                if (!t) {
                    i(c);
                    return
                }
                let e = Date.now();

                function d() {
                    return p(this, null, function*() {
                        var l = yield L("_fbc", a);
                        l && l.endsWith(t) ? i(l) : Date.now() - e < 5e3 ? setTimeout(d, 100) : i(null)
                    })
                }
                yield d()
            }))
        }), b = (t, a, i, c) => p(null, null, function*() {
            var e = yield L("connect_cid", a), d = yield L("_ga", a), l = "";
            d && d.includes(".") && (l = d.split(".").splice(2, 3).join("."));
            var n = "";
            if (i) {
                var r = i.split("-")[1],
                    o = "_ga_" + r,
                    u = yield L(o, a);
                n = Tt(u)
            }
            var h = new URL(t.context.document.location.href).searchParams,
                s = yield L("_fbp", a), m = null;
            s && s !== "" && (m = s);
            var A = yield L("_fbc", a), C = null;
            A && A !== "" && (C = A), h.get("fbclid") && (C = yield Et(h.get("fbclid"), a));
            var k = null,
                I = yield L("ttclid", a);
            I && I !== "" && (k = I), h.get("ttclid") && (k = h.get("ttclid"));
            var v = yield L("_ttp", a), y = null;
            v && v !== "" && (y = v);
            var M = yield Ct(a), g = t.context.document.referrer || t.context.document.location.origin, _ = {
                cid: l,
                ga_session_id: n,
                external_id: e,
                fbp: m,
                fbc: C,
                ttclid: k,
                ttp: y,
                page_referrer: g,
                page_location: t.context.document.location.href,
                page_title: t.context.document.title,
                engagement_time_msec: M,
                user_agent: t.context.navigator.userAgent
            }, T = yield L("__kla_id", a);
            if (T && T !== "") {
                var x = atob(T);
                try {
                    x = JSON.parse(x), x.$exchange_id && (_._kx = x.$exchange_id)
                } catch (D) {
                    console.error("Error parsing Klaviyo ID:", D)
                }
            }
            return _
        }), W = t => {
            t = t.toLowerCase().split(" ");
            for (var a = 0; a < t.length; a++) t[a] = t[a].charAt(0).toUpperCase() + t[a].slice(1);
            return t.join(" ")
        }, at = t => {
            var a = {};
            if (t.length > 1 && t.includes("collections"))
                if (t[0] !== "collections") {
                    var i = t.slice(1);
                    a.item_list_id = i.join("_"), a.item_list_name = W(i.join(" "))
                } else a.item_list_id = t.join("_"), a.item_list_name = W(t.join(" "));
            else a.item_list_id = t.join("_"), a.item_list_name = W(t.join(" "));
            return a
        }, z = (t, a) => {
            var i = t.replace(a, ""),
                c = "",
                e;
            if (i.includes("?")) {
                var d = i.indexOf("?");
                c = i.slice(0, d)
            } else c = i;
            if (e = c.length, c.length > 1 && c.charAt(e - 1) == "/") {
                c = c.slice(1, -1);
                var l = c.split("/");
                return at(l)
            } else {
                if (c.length <= 1) return {
                    item_list_id: "home",
                    item_list_name: "Home"
                };
                c = c.slice(1);
                var n = c.split("/");
                return at(n)
            }
        }, et = (t, a) => {
            var i = [],
                c, e, d = t.context.document.referrer,
                l = t.context.document.location.origin,
                n = z(d, l);
            return c = n.item_list_id, e = n.item_list_name, t.data.checkout.lineItems.forEach(function(r) {
                var o = {
                    item_id: r.variant.sku ? r.variant.sku : r.variant.product.id,
                    item_shopify_id: r.variant.product.id,
                    item_shopify_variant: r.variant.id,
                    item_name: r.title,
                    item_variant: r.variant.title || "default title",
                    currency: r.variant.price.currencyCode,
                    price: r.variant.price.amount,
                    item_brand: r.variant.product.vendor,
                    item_list_id: c,
                    item_list_name: e,
                    image_url: r.variant.image.src,
                    quantity: r.quantity
                };
                a === "custom/update_checkout" && (o.sku = r.variant.sku ? r.variant.sku : r.variant.product.id, o.product_id = r.variant.product.id, o.variant_id = r.variant.id, o.title = r.variant.product.title, o.variant_title = r.variant.title, o.vendor = r.variant.product.vendor), i.push(o)
            }), i
        }, V = (t, a, i) => p(null, null, function*() {
            var r;
            try {
                var c = yield i.cookie.get("cart_currency"), e = a.context.window.location.hostname, d = e.replace(/^www\./, ""), l = (r = JSON.parse(t)) != null ? r : [];
                if (!l || !Array.isArray(l)) return null;
                var n = l.find(o => o.domain === d && o.currencies.some(u => u.currency === c));
                return n || (n = l.find(o => o.domain === d && o.is_default)), n || (n = l.find(o => o.domain === d)), !n && l.length > 0 && (n = l[0]), n ? n.ga4_measurement_id : null
            } catch (o) {
                return console.error("Error parsing GA4 Measurement IDs:", o), null
            }
        })
    });
    var It, w, j = S(() => {
        "use strict";
        It = (t, a) => {
            let i = "https://connect.thrudark.com/shopify/webhook/custom",
                c = {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "X-Shopify-shop-id": a,
                        "X-shopify-topic": t.event
                    },
                    keepalive: !0,
                    body: JSON.stringify(t)
                };
            fetch(i, c)
        }, w = It
    });
    var St, it, ct = S(() => {
        "use strict";
        O();
        j();
        St = (t, a, i, c, e, d) => p(null, null, function*() {
            var l = yield a.cookie.get("cart_currency"), n = yield a.localStorage.getItem("shop_market_id"), r = t.context.window.location.href;
            if (!r.includes("processing")) {
                yield rt(a);
                var o = yield b(t, a, i, e), u = {
                    id: t.id,
                    event_source_url: r,
                    event: "custom/page_view",
                    currency: l
                };
                n && (u.shop_market_id = n), u.user_data = o;
                let s = e == null ? void 0 : e.marketingAllowed;
                u.consent = u.consent || {}, u.consent.marketingAllowed = s, u.consent.analyticsAllowed = e == null ? void 0 : e.analyticsProcessingAllowed, w(u, c), s || (u.consent.status = "accepted", u.consent.fromDeferEvent = !0, d(() => w(u, c)));
                var h = P();
                E(h, "latestETMSec", a)
            }
        }), it = St
    });
    var Lt, ot, nt = S(() => {
        "use strict";
        O();
        j();
        Lt = (t, a, i, c, e, d) => p(null, null, function*() {
            var l = yield a.cookie.get("cart_currency"), n = yield a.localStorage.getItem("shop_market_id"), r = yield b(t, a, i, e), o = t.data.productVariant.title;
            o === "" && (o = "Default Title");
            var u = t.context.document.referrer,
                h = t.context.document.location.origin,
                s = t.context.document.location.protocol,
                m = t.context.document.location.href,
                A = z(u, h),
                C = A.item_list_id,
                k = A.item_list_name,
                I = s + t.data.productVariant.image.src,
                v = t.data.productVariant.price.currencyCode,
                y = t.data.productVariant.price.amount,
                M = t.data.productVariant.sku;
            M === "" && (M = t.data.productVariant.product.id);
            var g = {
                    currency: v,
                    value: y,
                    affiliation: "Online Store",
                    items: [{
                        item_id: M,
                        item_shopify_id: t.data.productVariant.product.id,
                        item_shopify_variant: t.data.productVariant.id,
                        item_name: t.data.productVariant.product.title,
                        item_variant: o,
                        currency: v,
                        price: y,
                        item_brand: t.data.productVariant.product.vendor,
                        item_list_id: C,
                        item_list_name: k,
                        image_url: I,
                        product_url: m
                    }]
                },
                _ = {
                    id: t.id,
                    event_source_url: m,
                    currency: l
                };
            n && (_.shop_market_id = n), _.user_data = r;
            var T = [],
                x = [],
                D = t.data.productVariant.id || t.data.productVariant.sku,
                R = {
                    id: D,
                    quantity: 1
                };
            T.push(R), x.push(D);
            var G = {
                content_type: "product",
                currency: v,
                value: y,
                contents: T,
                content_ids: x
            };
            _.product_data = G;
            var U = g;
            _.ga4_data = U, _.event = "custom/content_view";
            let N = e == null ? void 0 : e.marketingAllowed;
            _.consent = _.consent || {}, _.consent.marketingAllowed = N, _.consent.analyticsAllowed = e == null ? void 0 : e.analyticsProcessingAllowed, w(_, c), N || (_.consent.status = "accepted", _.consent.fromDeferEvent = !0, d(() => w(_, c)));
            var f = P();
            E(f, "latestETMSec", a)
        }), ot = Lt
    });
    var Pt, dt, st = S(() => {
        "use strict";
        O();
        j();
        Pt = (t, a, i, c, e, d) => p(null, null, function*() {
            var U, N, f, X;
            try {
                var l = yield a.cookie.get("cart_currency"), n = yield a.localStorage.getItem("shop_market_id"), r = (X = (f = (N = (U = t == null ? void 0 : t.data) == null ? void 0 : U.cartLine) == null ? void 0 : N.merchandise) == null ? void 0 : f.product) == null ? void 0 : X.url, o = r ? r.includes("variant") : !1;
                if (!r || o) {
                    var u = yield b(t, a, i, e), h = t.context.document.referrer, s = t.context.document.location.origin;
                    r = s + t.data.cartLine.merchandise.product.url;
                    var m = z(h, s),
                        A = m.item_list_id,
                        C = m.item_list_name,
                        k = t.data.cartLine.merchandise.price.currencyCode,
                        I = t.data.cartLine.merchandise.price.amount,
                        v = t.data.cartLine.cost.totalAmount.amount,
                        y = t.data.cartLine.merchandise.sku;
                    y === "" && (y = t.data.cartLine.merchandise.product.id);
                    var M = [{
                            item_id: y,
                            item_shopify_id: t.data.cartLine.merchandise.product.id,
                            item_shopify_variant: t.data.cartLine.merchandise.id,
                            item_name: t.data.cartLine.merchandise.product.title,
                            item_variant: "Default Variant Title",
                            currency: k,
                            price: I,
                            quantity: t.data.cartLine.quantity,
                            item_brand: t.data.cartLine.merchandise.product.vendor,
                            item_list_id: A,
                            item_list_name: C,
                            image_url: t.data.cartLine.merchandise.image.src,
                            product_url: r
                        }],
                        g = {
                            id: t.id,
                            event_source_url: t.context.document.location.href,
                            currency: l
                        };
                    n && (g.shop_market_id = n), g.user_data = u;
                    var _ = [],
                        T = [],
                        x = t.data.cartLine.merchandise.id || t.data.cartLine.merchandise.sku,
                        D = {
                            id: x,
                            quantity: t.data.cartLine.quantity
                        };
                    _.push(D), T.push(x);
                    var R = {
                        content_type: "product",
                        currency: k,
                        value: v,
                        contents: _,
                        content_ids: T
                    };
                    g.product_data = R, g.items = M, g.event = "custom/add_to_cart";
                    let B = e == null ? void 0 : e.marketingAllowed;
                    g.consent = g.consent || {}, g.consent.marketingAllowed = B, g.consent.analyticsAllowed = e == null ? void 0 : e.analyticsProcessingAllowed, w(g, c), B || (g.consent.status = "accepted", g.consent.fromDeferEvent = !0, d(() => w(g, c)));
                    var G = P();
                    E(G, "latestETMSec", a)
                }
            } catch (B) {
                console.error("Error processing product_added_to_cart event:", B)
            }
        }), dt = Pt
    });
    var Mt, lt, ut = S(() => {
        "use strict";
        O();
        j();
        Mt = (t, a, i, c, e, d) => p(null, null, function*() {
            var l = yield a.cookie.get("cart_currency"), n = yield a.localStorage.getItem("shop_market_id"), r = {
                id: t.id,
                event_source_url: t.context.window.location.href,
                platform_source: "extensibility",
                currency: l
            };
            n && (r.shop_market_id = n);
            var o = yield b(t, a, i, e);
            r.user_data = o;
            var u = {};
            u.value = t.data.checkout.totalPrice.amount, u.currency = t.data.checkout.totalPrice.currencyCode, u.affiliation = "Online Store";
            var h = et(t, "custom/begin_checkout");
            u.items = h, r.ga4_data = u, r.event = "custom/begin_checkout";
            var s = t.data.checkout,
                m = {
                    currency: s.currencyCode,
                    content_type: "product",
                    value: parseFloat(s.totalPrice.amount)
                },
                A = [],
                C = [];
            s.lineItems.forEach(function(v) {
                var y = v.variant.id ? v.variant.id : v.variant.product.id;
                A.push({
                    id: y,
                    quantity: v.quantity,
                    item_price: v.variant.price.amount
                }), C.push(y)
            }), m.contents = A, m.content_ids = C, r.product_data = m;
            let k = e == null ? void 0 : e.marketingAllowed;
            r.consent = r.consent || {}, r.consent.marketingAllowed = k, r.consent.analyticsAllowed = e == null ? void 0 : e.analyticsProcessingAllowed, w(r, c), k || (r.consent.status = "accepted", r.consent.fromDeferEvent = !0, d(() => w(r, c)));
            var I = P();
            E(I, "latestETMSec", a)
        }), lt = Mt
    });
    var bt, mt, pt = S(() => {
        "use strict";
        O();
        j();
        bt = (t, a, i, c, e, d) => p(null, null, function*() {
            var l = yield a.cookie.get("cart_currency"), n = yield a.localStorage.getItem("shop_market_id"), r = {
                id: "",
                event_source_url: t.context.window.location.href,
                currency: l
            };
            n && (r.shop_market_id = n);
            var o = t.data.checkout.billingAddress.firstName ? t.data.checkout.billingAddress.firstName.toLowerCase() : null,
                u = t.data.checkout.billingAddress.lastName ? t.data.checkout.billingAddress.lastName.toLowerCase() : null,
                h = t.data.checkout.billingAddress.city ? t.data.checkout.billingAddress.city.replace(/ /g, "").toLowerCase() : null,
                s = t.data.checkout.billingAddress.province ? t.data.checkout.billingAddress.province.replace(/ /g, "").toLowerCase() : null,
                m = t.data.checkout.billingAddress.zip ? t.data.checkout.billingAddress.zip.replace(/ /g, "").replace("-", "").toLowerCase() : null,
                A = t.data.checkout.billingAddress.country ? t.data.checkout.billingAddress.country.toLowerCase() : null,
                C = yield b(t, a, i, e);
            r.user_data = C;
            var k = {
                first_name: o,
                last_name: u,
                default_address: {
                    full_name: o + u,
                    first_name: o,
                    last_name: u,
                    address1: t.data.checkout.billingAddress.address1,
                    city: h,
                    province: s,
                    province_code: t.data.checkout.billingAddress.provinceCode,
                    zip: m,
                    country: A,
                    country_code: t.data.checkout.billingAddress.countryCode
                }
            };
            if (t.data.checkout.billingAddress.address2 && (k.default_address.address2 = t.data.checkout.billingAddress.address2), t.data.checkout.email && (k.email = t.data.checkout.email.toLowerCase()), t.data.checkout.billingAddress.phone) {
                var I = t.data.checkout.billingAddress.phone.replace("+", "");
                k.default_address.phone = I
            }
            r.customer = k;
            var v = {
                    content_type: "product",
                    currency: t.data.checkout.totalPrice.currencyCode,
                    value: t.data.checkout.totalPrice.amount
                },
                y = [],
                M = [],
                g = [],
                _ = 0;
            t.data.checkout.lineItems.forEach(function(f) {
                var X = f.variant.id ? f.variant.id : f.variant.product.id;
                y.push({
                    id: X,
                    quantity: f.quantity
                }), M.push(X), g.push({
                    sku: f.variant.sku,
                    title: f.variant.product.title,
                    vendor: f.variant.product.vendor,
                    variant_title: f.variant.title,
                    price: f.variant.price.amount,
                    quantity: f.quantity,
                    product_id: f.variant.product.id,
                    variant_id: f.variant.id
                }), f.discountAllocations && f.discountAllocations.length > 0 && (_ = _ + f.discountAllocations[0].amount.amount)
            }), v.contents = y, v.content_ids = M, r.product_data = v, r.line_items = g;
            let T = [];
            t.data.checkout.discountApplications && t.data.checkout.discountApplications.length > 0 && (T.push({
                code: t.data.checkout.discountApplications[0].title,
                amount: _
            }), r.discount_codes = T), r.source_name = "web", r.total_price = t.data.checkout.totalPrice.amount, r.total_tax = t.data.checkout.totalTax.amount, r.subtotal_price = t.data.checkout.subtotalPrice.amount, r.shipping_price = t.data.checkout.shippingLine.price.amount ? t.data.checkout.shippingLine.price.amount : 0, r.event = "custom/purchase";
            var x = t.data.checkout.order.id.split("/"),
                D = x[x.length - 1];
            r.name = D;
            var R = "payment_method_not_available";
            if (t.data.checkout.transactions && t.data.checkout.transactions[0] && t.data.checkout.transactions[0].gateway && (R = t.data.checkout.transactions[0].gateway), r.gateway = R, r.id = D, c === "63412404413") {
                var G = r.line_items.some(f => f.quantity >= 5);
                if (G) return
            }
            let U = e == null ? void 0 : e.marketingAllowed;
            r.consent = r.consent || {}, r.consent.marketingAllowed = U, r.consent.analyticsAllowed = e == null ? void 0 : e.analyticsProcessingAllowed, w(r, c), U || (r.consent.status = "accepted", r.consent.fromDeferEvent = !0, d(() => w(r, c)));
            var N = P();
            E(N, "latestETMSec", a)
        }), mt = bt
    });
    var _t = yt(q => {
        "use strict";
        K();
        ct();
        nt();
        st();
        ut();
        pt();
        O();
        F(({
            analytics: t,
            browser: a,
            settings: i,
            init: c,
            customerPrivacy: e
        }) => {
            let d = i.ga4ID,
                l = i.ga4MeasurementIds || "[]",
                n = i.shopId,
                r = c.customerPrivacy;
            var o = [];

            function u(s) {
                o.push(s)
            }

            function h() {
                o.forEach(function(s) {
                    s()
                }), o = []
            }
            e.subscribe("visitorConsentCollected", s => {
                r = s.customerPrivacy, r != null && r.marketingAllowed ? h() : o = []
            }), t.subscribe("page_viewed", s => p(null, null, function*() {
                var m = yield V(l, s, a);
                m && (d = m), yield it(s, a, d, n, r, u)
            })), t.subscribe("product_viewed", s => p(null, null, function*() {
                var m = yield V(l, s, a);
                m && (d = m), yield ot(s, a, d, n, r, u)
            })), t.subscribe("product_added_to_cart", s => p(null, null, function*() {
                var m = yield V(l, s, a);
                m && (d = m), yield dt(s, a, d, n, r, u)
            })), t.subscribe("checkout_started", s => p(null, null, function*() {
                var m = yield V(l, s, a);
                m && (d = m), yield lt(s, a, d, n, r, u)
            })), t.subscribe("checkout_completed", s => p(null, null, function*() {
                var m = yield V(l, s, a);
                m && (d = m), yield mt(s, a, d, n, r, u)
            }))
        })
    });
    var ka = At(_t());
})();