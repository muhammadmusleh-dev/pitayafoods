{
    "token": "hWN79WSTVxwnBp8zLH23irSN?key=0be7cde87871b00b5bb470731a77d537",
    "note": "",
    "attributes": {
        "GE_isApplePay": "false",
        "GE_consentPrefs": "{\"marketing\":\"\",\"analytics\":\"\",\"preferences\":\"\",\"sale_of_data\":\"\"}",
        "cartToken": "hWN79WSTVxwnBp8zLH23irSN?key=0be7cde87871b00b5bb470731a77d537",
        "GE_utmParams": "utm_source=direct\u0026utm_medium=(none)\u0026utm_campaign=(not-set)",
        "GE_clientId": "772890070.742765963.2465",
        "GE_frtToken": "a2bacf63b7aa4859bb424c07afa50e4b_1767384292134___24ck_tt",
        "GLBE_SESS_ID": "772890070.742765963.2465",
        "ftkn": "a2bacf63b7aa4859bb424c07afa50e4b_1767384482614__UDF43_24ck"
    },
    "original_total_price": 0,
    "total_price": 0,
    "total_discount": 0,
    "total_weight": 0.0,
    "item_count": 0,
    "items": [],
    "requires_shipping": false,
    "currency": "PKR",
    "items_subtotal_price": 0,
    "cart_level_discount_applications": [],
    "discount_codes": []
}