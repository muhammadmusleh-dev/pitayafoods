if (!customElements.get('submarine-app')) {
    customElements.define(
        'submarine-app',
        class Submarines extends window.BAO.CustomElement {

            constructor() {
                super()

                // return if no parent presales info
                if (this.dataset.parentPresalesInfoEl === '') return

                // use this to find active campaign... 
                this.parentPreSales = JSON.parse(this.dataset.parentPresalesInfoEl)
                this.activeCampaignId = this.activeCampaignId(this.parentPreSales)

                // removes selling plan input if no active campaign...
                if (this.activeCampaignId == null) {
                    const element = document.querySelector('[name="selling_plan"]');
                    element ? .remove();
                    return
                }

                this.reserveText = this.dataset.preOrderBtnTextEl
                this.variantAvailable = this.dataset.availableEl
                this.messaging = this.querySelectorAll('.prd-Details_Presale-Message')

                this.initialiseSubmarine()
            }

            initialiseSubmarine() {
                console.log('Submarine initialised')

                // variant trigger
                const triggers = document.querySelectorAll(
                    '[data-el="product-options.trigger"]',
                )

                if (triggers.length !== 0) {
                    // on variant trigger click
                    triggers.forEach(triggerEl => {
                        triggerEl.addEventListener('click', (event) => {
                            this.setSelectedVariant(triggerEl.getAttribute('data-title'), event)
                        })
                    })

                    // on page load check for variant selection
                    triggers.forEach(triggerEl => {
                        if (triggerEl.getAttribute('aria-pressed') === 'true') {
                            this.setSelectedVariant(triggerEl.getAttribute('data-title'))
                        }
                    })
                } else {
                    this.setSelectedVariant('Default Title')
                }
            }

            // sets the selected variant based on the variant trigger
            setSelectedVariant(variant, event) {
                // clear messaging 
                document.querySelector('.prd-Basket-Message').classList.remove('prd-Basket-Message--show')

                // clear selected and reselected variant
                this.messaging.forEach(message => {
                    const messageVariant = message.getAttribute('data-variant-title')
                    const dataVariantPreSales = message.getAttribute('data-variant-presales')

                    let messagePreSales = null
                    if (dataVariantPreSales.length > 0) {
                        messagePreSales = JSON.parse(message ? .getAttribute('data-variant-presales'))
                    }

                    // check campaign is active on this variant
                    let isCampaignActiveOnThisVariant = null
                    if (messagePreSales != null) {
                        isCampaignActiveOnThisVariant = this.checkVarianthasActiveCampaign(messagePreSales)
                    }

                    if (isCampaignActiveOnThisVariant == null) {
                        console.log('no active campaign on this variant')
                        return
                    }

                    if (messageVariant === variant) {
                        message.setAttribute('data-selected', 'true')

                        // how many available for the variant? 
                        const available = message.getAttribute('data-variant-available')
                        // how many are reserved on the active campaign?
                        const reservedTotal = isCampaignActiveOnThisVariant[this.activeCampaignId].reserved

                        if (available && reservedTotal < available) {
                            const setQuantitySelectorAmount = available - reservedTotal

                            // limit quantity selector.. 
                            if (setQuantitySelectorAmount < 10) {
                                this.setQuantitySelector(setQuantitySelectorAmount)
                            } else {
                                this.setQuantitySelector(10)
                            }

                            // show messsage
                            document.querySelector('.prd-Basket-Message').classList.add('prd-Basket-Message--show')

                            // update button state (variant)
                            if (event) {
                                event.target.classList.remove('prd-Options_Button-soldOut')
                            }

                            // update add to cart button
                            this.updateButton('Add to Cart')

                        } else {
                            this.showOutOfStockButton()
                        }
                    } else {
                        message.setAttribute('data-selected', 'false')
                    }
                })
            }

            // gets the total reserved ammount for the selected variant
            getReservedAmmount(data) {
                let reservedTotal = 0

                data.forEach(item => {
                    Object.values(item).forEach(value => {
                        const reservedNumber = value.reserved;
                        if (reservedNumber !== undefined) {
                            reservedTotal = reservedTotal + reservedNumber
                        }
                    })
                })
                return reservedTotal
            }

            // updates the button text
            updateButton(newBtnText) {
                // add to cart button
                const btn = document.querySelector('.prd-Details_Button-addToCart')
                // back in stock button
                const bisBtn = document.querySelector('.prd-Details_Button-bis')

                setTimeout(() => {
                    btn ? .setAttribute('aria-hidden', 'false')
                    btn ? .removeAttribute('disabled')
                    btn.querySelector('.btn-Button_Text').textContent = 'Add to Cart'
                    bisBtn ? .setAttribute('aria-hidden', 'true')
                    bisBtn ? .setAttribute('style', 'display: none')
                })
            }

            showOutOfStockButton(newBtnText) {
                // add to cart button
                const btn = document.querySelector('.prd-Details_Button-addToCart')
                // back in stock button
                const bisBtn = document.querySelector('.prd-Details_Button-bis')

                setTimeout(() => {
                    btn ? .setAttribute('aria-hidden', 'true')
                    btn ? .setAttribute('disabled', 'true')
                    // btn.querySelector('.btn-Button_Text').textContent = 'Reserve'
                    bisBtn ? .setAttribute('aria-hidden', 'false')
                    bisBtn ? .setAttribute('style', 'display: block')
                }, 1000)
            }

            setQuantitySelector(amount) {
                const q = document.querySelectorAll('#quantity option')
                q.forEach((option, index) => {
                    if (index > amount - 1) {
                        option.setAttribute('disabled', 'true')
                    } else {
                        option.removeAttribute('disabled')
                    }
                })
            }

            // this function is not required at present... 
            campaignEndDate() {
                // this contains all the campaign info set at product level. 
                this.parentPreSales = JSON.parse(this.dataset.parentPresalesInfoEl)
                this.parentPreSalesAmount = this.parentPreSales.length

                // finds the active campaign. 
                let active = null
                this.parentPreSales.forEach((item, index) => {
                    if (item.status === 'launched') {
                        active = index
                    }
                })
                // sets the active campaign
                this.parentPreSalesCurrent = this.parentPreSales[active]

                // format the end date as dd month yyyy
                const endDateString = this.parentPreSalesCurrent.end_at;
                const endDate = new Date(endDateString);

                // Define an array to store month names
                const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

                // Get the day, month, and year components of the date
                const day = endDate.getDate();
                const monthIndex = endDate.getMonth(); // Months are zero-based in JavaScript
                const year = endDate.getFullYear();

                // Format the date
                const formattedEndDate = `${months[monthIndex]} ${day}, ${year}`;

                const inputItem = `<input type="hidden" name="properties[shipping from]" value="${formattedEndDate}">`
                document.querySelector('.prd-Details_Form').insertAdjacentHTML('afterbegin', inputItem)
            }

            // sets the active campaign id
            activeCampaignId(parentPreSales) {
                // if parent presales is not an array push to a new array else use the array
                if (!Array.isArray(parentPreSales)) {
                    parentPreSales = [parentPreSales]
                }

                let active = null
                parentPreSales.forEach((item, index) => {
                    if (item.status === 'launched') {
                        const today = new Date()
                        const launch = new Date(item.launched_at)
                        // console.log('today', today, 'launch', launch, today > launch)
                        if (launch != null) {
                            if (today > launch) {
                                active = item.id
                                return active
                            } else {
                                const element = document.querySelector('[name="selling_plan"]');
                                element.value = '0'
                                return
                            }
                        }
                    }
                })
                return active
            }

            // checks if the variant has an active campaign
            checkVarianthasActiveCampaign(messagePreSales) {
                let hasActiveCampaign = null
                messagePreSales.forEach(item => {
                    // get key of the object
                    if (Object.keys(item)[0] === this.activeCampaignId) {
                        hasActiveCampaign = item
                        return
                    }
                })
                return hasActiveCampaign
            }
        }
    )
}

if (!customElements.get('submarine-push-cart')) {
    customElements.define(
        'submarine-push-cart',
        class SubmarinePushCart extends window.BAO.CustomElement {

            constructor() {
                super()

                if (this.dataset.parentPresalesInfoEl === '') return // added as safety net... need to retest this. 

                console.log('Submarine push cart initialised')

                // use this to find active campaign... 
                this.parentPreSales = JSON.parse(this.dataset.parentPresalesInfoEl)
                // active campaign id
                this.activeCampaignId = this.getActiveCampaignId(this.parentPreSales)
                this.variantPreSales = JSON.parse(this.dataset.variantPresales)
                this.activeCampaign = this.checkVarianthasActiveCampaign(this.variantPreSales)

                if (this.activeCampaign) {
                    this.querySelector('.psh-CartItem').classList.add('psh-CartItem--pill-msg')
                    const pillMsg = this.querySelector('.pill-msg')
                    pillMsg.style.display = 'block'
                    pillMsg.textContent = `Shipping from ${this.campaignEndDate()}`
                    this.querySelector('.psh-CartItem_SelectContainer').style.display = 'none'
                    this.querySelector('.psh-CartItem_Quantity').style.display = 'block'
                }

            }

            // sets the active campaign id
            getActiveCampaignId(parentPreSales) {
                if (!Array.isArray(parentPreSales)) {
                    parentPreSales = [parentPreSales]
                }
                let active = null
                parentPreSales.forEach((item, index) => {
                    if (item.status === 'launched') {
                        const today = new Date()
                        const launch = new Date(item.launched_at)
                        if (launch != null) {
                            if (today > launch) {
                                active = item.id
                                return
                            } else {
                                return
                            }
                        }
                    }
                })
                return active
            }

            checkVarianthasActiveCampaign(messagePreSales) {
                let hasActiveCampaign = null
                messagePreSales.forEach(item => {
                    // get key of the object
                    if (Object.keys(item)[0] === this.activeCampaignId) {
                        hasActiveCampaign = item
                        return
                    }
                })
                return hasActiveCampaign
            }

            campaignEndDate() {

                let active = null
                this.parentPreSales.forEach((item, index) => {
                    if (item.status === 'launched') {
                        active = index
                    }
                })
                // sets the active campaign
                this.parentPreSalesCurrent = this.parentPreSales[active]

                // format the end date as dd month yyyy
                const endDateString = this.parentPreSalesCurrent.fulfil_at;
                const endDate = new Date(endDateString);

                // Define an array to store month names
                const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

                // Get the day, month, and year components of the date
                const day = endDate.getDate();
                const monthIndex = endDate.getMonth(); // Months are zero-based in JavaScript
                const year = endDate.getFullYear();

                // Format the date
                const formattedEndDate = `${months[monthIndex]} ${day}, ${year}`;

                return formattedEndDate
            }
        })
}