if (!customElements.get('header-announcement-ticker')) {
    customElements.define(
        'header-announcement-ticker',
        class HeaderAnnouncementTicker extends window.BAO.CustomElement {
            constructor() {
                super()

                this.items = this.firstElementChild

                this.freeShippingAmount = this.dataset.free_shipping_amountEl
                this.currencySymbol = this.dataset.currencySymbolEl
                this.currencyCode = this.dataset.currencyCodeEl

                const clone = this.items.cloneNode(true)
                this.appendChild(clone)

                const body = document.body || document.documentElement
                body.style.setProperty(
                    '--Announcement_Height',
                    `${this.offsetHeight}px`,
                )

                if (this.freeShippingAmount != null) {
                    this.currencyConversion()
                }
            }

            currencyConversion() {
                const localeFreeShippingCost = this.freeShippingAmount * window.Shopify.currency.rate
                const localeFreeShippingRounded = Math.ceil(localeFreeShippingCost.toFixed(2))
                const LocaleCurrencyMsg = `${this.currencySymbol}${localeFreeShippingRounded} `

                const replaceText = this.querySelectorAll('.shipping-amount')
                if (replaceText.length > 0) {
                    replaceText.forEach((el) => {
                        el.textContent = LocaleCurrencyMsg
                        el.style.display = 'inline'
                    })
                }
            }
        },
    )
}