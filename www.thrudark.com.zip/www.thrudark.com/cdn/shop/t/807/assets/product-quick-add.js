if (!customElements.get('product-quick-add')) {
    class ProductQuickAdd extends window.BAO.CustomElement {
        constructor() {
            super()

            this.externalEls = {
                backInStock: {
                    exists: false
                },
                container: {
                    exists: false
                },
            }

            const container = this.closest(
                '[data-product-quick-add-external-el="container"]',
            )
            if (container) {
                this.externalEls.container = {
                    exists: Boolean(container),
                    element: container,
                    elements: [container],
                }

                const backInStockElements = container.querySelectorAll(
                    '[data-product-quick-add-external-el="backInStockButton"]',
                )
                this.externalEls.backInStock = {
                    exists: backInStockElements.length > 0,
                    element: backInStockElements[0],
                    elements: [...backInStockElements],
                }
            }
        }

        setupListeners() {
            super.setupListeners()

            if (this.els.variant) {
                this.els.variant.elements.forEach(variant => {
                    this.listeners.add(variant, 'click', event => this.handleClick(event))
                })
            }

            if (this.externalEls.backInStock.exists) {
                this.listeners.add(
                    this.externalEls.backInStock.element,
                    'click',
                    event => this.openBackInStockModal(event),
                )
            }
        }

        /** @param {MouseEvent} event */
        handleClick({
            target
        }) {

            // check for open cart drawers
            const cartDrawers = document.querySelectorAll('.collection-quick-add.open')
            if (cartDrawers.length > 0) {
                cartDrawers.forEach(drawer => {
                    drawer.classList.remove('open')
                })
            }

            const {
                variantAvailable,
                variantId,
                preOrderDate,
                sellingPlanGroupId,
                gwp
            } = target.dataset
            const isAvailable = variantAvailable === 'true'
            const preOrderDateIsValid = window.BAO.utils.checkDateIsInTheFuture(preOrderDate)
            const itemProperties = preOrderDate !== '' && preOrderDateIsValid ? {
                'shipping from': preOrderDate
            } : {};
            const isGwp = gwp === 'true' ? {
                '__gwp': true
            } : {};

            if (sellingPlanGroupId != null && sellingPlanGroupId !== '') {

                if (isAvailable) {
                    window.BAO.Cart.addItem({
                        id: variantId,
                        selling_plan: sellingPlanGroupId,
                        properties: itemProperties
                    }, null, {
                        sections: window.BAO.utils.sectionRenderer.pushCartSections.map(
                            s => s.section,
                        ),
                    })
                }

            } else {

                if (isAvailable) {
                    // temporary fix for GWP - needs refactor.... 
                    window.BAO.Cart.addItem({
                        id: variantId,
                        properties: isGwp
                    }, null, {
                        sections: window.BAO.utils.sectionRenderer.pushCartSections.map(
                            s => s.section,
                        ),
                    })
                }

            }

            this.toggleBackInStock(variantId, isAvailable)

            this.els.variant.elements.forEach(variant => {
                const isTarget = variant === target
                variant.setAttribute('aria-pressed', isTarget)
            })
        }

        toggleBackInStock(id, isAvailable) {
            if (this.externalEls.backInStock && this.externalEls.backInStock.exists) {
                this.externalEls.backInStock.elements.forEach(element => {
                    element.dataset.variantId = id
                    element.setAttribute('aria-hidden', isAvailable)
                })
            }
        }

        openBackInStockModal(event) {
            window.BAO.dispatchEvent('back-in-stock-modal:open', {
                chosenVariant: event.currentTarget.dataset.variantId,
                productId: this.dataset.productId,
                productTitle: this.dataset.productTitle,
                variants: this.variants,
            })
        }

        get variants() {
            if (!this.els.variant || !this.els.variant.exists) {
                return [{
                    id: this.dataset.defaultVariantID,
                    title: this.dataset.defaultVariantTitle,
                }, ]
            }

            const variantButtons = this.els.variant.elements

            return variantButtons.map(button => ({
                id: button.dataset.variantId,
                title: button.textContent.trim(),
            }))
        }
    }

    customElements.define('product-quick-add', ProductQuickAdd)
}