class ConvertCurrency extends HTMLElement {
    constructor() {
        super()

        this.numbertoConvert = this.dataset.numberToConvert
        this.currency = this.dataset.currency
        this.placement = this.querySelector('span')
        this.initialiseConvertCurrency()
    }

    initialiseConvertCurrency() {

        const localeFreeShippingCost = this.numbertoConvert * window.Shopify.currency.rate
        const localeFreeShippingRounded = Math.ceil(localeFreeShippingCost.toFixed(2))
        const LocaleCurrencyMsg = `${this.currency}${localeFreeShippingRounded} `
        this.placement.textContent = LocaleCurrencyMsg
    }
}

customElements.define('convert-currency', ConvertCurrency)