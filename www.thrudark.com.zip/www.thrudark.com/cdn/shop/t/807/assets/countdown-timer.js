if (!customElements.get("countdown-timer")) {
    customElements.define(
        "countdown-timer",
        class CountdownTimer extends HTMLElement {
            constructor() {
                super();

                this.countdown = this.querySelector('[data-el="countdown"]');
                this.expiry = this.getAttribute("data-expiry");
                this.expiryDate = this.getAttribute("data-date");
                this.messageEl = this.querySelector('[data-el="message"]');
                this.message = this.getAttribute("data-message");
                this.timeStyle = this.getAttribute("data-time-style");
                this.initialiseCountdownTimer =
                    this.initialiseCountdownTimer.bind(this);
                this.initialiseCountdownTimer();
            }

            initialiseCountdownTimer() {
                if (this.countdown != null && this.expiryDate != null) {
                    const component = this;
                    const counter = this.countdown;
                    const countDownDate = new Date(this.expiryDate).getTime();
                    const expirationMessage = this.expiry;

                    const messageEl = this.messageEl;
                    const message = this.message;
                    const timeStyle = this.timeStyle;

                    const x = setInterval(function() {
                        // Get today's date and time
                        const now = new Date().getTime();

                        // Find the distance between now and the count down date
                        const distance = countDownDate - now;

                        // Time calculations for days, hours, minutes and seconds
                        const days = Math.floor(distance / (1000 * 60 * 60 * 24));
                        const hours = Math.floor(
                            (distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
                        );
                        const hoursToNow = Math.floor(distance / (1000 * 60 * 60));
                        const minutesToNow = Math.floor(distance / (1000 * 60));
                        const minutes = Math.floor(
                            (distance % (1000 * 60 * 60)) / (1000 * 60)
                        );
                        const seconds = Math.floor((distance % (1000 * 60)) / 1000);

                        counter.innerHTML = "";

                        const daysText = days > 1 ? "days" : "day";
                        const hoursText = hours > 1 ? "hours" : "hour";
                        const minutesText = minutes > 1 ? "minutes" : "minute";
                        const minutesToNowText = minutesToNow > 1 ? "minutes" : "minute";
                        const secondsText = seconds > 1 ? "seconds" : "second";

                        // if (timeStyle && timeStyle === "hours-only") {
                        //   if (hoursToNow < 2) {
                        //     counter.innerHTML += `<span class="minutes">${minutesToNow} ${minutesToNowText}</span>`;
                        //   } else {
                        //     counter.innerHTML += `<span class="hours">${hoursToNow} ${hoursText}</span>`;
                        //   }
                        // }

                        if (timeStyle && timeStyle === "compacted") {
                            if (days >= 2) {
                                counter.innerHTML += `<span class="days">${days} ${daysText} </span>`;
                            } else {
                                if (hoursToNow < 2) {
                                    counter.innerHTML += `<span class="minutes">${minutesToNow} ${minutesToNowText}</span>`;
                                } else {
                                    counter.innerHTML += `<span class="hours">${hoursToNow} ${hoursText}</span>`;
                                }
                            }
                        }

                        if (timeStyle && timeStyle === "show-all") {
                            counter.innerHTML += `<span class="days">${days} ${daysText}, </span>`;
                            counter.innerHTML += `<span class="hours">${hours} ${hoursText}, </span>`;
                            counter.innerHTML += `<span class="minutes">${minutes} ${minutesText}, </span>`;
                            counter.innerHTML += `<span class="seconds">${seconds} ${secondsText}</span>`;
                        }

                        if (messageEl != null && message != null) {
                            messageEl.innerHTML = message;
                        }

                        // If the count down is finished...
                        if (distance < 0) {
                            clearInterval(x);
                            if (expirationMessage != null) {
                                component.innerHTML = `${expirationMessage}`;
                            } else {
                                component.classList.add("hide");
                            }
                        }
                    }, 1000);
                }
            }
        }
    );
}