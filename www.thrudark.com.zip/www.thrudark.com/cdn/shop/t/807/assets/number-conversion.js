class NumberConversion extends HTMLElement {
    constructor() {
        super()

        this.initialiseNumberConversion()
    }

    initialiseNumberConversion() {
        let updatedThreshold
        if (this.dataset.bypass) {
            updatedThreshold = this.dataset.threshold
        } else {
            updatedThreshold = this.convertCurrency(this.dataset.threshold)
        }

        const difference = updatedThreshold - this.dataset.cartTotal

        this.comparecartTotal(difference, updatedThreshold, this.dataset.cartTotal)
    }

    convertCurrency(amount) {
        const currencyRate = amount * window.Shopify.currency.rate
        const currencyRateRounded = Math.ceil(currencyRate.toFixed(2))
        return currencyRateRounded
    }

    formatCurrency(amount) {
        const formatted = amount.slice(0, -2) + '.' + amount.slice(-2);
        return formatted
    }

    comparecartTotal(diff, thresh, cartTotal) {
        let fill = false

        if (diff <= 0) {
            this.querySelector('.success').style.display = 'block'
            fill = true
        } else {
            this.updateIncentivise(diff)
        }
        this.updateProgressBar(thresh, cartTotal, fill)
    }

    updateIncentivise(diff) {
        const incentivise = this.querySelector('.incentivise')
        const incentiviseMsg = this.dataset.message
        const formattedDifference = this.formatCurrency(diff.toString())
        const price = `<strong>${this.dataset.currencySymbol}${formattedDifference}</strong>`
        const formattedMsg = incentiviseMsg.replace('[amount]', price)
        incentivise.innerHTML = formattedMsg
        incentivise.style.display = 'block'
    }

    updateProgressBar(thresh, cartTotal, fill) {
        const progress = document.querySelector('.psh-CartDelivery_Bar')
        if (fill) {
            progress.style.transform = `translateX(0%)`
        } else {
            const percentage = (cartTotal / thresh) * 100
            const leftover = 100 - percentage
            progress.style.transform = `translateX(-${leftover}%)`
        }
    }

}

customElements.define('number-conversion', NumberConversion)