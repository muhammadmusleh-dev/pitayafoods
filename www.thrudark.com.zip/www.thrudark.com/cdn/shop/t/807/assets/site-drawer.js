import KeenSlider from 'https://cdn.skypack.dev/keen-slider@5.5.1'

class SiteDrawer extends window.BAO.CustomElement {
    CLASSES = {
        activeDrawerClass: 'drw-Drawer-active'
    }

    constructor() {
        super()

        if (this.drawerShouldBeMoved) {
            window.setTimeout(() => {
                this.moveToElement.appendChild(this)

                this.start()
            }, parseInt(this.getAttribute('data-module-drawers-move-delay'), 10) || 0)
        } else {
            this.start()
        }
    }

    start() {
        this.drawers = this.closest('site-drawers')

        if (!this.drawers)
            throw new Error(
                `${this.nodeName.toLowerCase()} should be inside a <site-drawers> element`
            )
        this.drawers.drawers.push(this)

        this._isOpen = false
    }

    get key() {
        return this.getAttribute('key')
    }

    get elements() {
        return {
            trigger: window.BAO.utils.getElement(
                `[data-drawers-trigger=${this.key}]`
            ),
            close: window.BAO.utils.getElement(
                `[data-module-drawers-close=${this.key}]`
            )
        }
    }

    get isOpen() {
        return this._isOpen
    }

    set isOpen(val) {
        this._isOpen = val

        this.classList.toggle(this.CLASSES.activeDrawerClass, val)

        const loopReturns = document.getElementById('loop-onstore')
        const drawState = document
            .querySelector('site-drawers')
            .classList.contains('drw-Drawers-active')

        if (loopReturns !== null && drawState == false) {
            loopReturns.classList.add('active')
        } else if (loopReturns !== null && drawState == true) {
            loopReturns.classList.remove('active')
        }
    }

    get drawerShouldBeMoved() {
        return this.hasAttribute('data-module-drawers-move-me')
    }

    get moveToElement() {
        switch (this.getAttribute('data-module-drawers-move-me')) {
            case 'root':
                return document.querySelector('site-drawers')
            default:
                return window.BAO.utils.getElement(
                    this.getAttribute('data-module-drawers-move-me')
                )
        }
    }
}

customElements.define('site-drawer', SiteDrawer)