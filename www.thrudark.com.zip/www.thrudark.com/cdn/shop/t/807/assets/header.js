// eslint-disable-next-line import/no-default-export
class HeaderScroll extends HTMLElement {
    constructor() {
        super()

        this.triggerEls = this.querySelectorAll('[data-el="search.trigger"]')
        this.searchEl = this.querySelectorAll('[data-el="search.container"]')
        this.searchIconEl = this.querySelectorAll('[data-el="search.iconSearch"]')
        this.closeIconEl = this.querySelectorAll('[data-el="search.iconClose"]')

        this.searchInput = this.querySelector('#searchtext');
        this.searchButton = this.querySelector('#searchbutton');

        this.isTicking = false
        // eslint-disable-next-line
        this.lastKnownY = window.scrollY
        this.offsetTrackedY = 0
        this.scrollOffset = 600
        // this.scrollOffset = 100
        this.safeZone = 200
        this.scrollDirection = ''

        this.setupListeners()

        this.requestTick = this.requestTick.bind(this)
        this.updateEl = this.updateEl.bind(this)

        this.updateEl()
    }

    setupListeners() {

        this.onScroll = this.onScroll.bind(this)

        window.addEventListener('scroll', this.onScroll, {
            passive: true
        })

        if (this.searchInput ? .value.length > 0) {
            this.searchButton.removeAttribute("disabled");
        }

        this.searchInput ? .addEventListener('keyup', (event) => {
            if (this.searchInput.value.length > 0) {
                this.searchButton.removeAttribute("disabled");
            } else {
                this.searchButton.setAttribute("disabled", '');
            }
        }, false);

        this.triggerEls.forEach(button => {
            button.addEventListener('click', () => {
                this.toggleSearch()
            })
        })
    }

    onScroll() {
        const previouslyKnown = this.lastKnownY
        const previousDirection = this.scrollDirection

        // eslint-disable-next-line
        this.lastKnownY = window.scrollY
        this.scrollDirection = previouslyKnown < this.lastKnownY ? 'down' : 'up'

        if (previousDirection !== this.scrollDirection) {
            this.offsetTrackedY = this.lastKnownY
        }

        this.requestTick()
    }

    requestTick() {
        if (!this.isTicking) requestAnimationFrame(this.updateEl)

        this.isTicking = true
    }

    updateEl() {
        this.isTicking = false

        this.setFixed()
        this.setSize()
        this.setVisibility()
    }

    toggleSearch() {

        // possible better solution... 
        setTimeout(() => {
            document.querySelector('.hd-Banner_Search-mobile .header__search__inner .icon-search').click()
        })

        this.searchEl.forEach(search => {
            search.setAttribute(
                'aria-hidden',
                search.getAttribute('aria-hidden') === 'true' ? 'false' : 'true'
            )
        })

        this.searchIconEl.forEach(searchIcon => {
            searchIcon.setAttribute(
                'aria-hidden',
                searchIcon.getAttribute('aria-hidden') === 'false' ? 'true' : 'false'
            )
        })

        this.closeIconEl.forEach(closeIcon => {
            closeIcon.setAttribute(
                'aria-hidden',
                closeIcon.getAttribute('aria-hidden') === 'true' ? 'false' : 'true'
            )
        })
    }

    setFixed() {
        this.classList.toggle('hd-Banner-fixed', this.shouldBeFixed)
        document.body.classList.toggle('util-Banner-fixed', this.shouldBeFixed)
    }

    setSize() {
        this.classList.toggle('hd-Banner-small', this.shouldBeFixed)
        document.body.classList.toggle('util-Banner-small', this.shouldBeFixed)
    }

    setVisibility() {
        this.classList.toggle('hd-Banner-hidden', !this.shouldBeVisible)
        document.body.classList.toggle('util-Banner-hidden', !this.shouldBeVisible)
    }

    get shouldBeFixed() {
        return this.lastKnownY >= this.safeZone
    }

    get shouldBeVisible() {

        // return false hides header... 
        const searchButton = document.querySelector('.hd-Banner_Item-mobile .hd-Search_Button')
        const isSearchOpen = document.querySelector('.hd-Banner_Search-mobile .search-modal__form').getAttribute('open')

        if (this.lastKnownY < this.safeZone / 2) {
            return true
        } else if (this.lastKnownY <= this.safeZone * 2) {

            // check window size... 
            if (window.innerWidth > 768) {
                // close search on desktop...
                document.body.click()
            } else {

                if (isSearchOpen) {
                    return true
                }

            }
            return false
        }

        if (this.scrollDirection === 'down') {
            // if (window.innerWidth < 768 && !this.isOverOffset ) {
            //   const searchButton = document.querySelector('.hd-Banner_Item-mobile .hd-Search_Button')
            //   searchButton.click()
            // }
            return !this.isOverOffset
        } else if (this.scrollDirection === 'up') {
            return this.isOverOffset
        }
    }

    get isOverOffset() {
        if (this.scrollDirection === 'down') {
            return this.lastKnownY >= this.offsetTrackedY + this.scrollOffset
        } else if (this.scrollDirection === 'up') {
            return this.lastKnownY <= this.offsetTrackedY - this.scrollOffset
        }
    }

    get containerEl() {
        return this.closest('[data-header-container-el]')
    }
}

customElements.define('header-scroll', HeaderScroll)