if (!customElements.get('tabbed-collections')) {
    customElements.define(
        'tabbed-collections',
        class TabList extends window.BAO.CustomElement {
            constructor() {
                super()
                this.tabs = this.querySelectorAll('.tabbed-collection__tabs__tab')
                this.panels = this.querySelectorAll('.tabbed-collection__collection__collection')
                this.init()
            }

            init() {
                this.tabs.forEach(tab => {
                    tab.addEventListener('click', e => {
                        const index = [...this.tabs].indexOf(tab)
                        this.clearSelected()
                        this.setActivePanel(index)
                        tab.classList.add('tabbed-collection__tabs__tab--selected')
                    })
                }, )
            }

            clearSelected() {
                this.tabs.forEach(tab => {
                    tab.classList.remove('tabbed-collection__tabs__tab--selected')
                })
            }

            setActivePanel(index) {
                this.panels.forEach(panel => {
                    panel.classList.remove('tabbed-collection__collection__collection--active')
                })
                this.panels[index].classList.add('tabbed-collection__collection__collection--active')
            }

        })
}