// eslint-disable-next-line import/no-unresolved
import gsap from 'https://cdn.skypack.dev/gsap'

class ParallaxItems {
    constructor() {
        this.isTicking = false
        this.lastKnownY = window.scrollY

        this.parallaxEls = document.querySelectorAll('[data-parallax-el="item"]')

        if (this.parallaxEls.length === 0) return

        this.requestTick = this.requestTick.bind(this)
        this.updateEl = this.updateEl.bind(this)

        this.setupElements()

        this.updateEl()

        this.setupListeners()
    }

    setupListeners() {
        this.onScroll = this.onScroll.bind(this)

        window.addEventListener('scroll', this.onScroll, {
            passive: true
        })
    }

    onScroll() {
        this.lastKnownY = window.scrollY

        this.requestTick()
    }

    requestTick() {
        if (!this.isTicking) requestAnimationFrame(this.updateEl)

        this.isTicking = true
    }

    updateEl() {
        this.isTicking = false

        this.moveParallaxItem()
    }

    moveParallaxItem() {
        this.parallaxEls.forEach(parallaxEl => {
            if (parallaxEl.offsetParent === null) return

            const windowHeight = window.innerHeight

            const amountToMove = parseFloat(parallaxEl.dataset.parallaxAmount)
            const elementHeight = parallaxEl.offsetHeight

            const scaleAmount = amountToMove / elementHeight + 1

            const actualItemHeight = elementHeight + amountToMove
            const heightDifference = actualItemHeight - elementHeight

            const elementStartPoint =
                window.BAO.utils.getOffsetTop(parallaxEl) - windowHeight
            const elementEndPoint =
                window.BAO.utils.getOffsetTop(parallaxEl) + elementHeight

            if (this.lastKnownY < elementStartPoint) {
                gsap.to(parallaxEl, 1, {
                    y: amountToMove / -2,
                    scale: scaleAmount,
                })

                return
            }

            if (this.lastKnownY > elementEndPoint) {
                gsap.to(parallaxEl, 1, {
                    y: amountToMove / 2,
                    scale: scaleAmount,
                })

                return
            }

            const totalScrollAmount = elementEndPoint - elementStartPoint

            const scrollYAsAPercentageOfJourney =
                (this.lastKnownY - elementStartPoint) / totalScrollAmount

            const transformAmount =
                heightDifference * scrollYAsAPercentageOfJourney - heightDifference / 2

            gsap.to(parallaxEl, 1, {
                y: transformAmount,
                scale: scaleAmount,
            })
        })
    }

    setupElements() {
        this.parallaxEls.forEach(parallaxEl => {
            if (parallaxEl.offsetParent === null) return

            const amountToMove = parseFloat(parallaxEl.dataset.parallaxAmount)
            const elementHeight = parallaxEl.offsetHeight

            const scaleAmount = amountToMove / elementHeight + 1

            parallaxEl.style.setProperty('--ScaleAmount', scaleAmount)
            parallaxEl.classList.add('ani-Parallax_Item')
        })
    }
}

window.BAO.parallaxItems = new ParallaxItems()