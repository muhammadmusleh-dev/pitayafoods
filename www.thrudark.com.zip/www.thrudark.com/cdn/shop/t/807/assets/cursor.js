// eslint-disable-next-line import/no-unresolved
import gsap from 'https://cdn.skypack.dev/gsap'

class Cursor extends window.BAO.CustomElement {
    constructor() {
        super()

        this.allLinkEls = document.querySelectorAll('a,button')
        this.zoomEls = document.querySelectorAll(
            `[data-custom-cursor-external-el='zoom']`
        )
        this.carouselEls = document.querySelectorAll(
            `[data-custom-cursor-external-el='carousel']`
        )
        this.videoEls = document.querySelectorAll(
            `[data-custom-cursor-external-el='video']`
        )

        this.revert = document.querySelectorAll(
            `[data-custom-cursor-external-el='revert']`
        )

        this.cursorSettings = {
            x: -200,
            y: -200
        }

        if (window.innerWidth < 900) return

        setTimeout(() => {
            this.initialiseCursor()
        }, 500)
    }

    setupListeners() {
        this.initialiseLinkCursor()
        this.initialiseZoomCursor()
        this.initialiseCarouselCursor()
        this.initialiseVideoCursor()
        this.inintialiseRevertCursor()
    }

    initialiseCursor() {
        this.cursorSettings.x = -100
        this.cursorSettings.y = -100

        document.addEventListener('mousemove', e => {
            this.cursorSettings.x = e.clientX
            this.cursorSettings.y = e.clientY
        })

        const renderCursor = () => {
            gsap.to(this.els.dot.element, 0.1, {
                x: this.cursorSettings.x,
                y: this.cursorSettings.y
            })

            gsap.to(this.els.circle.element, 0.5, {
                x: this.cursorSettings.x,
                y: this.cursorSettings.y
            })

            requestAnimationFrame(renderCursor)
        }

        requestAnimationFrame(renderCursor)
    }

    initialiseLinkCursor() {
        this.allLinkEls.forEach(linkElement => {
            this.listeners.add(
                linkElement,
                'mouseenter',
                this.handleLinkEnter.bind(this)
            )
            this.listeners.add(
                linkElement,
                'mouseleave',
                this.handleLinkLeave.bind(this)
            )
        })
    }

    handleLinkEnter() {
        this.classList.add(`cur-Cursor-linkActive`)
    }

    handleLinkLeave() {
        this.classList.remove(`cur-Cursor-linkActive`)
    }

    initialiseZoomCursor() {
        this.zoomEls.forEach(zoomEl => {
            this.listeners.add(zoomEl, 'mouseenter', this.handleZoomEnter.bind(this))
            this.listeners.add(zoomEl, 'mouseleave', this.handleZoomLeave.bind(this))
        })
    }

    handleZoomEnter() {
        this.classList.add(`cur-Cursor-zoomActive`)
    }

    handleZoomLeave() {
        this.classList.remove(`cur-Cursor-zoomActive`)
    }

    initialiseCarouselCursor() {
        this.carouselEls.forEach(carouselEl => {
            this.listeners.add(
                carouselEl,
                'mouseenter',
                this.handleCarouselEnter.bind(this)
            )
            this.listeners.add(
                carouselEl,
                'mouseleave',
                this.handleCarouselLeave.bind(this)
            )
        })
    }

    handleCarouselEnter() {
        this.classList.add(`cur-Cursor-carouselActive`)
        document.body.classList.add(`util-HideCursor`)
    }

    handleCarouselLeave() {
        this.classList.remove(`cur-Cursor-carouselActive`)
        document.body.classList.remove(`util-HideCursor`)
    }

    initialiseVideoCursor() {
        this.videoEls.forEach(videoEl => {
            this.listeners.add(
                videoEl,
                'mouseenter',
                this.handleVideoEnter.bind(this)
            )
            this.listeners.add(
                videoEl,
                'mouseleave',
                this.handleVideoLeave.bind(this)
            )
        })
    }

    handleVideoEnter() {
        this.classList.add(`cur-Cursor-videoActive`)
        document.body.classList.add(`util-HideCursor`)
    }

    handleVideoLeave() {
        this.classList.remove(`cur-Cursor-videoActive`)
        document.body.classList.remove(`util-HideCursor`)
    }

    inintialiseRevertCursor() {
        this.revert.forEach(revertEl => {
            this.listeners.add(revertEl, 'mouseenter', this.handleRevertEnter.bind(this))
            this.listeners.add(revertEl, 'mouseleave', this.handleRevertLeave.bind(this))
        })
    }

    handleRevertEnter() {
        this.classList.add(`cur-Cursor-revertActive`)
    }

    handleRevertLeave() {
        this.classList.remove(`cur-Cursor-revertActive`)
    }
}

customElements.define('custom-cursor', Cursor)