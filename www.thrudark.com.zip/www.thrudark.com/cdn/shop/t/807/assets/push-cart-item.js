if (!customElements.get('push-cart-item')) {
    customElements.define(
        'push-cart-item',
        class PushCartItem extends window.BAO.CustomElement {
            _loading = false
            sections = window.BAO.utils.sectionRenderer.pushCartSections

            setupListeners() {
                super.setupListeners()

                this.removeLineItem = this.removeLineItem.bind(this)
                this.updateQuantity = this.updateQuantity.bind(this)

                if (this.els ? .remove ? .exists) {
                    this.listeners.add(this.els.remove.element, 'click', this.removeLineItem)
                }

                if (this.els ? .quantity ? .exists) {
                    this.listeners.add(this.els.quantity.element, 'change', this.updateQuantity)
                }
            }

            async removeLineItem() {
                const checkisBundle = this.querySelector('.bundle-icon')

                const state = await window.BAO.Cart.removeItem(
                    this.line,
                    this.sections.map(s => s.section),
                )

                if (checkisBundle) {
                    const bundleId = checkisBundle.dataset.bundleId
                    await this.removeLineItemsByProperty('_bundler_id', bundleId)
                }

                if ('sections' in state) {
                    this.renderSections(state.sections)
                }
            }

            async updateQuantity(e) {
                const quantity = parseInt(e.target.value, 10)
                const state = await window.BAO.Cart.updateQuantity(
                    this.line,
                    quantity,
                    this.sections.map(s => s.section),
                )

                await this.removeLineItemsByProperty('__gwp', true)

                if ('sections' in state) {
                    this.renderSections(state.sections)
                }
            }

            async removeLineItemsByProperty(propertyName, propertyValue = null) {
                try {
                    const response = await fetch('/cart.js')
                    const cart = await response.json()
                    const itemsToRemove = cart.items.filter(item => {
                        const props = item.properties || {}
                        return propertyValue === null ?
                            Object.prototype.hasOwnProperty.call(props, propertyName) :
                            props[propertyName] === propertyValue
                    })

                    if (itemsToRemove.length === 0) return

                    const updatePayload = {
                        updates: Object.fromEntries(itemsToRemove.map(item => [item.id, 0])),
                    }

                    await fetch('/cart/update.js', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(updatePayload),
                    })

                    if (propertyName === '_bundler_id') {
                        const url = sessionStorage.getItem('bundle-visitor')
                        sessionStorage.removeItem('bundle-visitor')
                        url ? window.location.href = url : window.location.reload()
                        window.location.reload()
                    } else {
                        window.location.reload()
                    }
                } catch (error) {
                    console.error('Error removing line items:', error)
                }
            }

            get loading() {
                return this._loading
            }

            set loading(val) {
                this._loading = val
            }

            get line() {
                return parseInt(this.getAttribute('index'), 10)
            }
        },
    )
}