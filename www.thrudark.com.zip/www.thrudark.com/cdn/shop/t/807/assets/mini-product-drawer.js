if (!customElements.get('mini-product-drawer')) {
    customElements.define(
        'mini-product-drawer',
        class MiniProductDrawer extends window.BAO.CustomElement {
            constructor() {
                super()

                this.trigger = this.querySelector('.mini-product-drawer__open')
                this.handle = this.dataset.handle
                this.miniProductDrawer = document.querySelector('.mini-product-drawer-drawer')
                this.miniProductDrawerInner = document.querySelector('.mini-product-drawer__inner')
                this.close = document.querySelector('.mini-product-drawer__close-button')

                this.initialiseMiniProductDrawer()
            }

            initialiseMiniProductDrawer() {
                this.close.addEventListener('click', this.closeThisDrawer.bind(this))
                this.trigger.addEventListener('click', this.handleClick.bind(this))
            }

            handleClick() {
                this.getProduct(this.handle)
                this.OpenDrawer()
            }

            getProduct(handle) {
                this.miniProductDrawerInner.innerHTML = 'Loading...'

                fetch(window.Shopify.routes.root + `products/${handle}?view=mini-pdp`)
                    .then(res => res.text())
                    .then(html => {
                        this.miniProductDrawerInner.innerHTML = html

                        // Execute any <script> tags in the fetched HTML
                        this.miniProductDrawerInner.querySelectorAll('script').forEach(oldScript => {
                            const newScript = document.createElement('script');
                            newScript.textContent = oldScript.textContent;

                            // Copy over attributes like src, type, etc.
                            Array.from(oldScript.attributes).forEach(attr =>
                                newScript.setAttribute(attr.name, attr.value)
                            );

                            // Replace the old <script> with the new one to trigger execution
                            oldScript.replaceWith(newScript);
                            this.miniProductDrawer.classList.add('active')
                        });
                    })
                    .catch(error => console.error('Error loading product:', error));
            }

            closeThisDrawer() {
                this.miniProductDrawer.classList.remove('active')
            }

            OpenDrawer() {
                this.classList.add('active')
            }
        }

    )
}