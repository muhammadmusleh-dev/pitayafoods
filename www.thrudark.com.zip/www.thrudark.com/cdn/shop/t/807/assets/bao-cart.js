/** @const {String[]} The sections we want returned from cart actions by default */
const DEFAULT_SECTIONS = [];
/** @const {String} The context in which we want the sections to be rendered in */
const DEFAULT_SECTIONS_URL = /^\/apps/.test(window.location.pathname) ?
    "/cart" :
    window.location.pathname;

/**
 * By Association Only's cart helper methods
 */
class BaoCart {
    /**
     * Add a new line item to the cart
     * @param {object} item The item we want to add values to pass to /cart/add.js
     * @param {number} item.id The variant's unique ID
     * @param {number} item.quantity The quantity of items to be added to the cart
     * @param {object} item.properties Line item property key/values
     *   (https://help.shopify.com/en/themes/liquid/objects/line_item#line_item-properties)
     * @param {HTMLFormElement} form The form that has added the item
     * @param {object} options Optional values to pass to /cart/add.js
     * @param {string[]} [options.sections] - The sections we want rendered alongside any cart
     *   changes
     * @param {string} [options.sectionsUrl] - The context in which we want the sections to be
     *   rendered in
     * @param {object} [options.attributes] Key/values that we want to add to the cart attributes
     *
     * @returns {Promise} Resolves with the line item object (See response of cart/add.js
     *   https://help.shopify.com/en/themes/development/getting-started/using-ajax-api#add-to-cart)
     */
    async addItem({
            id,
            quantity = 1,
            selling_plan = null,
            properties = {}
        },
        form, {
            sections = DEFAULT_SECTIONS,
            sectionsUrl = DEFAULT_SECTIONS_URL,
            attributes = {},
        } = {}
    ) {
        const item = {
            id,
            quantity,
            selling_plan,
            properties,
        };

        window.BAO.dispatchEvent(window.BAO.EVENTS.PUSH_CART.BEFORE_ADD, {
            item,
            attributes,
            form,
        });

        const body = {
            items: [item],
            attributes,
        };

        if (sections.length) {
            body.sections = sections;
            body.sections_url = sectionsUrl;
        }

        try {
            const state = await window.BAO.utils.fetchJSON(
                `${window.routes.cartAddUrl}`, {
                    ...window.BAO.utils.getDefaultRequestConfig(),
                    ...{
                        body: JSON.stringify(body)
                    },
                }
            );

            window.BAO.dispatchEvent(window.BAO.EVENTS.PUSH_CART.AFTER_ADD, {
                item,
                state,
                form,
            });

            return state;
        } catch (e) {
            console.error(e);
        }
    }

    /**
     * Add multiple new line item to the cart
     * @param {object[]} items The items we want to add values to pass to /cart/add.js
     * @param {number} items[].id The variant's unique ID
     * @param {number} items[].quantity The quantity of items to be added to the cart
     * @param {object} items[].properties Line item property key/values
     *  (https://help.shopify.com/en/themes/liquid/objects/line_item#line_item-properties)
     * @param {object} options Optional values to pass to /cart/add.js
     * @param {string[]} [options.sections] - The sections we want rendered alongside any cart
     *  changes
     * @param {string} [options.sectionsUrl] - The context in which we want the sections to be
     * rendered in
     * @param {object} [options.attributes] Key/values that we want to add to the cart attributes
     * @returns {Promise} Resolves with the line item object (See response of cart/add.js
     * https://help.shopify.com/en/themes/development/getting-started/using-ajax-api#add-to-cart)
     * @example
     * window.BAO.Cart.addItems([
     *  {
     *    id: 123,
     *    quantity: 1,
     *    properties: {
     *      'My property': 'My value',
     *    },
     *  },
     *  {
     *    id: 456,
     *    quantity: 2,
     *    properties: {
     *      'My property': 'My value',
     *    },
     *  },
     * ],
     * {
     *  sections: ['cart'],
     *  sectionsUrl: '/cart',
     *  attributes: {
     *    'My attribute': 'My value',
     *  },
     * });
     * // => { items: [ { id: 123, quantity: 1, ... }, { id: 456, quantity: 2, ... } ], ... }
     */

    async addItems(
        items, {
            sections = DEFAULT_SECTIONS,
            sectionsUrl = DEFAULT_SECTIONS_URL,
            attributes = {},
        } = {}
    ) {
        window.BAO.dispatchEvent(window.BAO.EVENTS.PUSH_CART.BEFORE_ADD, {
            items,
            attributes,
        });

        const body = {
            items,
            attributes,
        };

        if (sections.length) {
            body.sections = sections;
            body.sections_url = sectionsUrl;
        }

        try {
            const state = await window.BAO.utils.fetchJSON(
                `${window.routes.cartAddUrl}`, {
                    ...window.BAO.utils.getDefaultRequestConfig(),
                    ...{
                        body: JSON.stringify(body)
                    },
                }
            );

            window.BAO.dispatchEvent(window.BAO.EVENTS.PUSH_CART.AFTER_ADD, {
                items,
                state,
            });

            return state;
        } catch (e) {
            console.error(e);
        }
    }

    /**
     * Updates the quantity of an item in the cart. You can set the quantity to 0 to remove the item
     *
     * @param {number} line - The index of the line item we want to change
     * @param {number} quantity - The amount of the item we want change the line item to. Can be 0.
     * @param {string[]} [sections] - The sections we want rendered alongside any cart changes
     * @param {string} [sectionsUrl] - The context in which we want the sections to be rendered in
     *
     * @returns {Promise<object>}
     */
    async updateQuantity(
        line,
        quantity,
        sections = DEFAULT_SECTIONS,
        sectionsUrl = DEFAULT_SECTIONS_URL
    ) {
        window.BAO.dispatchEvent(
            window.BAO.EVENTS.PUSH_CART.BEFORE_UPDATE_ITEM_QUANTITY, {
                line,
                quantity,
            }
        );
        const body = {
            line,
            quantity,
        };

        if (sections.length) {
            body.sections = sections;
            body.sections_url = sectionsUrl;
        }

        try {
            const state = await window.BAO.utils.fetchJSON(
                `${window.routes.cartChangeUrl}`, {
                    ...window.BAO.utils.getDefaultRequestConfig(),
                    ...{
                        body: JSON.stringify(body)
                    },
                }
            );

            window.BAO.dispatchEvent(
                window.BAO.EVENTS.PUSH_CART.AFTER_UPDATE_ITEM_QUANTITY, {
                    state,
                }
            );

            return state;
        } catch (err) {
            console.error(err);
        }
    }

    /**
     * Remove an item from the cart
     *
     * @param {number} line - The index of the line item we want to change
     * @param {string[]} [sections] - The sections we want rendered alongside any cart changes
     * @param {string} [sectionsUrl] - The context in which we want the sections to be rendered in
     *
     * @returns {Promise}
     */
    async removeItem(line, sections = [], sectionsUrl = DEFAULT_SECTIONS_URL) {
        return this.updateQuantity(line, 0, sections, sectionsUrl);
    }

    /**
     * Update cart attributes
     *
     * https://shopify.dev/api/ajax/reference/cart#update-cart-attributes
     *
     * @param {object} attributes - An object of key/value pairs you want to update
     *
     * @returns {Promise}
     */
    async updateCartAttributes(attributes) {
        window.BAO.dispatchEvent(
            window.BAO.EVENTS.PUSH_CART.BEFORE_UPDATE_CART_ATTRIBUTES, {
                attributes,
            }
        );

        try {
            const state = await window.BAO.utils.fetchJSON(
                `${window.routes.cartUpdateUrl}`, {
                    ...window.BAO.utils.getDefaultRequestConfig(),
                    ...{
                        body: JSON.stringify({
                            attributes
                        })
                    },
                }
            );

            window.BAO.dispatchEvent(
                window.BAO.EVENTS.PUSH_CART.AFTER_UPDATE_CART_ATTRIBUTES, {
                    attributes,
                }
            );

            return state;
        } catch (e) {
            console.error(e);
        }
    }
}

window.BAO.Cart = new BaoCart();