class PushCartBundles extends HTMLElement {
    constructor() {
        super();
        this.init();
    }

    init() {
        document.body.addEventListener("click", (e) => {
            const button = e.target.closest(".sec-ImageText_Link");
            if (button ? .dataset.addproductstocart == "true") {
                e.preventDefault();
                const itemsToAdd = this.getItemsToAdd(button);
                this.addToCart(itemsToAdd);
            }
        });
    }

    getItemsToAdd(button) {
        const itemsToAdd = button.href.split("/cart/")[1].split(",");
        return itemsToAdd.map((item) => {
            return {
                id: item,
                quantity: 1,
            };
        });
    }

    // add the items to cart and re-render the push cart using the BAO API in the following format
    /**
     * Add a new line item to the cart
     * @param {object} item The item we want to add values to pass to /cart/add.js
     * @param {number} item.id The variant's unique ID
     * @param {number} item.quantity The quantity of items to be added to the cart
     * @param {object} item.properties Line item property key/values
     *   (https://help.shopify.com/en/themes/liquid/objects/line_item#line_item-properties)
     * @param {HTMLFormElement} form The form that has added the item
     * @param {object} options Optional values to pass to /cart/add.js
     * @param {string[]} [options.sections] - The sections we want rendered alongside any cart
     *   changes
     * @param {string} [options.sectionsUrl] - The context in which we want the sections to be
     *   rendered in
     * @param {object} [options.attributes] Key/values that we want to add to the cart attributes
     *
     * @returns {Promise} Resolves with the line item object (See response of cart/add.js
     *   https://help.shopify.com/en/themes/development/getting-started/using-ajax-api#add-to-cart)
     */
    async addToCart(itemsToAdd) {
        const items = itemsToAdd.map((item) => {
            return {
                id: item.id,
                quantity: item.quantity,
            };
        });

        const body = {
            items,
        };

        try {
            const state = await window.BAO.utils.fetchJSON(
                `${window.routes.cartAddUrl}`, {
                    ...window.BAO.utils.getDefaultRequestConfig(),
                    ...{
                        body: JSON.stringify(body)
                    },
                }
            );

            window.BAO.dispatchEvent(window.BAO.EVENTS.PUSH_CART.AFTER_ADD, {
                state,
            });
        } catch (error) {
            window.BAO.dispatchEvent(window.BAO.EVENTS.PUSH_CART.ADD_ERROR, {
                error,
            });
        }
    }
}

// define the custom element
customElements.define("push-cart-bundles", PushCartBundles);