class BAOCustomElement extends HTMLElement {
    _elIdentifier = `data-${this.identifier}-el`
    hasBeenInitialised = false
    /**
     * sections - a list of sections that are related to this element. They can be updated by calling the renderSections method with updated HTML
     * @type {Section[]}
     * @public
     */
    sections = []

    constructor() {
        super()

        /** @type {Object.<{ exists: boolean, elements: HTMLElement[], element: HTMLElement }>} */
        this.els = this.getElements()
        this.listeners = new window.BAO.utils.Listeners()
    }

    connectedCallback() {
        if (this.hasBeenInitialised) return

        this.hasBeenInitialised = true

        this.setupListeners()
    }

    disconnectedCallback() {
        this.listeners.removeAll()
    }

    setupListeners() {}

    getElements() {
        const elementIdentifiers = this._getElementIdentifiers()

        return elementIdentifiers.reduce((els, identifier) => {
            const elements = Array.from(
                this.querySelectorAll(`[${this._elIdentifier}="${identifier}"]`),
            )

            els[identifier] = {
                exists: elements.length > 0,
                elements,
                element: elements[0],
            }

            return els
        }, {})
    }

    _getElementIdentifiers() {
        return Array.from(this.querySelectorAll(`[${this._elIdentifier}]`)).map(
            el => el.getAttribute(this._elIdentifier),
        )
    }

    /**
     * Renders multiple sections based on sections returned from the cart AJAX API
     *
     * @param {object} stateSections - An object where the keys are section ids and the values are the HTML returned from the section rendering API
     *
     * @returns {void}
     */
    renderSections(stateSections) {

        if (this.sections.length === 0) return

        const sectionsToRender = this.sections
            .filter(s => s.id in stateSections)
            .map(s => Object.assign({}, s, {
                html: stateSections[s.id]
            }))

        window.BAO.utils.sectionRenderer.renderMultiple(sectionsToRender)
    }

    get identifier() {
        return this.nodeName.toLowerCase()
    }
}

window.BAO.CustomElement = BAOCustomElement