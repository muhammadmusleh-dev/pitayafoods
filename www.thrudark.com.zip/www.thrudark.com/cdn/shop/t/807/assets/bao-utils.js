window.BAO.utils ? ? = {}

/**
 * Returns the first element that is a descendant of node that
 * matches selectors.
 *
 * @param {String} selector - A DOMString containing one or more selectors to match. This string
 *   must be a valid CSS selector string
 * @param {Object} [config] - You can pass a context to scope the element selection
 * @param {HTMLElement|Document} [context=Document] - The scope we will try and find the element in
 *
 * @returns {HTMLElement} The found element or null
 */
function getElement(selector, {
    context = document
} = {}) {
    return context.querySelector(selector)
}

/**
 * Returns a list of elements that are a descendant of node that
 * matches selectors.
 *
 * @param {String} selector - A DOMString containing one or more selectors to match. This string
 *   must be a valid CSS selector string
 * @param {Object} [config] - You can pass a context to scope the element selection
 * @param {HTMLElement|Document} [context=Document] - The scope we will try and find the element in
 * @param {Boolean} [asArray=true] - Return the elements as an Array instead of an NodeList?
 *
 * @returns {Array|NodeList} The found elements or null
 */
function getElements(selector, {
    context = document,
    asArray = true
} = {}) {
    const items = context.querySelectorAll(selector)

    return asArray ? Array.from(items) : items
}

/**
 * Checks if the passed string contains any items in an array
 *
 * @param {String} str - The string we will be searching
 * @param {Array} [items] - A list of the items we will be checking for presence in the str
 *
 * @returns {Boolean}
 */
function doesStringContainAny(str, items = []) {
    return items.some(i => str.includes(i))
}

/**
 * Creates an HTMLElement
 *
 * @param {String} tag - What type of element we want this to be
 * @param {Object} [options] - A key / value pair of properties and values we want to set on the
 *   newly created element
 *
 * @returns {HTMLElement}
 */
function createElement(tag, options = {}) {
    const el = document.createElement(tag)

    Object.entries(options).forEach(([key, value]) => {
        el.setAttribute(key, value)
    })

    return el
}

/**
 * Creates an array starting from zero with the length of the passed amount
 *
 * @param {Number} amount - How long do we want this array to be?
 *
 * @returns {Array}
 */
function range(amount) {
    return [...Array(amount).keys()]
}

/**
 * camelCase a string
 *
 * @param {String} str
 *
 * @return {String} value - formatted value
 */
function camelize(str) {
    return str
        .replace(/(?:^\w|[A-Z]|\b\w)/g, (word, index) => {
            return index === 0 ? word.toLowerCase() : word.toUpperCase()
        })
        .replace(/\s+/g, '')
}

/**
 * A Javascript equivalent of Shopify's | img_url filter
 *
 * @param {Object} The properties we will use to create the URL
 * @param {String} src - The Shopify CDN URL of the image
 * @param {String} size - What size we want the image to be
 * @param {null|String} [crop=null] - By default the images aren't cropped but we can choose to
 *   crop them
 * @param {null|Number} [scale=null] - Images are 1x by default, you can choose to pass a different
 *   scale
 *
 * @returns {String}
 */
function resizeImage({
    src,
    size,
    crop = null,
    scale = null
} = {}) {
    if (size == null) {
        return src
    }

    if (size === 'master') {
        return src.replace(/http(s)?:/, '')
    }

    const match = src.match(/\.(jpg|jpeg|gif|png|bmp|bitmap|tiff|tif)(\?v=\d+)?/i)

    if (match != null) {
        const prefix = src.split(match[0])
        const suffix = match[0]
        const scaleString = scale ? `@${scale}x` : ''
        const cropString = crop ? `_crop_${crop}` : ''

        return `${prefix[0]}_${size}${cropString}${scaleString}${suffix}`.replace(
            /http(s)?:/,
            '',
        )
    } else {
        return null
    }
}

/**
 * This is the default config we will use when using fetch()
 *
 * @returns {Object}
 */
function getDefaultRequestConfig() {
    return {
        method: 'POST',
        headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
        },
    }
}

/**
 * Default fetch boilerplate
 * @param {String} url - The URL we are looking to fetch
 * @param {Object} [config] - .fetch config to override the default
 *
 * @returns {Promise}
 */
function fetchJSON(url, config = {}) {
    return fetch(url, Object.assign({}, getDefaultRequestConfig(), config)).then(
        response => {
            if (!response.ok) {
                throw response
            }
            return response.json()
        },
    )
}

/**
 * This will fetch product data from Shopify's AJAX API by handle
 *
 * @param {String} handle - The products handle
 *
 * @returns {Promise}
 */
function fetchProductData(handle) {
    try {
        return fetchJSON(`/products/${handle}.js`)
    } catch (e) {
        console.error(e)
    }
}

/**
 * Gets the offsetTop of the passed element relevant to it's offsetParent
 *
 * @param {HTMLElement|Element} el - The element we'll be getting the offsetTop for
 * @param {Document|HTMLElement} [parent=HTMLBodyElement] - The offsetParent we want to get the offsetTop relative to
 * @param {Number} [offsetTop=0] - The starting offsetTop. This tends to be 0 but given this is a
 *   recursive function, we need to pass it to let it build up
 *
 * @returns {Number}
 */
function getOffsetTop(el, parent = document.body, offsetTop = 0) {
    if (!isNaN(el.offsetTop)) {
        offsetTop += el.offsetTop
    }

    return el.offsetParent === parent ?
        offsetTop :
        getOffsetTop(el.offsetParent, parent, offsetTop)
}

/**
 * Accepts a date in the format of YYYY-MM-DD
 *
 * @returns {Boolean}
 */

function checkDateIsInTheFuture(dateToTest) {

    var currentDate = new Date();
    // Format the date as "YYYY-MM-DD"
    var formattedDate = currentDate.toISOString().split('T')[0];

    // Convert date strings to Date objects
    var date1 = new Date(formattedDate);
    var date2 = new Date(dateToTest);

    if (date2 > date1) {
        return true
    } else {
        return false
    }

}

Object.assign(window.BAO.utils, {
    camelize,
    createElement,
    doesStringContainAny,
    fetchJSON,
    fetchProductData,
    getDefaultRequestConfig,
    getElement,
    getElements,
    getOffsetTop,
    range,
    resizeImage,
    checkDateIsInTheFuture,
})