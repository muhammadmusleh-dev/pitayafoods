// eslint-disable-next-line import/no-unresolved
import KeenSlider from 'https://cdn.skypack.dev/keen-slider@5.5.1'

if (!customElements.get('collection-carousel')) {
    customElements.define(
        'collection-carousel',
        class CollectionFeature extends window.BAO.CustomElement {
            constructor() {
                super()

                if (this.els.slide.elements.length < 3) return

                this.slideDirection = this.els.slides.element.dataset.directionright == 'true' ? true : false

                this.carousel = this.initialiseCarousel(this.slideDirection)

            }

            initialiseCarousel(e) {
                if (this.els.slide.elements.length > 2) {
                    this.els.slides.element.setAttribute(
                        'data-custom-cursor-external-el',
                        'carousel',
                    )
                }

                return new KeenSlider(this.els.slides.element, {
                    duration: 1000,
                    mode: 'snap',
                    slidesPerView: 1.3,
                    slides: '.car-Carousel_Slide',
                    spacing: 15,
                    rtl: this.slideDirection,
                    breakpoints: {
                        '(min-width: 768px)': {
                            loop: true,
                            mode: 'snap',
                            controls: this.els.slide.elements.length > 2,
                            slidesPerView: 2.5,
                            spacing: 0,
                        },
                    },
                    move: instance => {
                        this.els.slide.elements.forEach((slide, index) => {
                            slide.setAttribute(
                                'aria-hidden',
                                index !== instance.details().relativeSlide,
                            )
                        })
                    },
                    created: instance => {
                        this.els.dot.elements.forEach(dot => {
                            dot.addEventListener('click', () => {
                                instance.moveToSlide(dot.dataset.slide)
                            })
                        })
                    },
                    slideChanged: instance => {
                        this.els.dot.elements.forEach(dot => {
                            dot.setAttribute(
                                'aria-current',
                                parseInt(dot.dataset.slide) === instance.details().relativeSlide,
                            )
                        })
                    },
                })
            }
        },
    )
}