if (!customElements.get('product-card-colours')) {
    customElements.define(
        'product-card-colours',
        class ProductCardColours extends window.BAO.CustomElement {
            constructor() {
                super()

                this.initialize()
            }

            initialize() {
                this.renderProductColours()
            }

            renderProductColours() {
                return fetch(
                        `/products/${this.dataset.productHandle}?view=colour-variations--card`,
                    )
                    .then(res => res.text())
                    .then(html => {
                        this.innerHTML = html
                    })
            }
        },
    )
}