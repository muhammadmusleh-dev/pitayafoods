window.BAO.EVENTS = {
    PUSH_CART: {
        BEFORE_ADD: 'BEFORE_ADD',
        AFTER_ADD: 'AFTER_ADD',
        BEFORE_UPDATE_ITEM_QUANTITY: 'BEFORE_UPDATE_ITEM_QUANTITY',
        AFTER_UPDATE_ITEM_QUANTITY: 'AFTER_UPDATE_ITEM_QUANTITY',
        BEFORE_UPDATE_CART_ATTRIBUTES: 'BEFORE_UPDATE_CART_ATTRIBUTES',
        AFTER_UPDATE_CART_ATTRIBUTES: 'AFTER_UPDATE_CART_ATTRIBUTES',
    },
}

class EventBus {
    bus = document.createElement('div')

    addEventListener(event, callback) {
        this.bus.addEventListener(event, callback)
    }

    removeEventListener(event, callback) {
        this.bus.removeEventListener(event, callback)
    }

    dispatchEvent(event, detail = {}) {
        this.bus.dispatchEvent(new CustomEvent(event, {
            detail
        }))
    }
}

window.BAO.eventBus = new EventBus()
window.BAO.dispatchEvent = window.BAO.eventBus.dispatchEvent.bind(
    window.BAO.eventBus
)