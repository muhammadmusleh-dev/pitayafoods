class AnimateScroll {
    constructor() {
        this.isTicking = false
        this.lastKnownY = window.scrollY

        this.sectionEls = document.querySelectorAll(
            '[data-animate-scroll-el="trigger"]',
        )

        if (this.sectionEls.length === 0) return

        this.requestTick = this.requestTick.bind(this)
        this.updateEl = this.updateEl.bind(this)

        this.setupElements()

        this.updateEl()

        this.setupListeners()
    }

    setupListeners() {
        this.onScroll = this.onScroll.bind(this)

        window.addEventListener('scroll', this.onScroll, {
            passive: true
        })
    }

    onScroll() {
        this.lastKnownY = window.scrollY

        this.requestTick()
    }

    requestTick() {
        if (!this.isTicking) requestAnimationFrame(this.updateEl)

        this.isTicking = true
    }

    updateEl() {
        this.isTicking = false

        this.animateOnScroll()
    }

    animateOnScroll() {
        this.sectionEls.forEach(sectionEl => {
            const elementTriggerPoint =
                window.BAO.utils.getOffsetTop(sectionEl) - window.innerHeight + 100

            if (this.lastKnownY > elementTriggerPoint) {
                let timeoutOffset = 0
                const letterEls = sectionEl.querySelectorAll(
                    '[data-animate-scroll-el="letter"]',
                )

                letterEls.forEach(letterEl => {
                    timeoutOffset = timeoutOffset + 50

                    setTimeout(() => {
                        letterEl.classList.add(`ani-Scroll_Letter-animate`)
                    }, timeoutOffset)
                })

                const textEl = sectionEl.querySelector(
                    '[data-animate-scroll-el="text"]',
                )
                if (textEl) {
                    timeoutOffset = timeoutOffset + 200

                    setTimeout(() => {
                        textEl.classList.add(`ani-Scroll_Block-animate`)
                    }, timeoutOffset)
                }

                const kickerEl = sectionEl.querySelector(
                    '[data-animate-scroll-el="kicker"]',
                )
                const buttonsEl = sectionEl.querySelector(
                    '[data-animate-scroll-el="buttons"]',
                )

                timeoutOffset = timeoutOffset + 200

                const iconsEl = sectionEl.querySelector(
                    '[data-animate-scroll-el="icons"]',
                )

                if (iconsEl) {
                    timeoutOffset = timeoutOffset + 200

                    setTimeout(() => {
                        iconsEl.classList.add(`ani-Scroll_Block-animate`)
                    }, timeoutOffset)
                }

                if (kickerEl) {
                    setTimeout(() => {
                        kickerEl.classList.add(`ani-Scroll_Block-animate`)
                    }, timeoutOffset)
                }
                if (buttonsEl) {
                    setTimeout(() => {
                        buttonsEl.classList.add(`ani-Scroll_Block-animate`)
                    }, timeoutOffset)
                }
            }
        })
    }

    setupElements() {
        this.sectionEls.forEach(sectionEl => {
            const kickerEl = sectionEl.querySelector(
                '[data-animate-scroll-el="kicker"]',
            )
            const titleEl = sectionEl.querySelector(
                '[data-animate-scroll-el="title"]',
            )
            const textEl = sectionEl.querySelector('[data-animate-scroll-el="text"]')
            const iconsEl = sectionEl.querySelector('[data-animate-scroll-el="icons"]')
            const buttonsEl = sectionEl.querySelector(
                '[data-animate-scroll-el="buttons"]',
            )

            if (kickerEl) {
                kickerEl.classList.add('ani-Scroll_Block')
            }
            if (titleEl) {
                titleEl.innerHTML = titleEl.textContent.replace(
                    /\S/g,
                    `<span class='ani-Scroll_Letter' data-animate-scroll-el="letter">$&</span>`,
                )
            }
            if (textEl) {
                textEl.classList.add('ani-Scroll_Block')
            }
            if (buttonsEl) {
                buttonsEl.classList.add('ani-Scroll_Block')
            }
            if (iconsEl) {
                iconsEl.classList.add('ani-Scroll_Block')
            }
        })
    }
}

window.BAO.animateScroll = new AnimateScroll()