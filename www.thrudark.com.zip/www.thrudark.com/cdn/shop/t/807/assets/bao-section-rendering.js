/**
 * The makeup of a section to be used by our SectionRenderer
 *
 * @typedef {Object} Section
 * @property {String} id - The ID of the section. This will be the filename of the section
 * @property {String} selector - The CSS selector which contains the sections content
 * @property {String} html - This is the HTML returned by the section rendering API
 */
window.BAO.utils.sectionRenderer = new(class SectionRenderer {
    /**
     * Render a section returned from the section rendering API
     *
     * @param {Section} section - The makeup of the section we want to render
     *
     * @returns {void}
     */
    render(section) {
        this.validate(section);

        const baseElement = document.getElementById(section.id);
        if (!baseElement) {
            console.info(
                `Tried to render ${section.id} but no element with id="${section.id} exists"`
            );

            return;
        }

        const elementToReplace =
            document.getElementById(section.id).querySelector(section.selector) ||
            document.getElementById(section.id);

        elementToReplace.outerHTML = this.getInnerHtml(
            section.html,
            section.selector
        );
    }

    /**
     * Render multiple sections returned from the section rendering API
     *
     * @param {Section[]} sections - The sections we want to render
     *
     * @returns {void}
     */
    renderMultiple(sections) {
        sections.forEach((section) => this.render(section));
    }

    /**
     * Grab the HTML that is inside the section otherwise we end up with section inception
     *
     * @param {String} html - The section HTML returned from the section rendering API
     * @param {String} selector - The CSS selector which contains the sections content
     *
     * @returns {String}
     */
    getInnerHtml(html, selector) {
        return new DOMParser()
            .parseFromString(html, "text/html")
            .querySelector(selector).innerHTML;
    }

    /**
     * Render a section returned from the section rendering API
     *
     * @param {Section} section - The makeup of the section we want to render
     *
     * @returns {Boolean}
     */
    validate(section) {
        const isValid = this.expectedKeys.every((key) => key in section);

        if (!isValid) {
            throw new Error(
                `section is missing these keys: "${this.expectedKeys
          .filter((k) => !(k in section))
          .join(", ")}"`
            );
        }

        return isValid;
    }

    get expectedKeys() {
        return ["id", "selector", "html"];
    }

    get cartSections() {
        return [{
                id: "cart-items",
                section: "cart-items",
                selector: ".shopify-section",
            },
            {
                id: "cart-upsell",
                section: "cart-upsell",
                selector: ".shopify-section",
            },
            {
                id: "cart-summary",
                section: "cart-summary",
                selector: ".shopify-section",
            },
            {
                id: "push-cart-godark",
                section: "push-cart-godark",
                selector: ".shopify-section",
            },
        ];
    }

    get pushCartSections() {
        return [{
                id: "push-cart-delivery",
                section: "push-cart-delivery",
                selector: ".shopify-section",
            },
            {
                id: "push-cart-items",
                section: "push-cart-items",
                selector: ".shopify-section",
            },
            {
                id: "push-cart-footer",
                section: "push-cart-footer",
                selector: ".shopify-section",
            },
            // {
            //   id: "push-cart-gwp",
            //   section: "push-cart-gwp",
            //   selector: ".shopify-section",
            // },
            {
                id: "gwp-cart-bogof",
                section: "gwp-cart-bogof",
                selector: ".shopify-section",
            },
            {
                id: "gwp-cart-threshold",
                section: "gwp-cart-threshold",
                selector: ".shopify-section",
            },
            // {
            //   id: "push-cart-godark",
            //   section: "push-cart-godark",
            //   selector: ".shopify-section",
            // },
        ];
    }
})();