class LoginTab extends HTMLElement {
    constructor() {
        super()

        console.log('LoginTab constructor called')

        this.tabOne = this.querySelector('.tab-header__tab--one')
        this.tabTwo = this.querySelector('.tab-header__tab--two')

        this.contentOne = this.querySelector('.tab-content--tab-one')
        this.contentTwo = this.querySelector('.tab-content--tab-two')

        this.loginCopy = this.querySelector('.login-copy')
        this.signUpCopy = this.querySelector('.sign-up-copy')

        // get context param from url
        // eslint-disable-next-line compat/compat
        const url = new URL(window.location.href)
        const context = url.searchParams.get('context')

        if (context === 'login') {
            this.loginCopy.classList.add('active')
            this.signUpCopy.classList.remove('active')
            this.tabTwo.classList.add('active')
            this.tabOne.classList.remove('active')
            this.contentOne.classList.add('tab-content--hide')
            this.contentTwo.classList.remove('tab-content--hide')
        } else {
            console.log('context is not login')
            this.loginCopy.classList.remove('active')
            this.signUpCopy.classList.add('active')
            this.tabTwo.classList.remove('active')
            this.tabOne.classList.add('active')
            this.contentOne.classList.remove('tab-content--hide')
            this.contentTwo.classList.add('tab-content--hide')
        }

        this.initialiseLoginTab()

    }

    initialiseLoginTab() {

        // tab one is sign up
        // tab two is login
        const tabOne = this.tabOne
        const tabTwo = this.tabTwo
        const conOne = this.contentOne
        const conTwo = this.contentTwo

        tabOne.addEventListener('click', () => {
            this.loginCopy.classList.remove('active')
            this.signUpCopy.classList.add('active')
            tabOne.classList.add('active')
            tabTwo.classList.remove('active')
            conTwo.classList.add('tab-content--hide')
            conOne.classList.remove('tab-content--hide')
        })

        tabTwo.addEventListener('click', () => {
            this.loginCopy.classList.add('active')
            this.signUpCopy.classList.remove('active')
            tabOne.classList.remove('active')
            tabTwo.classList.add('active')
            conTwo.classList.remove('tab-content--hide')
            conOne.classList.add('tab-content--hide')
        })
    }

}

customElements.define('login-tab', LoginTab)