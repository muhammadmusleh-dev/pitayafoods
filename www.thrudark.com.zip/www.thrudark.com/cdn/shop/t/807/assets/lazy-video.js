class LazyVideo {
    constructor() {
        this.lazyVideoEls = document.querySelectorAll('[data-lazy-video]')

        if (this.lazyVideoEls.length === 0) return

        this.setupListeners()
    }

    setupListeners() {
        // Lazy load videos
        document.addEventListener('DOMContentLoaded', () => {
            // eslint-disable-next-line compat/compat
            const lazyVideoObserver = new IntersectionObserver(
                (entries, observer) => {
                    entries.forEach(video => {
                        if (video.isIntersecting) {
                            const lazyVideoEl = video.target

                            for (const source in lazyVideoEl.children) {
                                const videoSource = lazyVideoEl.children[source]
                                if (
                                    typeof videoSource.tagName === 'string' &&
                                    videoSource.tagName === 'SOURCE'
                                ) {
                                    videoSource.src = videoSource.dataset.src
                                }
                            }
                            lazyVideoEl.load()
                            lazyVideoObserver.unobserve(lazyVideoEl)
                            lazyVideoEl.classList.add('util-LazyVideo-loaded')

                            if (
                                window.innerWidth > 768 ||
                                lazyVideoEl.hasAttribute('autoplay') === false
                            )
                                return

                            if (lazyVideoEl.paused) {
                                document.addEventListener('touchstart', () => {
                                    if (lazyVideoEl.paused) {
                                        lazyVideoEl.play()
                                    }
                                })
                            }
                        }
                    })
                },
            )

            this.lazyVideoEls.forEach(lazyVideo => {
                lazyVideoObserver.observe(lazyVideo)
            })
        })
    }
}

window.BAO.lazyVideo = new LazyVideo()