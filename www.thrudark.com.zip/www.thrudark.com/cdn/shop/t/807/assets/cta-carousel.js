// eslint-disable-next-line import/no-unresolved
import KeenSlider from 'https://cdn.skypack.dev/keen-slider@5.5.1'

if (!customElements.get('cta-carousel')) {
    customElements.define(
        'cta-carousel',
        class CtaCarousel extends window.BAO.CustomElement {
            constructor() {
                super()

                if (this.els.slide.elements.length < 2) return

                this.carousel = this.initialiseCarousel()
            }

            initialiseCarousel() {
                if (this.els.slide.elements.length > 3) {
                    this.els.slides.element.setAttribute(
                        'data-custom-cursor-external-el',
                        'carousel',
                    )
                }

                return new KeenSlider(this.els.slides.element, {
                    duration: 1000,
                    mode: 'snap',
                    slidesPerView: 1.3,
                    slides: '.car-Carousel_Slide',
                    spacing: 15,
                    breakpoints: {
                        '(min-width: 768px)': {
                            centered: true,
                            loop: true,
                            mode: 'snap',
                            slidesPerView: 2.1,
                            spacing: 30,
                        },
                        '(min-width: 900px)': {
                            centered: true,
                            loop: true,
                            mode: 'snap',
                            slidesPerView: 3.2,
                            spacing: 30,
                        },
                    },
                    move: instance => {
                        this.els.slide.elements.forEach((slide, index) => {
                            slide.setAttribute(
                                'aria-hidden',
                                index !== instance.details().relativeSlide,
                            )
                        })
                    },
                    created: instance => {
                        this.els.dot.elements.forEach(dot => {
                            dot.addEventListener('click', () => {
                                instance.moveToSlide(dot.dataset.slide)
                            })
                        })
                    },
                    slideChanged: instance => {
                        this.els.dot.elements.forEach(dot => {
                            dot.setAttribute(
                                'aria-current',
                                parseInt(dot.dataset.slide) === instance.details().relativeSlide,
                            )
                        })
                    },
                })
            }
        },
    )
}