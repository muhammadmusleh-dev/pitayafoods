try {
    (() => {
        var t = {
                9302: function(t, e, r) {
                    var n, i;
                    n = 0, i = function() {
                        var t = t || function(t, e) {
                            if ("undefined" != typeof window && window.crypto && (n = window.crypto), "undefined" != typeof self && self.crypto && (n = self.crypto), "undefined" != typeof globalThis && globalThis.crypto && (n = globalThis.crypto), !n && "undefined" != typeof window && window.msCrypto && (n = window.msCrypto), !n && void 0 !== r.g && r.g.crypto && (n = r.g.crypto), !n) try {
                                n = r(4882)
                            } catch (t) {}
                            var n, i = function() {
                                    if (n) {
                                        if ("function" == typeof n.getRandomValues) try {
                                            return n.getRandomValues(new Uint32Array(1))[0]
                                        } catch (t) {}
                                        if ("function" == typeof n.randomBytes) try {
                                            return n.randomBytes(4).readInt32LE()
                                        } catch (t) {}
                                    }
                                    throw Error("Native crypto module could not be used to get secure random number.")
                                },
                                o = Object.create || function() {
                                    function t() {}
                                    return function(e) {
                                        var r;
                                        return t.prototype = e, r = new t, t.prototype = null, r
                                    }
                                }(),
                                s = {},
                                a = s.lib = {},
                                c = a.Base = {
                                    extend: function(t) {
                                        var e = o(this);
                                        return t && e.mixIn(t), (!e.hasOwnProperty("init") || this.init === e.init) && (e.init = function() {
                                            e.$super.init.apply(this, arguments)
                                        }), e.init.prototype = e, e.$super = this, e
                                    },
                                    create: function() {
                                        var t = this.extend();
                                        return t.init.apply(t, arguments), t
                                    },
                                    init: function() {},
                                    mixIn: function(t) {
                                        for (var e in t) t.hasOwnProperty(e) && (this[e] = t[e]);
                                        t.hasOwnProperty("toString") && (this.toString = t.toString)
                                    },
                                    clone: function() {
                                        return this.init.prototype.extend(this)
                                    }
                                },
                                u = a.WordArray = c.extend({
                                    init: function(t, r) {
                                        t = this.words = t || [], e != r ? this.sigBytes = r : this.sigBytes = 4 * t.length
                                    },
                                    toString: function(t) {
                                        return (t || l).stringify(this)
                                    },
                                    concat: function(t) {
                                        var e = this.words,
                                            r = t.words,
                                            n = this.sigBytes,
                                            i = t.sigBytes;
                                        if (this.clamp(), n % 4)
                                            for (var o = 0; o < i; o++) {
                                                var s = r[o >>> 2] >>> 24 - o % 4 * 8 & 255;
                                                e[n + o >>> 2] |= s << 24 - (n + o) % 4 * 8
                                            } else
                                                for (var a = 0; a < i; a += 4) e[n + a >>> 2] = r[a >>> 2];
                                        return this.sigBytes += i, this
                                    },
                                    clamp: function() {
                                        var e = this.words,
                                            r = this.sigBytes;
                                        e[r >>> 2] &= 4294967295 << 32 - r % 4 * 8, e.length = t.ceil(r / 4)
                                    },
                                    clone: function() {
                                        var t = c.clone.call(this);
                                        return t.words = this.words.slice(0), t
                                    },
                                    random: function(t) {
                                        for (var e = [], r = 0; r < t; r += 4) e.push(i());
                                        return new u.init(e, t)
                                    }
                                }),
                                f = s.enc = {},
                                l = f.Hex = {
                                    stringify: function(t) {
                                        for (var e = t.words, r = t.sigBytes, n = [], i = 0; i < r; i++) {
                                            var o = e[i >>> 2] >>> 24 - i % 4 * 8 & 255;
                                            n.push((o >>> 4).toString(16)), n.push((15 & o).toString(16))
                                        }
                                        return n.join("")
                                    },
                                    parse: function(t) {
                                        for (var e = t.length, r = [], n = 0; n < e; n += 2) r[n >>> 3] |= parseInt(t.substr(n, 2), 16) << 24 - n % 8 * 4;
                                        return new u.init(r, e / 2)
                                    }
                                },
                                p = f.Latin1 = {
                                    stringify: function(t) {
                                        for (var e = t.words, r = t.sigBytes, n = [], i = 0; i < r; i++) {
                                            var o = e[i >>> 2] >>> 24 - i % 4 * 8 & 255;
                                            n.push(String.fromCharCode(o))
                                        }
                                        return n.join("")
                                    },
                                    parse: function(t) {
                                        for (var e = t.length, r = [], n = 0; n < e; n++) r[n >>> 2] |= (255 & t.charCodeAt(n)) << 24 - n % 4 * 8;
                                        return new u.init(r, e)
                                    }
                                },
                                d = f.Utf8 = {
                                    stringify: function(t) {
                                        try {
                                            return decodeURIComponent(escape(p.stringify(t)))
                                        } catch (t) {
                                            throw Error("Malformed UTF-8 data")
                                        }
                                    },
                                    parse: function(t) {
                                        return p.parse(unescape(encodeURIComponent(t)))
                                    }
                                },
                                h = a.BufferedBlockAlgorithm = c.extend({
                                    reset: function() {
                                        this._data = new u.init, this._nDataBytes = 0
                                    },
                                    _append: function(t) {
                                        "string" == typeof t && (t = d.parse(t)), this._data.concat(t), this._nDataBytes += t.sigBytes
                                    },
                                    _process: function(e) {
                                        var r, n = this._data,
                                            i = n.words,
                                            o = n.sigBytes,
                                            s = this.blockSize,
                                            a = o / (4 * s),
                                            c = (a = e ? t.ceil(a) : t.max((0 | a) - this._minBufferSize, 0)) * s,
                                            f = t.min(4 * c, o);
                                        if (c) {
                                            for (var l = 0; l < c; l += s) this._doProcessBlock(i, l);
                                            r = i.splice(0, c), n.sigBytes -= f
                                        }
                                        return new u.init(r, f)
                                    },
                                    clone: function() {
                                        var t = c.clone.call(this);
                                        return t._data = this._data.clone(), t
                                    },
                                    _minBufferSize: 0
                                });
                            a.Hasher = h.extend({
                                cfg: c.extend(),
                                init: function(t) {
                                    this.cfg = this.cfg.extend(t), this.reset()
                                },
                                reset: function() {
                                    h.reset.call(this), this._doReset()
                                },
                                update: function(t) {
                                    return this._append(t), this._process(), this
                                },
                                finalize: function(t) {
                                    return t && this._append(t), this._doFinalize()
                                },
                                blockSize: 16,
                                _createHelper: function(t) {
                                    return function(e, r) {
                                        return new t.init(r).finalize(e)
                                    }
                                },
                                _createHmacHelper: function(t) {
                                    return function(e, r) {
                                        return new v.HMAC.init(t, r).finalize(e)
                                    }
                                }
                            });
                            var v = s.algo = {};
                            return s
                        }(Math);
                        return t
                    }, t.exports = i()
                },
                7674: function(t, e, r) {
                    var n, i;
                    n = 0, i = function(t) {
                        var e, r, n, i, o, s, a, c, u;
                        return e = Math, n = (r = t.lib).WordArray, i = r.Hasher, o = t.algo, s = [], a = [],
                            function() {
                                function t(t) {
                                    return (t - (0 | t)) * 4294967296 | 0
                                }
                                for (var r = 2, n = 0; n < 64;)(function(t) {
                                    for (var r = e.sqrt(t), n = 2; n <= r; n++)
                                        if (!(t % n)) return !1;
                                    return !0
                                })(r) && (n < 8 && (s[n] = t(e.pow(r, .5))), a[n] = t(e.pow(r, 1 / 3)), n++), r++
                            }(), c = [], u = o.SHA256 = i.extend({
                                _doReset: function() {
                                    this._hash = new n.init(s.slice(0))
                                },
                                _doProcessBlock: function(t, e) {
                                    for (var r = this._hash.words, n = r[0], i = r[1], o = r[2], s = r[3], u = r[4], f = r[5], l = r[6], p = r[7], d = 0; d < 64; d++) {
                                        if (d < 16) c[d] = 0 | t[e + d];
                                        else {
                                            var h = c[d - 15],
                                                v = (h << 25 | h >>> 7) ^ (h << 14 | h >>> 18) ^ h >>> 3,
                                                g = c[d - 2],
                                                _ = (g << 15 | g >>> 17) ^ (g << 13 | g >>> 19) ^ g >>> 10;
                                            c[d] = v + c[d - 7] + _ + c[d - 16]
                                        }
                                        var I = u & f ^ ~u & l,
                                            y = n & i ^ n & o ^ i & o,
                                            m = (n << 30 | n >>> 2) ^ (n << 19 | n >>> 13) ^ (n << 10 | n >>> 22),
                                            b = (u << 26 | u >>> 6) ^ (u << 21 | u >>> 11) ^ (u << 7 | u >>> 25),
                                            S = p + b + I + a[d] + c[d],
                                            E = m + y;
                                        p = l, l = f, f = u, u = s + S | 0, s = o, o = i, i = n, n = S + E | 0
                                    }
                                    r[0] = r[0] + n | 0, r[1] = r[1] + i | 0, r[2] = r[2] + o | 0, r[3] = r[3] + s | 0, r[4] = r[4] + u | 0, r[5] = r[5] + f | 0, r[6] = r[6] + l | 0, r[7] = r[7] + p | 0
                                },
                                _doFinalize: function() {
                                    var t = this._data,
                                        r = t.words,
                                        n = 8 * this._nDataBytes,
                                        i = 8 * t.sigBytes;
                                    return r[i >>> 5] |= 128 << 24 - i % 32, r[(i + 64 >>> 9 << 4) + 14] = e.floor(n / 4294967296), r[(i + 64 >>> 9 << 4) + 15] = n, t.sigBytes = 4 * r.length, this._process(), this._hash
                                },
                                clone: function() {
                                    var t = i.clone.call(this);
                                    return t._hash = this._hash.clone(), t
                                }
                            }), t.SHA256 = i._createHelper(u), t.HmacSHA256 = i._createHmacHelper(u), t.SHA256
                    }, t.exports = i(r(9302))
                },
                3462: function() {},
                4882: function() {},
                5080: function(t, e, r) {
                    t.exports = r(7500)
                },
                2443: function(t, e, r) {
                    t.exports = r(4761)
                },
                4738: function(t, e, r) {
                    t.exports = r(2514)
                },
                4269: function(t, e, r) {
                    var n = r(4738);

                    function i(t, e, r, i, o, s, a) {
                        try {
                            var c = t[s](a),
                                u = c.value
                        } catch (t) {
                            r(t);
                            return
                        }
                        c.done ? e(u) : n.resolve(u).then(i, o)
                    }
                    t.exports = function(t) {
                        return function() {
                            var e = this,
                                r = arguments;
                            return new n(function(n, o) {
                                var s = t.apply(e, r);

                                function a(t) {
                                    i(s, n, o, a, c, "next", t)
                                }

                                function c(t) {
                                    i(s, n, o, a, c, "throw", t)
                                }
                                a(void 0)
                            })
                        }
                    }, t.exports.__esModule = !0, t.exports.default = t.exports
                },
                7227: function(t, e, r) {
                    var n = r(2443),
                        i = r(5080);

                    function o() {
                        return t.exports = o = n ? i(n).call(n) : function(t) {
                            for (var e = 1; e < arguments.length; e++) {
                                var r = arguments[e];
                                for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (t[n] = r[n])
                            }
                            return t
                        }, t.exports.__esModule = !0, t.exports.default = t.exports, o.apply(this, arguments)
                    }
                    t.exports = o, t.exports.__esModule = !0, t.exports.default = t.exports
                },
                7107: function(t, e, r) {
                    "use strict";
                    var n = r(4168);
                    t.exports = n
                },
                7771: function(t, e, r) {
                    "use strict";
                    var n = r(2206);
                    t.exports = n
                },
                2433: function(t, e, r) {
                    "use strict";
                    var n = r(9392);
                    r(4716), r(5320), t.exports = n
                },
                1061: function(t, e, r) {
                    "use strict";
                    r(2644);
                    var n = r(817);
                    t.exports = n("Array", "includes")
                },
                8066: function(t, e, r) {
                    "use strict";
                    r(7985);
                    var n = r(817);
                    t.exports = n("Array", "push")
                },
                9297: function(t, e, r) {
                    "use strict";
                    r(8813);
                    var n = r(817);
                    t.exports = n("Array", "reduce")
                },
                52: function(t, e, r) {
                    "use strict";
                    r(6498);
                    var n = r(817);
                    t.exports = n("Function", "bind")
                },
                8612: function(t, e, r) {
                    "use strict";
                    r(4182), t.exports = r(5017)
                },
                7225: function(t, e, r) {
                    "use strict";
                    var n = r(5040),
                        i = r(52),
                        o = Function.prototype;
                    t.exports = function(t) {
                        var e = t.bind;
                        return t === o || n(o, t) && e === o.bind ? i : e
                    }
                },
                8411: function(t, e, r) {
                    "use strict";
                    var n = r(5040),
                        i = r(1061),
                        o = r(6495),
                        s = Array.prototype,
                        a = String.prototype;
                    t.exports = function(t) {
                        var e = t.includes;
                        return t === s || n(s, t) && e === s.includes ? i : "string" == typeof t || t === a || n(a, t) && e === a.includes ? o : e
                    }
                },
                8606: function(t, e, r) {
                    "use strict";
                    var n = r(5040),
                        i = r(8066),
                        o = Array.prototype;
                    t.exports = function(t) {
                        var e = t.push;
                        return t === o || n(o, t) && e === o.push ? i : e
                    }
                },
                2862: function(t, e, r) {
                    "use strict";
                    var n = r(5040),
                        i = r(9297),
                        o = Array.prototype;
                    t.exports = function(t) {
                        var e = t.reduce;
                        return t === o || n(o, t) && e === o.reduce ? i : e
                    }
                },
                733: function(t, e, r) {
                    "use strict";
                    var n = r(5040),
                        i = r(3591),
                        o = String.prototype;
                    t.exports = function(t) {
                        var e = t.trim;
                        return "string" == typeof t || t === o || n(o, t) && e === o.trim ? i : e
                    }
                },
                3437: function(t, e, r) {
                    "use strict";
                    r(244);
                    var n = r(5236);
                    t.exports = n.Object.assign
                },
                6951: function(t, e, r) {
                    "use strict";
                    r(6092);
                    var n = r(5236);
                    t.exports = n.Object.entries
                },
                8640: function(t, e, r) {
                    "use strict";
                    r(7300), r(6809), r(8318), r(1190), r(3998);
                    var n = r(5568),
                        i = r(309),
                        o = r(5236).Promise,
                        s = o.allSettled;
                    t.exports = function(t) {
                        return n(s, i(this) ? this : o, t)
                    }
                },
                6670: function(t, e, r) {
                    "use strict";
                    r(370), r(7300), r(6809), r(8318), r(1190), r(1402), r(6242), r(5581), r(3998);
                    var n = r(5236);
                    t.exports = n.Promise
                },
                6495: function(t, e, r) {
                    "use strict";
                    r(4857);
                    var n = r(817);
                    t.exports = n("String", "includes")
                },
                3591: function(t, e, r) {
                    "use strict";
                    r(2896);
                    var n = r(817);
                    t.exports = n("String", "trim")
                },
                7500: function(t, e, r) {
                    "use strict";
                    t.exports = r(8384)
                },
                4761: function(t, e, r) {
                    "use strict";
                    t.exports = r(2786)
                },
                2514: function(t, e, r) {
                    "use strict";
                    t.exports = r(517)
                },
                8384: function(t, e, r) {
                    "use strict";
                    var n = r(7107);
                    t.exports = n
                },
                2786: function(t, e, r) {
                    "use strict";
                    var n = r(7771);
                    t.exports = n
                },
                517: function(t, e, r) {
                    "use strict";
                    var n = r(2433);
                    r(398), r(4644), r(856), t.exports = n
                },
                5168: function(t, e, r) {
                    "use strict";
                    var n = r(309),
                        i = r(1024),
                        o = TypeError;
                    t.exports = function(t) {
                        if (n(t)) return t;
                        throw new o(i(t) + " is not a function")
                    }
                },
                3900: function(t, e, r) {
                    "use strict";
                    var n = r(5835),
                        i = r(1024),
                        o = TypeError;
                    t.exports = function(t) {
                        if (n(t)) return t;
                        throw new o(i(t) + " is not a constructor")
                    }
                },
                6211: function(t, e, r) {
                    "use strict";
                    var n = r(7979),
                        i = String,
                        o = TypeError;
                    t.exports = function(t) {
                        if (n(t)) return t;
                        throw new o("Can't set " + i(t) + " as a prototype")
                    }
                },
                4809: function(t) {
                    "use strict";
                    t.exports = function() {}
                },
                3893: function(t, e, r) {
                    "use strict";
                    var n = r(5040),
                        i = TypeError;
                    t.exports = function(t, e) {
                        if (n(e, t)) return t;
                        throw new i("Incorrect invocation")
                    }
                },
                1985: function(t, e, r) {
                    "use strict";
                    var n = r(3054),
                        i = String,
                        o = TypeError;
                    t.exports = function(t) {
                        if (n(t)) return t;
                        throw new o(i(t) + " is not an object")
                    }
                },
                7868: function(t, e, r) {
                    "use strict";
                    var n = r(4259),
                        i = r(3299),
                        o = r(3934),
                        s = function(t) {
                            return function(e, r, s) {
                                var a, c = n(e),
                                    u = o(c);
                                if (0 === u) return !t && -1;
                                var f = i(s, u);
                                if (t && r != r) {
                                    for (; u > f;)
                                        if ((a = c[f++]) != a) return !0
                                } else
                                    for (; u > f; f++)
                                        if ((t || f in c) && c[f] === r) return t || f || 0;
                                return !t && -1
                            }
                        };
                    t.exports = {
                        includes: s(!0),
                        indexOf: s(!1)
                    }
                },
                2339: function(t, e, r) {
                    "use strict";
                    var n = r(2280);
                    t.exports = function(t, e) {
                        var r = [][t];
                        return !!r && n(function() {
                            r.call(null, e || function() {
                                return 1
                            }, 1)
                        })
                    }
                },
                4090: function(t, e, r) {
                    "use strict";
                    var n = r(5168),
                        i = r(6707),
                        o = r(9110),
                        s = r(3934),
                        a = TypeError,
                        c = "Reduce of empty array with no initial value",
                        u = function(t) {
                            return function(e, r, u, f) {
                                var l = i(e),
                                    p = o(l),
                                    d = s(l);
                                if (n(r), 0 === d && u < 2) throw new a(c);
                                var h = t ? d - 1 : 0,
                                    v = t ? -1 : 1;
                                if (u < 2)
                                    for (;;) {
                                        if (h in p) {
                                            f = p[h], h += v;
                                            break
                                        }
                                        if (h += v, t ? h < 0 : d <= h) throw new a(c)
                                    }
                                for (; t ? h >= 0 : d > h; h += v) h in p && (f = r(f, p[h], h, l));
                                return f
                            }
                        };
                    t.exports = {
                        left: u(!1),
                        right: u(!0)
                    }
                },
                296: function(t, e, r) {
                    "use strict";
                    var n = r(5562),
                        i = r(9996),
                        o = TypeError,
                        s = Object.getOwnPropertyDescriptor,
                        a = n && ! function() {
                            if (void 0 !== this) return !0;
                            try {
                                Object.defineProperty([], "length", {
                                    writable: !1
                                }).length = 1
                            } catch (t) {
                                return t instanceof TypeError
                            }
                        }();
                    t.exports = a ? function(t, e) {
                        if (i(t) && !s(t, "length").writable) throw new o("Cannot set read only .length");
                        return t.length = e
                    } : function(t, e) {
                        return t.length = e
                    }
                },
                7514: function(t, e, r) {
                    "use strict";
                    var n = r(1335);
                    t.exports = n([].slice)
                },
                1314: function(t, e, r) {
                    "use strict";
                    var n = r(5737)("iterator"),
                        i = !1;
                    try {
                        var o = 0,
                            s = {
                                next: function() {
                                    return {
                                        done: !!o++
                                    }
                                },
                                return: function() {
                                    i = !0
                                }
                            };
                        s[n] = function() {
                            return this
                        }, Array.from(s, function() {
                            throw 2
                        })
                    } catch (t) {}
                    t.exports = function(t, e) {
                        try {
                            if (!e && !i) return !1
                        } catch (t) {
                            return !1
                        }
                        var r = !1;
                        try {
                            var o = {};
                            o[n] = function() {
                                return {
                                    next: function() {
                                        return {
                                            done: r = !0
                                        }
                                    }
                                }
                            }, t(o)
                        } catch (t) {}
                        return r
                    }
                },
                6684: function(t, e, r) {
                    "use strict";
                    var n = r(1335),
                        i = n({}.toString),
                        o = n("".slice);
                    t.exports = function(t) {
                        return o(i(t), 8, -1)
                    }
                },
                4362: function(t, e, r) {
                    "use strict";
                    var n = r(6630),
                        i = r(309),
                        o = r(6684),
                        s = r(5737)("toStringTag"),
                        a = Object,
                        c = "Arguments" === o(function() {
                            return arguments
                        }()),
                        u = function(t, e) {
                            try {
                                return t[e]
                            } catch (t) {}
                        };
                    t.exports = n ? o : function(t) {
                        var e, r, n;
                        return void 0 === t ? "Undefined" : null === t ? "Null" : "string" == typeof(r = u(e = a(t), s)) ? r : c ? o(e) : "Object" === (n = o(e)) && i(e.callee) ? "Arguments" : n
                    }
                },
                9634: function(t, e, r) {
                    "use strict";
                    var n = r(1615),
                        i = r(6026),
                        o = r(788),
                        s = r(8250);
                    t.exports = function(t, e, r) {
                        for (var a = i(e), c = s.f, u = o.f, f = 0; f < a.length; f++) {
                            var l = a[f];
                            !n(t, l) && !(r && n(r, l)) && c(t, l, u(e, l))
                        }
                    }
                },
                8634: function(t, e, r) {
                    "use strict";
                    var n = r(5737)("match");
                    t.exports = function(t) {
                        var e = /./;
                        try {
                            "/./" [t](e)
                        } catch (r) {
                            try {
                                return e[n] = !1, "/./" [t](e)
                            } catch (t) {}
                        }
                        return !1
                    }
                },
                6034: function(t, e, r) {
                    "use strict";
                    var n = r(2280);
                    t.exports = !n(function() {
                        function t() {}
                        return t.prototype.constructor = null, Object.getPrototypeOf(new t) !== t.prototype
                    })
                },
                6616: function(t) {
                    "use strict";
                    t.exports = function(t, e) {
                        return {
                            value: t,
                            done: e
                        }
                    }
                },
                5245: function(t, e, r) {
                    "use strict";
                    var n = r(5562),
                        i = r(8250),
                        o = r(3067);
                    t.exports = n ? function(t, e, r) {
                        return i.f(t, e, o(1, r))
                    } : function(t, e, r) {
                        return t[e] = r, t
                    }
                },
                3067: function(t) {
                    "use strict";
                    t.exports = function(t, e) {
                        return {
                            enumerable: !(1 & t),
                            configurable: !(2 & t),
                            writable: !(4 & t),
                            value: e
                        }
                    }
                },
                5269: function(t, e, r) {
                    "use strict";
                    var n = r(8250);
                    t.exports = function(t, e, r) {
                        return n.f(t, e, r)
                    }
                },
                9491: function(t, e, r) {
                    "use strict";
                    var n = r(5245);
                    t.exports = function(t, e, r, i) {
                        return i && i.enumerable ? t[e] = r : n(t, e, r), t
                    }
                },
                4945: function(t, e, r) {
                    "use strict";
                    var n = r(5017),
                        i = Object.defineProperty;
                    t.exports = function(t, e) {
                        try {
                            i(n, t, {
                                value: e,
                                configurable: !0,
                                writable: !0
                            })
                        } catch (r) {
                            n[t] = e
                        }
                        return e
                    }
                },
                5562: function(t, e, r) {
                    "use strict";
                    var n = r(2280);
                    t.exports = !n(function() {
                        return 7 !== Object.defineProperty({}, 1, {
                            get: function() {
                                return 7
                            }
                        })[1]
                    })
                },
                4155: function(t, e, r) {
                    "use strict";
                    var n = r(5017),
                        i = r(3054),
                        o = n.document,
                        s = i(o) && i(o.createElement);
                    t.exports = function(t) {
                        return s ? o.createElement(t) : {}
                    }
                },
                3385: function(t) {
                    "use strict";
                    var e = TypeError;
                    t.exports = function(t) {
                        if (t > 9007199254740991) throw e("Maximum allowed index exceeded");
                        return t
                    }
                },
                2: function(t) {
                    "use strict";
                    t.exports = {
                        CSSRuleList: 0,
                        CSSStyleDeclaration: 0,
                        CSSValueList: 0,
                        ClientRectList: 0,
                        DOMRectList: 0,
                        DOMStringList: 0,
                        DOMTokenList: 1,
                        DataTransferItemList: 0,
                        FileList: 0,
                        HTMLAllCollection: 0,
                        HTMLCollection: 0,
                        HTMLFormElement: 0,
                        HTMLSelectElement: 0,
                        MediaList: 0,
                        MimeTypeArray: 0,
                        NamedNodeMap: 0,
                        NodeList: 1,
                        PaintRequestList: 0,
                        Plugin: 0,
                        PluginArray: 0,
                        SVGLengthList: 0,
                        SVGNumberList: 0,
                        SVGPathSegList: 0,
                        SVGPointList: 0,
                        SVGStringList: 0,
                        SVGTransformList: 0,
                        SourceBufferList: 0,
                        StyleSheetList: 0,
                        TextTrackCueList: 0,
                        TextTrackList: 0,
                        TouchList: 0
                    }
                },
                7681: function(t) {
                    "use strict";
                    t.exports = ["constructor", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "toLocaleString", "toString", "valueOf"]
                },
                7176: function(t, e, r) {
                    "use strict";
                    var n = r(3545);
                    t.exports = /ipad|iphone|ipod/i.test(n) && "undefined" != typeof Pebble
                },
                3171: function(t, e, r) {
                    "use strict";
                    var n = r(3545);
                    t.exports = /(?:ipad|iphone|ipod).*applewebkit/i.test(n)
                },
                7238: function(t, e, r) {
                    "use strict";
                    var n = r(5285);
                    t.exports = "NODE" === n
                },
                6481: function(t, e, r) {
                    "use strict";
                    var n = r(3545);
                    t.exports = /web0s(?!.*chrome)/i.test(n)
                },
                3545: function(t, e, r) {
                    "use strict";
                    var n = r(5017).navigator,
                        i = n && n.userAgent;
                    t.exports = i ? String(i) : ""
                },
                1898: function(t, e, r) {
                    "use strict";
                    var n, i, o = r(5017),
                        s = r(3545),
                        a = o.process,
                        c = o.Deno,
                        u = a && a.versions || c && c.version,
                        f = u && u.v8;
                    f && (i = (n = f.split("."))[0] > 0 && n[0] < 4 ? 1 : +(n[0] + n[1])), !i && s && (!(n = s.match(/Edge\/(\d+)/)) || n[1] >= 74) && (n = s.match(/Chrome\/(\d+)/)) && (i = +n[1]), t.exports = i
                },
                5285: function(t, e, r) {
                    "use strict";
                    var n = r(5017),
                        i = r(3545),
                        o = r(6684),
                        s = function(t) {
                            return i.slice(0, t.length) === t
                        };
                    t.exports = s("Bun/") ? "BUN" : s("Cloudflare-Workers") ? "CLOUDFLARE" : s("Deno/") ? "DENO" : s("Node.js/") ? "NODE" : n.Bun && "string" == typeof Bun.version ? "BUN" : n.Deno && "object" == typeof Deno.version ? "DENO" : "process" === o(n.process) ? "NODE" : n.window && n.document ? "BROWSER" : "REST"
                },
                4549: function(t, e, r) {
                    "use strict";
                    var n, i = r(1335),
                        o = Error,
                        s = i("".replace);
                    var a = (n = "zxcasd", String(new o(n).stack)),
                        c = /\n\s*at [^:]*:[^\n]*/,
                        u = c.test(a);
                    t.exports = function(t, e) {
                        if (u && "string" == typeof t && !o.prepareStackTrace)
                            for (; e--;) t = s(t, c, "");
                        return t
                    }
                },
                1441: function(t, e, r) {
                    "use strict";
                    var n = r(5245),
                        i = r(4549),
                        o = r(7031),
                        s = Error.captureStackTrace;
                    t.exports = function(t, e, r, a) {
                        o && (s ? s(t, e) : n(t, "stack", i(r, a)))
                    }
                },
                7031: function(t, e, r) {
                    "use strict";
                    var n = r(2280),
                        i = r(3067);
                    t.exports = !n(function() {
                        var t = Error("a");
                        return !("stack" in t) || (Object.defineProperty(t, "stack", i(1, 7)), 7 !== t.stack)
                    })
                },
                5633: function(t, e, r) {
                    "use strict";
                    var n = r(5017),
                        i = r(5473),
                        o = r(3102),
                        s = r(309),
                        a = r(788).f,
                        c = r(9118),
                        u = r(5236),
                        f = r(9141),
                        l = r(5245),
                        p = r(1615);
                    r(1258);
                    var d = function(t) {
                        var e = function(r, n, o) {
                            if (this instanceof e) {
                                switch (arguments.length) {
                                    case 0:
                                        return new t;
                                    case 1:
                                        return new t(r);
                                    case 2:
                                        return new t(r, n)
                                }
                                return new t(r, n, o)
                            }
                            return i(t, this, arguments)
                        };
                        return e.prototype = t.prototype, e
                    };
                    t.exports = function(t, e) {
                        var r, i, h, v, g, _, I, y, m, b = t.target,
                            S = t.global,
                            E = t.stat,
                            x = t.proto,
                            O = S ? n : E ? n[b] : n[b] && n[b].prototype,
                            T = S ? u : u[b] || l(u, b, {})[b],
                            R = T.prototype;
                        for (v in e) i = !(r = c(S ? v : b + (E ? "." : "#") + v, t.forced)) && O && p(O, v), _ = T[v], i && (I = t.dontCallGetSet ? (m = a(O, v)) && m.value : O[v]), g = i && I ? I : e[v], (r || x || typeof _ != typeof g) && (y = t.bind && i ? f(g, n) : t.wrap && i ? d(g) : x && s(g) ? o(g) : g, (t.sham || g && g.sham || _ && _.sham) && l(y, "sham", !0), l(T, v, y), x && (h = b + "Prototype", !p(u, h) && l(u, h, {}), l(u[h], v, g), t.real && R && (r || !R[v]) && l(R, v, g)))
                    }
                },
                2280: function(t) {
                    "use strict";
                    t.exports = function(t) {
                        try {
                            return !!t()
                        } catch (t) {
                            return !0
                        }
                    }
                },
                5473: function(t, e, r) {
                    "use strict";
                    var n = r(7364),
                        i = Function.prototype,
                        o = i.apply,
                        s = i.call;
                    t.exports = "object" == typeof Reflect && Reflect.apply || (n ? s.bind(o) : function() {
                        return s.apply(o, arguments)
                    })
                },
                9141: function(t, e, r) {
                    "use strict";
                    var n = r(3102),
                        i = r(5168),
                        o = r(7364),
                        s = n(n.bind);
                    t.exports = function(t, e) {
                        return i(t), void 0 === e ? t : o ? s(t, e) : function() {
                            return t.apply(e, arguments)
                        }
                    }
                },
                7364: function(t, e, r) {
                    "use strict";
                    var n = r(2280);
                    t.exports = !n(function() {
                        var t = (function() {}).bind();
                        return "function" != typeof t || t.hasOwnProperty("prototype")
                    })
                },
                8683: function(t, e, r) {
                    "use strict";
                    var n = r(1335),
                        i = r(5168),
                        o = r(3054),
                        s = r(1615),
                        a = r(7514),
                        c = r(7364),
                        u = Function,
                        f = n([].concat),
                        l = n([].join),
                        p = {},
                        d = function(t, e, r) {
                            if (!s(p, e)) {
                                for (var n = [], i = 0; i < e; i++) n[i] = "a[" + i + "]";
                                p[e] = u("C,a", "return new C(" + l(n, ",") + ")")
                            }
                            return p[e](t, r)
                        };
                    t.exports = c ? u.bind : function(t) {
                        var e = i(this),
                            r = e.prototype,
                            n = a(arguments, 1),
                            s = function() {
                                var r = f(n, a(arguments));
                                return this instanceof s ? d(e, r.length, r) : e.apply(t, r)
                            };
                        return o(r) && (s.prototype = r), s
                    }
                },
                5568: function(t, e, r) {
                    "use strict";
                    var n = r(7364),
                        i = Function.prototype.call;
                    t.exports = n ? i.bind(i) : function() {
                        return i.apply(i, arguments)
                    }
                },
                1020: function(t, e, r) {
                    "use strict";
                    var n = r(5562),
                        i = r(1615),
                        o = Function.prototype,
                        s = n && Object.getOwnPropertyDescriptor,
                        a = i(o, "name"),
                        c = a && (!n || n && s(o, "name").configurable);
                    t.exports = {
                        EXISTS: a,
                        PROPER: a && "something" === (function() {}).name,
                        CONFIGURABLE: c
                    }
                },
                5446: function(t, e, r) {
                    "use strict";
                    var n = r(1335),
                        i = r(5168);
                    t.exports = function(t, e, r) {
                        try {
                            return n(i(Object.getOwnPropertyDescriptor(t, e)[r]))
                        } catch (t) {}
                    }
                },
                3102: function(t, e, r) {
                    "use strict";
                    var n = r(6684),
                        i = r(1335);
                    t.exports = function(t) {
                        if ("Function" === n(t)) return i(t)
                    }
                },
                1335: function(t, e, r) {
                    "use strict";
                    var n = r(7364),
                        i = Function.prototype,
                        o = i.call,
                        s = n && i.bind.bind(o, o);
                    t.exports = n ? s : function(t) {
                        return function() {
                            return o.apply(t, arguments)
                        }
                    }
                },
                817: function(t, e, r) {
                    "use strict";
                    var n = r(5017),
                        i = r(5236);
                    t.exports = function(t, e) {
                        var r = i[t + "Prototype"],
                            o = r && r[e];
                        if (o) return o;
                        var s = n[t],
                            a = s && s.prototype;
                        return a && a[e]
                    }
                },
                3878: function(t, e, r) {
                    "use strict";
                    var n = r(5236),
                        i = r(5017),
                        o = r(309),
                        s = function(t) {
                            return o(t) ? t : void 0
                        };
                    t.exports = function(t, e) {
                        return arguments.length < 2 ? s(n[t]) || s(i[t]) : n[t] && n[t][e] || i[t] && i[t][e]
                    }
                },
                6782: function(t, e, r) {
                    "use strict";
                    var n = r(4362),
                        i = r(7522),
                        o = r(2190),
                        s = r(9122),
                        a = r(5737)("iterator");
                    t.exports = function(t) {
                        if (!o(t)) return i(t, a) || i(t, "@@iterator") || s[n(t)]
                    }
                },
                4801: function(t, e, r) {
                    "use strict";
                    var n = r(5568),
                        i = r(5168),
                        o = r(1985),
                        s = r(1024),
                        a = r(6782),
                        c = TypeError;
                    t.exports = function(t, e) {
                        var r = arguments.length < 2 ? a(t) : e;
                        if (i(r)) return o(n(r, t));
                        throw new c(s(t) + " is not iterable")
                    }
                },
                7522: function(t, e, r) {
                    "use strict";
                    var n = r(5168),
                        i = r(2190);
                    t.exports = function(t, e) {
                        var r = t[e];
                        return i(r) ? void 0 : n(r)
                    }
                },
                5017: function(t, e, r) {
                    "use strict";
                    var n = function(t) {
                        return t && t.Math === Math && t
                    };
                    t.exports = n("object" == typeof globalThis && globalThis) || n("object" == typeof window && window) || n("object" == typeof self && self) || n("object" == typeof r.g && r.g) || n("object" == typeof this && this) || function() {
                        return this
                    }() || Function("return this")()
                },
                1615: function(t, e, r) {
                    "use strict";
                    var n = r(1335),
                        i = r(6707),
                        o = n({}.hasOwnProperty);
                    t.exports = Object.hasOwn || function(t, e) {
                        return o(i(t), e)
                    }
                },
                9090: function(t) {
                    "use strict";
                    t.exports = {}
                },
                7504: function(t) {
                    "use strict";
                    t.exports = function(t, e) {
                        try {} catch (t) {}
                    }
                },
                7526: function(t, e, r) {
                    "use strict";
                    var n = r(3878);
                    t.exports = n("document", "documentElement")
                },
                7360: function(t, e, r) {
                    "use strict";
                    var n = r(5562),
                        i = r(2280),
                        o = r(4155);
                    t.exports = !n && !i(function() {
                        return 7 !== Object.defineProperty(o("div"), "a", {
                            get: function() {
                                return 7
                            }
                        }).a
                    })
                },
                9110: function(t, e, r) {
                    "use strict";
                    var n = r(1335),
                        i = r(2280),
                        o = r(6684),
                        s = Object,
                        a = n("".split);
                    t.exports = i(function() {
                        return !s("z").propertyIsEnumerable(0)
                    }) ? function(t) {
                        return "String" === o(t) ? a(t, "") : s(t)
                    } : s
                },
                8910: function(t, e, r) {
                    "use strict";
                    var n = r(1335),
                        i = r(309),
                        o = r(1258),
                        s = n(Function.toString);
                    !i(o.inspectSource) && (o.inspectSource = function(t) {
                        return s(t)
                    }), t.exports = o.inspectSource
                },
                9184: function(t, e, r) {
                    "use strict";
                    var n = r(3054),
                        i = r(5245);
                    t.exports = function(t, e) {
                        n(e) && "cause" in e && i(t, "cause", e.cause)
                    }
                },
                7179: function(t, e, r) {
                    "use strict";
                    var n, i, o, s = r(8402),
                        a = r(5017),
                        c = r(3054),
                        u = r(5245),
                        f = r(1615),
                        l = r(1258),
                        p = r(3137),
                        d = r(9090),
                        h = "Object already initialized",
                        v = a.TypeError,
                        g = a.WeakMap;
                    if (s || l.state) {
                        var _ = l.state || (l.state = new g);
                        _.get = _.get, _.has = _.has, _.set = _.set, n = function(t, e) {
                            if (_.has(t)) throw new v(h);
                            return e.facade = t, _.set(t, e), e
                        }, i = function(t) {
                            return _.get(t) || {}
                        }, o = function(t) {
                            return _.has(t)
                        }
                    } else {
                        var I = p("state");
                        d[I] = !0, n = function(t, e) {
                            if (f(t, I)) throw new v(h);
                            return e.facade = t, u(t, I, e), e
                        }, i = function(t) {
                            return f(t, I) ? t[I] : {}
                        }, o = function(t) {
                            return f(t, I)
                        }
                    }
                    t.exports = {
                        set: n,
                        get: i,
                        has: o,
                        enforce: function(t) {
                            return o(t) ? i(t) : n(t, {})
                        },
                        getterFor: function(t) {
                            return function(e) {
                                var r;
                                if (!c(e) || (r = i(e)).type !== t) throw new v("Incompatible receiver, " + t + " required");
                                return r
                            }
                        }
                    }
                },
                2571: function(t, e, r) {
                    "use strict";
                    var n = r(5737),
                        i = r(9122),
                        o = n("iterator"),
                        s = Array.prototype;
                    t.exports = function(t) {
                        return void 0 !== t && (i.Array === t || s[o] === t)
                    }
                },
                9996: function(t, e, r) {
                    "use strict";
                    var n = r(6684);
                    t.exports = Array.isArray || function(t) {
                        return "Array" === n(t)
                    }
                },
                309: function(t) {
                    "use strict";
                    var e = "object" == typeof document && document.all;
                    t.exports = void 0 === e && void 0 !== e ? function(t) {
                        return "function" == typeof t || t === e
                    } : function(t) {
                        return "function" == typeof t
                    }
                },
                5835: function(t, e, r) {
                    "use strict";
                    var n = r(1335),
                        i = r(2280),
                        o = r(309),
                        s = r(4362),
                        a = r(3878),
                        c = r(8910),
                        u = function() {},
                        f = a("Reflect", "construct"),
                        l = /^\s*(?:class|function)\b/,
                        p = n(l.exec),
                        d = !l.test(u),
                        h = function(t) {
                            if (!o(t)) return !1;
                            try {
                                return f(u, [], t), !0
                            } catch (t) {
                                return !1
                            }
                        },
                        v = function(t) {
                            if (!o(t)) return !1;
                            switch (s(t)) {
                                case "AsyncFunction":
                                case "GeneratorFunction":
                                case "AsyncGeneratorFunction":
                                    return !1
                            }
                            try {
                                return d || !!p(l, c(t))
                            } catch (t) {
                                return !0
                            }
                        };
                    v.sham = !0, t.exports = !f || i(function() {
                        var t;
                        return h(h.call) || !h(Object) || !h(function() {
                            t = !0
                        }) || t
                    }) ? v : h
                },
                9118: function(t, e, r) {
                    "use strict";
                    var n = r(2280),
                        i = r(309),
                        o = /#|\.prototype\./,
                        s = function(t, e) {
                            var r = c[a(t)];
                            return r === f || r !== u && (i(e) ? n(e) : !!e)
                        },
                        a = s.normalize = function(t) {
                            return String(t).replace(o, ".").toLowerCase()
                        },
                        c = s.data = {},
                        u = s.NATIVE = "N",
                        f = s.POLYFILL = "P";
                    t.exports = s
                },
                2190: function(t) {
                    "use strict";
                    t.exports = function(t) {
                        return null == t
                    }
                },
                3054: function(t, e, r) {
                    "use strict";
                    var n = r(309);
                    t.exports = function(t) {
                        return "object" == typeof t ? null !== t : n(t)
                    }
                },
                7979: function(t, e, r) {
                    "use strict";
                    var n = r(3054);
                    t.exports = function(t) {
                        return n(t) || null === t
                    }
                },
                1088: function(t) {
                    "use strict";
                    t.exports = !0
                },
                1130: function(t, e, r) {
                    "use strict";
                    var n = r(3054),
                        i = r(6684),
                        o = r(5737)("match");
                    t.exports = function(t) {
                        var e;
                        return n(t) && (void 0 !== (e = t[o]) ? !!e : "RegExp" === i(t))
                    }
                },
                4341: function(t, e, r) {
                    "use strict";
                    var n = r(3878),
                        i = r(309),
                        o = r(5040),
                        s = r(6878),
                        a = Object;
                    t.exports = s ? function(t) {
                        return "symbol" == typeof t
                    } : function(t) {
                        var e = n("Symbol");
                        return i(e) && o(e.prototype, a(t))
                    }
                },
                6639: function(t, e, r) {
                    "use strict";
                    var n = r(9141),
                        i = r(5568),
                        o = r(1985),
                        s = r(1024),
                        a = r(2571),
                        c = r(3934),
                        u = r(5040),
                        f = r(4801),
                        l = r(6782),
                        p = r(3742),
                        d = TypeError,
                        h = function(t, e) {
                            this.stopped = t, this.result = e
                        },
                        v = h.prototype;
                    t.exports = function(t, e, r) {
                        var g, _, I, y, m, b, S, E = r && r.that,
                            x = !!(r && r.AS_ENTRIES),
                            O = !!(r && r.IS_RECORD),
                            T = !!(r && r.IS_ITERATOR),
                            R = !!(r && r.INTERRUPTED),
                            P = n(e, E),
                            A = function(t) {
                                return g && p(g, "normal", t), new h(!0, t)
                            },
                            N = function(t) {
                                return x ? (o(t), R ? P(t[0], t[1], A) : P(t[0], t[1])) : R ? P(t, A) : P(t)
                            };
                        if (O) g = t.iterator;
                        else if (T) g = t;
                        else {
                            if (!(_ = l(t))) throw new d(s(t) + " is not iterable");
                            if (a(_)) {
                                for (I = 0, y = c(t); y > I; I++)
                                    if ((m = N(t[I])) && u(v, m)) return m;
                                return new h(!1)
                            }
                            g = f(t, _)
                        }
                        for (b = O ? t.next : g.next; !(S = i(b, g)).done;) {
                            try {
                                m = N(S.value)
                            } catch (t) {
                                p(g, "throw", t)
                            }
                            if ("object" == typeof m && m && u(v, m)) return m
                        }
                        return new h(!1)
                    }
                },
                3742: function(t, e, r) {
                    "use strict";
                    var n = r(5568),
                        i = r(1985),
                        o = r(7522);
                    t.exports = function(t, e, r) {
                        var s, a;
                        i(t);
                        try {
                            if (!(s = o(t, "return"))) {
                                if ("throw" === e) throw r;
                                return r
                            }
                            s = n(s, t)
                        } catch (t) {
                            a = !0, s = t
                        }
                        if ("throw" === e) throw r;
                        if (a) throw s;
                        return i(s), r
                    }
                },
                133: function(t, e, r) {
                    "use strict";
                    var n = r(9693).IteratorPrototype,
                        i = r(7546),
                        o = r(3067),
                        s = r(7592),
                        a = r(9122),
                        c = function() {
                            return this
                        };
                    t.exports = function(t, e, r, u) {
                        var f = e + " Iterator";
                        return t.prototype = i(n, {
                            next: o(+!u, r)
                        }), s(t, f, !1, !0), a[f] = c, t
                    }
                },
                4088: function(t, e, r) {
                    "use strict";
                    var n = r(5633),
                        i = r(5568),
                        o = r(1088),
                        s = r(1020),
                        a = r(309),
                        c = r(133),
                        u = r(6759),
                        f = r(3527),
                        l = r(7592),
                        p = r(5245),
                        d = r(9491),
                        h = r(5737),
                        v = r(9122),
                        g = r(9693),
                        _ = s.PROPER,
                        I = s.CONFIGURABLE,
                        y = g.IteratorPrototype,
                        m = g.BUGGY_SAFARI_ITERATORS,
                        b = h("iterator"),
                        S = "keys",
                        E = "values",
                        x = "entries",
                        O = function() {
                            return this
                        };
                    t.exports = function(t, e, r, s, h, g, T) {
                        c(r, e, s);
                        var R, P, A, N = function(t) {
                                if (t === h && L) return L;
                                if (!m && t && t in D) return D[t];
                                switch (t) {
                                    case S:
                                        return function() {
                                            return new r(this, t)
                                        };
                                    case E:
                                    case x:
                                        return function() {
                                            return new r(this, t)
                                        }
                                }
                                return function() {
                                    return new r(this)
                                }
                            },
                            C = e + " Iterator",
                            w = !1,
                            D = t.prototype,
                            k = D[b] || D["@@iterator"] || h && D[h],
                            L = !m && k || N(h),
                            M = "Array" === e && D.entries || k;
                        if (M && (R = u(M.call(new t))) !== Object.prototype && R.next && (!o && u(R) !== y && (f ? f(R, y) : !a(R[b]) && d(R, b, O)), l(R, C, !0, !0), o && (v[C] = O)), _ && h === E && k && k.name !== E && (!o && I ? p(D, "name", E) : (w = !0, L = function() {
                                return i(k, this)
                            })), h) {
                            if (P = {
                                    values: N(E),
                                    keys: g ? L : N(S),
                                    entries: N(x)
                                }, T)
                                for (A in P)(m || w || !(A in D)) && d(D, A, P[A]);
                            else n({
                                target: e,
                                proto: !0,
                                forced: m || w
                            }, P)
                        }
                        return (!o || T) && D[b] !== L && d(D, b, L, {
                            name: h
                        }), v[e] = L, P
                    }
                },
                9693: function(t, e, r) {
                    "use strict";
                    var n, i, o, s = r(2280),
                        a = r(309),
                        c = r(3054),
                        u = r(7546),
                        f = r(6759),
                        l = r(9491),
                        p = r(5737),
                        d = r(1088),
                        h = p("iterator"),
                        v = !1;
                    [].keys && (o = [].keys(), "next" in o ? (i = f(f(o))) !== Object.prototype && (n = i) : v = !0), !c(n) || s(function() {
                        var t = {};
                        return n[h].call(t) !== t
                    }) ? n = {} : d && (n = u(n)), !a(n[h]) && l(n, h, function() {
                        return this
                    }), t.exports = {
                        IteratorPrototype: n,
                        BUGGY_SAFARI_ITERATORS: v
                    }
                },
                9122: function(t) {
                    "use strict";
                    t.exports = {}
                },
                3934: function(t, e, r) {
                    "use strict";
                    var n = r(3586);
                    t.exports = function(t) {
                        return n(t.length)
                    }
                },
                6542: function(t) {
                    "use strict";
                    var e = Math.ceil,
                        r = Math.floor;
                    t.exports = Math.trunc || function(t) {
                        var n = +t;
                        return (n > 0 ? r : e)(n)
                    }
                },
                578: function(t, e, r) {
                    "use strict";
                    var n, i, o, s, a, c = r(5017),
                        u = r(461),
                        f = r(9141),
                        l = r(8151).set,
                        p = r(2962),
                        d = r(3171),
                        h = r(7176),
                        v = r(6481),
                        g = r(7238),
                        _ = c.MutationObserver || c.WebKitMutationObserver,
                        I = c.document,
                        y = c.process,
                        m = c.Promise,
                        b = u("queueMicrotask");
                    if (!b) {
                        var S = new p,
                            E = function() {
                                var t, e;
                                for (g && (t = y.domain) && t.exit(); e = S.get();) try {
                                    e()
                                } catch (t) {
                                    throw S.head && n(), t
                                }
                                t && t.enter()
                            };
                        d || g || v || !_ || !I ? !h && m && m.resolve ? ((s = m.resolve(void 0)).constructor = m, a = f(s.then, s), n = function() {
                            a(E)
                        }) : g ? n = function() {
                            y.nextTick(E)
                        } : (l = f(l, c), n = function() {
                            l(E)
                        }) : (i = !0, o = I.createTextNode(""), new _(E).observe(o, {
                            characterData: !0
                        }), n = function() {
                            o.data = i = !i
                        }), b = function(t) {
                            !S.head && n(), S.add(t)
                        }
                    }
                    t.exports = b
                },
                3441: function(t, e, r) {
                    "use strict";
                    var n = r(5168),
                        i = TypeError,
                        o = function(t) {
                            var e, r;
                            this.promise = new t(function(t, n) {
                                if (void 0 !== e || void 0 !== r) throw new i("Bad Promise constructor");
                                e = t, r = n
                            }), this.resolve = n(e), this.reject = n(r)
                        };
                    t.exports.f = function(t) {
                        return new o(t)
                    }
                },
                5732: function(t, e, r) {
                    "use strict";
                    var n = r(2952);
                    t.exports = function(t, e) {
                        return void 0 === t ? arguments.length < 2 ? "" : e : n(t)
                    }
                },
                3769: function(t, e, r) {
                    "use strict";
                    var n = r(1130),
                        i = TypeError;
                    t.exports = function(t) {
                        if (n(t)) throw new i("The method doesn't accept regular expressions");
                        return t
                    }
                },
                8268: function(t, e, r) {
                    "use strict";
                    var n = r(5562),
                        i = r(1335),
                        o = r(5568),
                        s = r(2280),
                        a = r(9340),
                        c = r(4858),
                        u = r(8571),
                        f = r(6707),
                        l = r(9110),
                        p = Object.assign,
                        d = Object.defineProperty,
                        h = i([].concat);
                    t.exports = !p || s(function() {
                        if (n && 1 !== p({
                                b: 1
                            }, p(d({}, "a", {
                                enumerable: !0,
                                get: function() {
                                    d(this, "b", {
                                        value: 3,
                                        enumerable: !1
                                    })
                                }
                            }), {
                                b: 2
                            })).b) return !0;
                        var t = {},
                            e = {},
                            r = Symbol("assign detection"),
                            i = "abcdefghijklmnopqrst";
                        return t[r] = 7, i.split("").forEach(function(t) {
                            e[t] = t
                        }), 7 !== p({}, t)[r] || a(p({}, e)).join("") !== i
                    }) ? function(t, e) {
                        for (var r = f(t), i = arguments.length, s = 1, p = c.f, d = u.f; i > s;) {
                            for (var v, g = l(arguments[s++]), _ = p ? h(a(g), p(g)) : a(g), I = _.length, y = 0; I > y;) v = _[y++], (!n || o(d, g, v)) && (r[v] = g[v])
                        }
                        return r
                    } : p
                },
                7546: function(t, e, r) {
                    "use strict";
                    var n, i = r(1985),
                        o = r(7659),
                        s = r(7681),
                        a = r(9090),
                        c = r(7526),
                        u = r(4155),
                        f = r(3137),
                        l = "prototype",
                        p = "script",
                        d = f("IE_PROTO"),
                        h = function() {},
                        v = function(t) {
                            return "<" + p + ">" + t + "</" + p + ">"
                        },
                        g = function(t) {
                            t.write(v("")), t.close();
                            var e = t.parentWindow.Object;
                            return t = null, e
                        },
                        _ = function() {
                            var t, e = u("iframe");
                            return e.style.display = "none", c.appendChild(e), e.src = String("java" + p + ":"), (t = e.contentWindow.document).open(), t.write(v("document.F=Object")), t.close(), t.F
                        },
                        I = function() {
                            try {
                                n = new ActiveXObject("htmlfile")
                            } catch (t) {}
                            I = "undefined" != typeof document ? document.domain && n ? g(n) : _() : g(n);
                            for (var t = s.length; t--;) delete I[l][s[t]];
                            return I()
                        };
                    a[d] = !0, t.exports = Object.create || function(t, e) {
                        var r;
                        return null !== t ? (h[l] = i(t), r = new h, h[l] = null, r[d] = t) : r = I(), void 0 === e ? r : o.f(r, e)
                    }
                },
                7659: function(t, e, r) {
                    "use strict";
                    var n = r(5562),
                        i = r(5622),
                        o = r(8250),
                        s = r(1985),
                        a = r(4259),
                        c = r(9340);
                    e.f = n && !i ? Object.defineProperties : function(t, e) {
                        s(t);
                        for (var r, n = a(e), i = c(e), u = i.length, f = 0; u > f;) o.f(t, r = i[f++], n[r]);
                        return t
                    }
                },
                8250: function(t, e, r) {
                    "use strict";
                    var n = r(5562),
                        i = r(7360),
                        o = r(5622),
                        s = r(1985),
                        a = r(9948),
                        c = TypeError,
                        u = Object.defineProperty,
                        f = Object.getOwnPropertyDescriptor,
                        l = "enumerable",
                        p = "configurable",
                        d = "writable";
                    e.f = n ? o ? function(t, e, r) {
                        if (s(t), e = a(e), s(r), "function" == typeof t && "prototype" === e && "value" in r && d in r && !r[d]) {
                            var n = f(t, e);
                            n && n[d] && (t[e] = r.value, r = {
                                configurable: p in r ? r[p] : n[p],
                                enumerable: l in r ? r[l] : n[l],
                                writable: !1
                            })
                        }
                        return u(t, e, r)
                    } : u : function(t, e, r) {
                        if (s(t), e = a(e), s(r), i) try {
                            return u(t, e, r)
                        } catch (t) {}
                        if ("get" in r || "set" in r) throw new c("Accessors not supported");
                        return "value" in r && (t[e] = r.value), t
                    }
                },
                788: function(t, e, r) {
                    "use strict";
                    var n = r(5562),
                        i = r(5568),
                        o = r(8571),
                        s = r(3067),
                        a = r(4259),
                        c = r(9948),
                        u = r(1615),
                        f = r(7360),
                        l = Object.getOwnPropertyDescriptor;
                    e.f = n ? l : function(t, e) {
                        if (t = a(t), e = c(e), f) try {
                            return l(t, e)
                        } catch (t) {}
                        if (u(t, e)) return s(!i(o.f, t, e), t[e])
                    }
                },
                9300: function(t, e, r) {
                    "use strict";
                    var n = r(1570),
                        i = r(7681).concat("length", "prototype");
                    e.f = Object.getOwnPropertyNames || function(t) {
                        return n(t, i)
                    }
                },
                4858: function(t, e) {
                    "use strict";
                    e.f = Object.getOwnPropertySymbols
                },
                6759: function(t, e, r) {
                    "use strict";
                    var n = r(1615),
                        i = r(309),
                        o = r(6707),
                        s = r(3137),
                        a = r(6034),
                        c = s("IE_PROTO"),
                        u = Object,
                        f = u.prototype;
                    t.exports = a ? u.getPrototypeOf : function(t) {
                        var e = o(t);
                        if (n(e, c)) return e[c];
                        var r = e.constructor;
                        return i(r) && e instanceof r ? r.prototype : e instanceof u ? f : null
                    }
                },
                5040: function(t, e, r) {
                    "use strict";
                    var n = r(1335);
                    t.exports = n({}.isPrototypeOf)
                },
                1570: function(t, e, r) {
                    "use strict";
                    var n = r(1335),
                        i = r(1615),
                        o = r(4259),
                        s = r(7868).indexOf,
                        a = r(9090),
                        c = n([].push);
                    t.exports = function(t, e) {
                        var r, n = o(t),
                            u = 0,
                            f = [];
                        for (r in n) !i(a, r) && i(n, r) && c(f, r);
                        for (; e.length > u;) i(n, r = e[u++]) && (~s(f, r) || c(f, r));
                        return f
                    }
                },
                9340: function(t, e, r) {
                    "use strict";
                    var n = r(1570),
                        i = r(7681);
                    t.exports = Object.keys || function(t) {
                        return n(t, i)
                    }
                },
                8571: function(t, e) {
                    "use strict";
                    var r = {}.propertyIsEnumerable,
                        n = Object.getOwnPropertyDescriptor,
                        i = n && !r.call({
                            1: 2
                        }, 1);
                    e.f = i ? function(t) {
                        var e = n(this, t);
                        return !!e && e.enumerable
                    } : r
                },
                3527: function(t, e, r) {
                    "use strict";
                    var n = r(5446),
                        i = r(3054),
                        o = r(9762),
                        s = r(6211);
                    t.exports = Object.setPrototypeOf || ("__proto__" in {} ? function() {
                        var t, e = !1,
                            r = {};
                        try {
                            (t = n(Object.prototype, "__proto__", "set"))(r, []), e = r instanceof Array
                        } catch (t) {}
                        return function(r, n) {
                            return (o(r), s(n), i(r)) ? (e ? t(r, n) : r.__proto__ = n, r) : r
                        }
                    }() : void 0)
                },
                191: function(t, e, r) {
                    "use strict";
                    var n = r(5562),
                        i = r(2280),
                        o = r(1335),
                        s = r(6759),
                        a = r(9340),
                        c = r(4259),
                        u = r(8571).f,
                        f = o(u),
                        l = o([].push),
                        p = n && i(function() {
                            var t = Object.create(null);
                            return t[2] = 2, !f(t, 2)
                        }),
                        d = function(t) {
                            return function(e) {
                                for (var r, i = c(e), o = a(i), u = p && null === s(i), d = o.length, h = 0, v = []; d > h;) r = o[h++], (!n || (u ? r in i : f(i, r))) && l(v, t ? [r, i[r]] : i[r]);
                                return v
                            }
                        };
                    t.exports = {
                        entries: d(!0),
                        values: d(!1)
                    }
                },
                8566: function(t, e, r) {
                    "use strict";
                    var n = r(6630),
                        i = r(4362);
                    t.exports = n ? ({}).toString : function() {
                        return "[object " + i(this) + "]"
                    }
                },
                357: function(t, e, r) {
                    "use strict";
                    var n = r(5568),
                        i = r(309),
                        o = r(3054),
                        s = TypeError;
                    t.exports = function(t, e) {
                        var r, a;
                        if ("string" === e && i(r = t.toString) && !o(a = n(r, t)) || i(r = t.valueOf) && !o(a = n(r, t)) || "string" !== e && i(r = t.toString) && !o(a = n(r, t))) return a;
                        throw new s("Can't convert object to primitive value")
                    }
                },
                6026: function(t, e, r) {
                    "use strict";
                    var n = r(3878),
                        i = r(1335),
                        o = r(9300),
                        s = r(4858),
                        a = r(1985),
                        c = i([].concat);
                    t.exports = n("Reflect", "ownKeys") || function(t) {
                        var e = o.f(a(t)),
                            r = s.f;
                        return r ? c(e, r(t)) : e
                    }
                },
                5236: function(t) {
                    "use strict";
                    t.exports = {}
                },
                4112: function(t) {
                    "use strict";
                    t.exports = function(t) {
                        try {
                            return {
                                error: !1,
                                value: t()
                            }
                        } catch (t) {
                            return {
                                error: !0,
                                value: t
                            }
                        }
                    }
                },
                8845: function(t, e, r) {
                    "use strict";
                    var n = r(5017),
                        i = r(61),
                        o = r(309),
                        s = r(9118),
                        a = r(8910),
                        c = r(5737),
                        u = r(5285),
                        f = r(1088),
                        l = r(1898),
                        p = i && i.prototype,
                        d = c("species"),
                        h = !1,
                        v = o(n.PromiseRejectionEvent),
                        g = s("Promise", function() {
                            var t = a(i),
                                e = t !== String(i);
                            if (!e && 66 === l || f && !(p.catch && p.finally)) return !0;
                            if (!l || l < 51 || !/native code/.test(t)) {
                                var r = new i(function(t) {
                                        t(1)
                                    }),
                                    n = function(t) {
                                        t(function() {}, function() {})
                                    };
                                if ((r.constructor = {})[d] = n, !(h = r.then(function() {}) instanceof n)) return !0
                            }
                            return !e && ("BROWSER" === u || "DENO" === u) && !v
                        });
                    t.exports = {
                        CONSTRUCTOR: g,
                        REJECTION_EVENT: v,
                        SUBCLASSING: h
                    }
                },
                61: function(t, e, r) {
                    "use strict";
                    var n = r(5017);
                    t.exports = n.Promise
                },
                2270: function(t, e, r) {
                    "use strict";
                    var n = r(1985),
                        i = r(3054),
                        o = r(3441);
                    t.exports = function(t, e) {
                        if (n(t), i(e) && e.constructor === t) return e;
                        var r = o.f(t);
                        return (0, r.resolve)(e), r.promise
                    }
                },
                2555: function(t, e, r) {
                    "use strict";
                    var n = r(61),
                        i = r(1314),
                        o = r(8845).CONSTRUCTOR;
                    t.exports = o || !i(function(t) {
                        n.all(t).then(void 0, function() {})
                    })
                },
                2962: function(t) {
                    "use strict";
                    var e = function() {
                        this.head = null, this.tail = null
                    };
                    e.prototype = {
                        add: function(t) {
                            var e = {
                                    item: t,
                                    next: null
                                },
                                r = this.tail;
                            r ? r.next = e : this.head = e, this.tail = e
                        },
                        get: function() {
                            var t = this.head;
                            if (t) {
                                var e = this.head = t.next;
                                return null === e && (this.tail = null), t.item
                            }
                        }
                    }, t.exports = e
                },
                9762: function(t, e, r) {
                    "use strict";
                    var n = r(2190),
                        i = TypeError;
                    t.exports = function(t) {
                        if (n(t)) throw new i("Can't call method on " + t);
                        return t
                    }
                },
                461: function(t, e, r) {
                    "use strict";
                    var n = r(5017),
                        i = r(5562),
                        o = Object.getOwnPropertyDescriptor;
                    t.exports = function(t) {
                        if (!i) return n[t];
                        var e = o(n, t);
                        return e && e.value
                    }
                },
                66: function(t, e, r) {
                    "use strict";
                    var n = r(3878),
                        i = r(5269),
                        o = r(5737),
                        s = r(5562),
                        a = o("species");
                    t.exports = function(t) {
                        var e = n(t);
                        s && e && !e[a] && i(e, a, {
                            configurable: !0,
                            get: function() {
                                return this
                            }
                        })
                    }
                },
                7592: function(t, e, r) {
                    "use strict";
                    var n = r(6630),
                        i = r(8250).f,
                        o = r(5245),
                        s = r(1615),
                        a = r(8566),
                        c = r(5737)("toStringTag");
                    t.exports = function(t, e, r, u) {
                        var f = r ? t : t && t.prototype;
                        f && (!s(f, c) && i(f, c, {
                            configurable: !0,
                            value: e
                        }), u && !n && o(f, "toString", a))
                    }
                },
                3137: function(t, e, r) {
                    "use strict";
                    var n = r(2025),
                        i = r(4289),
                        o = n("keys");
                    t.exports = function(t) {
                        return o[t] || (o[t] = i(t))
                    }
                },
                1258: function(t, e, r) {
                    "use strict";
                    var n = r(1088),
                        i = r(5017),
                        o = r(4945),
                        s = "__core-js_shared__",
                        a = t.exports = i[s] || o(s, {});
                    (a.versions || (a.versions = [])).push({
                        version: "3.38.1",
                        mode: n ? "pure" : "global",
                        copyright: "\xa9 2014-2024 Denis Pushkarev (zloirock.ru)",
                        license: "https://github.com/zloirock/core-js/blob/v3.38.1/LICENSE",
                        source: "https://github.com/zloirock/core-js"
                    })
                },
                2025: function(t, e, r) {
                    "use strict";
                    var n = r(1258);
                    t.exports = function(t, e) {
                        return n[t] || (n[t] = e || {})
                    }
                },
                3360: function(t, e, r) {
                    "use strict";
                    var n = r(1985),
                        i = r(3900),
                        o = r(2190),
                        s = r(5737)("species");
                    t.exports = function(t, e) {
                        var r, a = n(t).constructor;
                        return void 0 === a || o(r = n(a)[s]) ? e : i(r)
                    }
                },
                1760: function(t, e, r) {
                    "use strict";
                    var n = r(1335),
                        i = r(3642),
                        o = r(2952),
                        s = r(9762),
                        a = n("".charAt),
                        c = n("".charCodeAt),
                        u = n("".slice),
                        f = function(t) {
                            return function(e, r) {
                                var n, f, l = o(s(e)),
                                    p = i(r),
                                    d = l.length;
                                return p < 0 || p >= d ? t ? "" : void 0 : (n = c(l, p)) < 55296 || n > 56319 || p + 1 === d || (f = c(l, p + 1)) < 56320 || f > 57343 ? t ? a(l, p) : n : t ? u(l, p, p + 2) : (n - 55296 << 10) + (f - 56320) + 65536
                            }
                        };
                    t.exports = {
                        codeAt: f(!1),
                        charAt: f(!0)
                    }
                },
                4222: function(t, e, r) {
                    "use strict";
                    var n = r(1020).PROPER,
                        i = r(2280),
                        o = r(5598),
                        s = "​\x85᠎";
                    t.exports = function(t) {
                        return i(function() {
                            return !!o[t]() || s[t]() !== s || n && o[t].name !== t
                        })
                    }
                },
                2971: function(t, e, r) {
                    "use strict";
                    var n = r(1335),
                        i = r(9762),
                        o = r(2952),
                        s = r(5598),
                        a = n("".replace),
                        c = RegExp("^[" + s + "]+"),
                        u = RegExp("(^|[^" + s + "])[" + s + "]+$"),
                        f = function(t) {
                            return function(e) {
                                var r = o(i(e));
                                return 1 & t && (r = a(r, c, "")), 2 & t && (r = a(r, u, "$1")), r
                            }
                        };
                    t.exports = {
                        start: f(1),
                        end: f(2),
                        trim: f(3)
                    }
                },
                7076: function(t, e, r) {
                    "use strict";
                    var n = r(1898),
                        i = r(2280),
                        o = r(5017).String;
                    t.exports = !!Object.getOwnPropertySymbols && !i(function() {
                        var t = Symbol("symbol detection");
                        return !o(t) || !(Object(t) instanceof Symbol) || !Symbol.sham && n && n < 41
                    })
                },
                8151: function(t, e, r) {
                    "use strict";
                    var n, i, o, s, a = r(5017),
                        c = r(5473),
                        u = r(9141),
                        f = r(309),
                        l = r(1615),
                        p = r(2280),
                        d = r(7526),
                        h = r(7514),
                        v = r(4155),
                        g = r(2257),
                        _ = r(3171),
                        I = r(7238),
                        y = a.setImmediate,
                        m = a.clearImmediate,
                        b = a.process,
                        S = a.Dispatch,
                        E = a.Function,
                        x = a.MessageChannel,
                        O = a.String,
                        T = 0,
                        R = {},
                        P = "onreadystatechange";
                    p(function() {
                        n = a.location
                    });
                    var A = function(t) {
                            if (l(R, t)) {
                                var e = R[t];
                                delete R[t], e()
                            }
                        },
                        N = function(t) {
                            return function() {
                                A(t)
                            }
                        },
                        C = function(t) {
                            A(t.data)
                        },
                        w = function(t) {
                            a.postMessage(O(t), n.protocol + "//" + n.host)
                        };
                    (!y || !m) && (y = function(t) {
                        g(arguments.length, 1);
                        var e = f(t) ? t : E(t),
                            r = h(arguments, 1);
                        return R[++T] = function() {
                            c(e, void 0, r)
                        }, i(T), T
                    }, m = function(t) {
                        delete R[t]
                    }, I ? i = function(t) {
                        b.nextTick(N(t))
                    } : S && S.now ? i = function(t) {
                        S.now(N(t))
                    } : x && !_ ? (s = (o = new x).port2, o.port1.onmessage = C, i = u(s.postMessage, s)) : a.addEventListener && f(a.postMessage) && !a.importScripts && n && "file:" !== n.protocol && !p(w) ? (i = w, a.addEventListener("message", C, !1)) : i = P in v("script") ? function(t) {
                        d.appendChild(v("script"))[P] = function() {
                            d.removeChild(this), A(t)
                        }
                    } : function(t) {
                        setTimeout(N(t), 0)
                    }), t.exports = {
                        set: y,
                        clear: m
                    }
                },
                3299: function(t, e, r) {
                    "use strict";
                    var n = r(3642),
                        i = Math.max,
                        o = Math.min;
                    t.exports = function(t, e) {
                        var r = n(t);
                        return r < 0 ? i(r + e, 0) : o(r, e)
                    }
                },
                4259: function(t, e, r) {
                    "use strict";
                    var n = r(9110),
                        i = r(9762);
                    t.exports = function(t) {
                        return n(i(t))
                    }
                },
                3642: function(t, e, r) {
                    "use strict";
                    var n = r(6542);
                    t.exports = function(t) {
                        var e = +t;
                        return e != e || 0 === e ? 0 : n(e)
                    }
                },
                3586: function(t, e, r) {
                    "use strict";
                    var n = r(3642),
                        i = Math.min;
                    t.exports = function(t) {
                        var e = n(t);
                        return e > 0 ? i(e, 9007199254740991) : 0
                    }
                },
                6707: function(t, e, r) {
                    "use strict";
                    var n = r(9762),
                        i = Object;
                    t.exports = function(t) {
                        return i(n(t))
                    }
                },
                9643: function(t, e, r) {
                    "use strict";
                    var n = r(5568),
                        i = r(3054),
                        o = r(4341),
                        s = r(7522),
                        a = r(357),
                        c = r(5737),
                        u = TypeError,
                        f = c("toPrimitive");
                    t.exports = function(t, e) {
                        if (!i(t) || o(t)) return t;
                        var r, c = s(t, f);
                        if (c) {
                            if (void 0 === e && (e = "default"), r = n(c, t, e), !i(r) || o(r)) return r;
                            throw new u("Can't convert object to primitive value")
                        }
                        return void 0 === e && (e = "number"), a(t, e)
                    }
                },
                9948: function(t, e, r) {
                    "use strict";
                    var n = r(9643),
                        i = r(4341);
                    t.exports = function(t) {
                        var e = n(t, "string");
                        return i(e) ? e : e + ""
                    }
                },
                6630: function(t, e, r) {
                    "use strict";
                    var n = r(5737)("toStringTag"),
                        i = {};
                    i[n] = "z", t.exports = "[object z]" === String(i)
                },
                2952: function(t, e, r) {
                    "use strict";
                    var n = r(4362),
                        i = String;
                    t.exports = function(t) {
                        if ("Symbol" === n(t)) throw TypeError("Cannot convert a Symbol value to a string");
                        return i(t)
                    }
                },
                1024: function(t) {
                    "use strict";
                    var e = String;
                    t.exports = function(t) {
                        try {
                            return e(t)
                        } catch (t) {
                            return "Object"
                        }
                    }
                },
                4289: function(t, e, r) {
                    "use strict";
                    var n = r(1335),
                        i = 0,
                        o = Math.random(),
                        s = n(1..toString);
                    t.exports = function(t) {
                        return "Symbol(" + (void 0 === t ? "" : t) + ")_" + s(++i + o, 36)
                    }
                },
                6878: function(t, e, r) {
                    "use strict";
                    var n = r(7076);
                    t.exports = n && !Symbol.sham && "symbol" == typeof Symbol.iterator
                },
                5622: function(t, e, r) {
                    "use strict";
                    var n = r(5562),
                        i = r(2280);
                    t.exports = n && i(function() {
                        return 42 !== Object.defineProperty(function() {}, "prototype", {
                            value: 42,
                            writable: !1
                        }).prototype
                    })
                },
                2257: function(t) {
                    "use strict";
                    var e = TypeError;
                    t.exports = function(t, r) {
                        if (t < r) throw new e("Not enough arguments");
                        return t
                    }
                },
                8402: function(t, e, r) {
                    "use strict";
                    var n = r(5017),
                        i = r(309),
                        o = n.WeakMap;
                    t.exports = i(o) && /native code/.test(String(o))
                },
                5737: function(t, e, r) {
                    "use strict";
                    var n = r(5017),
                        i = r(2025),
                        o = r(1615),
                        s = r(4289),
                        a = r(7076),
                        c = r(6878),
                        u = n.Symbol,
                        f = i("wks"),
                        l = c ? u.for || u : u && u.withoutSetter || s;
                    t.exports = function(t) {
                        return !o(f, t) && (f[t] = a && o(u, t) ? u[t] : l("Symbol." + t)), f[t]
                    }
                },
                5598: function(t) {
                    "use strict";
                    t.exports = "	\n\v\f\r \xa0              　\u2028\u2029\uFEFF"
                },
                4704: function(t, e, r) {
                    "use strict";
                    var n = r(5633),
                        i = r(5040),
                        o = r(6759),
                        s = r(3527),
                        a = r(9634),
                        c = r(7546),
                        u = r(5245),
                        f = r(3067),
                        l = r(9184),
                        p = r(1441),
                        d = r(6639),
                        h = r(5732),
                        v = r(5737)("toStringTag"),
                        g = Error,
                        _ = [].push,
                        I = function(t, e) {
                            var r, n = i(y, this);
                            s ? r = s(new g, n ? o(this) : y) : (r = n ? this : c(y), u(r, v, "Error")), void 0 !== e && u(r, "message", h(e)), p(r, I, r.stack, 1), arguments.length > 2 && l(r, arguments[2]);
                            var a = [];
                            return d(t, _, {
                                that: a
                            }), u(r, "errors", a), r
                        };
                    s ? s(I, g) : a(I, g, {
                        name: !0
                    });
                    var y = I.prototype = c(g.prototype, {
                        constructor: f(1, I),
                        message: f(1, ""),
                        name: f(1, "AggregateError")
                    });
                    n({
                        global: !0,
                        constructor: !0,
                        arity: 2
                    }, {
                        AggregateError: I
                    })
                },
                370: function(t, e, r) {
                    "use strict";
                    r(4704)
                },
                2644: function(t, e, r) {
                    "use strict";
                    var n = r(5633),
                        i = r(7868).includes,
                        o = r(2280),
                        s = r(4809),
                        a = o(function() {
                            return ![, ].includes()
                        });
                    n({
                        target: "Array",
                        proto: !0,
                        forced: a
                    }, {
                        includes: function(t) {
                            return i(this, t, arguments.length > 1 ? arguments[1] : void 0)
                        }
                    }), s("includes")
                },
                7300: function(t, e, r) {
                    "use strict";
                    var n = r(4259),
                        i = r(4809),
                        o = r(9122),
                        s = r(7179),
                        a = r(8250).f,
                        c = r(4088),
                        u = r(6616),
                        f = r(1088),
                        l = r(5562),
                        p = "Array Iterator",
                        d = s.set,
                        h = s.getterFor(p);
                    t.exports = c(Array, "Array", function(t, e) {
                        d(this, {
                            type: p,
                            target: n(t),
                            index: 0,
                            kind: e
                        })
                    }, function() {
                        var t = h(this),
                            e = t.target,
                            r = t.index++;
                        if (!e || r >= e.length) return t.target = null, u(void 0, !0);
                        switch (t.kind) {
                            case "keys":
                                return u(r, !1);
                            case "values":
                                return u(e[r], !1)
                        }
                        return u([r, e[r]], !1)
                    }, "values");
                    var v = o.Arguments = o.Array;
                    if (i("keys"), i("values"), i("entries"), !f && l && "values" !== v.name) try {
                        a(v, "name", {
                            value: "values"
                        })
                    } catch (t) {}
                },
                7985: function(t, e, r) {
                    "use strict";
                    var n = r(5633),
                        i = r(6707),
                        o = r(3934),
                        s = r(296),
                        a = r(3385),
                        c = r(2280)(function() {
                            return 4294967297 !== [].push.call({
                                length: 4294967296
                            }, 1)
                        }),
                        u = c || ! function() {
                            try {
                                Object.defineProperty([], "length", {
                                    writable: !1
                                }).push()
                            } catch (t) {
                                return t instanceof TypeError
                            }
                        }();
                    n({
                        target: "Array",
                        proto: !0,
                        arity: 1,
                        forced: u
                    }, {
                        push: function(t) {
                            var e = i(this),
                                r = o(e),
                                n = arguments.length;
                            a(r + n);
                            for (var c = 0; c < n; c++) e[r] = arguments[c], r++;
                            return s(e, r), r
                        }
                    })
                },
                8813: function(t, e, r) {
                    "use strict";
                    var n = r(5633),
                        i = r(4090).left,
                        o = r(2339),
                        s = r(1898),
                        a = r(7238),
                        c = !a && s > 79 && s < 83 || !o("reduce");
                    n({
                        target: "Array",
                        proto: !0,
                        forced: c
                    }, {
                        reduce: function(t) {
                            var e = arguments.length;
                            return i(this, t, e, e > 1 ? arguments[1] : void 0)
                        }
                    })
                },
                6498: function(t, e, r) {
                    "use strict";
                    var n = r(5633),
                        i = r(8683);
                    n({
                        target: "Function",
                        proto: !0,
                        forced: Function.bind !== i
                    }, {
                        bind: i
                    })
                },
                4182: function(t, e, r) {
                    "use strict";
                    var n = r(5633),
                        i = r(5017);
                    n({
                        global: !0,
                        forced: i.globalThis !== i
                    }, {
                        globalThis: i
                    })
                },
                244: function(t, e, r) {
                    "use strict";
                    var n = r(5633),
                        i = r(8268);
                    n({
                        target: "Object",
                        stat: !0,
                        arity: 2,
                        forced: Object.assign !== i
                    }, {
                        assign: i
                    })
                },
                6092: function(t, e, r) {
                    "use strict";
                    var n = r(5633),
                        i = r(191).entries;
                    n({
                        target: "Object",
                        stat: !0
                    }, {
                        entries: function(t) {
                            return i(t)
                        }
                    })
                },
                6809: function() {},
                1190: function(t, e, r) {
                    "use strict";
                    var n = r(5633),
                        i = r(5568),
                        o = r(5168),
                        s = r(3441),
                        a = r(4112),
                        c = r(6639),
                        u = r(2555);
                    n({
                        target: "Promise",
                        stat: !0,
                        forced: u
                    }, {
                        allSettled: function(t) {
                            var e = this,
                                r = s.f(e),
                                n = r.resolve,
                                u = r.reject,
                                f = a(function() {
                                    var r = o(e.resolve),
                                        s = [],
                                        a = 0,
                                        u = 1;
                                    c(t, function(t) {
                                        var o = a++,
                                            c = !1;
                                        u++, i(r, e, t).then(function(t) {
                                            !c && (c = !0, s[o] = {
                                                status: "fulfilled",
                                                value: t
                                            }, --u || n(s))
                                        }, function(t) {
                                            !c && (c = !0, s[o] = {
                                                status: "rejected",
                                                reason: t
                                            }, --u || n(s))
                                        })
                                    }), --u || n(s)
                                });
                            return f.error && u(f.value), r.promise
                        }
                    })
                },
                5453: function(t, e, r) {
                    "use strict";
                    var n = r(5633),
                        i = r(5568),
                        o = r(5168),
                        s = r(3441),
                        a = r(4112),
                        c = r(6639),
                        u = r(2555);
                    n({
                        target: "Promise",
                        stat: !0,
                        forced: u
                    }, {
                        all: function(t) {
                            var e = this,
                                r = s.f(e),
                                n = r.resolve,
                                u = r.reject,
                                f = a(function() {
                                    var r = o(e.resolve),
                                        s = [],
                                        a = 0,
                                        f = 1;
                                    c(t, function(t) {
                                        var o = a++,
                                            c = !1;
                                        f++, i(r, e, t).then(function(t) {
                                            !c && (c = !0, s[o] = t, --f || n(s))
                                        }, u)
                                    }), --f || n(s)
                                });
                            return f.error && u(f.value), r.promise
                        }
                    })
                },
                1402: function(t, e, r) {
                    "use strict";
                    var n = r(5633),
                        i = r(5568),
                        o = r(5168),
                        s = r(3878),
                        a = r(3441),
                        c = r(4112),
                        u = r(6639),
                        f = r(2555),
                        l = "No one promise resolved";
                    n({
                        target: "Promise",
                        stat: !0,
                        forced: f
                    }, {
                        any: function(t) {
                            var e = this,
                                r = s("AggregateError"),
                                n = a.f(e),
                                f = n.resolve,
                                p = n.reject,
                                d = c(function() {
                                    var n = o(e.resolve),
                                        s = [],
                                        a = 0,
                                        c = 1,
                                        d = !1;
                                    u(t, function(t) {
                                        var o = a++,
                                            u = !1;
                                        c++, i(n, e, t).then(function(t) {
                                            !u && !d && (d = !0, f(t))
                                        }, function(t) {
                                            !u && !d && (u = !0, s[o] = t, --c || p(new r(s, l)))
                                        })
                                    }), --c || p(new r(s, l))
                                });
                            return d.error && p(d.value), n.promise
                        }
                    })
                },
                1830: function(t, e, r) {
                    "use strict";
                    var n = r(5633),
                        i = r(1088),
                        o = r(8845).CONSTRUCTOR,
                        s = r(61),
                        a = r(3878),
                        c = r(309),
                        u = r(9491),
                        f = s && s.prototype;
                    if (n({
                            target: "Promise",
                            proto: !0,
                            forced: o,
                            real: !0
                        }, {
                            catch: function(t) {
                                return this.then(void 0, t)
                            }
                        }), !i && c(s)) {
                        var l = a("Promise").prototype.catch;
                        f.catch !== l && u(f, "catch", l, {
                            unsafe: !0
                        })
                    }
                },
                674: function(t, e, r) {
                    "use strict";
                    var n, i, o, s, a = r(5633),
                        c = r(1088),
                        u = r(7238),
                        f = r(5017),
                        l = r(5568),
                        p = r(9491),
                        d = r(3527),
                        h = r(7592),
                        v = r(66),
                        g = r(5168),
                        _ = r(309),
                        I = r(3054),
                        y = r(3893),
                        m = r(3360),
                        b = r(8151).set,
                        S = r(578),
                        E = r(7504),
                        x = r(4112),
                        O = r(2962),
                        T = r(7179),
                        R = r(61),
                        P = r(8845),
                        A = r(3441),
                        N = "Promise",
                        C = P.CONSTRUCTOR,
                        w = P.REJECTION_EVENT,
                        D = P.SUBCLASSING,
                        k = T.getterFor(N),
                        L = T.set,
                        M = R && R.prototype,
                        j = R,
                        F = M,
                        U = f.TypeError,
                        H = f.document,
                        B = f.process,
                        V = A.f,
                        G = V,
                        q = !!(H && H.createEvent && f.dispatchEvent),
                        W = "unhandledrejection",
                        J = function(t) {
                            var e;
                            return !!(I(t) && _(e = t.then)) && e
                        },
                        K = function(t, e) {
                            var r, n, i, o = e.value,
                                s = 1 === e.state,
                                a = s ? t.ok : t.fail,
                                c = t.resolve,
                                u = t.reject,
                                f = t.domain;
                            try {
                                a ? (!s && (2 === e.rejection && $(e), e.rejection = 1), !0 === a ? r = o : (f && f.enter(), r = a(o), f && (f.exit(), i = !0)), r === t.promise ? u(new U("Promise-chain cycle")) : (n = J(r)) ? l(n, r, c, u) : c(r)) : u(o)
                            } catch (t) {
                                f && !i && f.exit(), u(t)
                            }
                        },
                        z = function(t, e) {
                            !t.notified && (t.notified = !0, S(function() {
                                for (var r, n = t.reactions; r = n.get();) K(r, t);
                                t.notified = !1, e && !t.rejection && Y(t)
                            }))
                        },
                        X = function(t, e, r) {
                            var n, i;
                            q ? ((n = H.createEvent("Event")).promise = e, n.reason = r, n.initEvent(t, !1, !0), f.dispatchEvent(n)) : n = {
                                promise: e,
                                reason: r
                            }, !w && (i = f["on" + t]) ? i(n) : t === W && E("Unhandled promise rejection", r)
                        },
                        Y = function(t) {
                            l(b, f, function() {
                                var e, r = t.facade,
                                    n = t.value;
                                if (Z(t) && (e = x(function() {
                                        u ? B.emit("unhandledRejection", n, r) : X(W, r, n)
                                    }), t.rejection = u || Z(t) ? 2 : 1, e.error)) throw e.value
                            })
                        },
                        Z = function(t) {
                            return 1 !== t.rejection && !t.parent
                        },
                        $ = function(t) {
                            l(b, f, function() {
                                var e = t.facade;
                                u ? B.emit("rejectionHandled", e) : X("rejectionhandled", e, t.value)
                            })
                        },
                        Q = function(t, e, r) {
                            return function(n) {
                                t(e, n, r)
                            }
                        },
                        tt = function(t, e, r) {
                            !t.done && (t.done = !0, r && (t = r), t.value = e, t.state = 2, z(t, !0))
                        },
                        te = function(t, e, r) {
                            if (!t.done) {
                                t.done = !0, r && (t = r);
                                try {
                                    if (t.facade === e) throw new U("Promise can't be resolved itself");
                                    var n = J(e);
                                    n ? S(function() {
                                        var r = {
                                            done: !1
                                        };
                                        try {
                                            l(n, e, Q(te, r, t), Q(tt, r, t))
                                        } catch (e) {
                                            tt(r, e, t)
                                        }
                                    }) : (t.value = e, t.state = 1, z(t, !1))
                                } catch (e) {
                                    tt({
                                        done: !1
                                    }, e, t)
                                }
                            }
                        };
                    if (C && (F = (j = function(t) {
                            y(this, F), g(t), l(n, this);
                            var e = k(this);
                            try {
                                t(Q(te, e), Q(tt, e))
                            } catch (t) {
                                tt(e, t)
                            }
                        }).prototype, (n = function(t) {
                            L(this, {
                                type: N,
                                done: !1,
                                notified: !1,
                                parent: !1,
                                reactions: new O,
                                rejection: !1,
                                state: 0,
                                value: null
                            })
                        }).prototype = p(F, "then", function(t, e) {
                            var r = k(this),
                                n = V(m(this, j));
                            return r.parent = !0, n.ok = !_(t) || t, n.fail = _(e) && e, n.domain = u ? B.domain : void 0, 0 === r.state ? r.reactions.add(n) : S(function() {
                                K(n, r)
                            }), n.promise
                        }), i = function() {
                            var t = new n,
                                e = k(t);
                            this.promise = t, this.resolve = Q(te, e), this.reject = Q(tt, e)
                        }, A.f = V = function(t) {
                            return t === j || t === o ? new i(t) : G(t)
                        }, !c && _(R) && M !== Object.prototype)) {
                        s = M.then, !D && p(M, "then", function(t, e) {
                            var r = this;
                            return new j(function(t, e) {
                                l(s, r, t, e)
                            }).then(t, e)
                        }, {
                            unsafe: !0
                        });
                        try {
                            delete M.constructor
                        } catch (t) {}
                        d && d(M, F)
                    }
                    a({
                        global: !0,
                        constructor: !0,
                        wrap: !0,
                        forced: C
                    }, {
                        Promise: j
                    }), h(j, N, !1, !0), v(N)
                },
                5581: function(t, e, r) {
                    "use strict";
                    var n = r(5633),
                        i = r(1088),
                        o = r(61),
                        s = r(2280),
                        a = r(3878),
                        c = r(309),
                        u = r(3360),
                        f = r(2270),
                        l = r(9491),
                        p = o && o.prototype,
                        d = !!o && s(function() {
                            p.finally.call({
                                then: function() {}
                            }, function() {})
                        });
                    if (n({
                            target: "Promise",
                            proto: !0,
                            real: !0,
                            forced: d
                        }, {
                            finally: function(t) {
                                var e = u(this, a("Promise")),
                                    r = c(t);
                                return this.then(r ? function(r) {
                                    return f(e, t()).then(function() {
                                        return r
                                    })
                                } : t, r ? function(r) {
                                    return f(e, t()).then(function() {
                                        throw r
                                    })
                                } : t)
                            }
                        }), !i && c(o)) {
                        var h = a("Promise").prototype.finally;
                        p.finally !== h && l(p, "finally", h, {
                            unsafe: !0
                        })
                    }
                },
                8318: function(t, e, r) {
                    "use strict";
                    r(674), r(5453), r(1830), r(1114), r(8466), r(5484)
                },
                1114: function(t, e, r) {
                    "use strict";
                    var n = r(5633),
                        i = r(5568),
                        o = r(5168),
                        s = r(3441),
                        a = r(4112),
                        c = r(6639),
                        u = r(2555);
                    n({
                        target: "Promise",
                        stat: !0,
                        forced: u
                    }, {
                        race: function(t) {
                            var e = this,
                                r = s.f(e),
                                n = r.reject,
                                u = a(function() {
                                    var s = o(e.resolve);
                                    c(t, function(t) {
                                        i(s, e, t).then(r.resolve, n)
                                    })
                                });
                            return u.error && n(u.value), r.promise
                        }
                    })
                },
                8466: function(t, e, r) {
                    "use strict";
                    var n = r(5633),
                        i = r(3441),
                        o = r(8845).CONSTRUCTOR;
                    n({
                        target: "Promise",
                        stat: !0,
                        forced: o
                    }, {
                        reject: function(t) {
                            var e = i.f(this);
                            return (0, e.reject)(t), e.promise
                        }
                    })
                },
                5484: function(t, e, r) {
                    "use strict";
                    var n = r(5633),
                        i = r(3878),
                        o = r(1088),
                        s = r(61),
                        a = r(8845).CONSTRUCTOR,
                        c = r(2270),
                        u = i("Promise"),
                        f = o && !a;
                    n({
                        target: "Promise",
                        stat: !0,
                        forced: o || a
                    }, {
                        resolve: function(t) {
                            return c(f && this === u ? s : this, t)
                        }
                    })
                },
                6242: function(t, e, r) {
                    "use strict";
                    var n = r(5633),
                        i = r(3441);
                    n({
                        target: "Promise",
                        stat: !0
                    }, {
                        withResolvers: function() {
                            var t = i.f(this);
                            return {
                                promise: t.promise,
                                resolve: t.resolve,
                                reject: t.reject
                            }
                        }
                    })
                },
                4857: function(t, e, r) {
                    "use strict";
                    var n = r(5633),
                        i = r(1335),
                        o = r(3769),
                        s = r(9762),
                        a = r(2952),
                        c = r(8634),
                        u = i("".indexOf);
                    n({
                        target: "String",
                        proto: !0,
                        forced: !c("includes")
                    }, {
                        includes: function(t) {
                            return !!~u(a(s(this)), a(o(t)), arguments.length > 1 ? arguments[1] : void 0)
                        }
                    })
                },
                3998: function(t, e, r) {
                    "use strict";
                    var n = r(1760).charAt,
                        i = r(2952),
                        o = r(7179),
                        s = r(4088),
                        a = r(6616),
                        c = "String Iterator",
                        u = o.set,
                        f = o.getterFor(c);
                    s(String, "String", function(t) {
                        u(this, {
                            type: c,
                            string: i(t),
                            index: 0
                        })
                    }, function() {
                        var t, e = f(this),
                            r = e.string,
                            i = e.index;
                        return i >= r.length ? a(void 0, !0) : (t = n(r, i), e.index += t.length, a(t, !1))
                    })
                },
                2896: function(t, e, r) {
                    "use strict";
                    var n = r(5633),
                        i = r(2971).trim,
                        o = r(4222);
                    n({
                        target: "String",
                        proto: !0,
                        forced: o("trim")
                    }, {
                        trim: function() {
                            return i(this)
                        }
                    })
                },
                398: function(t, e, r) {
                    "use strict";
                    r(370)
                },
                4644: function(t, e, r) {
                    "use strict";
                    r(1190)
                },
                856: function(t, e, r) {
                    "use strict";
                    r(1402)
                },
                4716: function(t, e, r) {
                    "use strict";
                    var n = r(5633),
                        i = r(5017),
                        o = r(5473),
                        s = r(7514),
                        a = r(3441),
                        c = r(5168),
                        u = r(4112),
                        f = i.Promise,
                        l = !1,
                        p = !f || !f.try || u(function() {
                            f.try(function(t) {
                                l = 8 === t
                            }, 8)
                        }).error || !l;
                    n({
                        target: "Promise",
                        stat: !0,
                        forced: p
                    }, {
                        try: function(t) {
                            var e = arguments.length > 1 ? s(arguments, 1) : [],
                                r = a.f(this),
                                n = u(function() {
                                    return o(c(t), void 0, e)
                                });
                            return (n.error ? r.reject : r.resolve)(n.value), r.promise
                        }
                    })
                },
                5320: function(t, e, r) {
                    "use strict";
                    r(6242)
                },
                6432: function(t, e, r) {
                    "use strict";
                    r(7300);
                    var n = r(2),
                        i = r(5017),
                        o = r(7592),
                        s = r(9122);
                    for (var a in n) o(i[a], a), s[a] = s.Array
                },
                577: function(t, e, r) {
                    "use strict";
                    var n = r(8612);
                    t.exports = n
                },
                4168: function(t, e, r) {
                    "use strict";
                    var n = r(7225);
                    t.exports = n
                },
                4141: function(t, e, r) {
                    "use strict";
                    var n = r(8411);
                    t.exports = n
                },
                2589: function(t, e, r) {
                    "use strict";
                    var n = r(8606);
                    t.exports = n
                },
                6762: function(t, e, r) {
                    "use strict";
                    var n = r(2862);
                    t.exports = n
                },
                1189: function(t, e, r) {
                    "use strict";
                    var n = r(733);
                    t.exports = n
                },
                2206: function(t, e, r) {
                    "use strict";
                    var n = r(3437);
                    t.exports = n
                },
                4378: function(t, e, r) {
                    "use strict";
                    var n = r(6951);
                    t.exports = n
                },
                5880: function(t, e, r) {
                    "use strict";
                    var n = r(8640);
                    r(6432), t.exports = n
                },
                9392: function(t, e, r) {
                    "use strict";
                    var n = r(6670);
                    r(6432), t.exports = n
                }
            },
            e = {};

        function r(n) {
            var i = e[n];
            if (void 0 !== i) return i.exports;
            var o = e[n] = {
                exports: {}
            };
            return t[n].call(o.exports, o, o.exports, r), o.exports
        }
        r.n = function(t) {
            var e = t && t.__esModule ? function() {
                return t.default
            } : function() {
                return t
            };
            return r.d(e, {
                a: e
            }), e
        }, r.d = function(t, e) {
            for (var n in e) r.o(e, n) && !r.o(t, n) && Object.defineProperty(t, n, {
                enumerable: !0,
                get: e[n]
            })
        }, r.g = function() {
            if ("object" == typeof globalThis) return globalThis;
            try {
                return this || Function("return this")()
            } catch (t) {
                if ("object" == typeof window) return window
            }
        }(), r.o = function(t, e) {
            return Object.prototype.hasOwnProperty.call(t, e)
        }, r.rv = function() {
            return "1.0.0-rc.0"
        }, r.ruid = "bundler=rspack@1.0.0-rc.0";
        (() => {
            "use strict";
            var t, e, n = r("577"),
                i = r.n(n),
                o = r("4141"),
                s = r.n(o),
                a = "TiktokAnalyticsObject",
                c = "tt_adInfo_v2",
                u = "tt_appInfo_v2",
                f = "_ttp",
                l = "tt_sessionId",
                p = "tt_s_pixel_session_index",
                d = "ttcsid",
                h = function(t) {
                    return t.WINDOWS_PHONE = "Windows Phone", t.ANDROID = "android", t.IOS = "ios", t.PC = "pc", t
                }({}),
                v = function(t) {
                    return t.MUSICAL_LY = "musical_ly", t.MUSICALLY_GO = "musically_go", t.TRILL = "trill", t.ULTRALITE = "ultralite", t.LEMON8 = "lemon8", t.TTLINK = "ttlink", t
                }({});
            v.LEMON8, v.TTLINK, v.MUSICAL_LY, h.IOS, h.ANDROID, v.TRILL, h.IOS, h.ANDROID;
            var g = {
                    expires: 390
                },
                _ = "ttoclid",
                I = null,
                y = () => "undefined" != typeof window ? window : void 0 !== i() ? i() : "undefined" != typeof self ? self : void 0 !== r.g ? r.g : Function("return this")(),
                m = () => y()[a] || "ttq",
                b = () => {
                    var t = y();
                    return I || t[m()]
                },
                S = () => {
                    var t = y();
                    return void 0 !== t.DedicatedWorkerGlobalScope ? t instanceof t.DedicatedWorkerGlobalScope : "DedicatedWorkerGlobalScope" === t.constructor.name
                },
                E = () => {
                    var t = y();
                    return ("object" == typeof navigator && navigator.userAgent ? navigator.userAgent : "") || t._userAgent
                },
                x = t => {
                    try {
                        var e = b();
                        return e && e._self_host_config && e._self_host_config[t] || ""
                    } catch (t) {
                        return ""
                    }
                },
                O = function(t, e) {
                    void 0 === e && (e = []);
                    try {
                        return s()(e).call(e, t)
                    } catch (t) {
                        return !1
                    }
                },
                T = t => {
                    var e = b(),
                        r = e._i || {},
                        n = t && r[t];
                    return t && n && n._partner ? n._partner : e._partner ? e._partner : ""
                },
                R = t => {
                    try {
                        var e = b()._plugins || {};
                        if (null != e[t]) return !!e[t];
                        return !0
                    } catch (t) {
                        return !0
                    }
                },
                P = () => {
                    try {
                        var t = b()._ppf;
                        return null == t.printAndClear ? void 0 : t.printAndClear()
                    } catch (t) {}
                },
                A = r("9392"),
                N = r.n(A),
                C = function(t) {
                    return t[t.NOT_SURE = 0] = "NOT_SURE", t[t.INVOKE_METHOD_ENABLED = 1] = "INVOKE_METHOD_ENABLED", t[t.INVOKE_METHOD_NOT_ENABLED = 2] = "INVOKE_METHOD_NOT_ENABLED", t
                }({}),
                w = function(t) {
                    return t.NORMAL = "1", t.NOT_CROSS_DOMAIN_IFRAME = "2", t.CROSS_DOMAIN_IFRAME = "3", t.WEB_WORKER = "4", t.SANDBOX_IFRAME = "5", t.GTM_IFRAME = "6", t.URL_IN_QUERY_IFRAME = "7", t.UNKNOWN_IFRAME = "8", t
                }({}),
                D = r("7227"),
                k = r.n(D),
                L = r("4269"),
                M = r.n(L),
                j = r("4378"),
                F = r.n(j);
            let U = (t = 21) => crypto.getRandomValues(new Uint8Array(t)).reduce((t, e) => ((e &= 63) < 36 ? t += e.toString(36) : e < 62 ? t += (e - 26).toString(36).toUpperCase() : e > 62 ? t += "-" : t += "_", t), "");

            function H(t) {
                var e = Error(t);
                return e.source = "ulid", e
            }
            var B = "0123456789ABCDEFGHJKMNPQRSTVWXYZ",
                V = B.length,
                G = 0xffffffffffff;

            function q(t, e, r) {
                return e > t.length - 1 ? t : t.substr(0, e) + r + t.substr(e + 1)
            }

            function W(t, e) {
                if (isNaN(t)) throw Error(t + " must be a number");
                if (t > G) throw H("cannot encode time greater than " + G);
                if (t < 0) throw H("time must be positive");
                if (!1 === Number.isInteger(t)) throw H("time must be an integer");
                for (var r = void 0, n = ""; e > 0; e--) r = t % V, n = B.charAt(r) + n, t = (t - r) / V;
                return n
            }

            function J(t, e) {
                for (var r = ""; t > 0; t--) r = function(t) {
                    var e = Math.floor(t() * V);
                    return e === V && (e = V - 1), B.charAt(e)
                }(e) + r;
                return r
            }

            function K() {
                var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
                    e = arguments[1];
                !e && (e = "undefined" != typeof window ? window : null);
                var n = e && (e.crypto || e.msCrypto);
                if (n) return function() {
                    var t = new Uint8Array(1);
                    return n.getRandomValues(t), t[0] / 255
                };
                try {
                    var i = r(3462);
                    return function() {
                        return i.randomBytes(1).readUInt8() / 255
                    }
                } catch (t) {}
                if (t) return function() {
                    return Math.random()
                };
                throw H("secure crypto unusable, insecure Math.random not allowed")
            }
            var z = function(t) {
                    return !t && (t = K()),
                        function(e) {
                            return isNaN(e) && (e = Date.now()), W(e, 10) + J(16, t)
                        }
                }(),
                X = function(t) {
                    return t.EMPTY_VALUE = "empty_value", t.WRONG_FORMAT = "wrong_format", t.CORRECT_FORMAT = "correct_format", t.HASHED = "hashed", t.HASHED_ERR = "hashed_err", t.HASHED_CORRECT = "hashed_correct", t.PLAINTEXT_EMAIL = "plaintext_email", t.PLAINTEXT_PHONE = "plaintext_phone", t
                }({}),
                Y = function(t) {
                    return t.EMPTY_VALUE = "empty_value", t.PLAIN_EMAIL = "plain_email", t.PLAIN_PHONE = "plain_phone", t.HASHED = "hashed", t.FILTER_EVENTS = "filter_events", t.UNKNOWN_INVALID = "unknown_invalid", t.BASE64_STRING_HASHED = "base64_string_hashed", t.BASE64_HEX_HASHED = "base64_hex_hashed", t.PLAIN_MDN_EMAIL = "plain_mdn_email", t.ZIP_CODE_IS_NOT_HASHED = "zip_code_is_not_hashed", t.ZIP_CODE_IS_NOT_US = "zip_code_is_not_us", t.ZIP_CODE_IS_HASHED = "zip_code_is_hashed", t.ZIP_CODE_IS_US = "zip_code_is_us", t
                }({}),
                Z = function(t) {
                    return t.Manual = "manual", t.ManualV2 = "manual_v2", t.Auto = "auto", t.EBManual = "eb_manual", t
                }({}),
                $ = function(t) {
                    return t.missing = "missing", t.valid = "valid", t.invalid = "invalid", t
                }({}),
                Q = {
                    raw_email: {
                        label: $.missing
                    },
                    raw_auto_email: {
                        label: $.missing
                    },
                    raw_phone: {
                        label: $.missing
                    },
                    raw_auto_phone: {
                        label: $.missing
                    },
                    hashed_email: {
                        label: $.missing
                    },
                    hashed_phone: {
                        label: $.missing
                    },
                    raw_eb_email: {
                        label: $.missing
                    },
                    raw_eb_phone: {
                        label: $.missing
                    }
                };

            function tt() {
                var t = Date.now();
                return ("number" != typeof t || isNaN(t) || !isFinite(t) || t < 0) && (t = new Date().getTime()), t
            }
            var te = t => "string" == typeof t,
                tr = t => "number" == typeof t,
                tn = t => "[object Object]" === Object.prototype.toString.call(t),
                ti = t => "{}" === JSON.stringify(t),
                to = t => t + "-" + tt() + "-" + (Math.floor(Math.random() * (9e12 - 1)) + 1e12),
                ts = function(t, e, r) {
                    return void 0 === r && (r = "-"), "" + t + r + e
                },
                ta = () => new Date(getTimestamp() + 864e5),
                tc = t => /^(0|([1-9]\d*))$/.test("" + t),
                tu = t => t,
                tf = t => tu(t),
                tl = t => void 0 !== t.metric_name;

            function tp(t, e) {
                var r, n = t;
                return function() {
                    if (n) {
                        for (var i = arguments.length, o = Array(i), s = 0; s < i; s++) o[s] = arguments[s];
                        r = t.apply(e, o), n = null
                    }
                    return r
                }
            }
            var td = t => U(t),
                th = t => t ? "" + t + "::" + td(20) : to("sessionId"),
                tv = () => {
                    for (var t = z(tt()); 27 !== t.length;) t.length > 27 ? t = t.slice(0, 27) : t += "_";
                    return t
                },
                tg = t => t ? t.split("::")[0] : "",
                t_ = () => isDev() ? "/static/config.js" : CONFIG_URL,
                tI = (t, e) => {
                    if (0 === Object.keys(t).length) return {};
                    var r = {
                            identity_params: {}
                        },
                        n = {
                            email: ["email_is_hashed", "sha256_email"],
                            phone_number: ["phone_is_hashed", "sha256_phone"],
                            zip_code: ["zip_code"]
                        };
                    return F()(e).forEach(e => {
                        var [i, o] = e;
                        o && n[i] && n[i].forEach(e => {
                            if (r.identity_params[e] = [X.EMPTY_VALUE], t[e]) {
                                var n = t[e] || [X.EMPTY_VALUE];
                                r.identity_params && (r.identity_params[e] = [...n])
                            }
                        })
                    }), r
                },
                ty = (t, e) => {
                    var r = {
                        identity_params: {}
                    };
                    return 0 === Object.keys(t).length ? {} : (F()(e).forEach(e => {
                        var [n, i] = e;
                        if (i) {
                            if (t[n] && t[n].length) {
                                var o = t[n] || [X.EMPTY_VALUE];
                                r.identity_params[n] = [...o]
                            } else r.identity_params[n] = [X.EMPTY_VALUE]
                        }
                    }), r)
                };

            function tm(t, e) {
                var r = Object.assign({}, t);
                return e.forEach(t => {
                    null !== r[t] && void 0 !== r[t] && delete r[t]
                }), r
            }
            var tb = (t, e) => {
                if (!t) return {};
                var r = {};
                return Object.keys(t).forEach(n => {
                    e[n] && (r[n] = t[n])
                }), r
            };

            function tS() {
                return (tS = _asyncToGenerator(function*(t) {
                    return void 0 === t && (t = 500), new _Promise(e => {
                        setTimeout(() => {
                            e(!0)
                        }, t)
                    })
                })).apply(this, arguments)
            }

            function tE(t, e) {
                var r = {};
                return t && (te(t) || tr(t) ? r.external_id = t.toString() : tn(t) && (r = t)), e && tn(e) && Object.assign(r, e), r
            }
            var tx = t => {
                    for (var e, r = Array.prototype.slice.call(document.getElementsByTagName("script")), n = 0; n < r.length; n++) {
                        var i = r[n];
                        if (i.innerHTML && i.innerHTML.indexOf(t) > -1) {
                            e = i;
                            break
                        }
                    }
                    return e
                },
                tO = t => {
                    var e = t.parentElement;
                    return !!e && ("HEAD" === e.tagName || tO(e))
                },
                tT = (t, e) => {
                    for (var r = [document.body], n = 0; n <= t && r.length;) {
                        var i, o = r.pop();
                        if (o === e) return !0;
                        if ((null == o ? void 0 : o.tagName.toLowerCase()) === "script" && (null == (i = o.src) ? void 0 : i.indexOf(SDK_HOSTNAME)) > -1) continue;
                        if (n++, "object" == typeof o && !!o.children)
                            for (var s = o.children.length - 1; s >= 0; s--) _pushInstanceProperty(r).call(r, o.children[s])
                    }
                    return !1
                },
                tR = t => tT(10, t),
                tP = t => function() {
                    for (var e = arguments.length, r = Array(e), n = 0; n < e; n++) r[n] = arguments[n];
                    N().resolve().then(() => t(...r))
                };
            /function WeakSet\(\) \{[\s\S]*\[native code\][\s\S]*\}/.test(WeakSet.toString()), /function WeakMap\(\) \{[\s\S]*\[native code\][\s\S]*\}/.test(WeakMap.toString());
            /function Date\(\) \{[\s\S]*\[native code\][\s\S]*\}/.test(Date.toString());
            var tA = function(t) {
                return t.EXTERNAL = "external", t.APP = "app", t.TIKTOK = "tiktok", t
            }({});
            Symbol.for("ID"), Symbol.for("type"), Symbol.for("partner"), Symbol.for("Options"), Symbol.for("Plugins"), Symbol.for("Rules"), Symbol.for("Info"), Symbol.for("extraParams"), Symbol.for("WebLibraryInfo"), Symbol.for("SignalType"), Symbol.for("IsOnsitePage");
            var tN = function(t) {
                    return t[t.OFFSITE = 0] = "OFFSITE", t[t.ONSITE = 1] = "ONSITE", t
                }({}),
                tC = () => {
                    var t;
                    return (null == (t = b()) || null == (t = t._env) ? void 0 : t.env) || tA.EXTERNAL
                },
                tw = () => {
                    var t, e;
                    return null != (t = null == (e = b()) ? void 0 : e._is_onsite) ? t : tN.OFFSITE
                },
                tD = t => (t || tC()) !== tA.EXTERNAL,
                tk = t => (t || tC()) === tA.TIKTOK,
                tL = () => {
                    var t = E();
                    return /windows phone/i.test(t) ? h.WINDOWS_PHONE : /android/i.test(t) ? h.ANDROID : /iPad|iPhone|iPod/.test(t) ? h.IOS : h.PC
                },
                tM = () => {
                    try {
                        return navigator.userAgentData.getHighEntropyValues(["model", "platformVersion"])
                    } catch (t) {
                        return N().resolve({})
                    }
                },
                tj = () => "android" === tL(),
                tF = () => "ios" === tL(),
                tU = () => window.top !== window;
            tp(() => /open_news/i.test(E()));
            tp(() => /ultralite/i.test(E()));
            var tH = () => {
                    try {
                        return window && window.top && window.top.location.href, !1
                    } catch (t) {
                        return !0
                    }
                },
                tB = () => {
                    try {
                        var t = new URL(decodeURIComponent(window.location.href)),
                            e = /https?:\/\/[^\s/$.?#].[^\s]*/i;
                        return e.test(t.search) || e.test(t.pathname)
                    } catch (t) {
                        return !1
                    }
                },
                tV = () => {
                    try {
                        if (!tH()) return w.NOT_CROSS_DOMAIN_IFRAME;
                        if (tB()) return w.URL_IN_QUERY_IFRAME;
                        if (window.google_tag_manager) return w.GTM_IFRAME;
                        if (window.name && "web-pixel-sandbox" === window.name) return w.SANDBOX_IFRAME;
                        return w.CROSS_DOMAIN_IFRAME
                    } catch (t) {
                        return w.UNKNOWN_IFRAME
                    }
                },
                tG = () => S() ? w.WEB_WORKER : tU() ? tV() : w.NORMAL,
                tq = () => {
                    var t = getUserAgent();
                    if (!!t) {
                        for (var e of _Object$values(TT_APP_NAME))
                            if (_includesInstanceProperty(t).call(t, e)) return e
                    }
                },
                tW = () => {
                    var t = getUserAgent();
                    if (!!t) {
                        var e = t.match(/\bapp_version\/(\S*)/),
                            r = e && e[1] ? e[1].match(/^\d+\.\d+\.\d+$/) : void 0;
                        return r ? r[0] : void 0
                    }
                },
                tJ = () => {
                    var t = getUserAgent();
                    if (!!t)
                        for (var e of Object.keys(TT_APP_NAME)) {
                            var r = RegExp("\\b" + TT_APP_NAME[e] + "_(\\S*)"),
                                n = t.match(r),
                                i = n && n[1] ? n[1].match(/^\d+\.\d+\.\d+$/) : void 0;
                            if (i) return i[0]
                        }
                },
                tK = (t, e) => {
                    for (var r = t.split("."), n = e.split("."), i = 0; i < Math.max(r.length, n.length); i++) {
                        var o = parseInt(r[i]) || Number.MAX_VALUE,
                            s = parseInt(n[i]) || -1;
                        if (o < s) break;
                        if (o > s) return !1
                    }
                    return !0
                },
                tz = t => {
                    var e = tq();
                    return void 0 !== e && t.has(e)
                },
                tX = r("2589"),
                tY = r.n(tX),
                tZ = {
                    info: [],
                    error: []
                };

            function t$(t, e, r) {
                void 0 === e && (e = {}), void 0 === r && (r = !1);
                try {
                    var n, i = b(),
                        o = null == i.getPlugin ? void 0 : i.getPlugin("Monitor");
                    o && o.info && "function" == typeof o.info ? o.info.call(o, t, e, r) : R("Monitor") && tY()(n = tZ.info).call(n, {
                        event: t,
                        detail: e,
                        withoutJSB: r
                    })
                } catch (t) {}
            }

            function tQ(t, e, r, n) {
                void 0 === r && (r = {}), void 0 === n && (n = !1);
                try {
                    var i, o = b(),
                        s = null == o.getPlugin ? void 0 : o.getPlugin("Monitor");
                    s && s.error && "function" == typeof s.error ? s.error.call(s, t, e, r, n) : R("Monitor") && tY()(i = tZ.error).call(i, {
                        event: t,
                        err: e,
                        detail: r,
                        withoutJSB: n
                    })
                } catch (t) {}
            }
            var t0 = () => {
                    try {
                        var t = b();
                        if (!(t && t._legacy && 0 !== t._legacy.length)) return !1;
                        return Object.keys(t._t).length > Object.keys(t._legacy || []).length || t.reporters.length > Object.keys(t._legacy || []).length
                    } catch (t) {
                        return !1
                    }
                },
                t1 = function(t) {
                    return t.LOAD_START = "load_start", t.LOAD_END = "load_end", t.BEFORE_INIT = "before_init", t.INIT_START = "init_start", t.INIT_END = "init_end", t.JSB_INIT_START = "jsb_init_start", t.JSB_INIT_END = "jsb_init_end", t.BEFORE_AD_INFO_INIT_START = "before_ad_info_init_start", t.AD_INFO_INIT_START = "ad_info_init_start", t.AD_INFO_INIT_END = "ad_info_init_end", t.IDENTIFY_INIT_START = "identify_init_start", t.IDENTIFY_INIT_END = "identify_init_end", t.PLUGIN_INIT_START = "_init_start", t.PLUGIN_INIT_END = "_init_end", t.PIXEL_SEND = "pixel_send", t.PIXEL_SEND_PCM = "pixel_send_PCM", t.JSB_SEND = "jsb_send", t.HTTP_SEND = "http_send", t.HANDLE_CACHE = "handle_cache", t.INIT_ERROR = "init_error", t.PIXEL_EMPTY = "pixel_empty", t.JSB_ERROR = "jsb_error", t.API_ERROR = "api_error", t.PLUGIN_ERROR = "plugin_error", t.CUSTOM_INFO = "custom_info", t.CUSTOM_ERROR = "custom_error", t.CUSTOM_TIMER = "custom_timer", t
                }({}),
                t2 = (t, e, r) => {
                    t.isBound(e) ? t.rebind(e).toConstantValue(r) : t.bind(e).toConstantValue(r)
                },
                t5 = () => {
                    var t = b();
                    return t && t._i || {}
                },
                t6 = (t, e) => {
                    var {
                        id: r,
                        type: n = ReporterType.PIXEL_CODE,
                        info: i,
                        options: o = {},
                        plugins: s = {},
                        rules: a = []
                    } = e, c = t.get(IDENTIFIER.TTQ), u = t.get(IDENTIFIER.TTQ_REPORTERS);
                    if (!u.some(t => t.getReporterId() === r)) {
                        t2(t, DependencyTypes.ID, r), t2(t, DependencyTypes.Type, n), t2(t, DependencyTypes.Info, i || {
                            [n]: r
                        }), t2(t, DependencyTypes.Options, o), t2(t, DependencyTypes.Plugins, s), t2(t, DependencyTypes.Rules, a), c.enableFirstPartyCookie((null == i ? void 0 : i.firstPartyCookieEnabled) || !1);
                        var f = t.get(IDENTIFIER.REPORTER);
                        if (s) {
                            var {
                                AdvancedMatching: l,
                                AutoAdvancedMatching: p
                            } = s, d = {};
                            l && Object.assign(d, l), p && Object.assign(d, p), f.setAdvancedMatchingAvailableProperties(d)
                        }
                        return f.on(ORIGIN_EVENT_TYPES.BEFORE_REPORT, (t, e, r, n, i) => {
                            c.dispatch(JELLY_CYCLE.PIXEL_SEND, t, e, r, n, i)
                        }, {}), _pushInstanceProperty(u).call(u, f), t.rebind(IDENTIFIER.TTQ_REPORTERS).toConstantValue(u), c.dispatch(JELLY_CYCLE.PIXEL_DID_MOUNT, f), f
                    }
                },
                t3 = (t, e) => (["getReporter", "usePlugin", "getPlugin", "resetCookieExpires", "getEmitter"].forEach(r => {
                    t[r] = function() {
                        for (var t = arguments.length, n = Array(t), i = 0; i < t; i++) n[i] = arguments[i];
                        return e[r].apply(e, n)
                    }
                }), t.context = e.context, t.reporters = e.reporters, t),
                t4 = (t, e) => {
                    var {
                        _partner: r,
                        _ttp: n,
                        _self_host_config: i,
                        _usd_exchange_rate: o,
                        _legacy: s,
                        _cc: a,
                        _variation_id: c,
                        _vids: u,
                        _server_unique_id: f,
                        _currency_list: l,
                        _plugins: p,
                        _aam: d,
                        _auto_config: h,
                        _cde: v,
                        _csid_config: g,
                        _ttls_config: _
                    } = t || {};
                    return Object.assign(e, {
                        partner: r,
                        ttp: n,
                        cc: a,
                        self_host_config: i,
                        usd_exchange_rate: o,
                        legacy: s,
                        variation_id: c,
                        vids: u,
                        server_unqiue_id: f,
                        currency_list: l,
                        plugins: p,
                        aam: d,
                        auto_config: h,
                        cde: v,
                        cookieBasedSessionConfig: g,
                        localServiceConfig: _
                    }), e
                },
                t8 = t => {
                    try {
                        var e = getGlobalTtq();
                        [...CONSENT_API, ...IDENTITY_API].forEach(r => {
                            e.find((n, i) => {
                                var [o, ...s] = n;
                                if (o === r) return t[r].apply(t, s), e.splice(i, 1), !0
                            })
                        })
                    } catch (t) {
                        error(MONITOR_EVENT.API_ERROR, t, {
                            extJSON: {
                                api: "handleP0APICache"
                            }
                        })
                    }
                },
                t7 = t => {
                    var e = getGlobalTtq();
                    if (e.length > 0)
                        for (; e.length;) {
                            var r = e.shift();
                            if (!!r) {
                                var [n, ...i] = r;
                                switch (!containPartner("Tealium") && setInstanceCache(n, i), n) {
                                    case "identify":
                                        t.identify(i[0], i[1]);
                                        break;
                                    case "page":
                                        t.page(i[0]);
                                        break;
                                    case "track":
                                        t.track(i[0], i[1], i[2] || {});
                                        break;
                                    case "enableCookie":
                                        t.enableCookie();
                                        break;
                                    case "disableCookie":
                                        t.disableCookie();
                                        break;
                                    case "holdConsent":
                                        t.holdConsent();
                                        break;
                                    case "revokeConsent":
                                        t.revokeConsent();
                                        break;
                                    case "grantConsent":
                                        t.grantConsent()
                                }
                            }
                        }
                },
                t9 = function(t) {
                    void 0 === t && (t = {});
                    var e = Object.assign({}, {
                        path: "/"
                    }, t);
                    "number" == typeof e.expires && (e.expires = new Date(tt() + 864e5 * e.expires)), e.expires instanceof Date && (e.expires = e.expires.toUTCString());
                    var r = "";
                    for (var n in e) {
                        if (!e[n]) continue;
                        if (r += "; " + n, !0 !== e[n]) r += "=" + e[n].split(";")[0]
                    }
                    return r
                },
                et = t => {
                    if (t && t.cde) {
                        var e = t.cde;
                        return Object.assign({}, g, {
                            expires: e
                        })
                    }
                    return g
                };
            class ee {
                getCookie(t) {
                    var e = this;
                    return M()(function*() {
                        var {
                            browser: r
                        } = e.sandboxPixelAPI, n = "";
                        try {
                            n = yield r.cookie.get(t)
                        } catch (e) {
                            try {
                                n = yield r.cookie.get(t)
                            } catch (t) {}
                        }
                        return n || ""
                    })()
                }
                parseCookies() {
                    var t = this;
                    return M()(function*() {
                        var e = yield t.getCookie(""), r = {}, n = e.split("; ");
                        if (!e) return r;
                        for (var i of n) {
                            var [o, s] = i.split("=");
                            r[o] = decodeURIComponent(s)
                        }
                        return r
                    })()
                }
                setCookieHandler(t, e, r) {
                    var n = this;
                    return M()(function*() {
                        try {
                            var {
                                browser: i,
                                getShopifyPageInfo: o
                            } = n.sandboxPixelAPI, {
                                location: s
                            } = o(), a = s.hostname || "";
                            return yield i.cookie.set(t + "=" + e + t9(Object.assign({}, r || n.cookieExpireOption, {
                                domain: "." + a
                            })))
                        } catch (t) {}
                        return ""
                    })()
                }
                setCookie(t, e, r) {
                    var n = this;
                    return M()(function*() {
                        var {
                            getShopifyPageInfo: i
                        } = n.sandboxPixelAPI, o = yield n.parseCookies();
                        if (0 === Object.keys(o).length || !o[t]) return yield n.setCookieHandler(t, e, r), e;
                        var {
                            referrer: s
                        } = i();
                        return !s || s.indexOf("www.tiktok.com") > 0 ? o[t] : (yield n.setCookieHandler(t, e, r), e)
                    })()
                }
                genCookieID() {
                    return tv()
                }
                enableFirstPartyCookie(t) {
                    var e = this;
                    return M()(function*() {
                        if (!t) return "";
                        var r = yield e.parseCookies(), n = r[f] || "", i = r._sttp || "";
                        e.initCookie = n || i;
                        var o = (n || i || e.genCookieID()).split(".")[0];
                        return yield e.setAnonymousId(o)
                    })()
                }
                setAnonymousId(t) {
                    var e = this;
                    return M()(function*() {
                        return (yield e.setCookie(f, e.convertToNewTtpCookieFormat(t), e.cookieExpireOption)) || ""
                    })()
                }
                convertToNewTtpCookieFormat(t) {
                    return t.split(".")[0] + ".tt.0"
                }
                verifyCookieWhenReport(t) {
                    var e = this;
                    return M()(function*() {
                        var {
                            context: r
                        } = t, n = null == r || null == (o = r.user) ? void 0 : o.anonymous_id;
                        if (!!n) {
                            var i = ((yield e.parseCookies())[f] || "").split(".")[0];
                            if (i && n.split(".")[0] !== i) {
                                var o, s, c = e.convertToNewTtpCookieFormat(i),
                                    u = self[self[a]] || [];
                                t.context.user.anonymous_id = c, null == u || null == (s = u.context) || s.setUserInfoWithoutIdentifyPlugin({
                                    anonymous_id: c
                                }), setTimeout(() => {
                                    t$(t1.CUSTOM_INFO, {
                                        custom_name: "sandbox_cookie_conflicts",
                                        extJSON: {
                                            event: t.event,
                                            event_id: t.event_id,
                                            message_id: t.message_id,
                                            message: i + ":" + n + ":" + e.initCookie
                                        }
                                    })
                                })
                            }
                        }
                    })()
                }
                constructor(t, e) {
                    this.sandboxPixelAPI = void 0, this.cookieExpireOption = void 0, this.initCookie = void 0, this.sandboxPixelAPI = t, this.cookieExpireOption = et(e), this.initCookie = ""
                }
            }
            class er {
                fetch(t, e, r, n, i, o) {
                    return M()(function*() {
                        return self.fetch(t, {
                            method: e,
                            credentials: i || "omit",
                            body: JSON.stringify(r || {}),
                            headers: n
                        }).then(() => !0).catch(t => (o && tQ(t1.CUSTOM_ERROR, t, {
                            custom_name: o
                        }), !1))
                    })()
                }
                send(t, e) {
                    var r = this;
                    return M()(function*() {
                        return r.fetch(t, "POST", e)
                    })()
                }
            }
            class en {
                getAdInfo() {
                    return N().resolve({})
                }
                getAppInfo() {
                    return N().resolve({})
                }
                send() {
                    return N().resolve({})
                }
            }
            class ei {
                pushPreposition(t) {
                    var e;
                    tY()(e = this.reportPreTasks).call(e, t)
                }
                report(t, e, r, n) {
                    return M()(function*() {
                        return N().resolve()
                    })()
                }
                constructor(t, e, r) {
                    this.httpService = void 0, this.bridgeService = void 0, this.reportPreTasks = void 0, this.httpService = t, this.bridgeService = e, this.reportPreTasks = r
                }
            }
            var eo = function(t) {
                    return t.LDU = "limited_data_use", t.EVENTID = "eventID", t.EVENT_ID = "event_id", t
                }({}),
                es = function(t) {
                    return t[t.defaultReport = 0] = "defaultReport", t[t.httpReport = 1] = "httpReport", t[t.htmlHttpReport = 2] = "htmlHttpReport", t
                }({}),
                ea = function(t) {
                    return t[t.P0 = 0] = "P0", t[t.P1 = 1] = "P1", t[t.P2 = 2] = "P2", t
                }({}),
                ec = "https://analytics.tiktok.com/api/v2",
                eu = ec + "/pixel",
                ef = ec + "/performance",
                el = ec + "/interaction",
                ep = ec + "/performance_interaction",
                ed = ec + "/pixel/perf",
                eh = ec + "/pixel/inter",
                ev = ec + "/pixel/act",
                eg = ec + "/shopify_pixel",
                e_ = ec + "/monitor",
                eI = "https://analytics-ipv6.tiktokw.us/ipv6/enrich_ipv6",
                ey = "_toutiao_params",
                em = r("5880"),
                eb = r.n(em),
                eS = t => {
                    var e = Array(t.length),
                        r = 0;
                    return new(N())((n, i) => {
                        for (var o = function(i) {
                                var o = t[i];
                                o && "function" == typeof o.then ? o.then(o => {
                                    e[i] = {
                                        status: "fulfilled",
                                        value: o
                                    }, ++r === t.length && n(e)
                                }).catch(o => {
                                    e[i] = {
                                        status: "rejected",
                                        reason: o
                                    }, ++r === t.length && n(e)
                                }) : (e[i] = {
                                    status: "fulfilled",
                                    value: o
                                }, ++r === t.length && n(e))
                            }, s = 0; s < t.length; s++) o(s)
                    })
                },
                eE = t => "function" == typeof eb() ? eb()(t) : eS(t),
                ex = function(t) {
                    return t[t.PENDING = 0] = "PENDING", t[t.FULFILLED = 1] = "FULFILLED", t
                }(ex || {});
            class eO {
                push(t) {
                    var e;
                    this.status = ex.PENDING, tY()(e = this.promiseQueue).call(e, t)
                }
                then(t) {
                    return this.status === ex.FULFILLED ? N().resolve(t()) : eE(this.promiseQueue).then(() => (this.status = ex.FULFILLED, t()))
                }
                constructor() {
                    this.promiseQueue = [], this.status = ex.FULFILLED
                }
            }
            class eT extends ei {
                report(t, e, r) {
                    var n = this;
                    return M()(function*() {
                        void 0 === r && (r = es.defaultReport);
                        var i = t === eg;
                        return (t !== e_ && (yield n.cookieService.verifyCookieWhenReport(e)), i) ? (!(yield n.httpService.fetch(t, "POST", e, {}, "include", "sandbox_req_err")) && n.httpService.fetch(eu, "POST", e, {
                            "Content-Type": "application/json"
                        }, "omit", "sandbox_send_err"), N().resolve()) : (n.httpService.send(t, e), N().resolve())
                    })()
                }
                constructor(t, e, r) {
                    super(t, e, new eO), this.httpService = void 0, this.cookieService = void 0, this.httpService = t, this.cookieService = r
                }
            }
            var eR = {
                cachedReferrer: "",
                cachedTitle: "",
                cachedHref: "",
                timer: null
            };

            function eP(t, e) {
                try {
                    var r = new URL(t),
                        n = r.searchParams.getAll(e);
                    if (0 !== n.length) return n[n.length - 1] || "";
                    return new URLSearchParams(r.hash).get(e) || ""
                } catch (t) {
                    return ""
                }
            }
            var eA = (t, e, r) => {
                try {
                    var n = eP(e, t);
                    if (n) return n;
                    return eP(r || "", t)
                } catch (t) {}
                return ""
            };

            function eN() {
                eR.cachedHref = window.location.href, eR.cachedReferrer = document.referrer, eR.cachedTitle = document.title, eR.timer && clearTimeout(eR.timer), eR.timer = setTimeout(() => {
                    eR.cachedHref = "", eR.cachedReferrer = "", eR.cachedTitle = "", eR.timer = null
                }, 3e3)
            }
            var eC = () => {
                    if (!tU()) return (window.location.href !== eR.cachedHref || null === eR.timer) && eN(), {
                        url: eR.cachedHref,
                        referrer: eR.cachedReferrer,
                        title: eR.cachedTitle
                    };
                    if (!tH()) {
                        var t, e, r;
                        return {
                            url: (null == (t = window) || null == (t = t.top) ? void 0 : t.location.href) || "",
                            referrer: (null == (e = window) || null == (e = e.top) ? void 0 : e.document.referrer) || "",
                            title: (null == (r = window) || null == (r = r.top) ? void 0 : r.document.title) || ""
                        }
                    }
                    if ((null === eR.timer || window.location.href !== eR.cachedHref) && eN(), /doubleclick\.net/.test(window.location.hostname)) {
                        var n = window.location.pathname,
                            i = {};
                        return n.split(";").forEach(t => {
                            var [e, r] = t.split("=");
                            e && r && (i[e] = decodeURIComponent(r))
                        }), {
                            url: i["~oref"] || eR.cachedHref,
                            referrer: eR.cachedReferrer,
                            title: eR.cachedTitle
                        }
                    }
                    return {
                        url: eR.cachedHref,
                        referrer: eR.cachedReferrer,
                        title: eR.cachedTitle
                    }
                },
                ew = t => {
                    var e;
                    return (null == t || null == (e = t.localServiceConfig) ? void 0 : e.key) || _
                },
                eD = (t, e) => {
                    try {
                        var r = eA("ttclid", t, e) || void 0,
                            n = eA("ext_params", t, e) || void 0,
                            i = eA(ey, t, e) || void 0,
                            o = parseInt(eA("ttuts", t, e), 10) || void 0,
                            {
                                log_extra: s,
                                idc: a,
                                cid: c
                            } = i ? JSON.parse(i) : {};
                        return {
                            callback: r,
                            ext_params: n,
                            log_extra: s,
                            creative_id: c,
                            idc: a,
                            ttuts: o,
                            ad_info_from: (s || a || c) && "url"
                        }
                    } catch (t) {
                        return {}
                    }
                },
                ek = (t, e) => {
                    try {
                        var {
                            log_extra: r,
                            ttuts: n
                        } = t;
                        if (!tF()) return !0;
                        if (!tk(e)) {
                            if (null != n) return 1 !== n;
                            return !0
                        }
                        if (r) {
                            var i = JSON.parse(r);
                            return 1 !== i.user_tracking_status
                        }
                        if (null === t.ATTStatus || void 0 === t.ATTStatus) return !0;
                        return 3 === t.ATTStatus
                    } catch (t) {
                        return !1
                    }
                },
                eL = (t, e) => {
                    var r = {};
                    try {
                        var {
                            creative_id: n,
                            callback: i,
                            idc: o,
                            convert_id: s,
                            ad_info_from: a,
                            ad_info_status: c,
                            log_extra: u,
                            ext_params: f,
                            ATTStatus: l
                        } = t;
                        if (n && (r.creative_id = n), o && (r.idc = o), s && (r.convert_id = s), a && (r.ad_info_from = a), c && (r.ad_info_status = c), f && (r.ext_params = f), l && (r.ATTStatus = l), u) {
                            var {
                                ad_user_agent: p,
                                ad_id: d,
                                rit: h,
                                ocbs: v,
                                vid: g,
                                idc: _,
                                country_id: I
                            } = JSON.parse(u);
                            d && (r.ad_id = d), h && (r.rit = h), p && (r.ad_user_agent = p), v && (r.ocbs = v), g && (r.vid = g), _ && (r.idc = _), I && (r.country_id = I)
                        }
                        return r
                    } catch (t) {
                        return e && e(t), r
                    }
                };
            class eM {
                getAdInfoFromCache() {
                    var t = this;
                    return M()(function*() {
                        var e = {};
                        if (!t.sandboxPixelAPI) return e;
                        try {
                            var {
                                getSessionStorageInSandbox: r
                            } = t.sandboxPixelAPI, n = JSON.parse((yield r(c)) || "{}");
                            tn(n) && Object.keys(n).length > 0 && (n.ad_info_from = "cache", n.ad_info_status = "fulfilled(cache)"), Object.assign(e, n)
                        } catch (t) {
                            tQ(t1.INIT_ERROR, t, {
                                extJSON: {
                                    position: "initAdInfo"
                                }
                            })
                        }
                        return e
                    })()
                }
                getAdInfo(t, e) {
                    var r = this;
                    return M()(function*() {
                        var n = {};
                        if (!r.sandboxPixelAPI && !t) return n;
                        try {
                            var {
                                getShopifyPageInfo: i,
                                setSessionStorageInSandbox: o
                            } = r.sandboxPixelAPI, {
                                referrer: s,
                                location: a
                            } = i(), u = eD(t || a && a.href || "", e || s || "");
                            Object.assign(n, u), r.sandboxPixelAPI && n && (n.creative_id && n.log_extra || n.callback) && (yield o(c, JSON.stringify(n)))
                        } catch (t) {
                            tQ(t1.INIT_ERROR, t, {
                                extJSON: {
                                    position: "initAdInfo"
                                }
                            })
                        }
                        return n
                    })()
                }
                constructor(t) {
                    this.sandboxPixelAPI = void 0, this.sandboxPixelAPI = t
                }
            }
            class ej {
                getAppInfo(t, e) {
                    var r = this;
                    return M()(function*() {
                        var n = {};
                        if (!r.sandboxPixelAPI || !t && !e) return n;
                        Object.assign(n, r.getAppInfoFromURL(t, e));
                        try {
                            var {
                                getSessionStorageInSandbox: i,
                                setSessionStorageInSandbox: o
                            } = r.sandboxPixelAPI, s = JSON.parse((yield i(u)) || "{}");
                            if (Object.keys(s).length > 0) return s;
                            if (n.platform = tL(), tj()) {
                                var {
                                    model: a,
                                    platformVersion: c
                                } = yield tM();
                                n.device_model = a, n.android_version = c
                            }!ti(n) && (yield o(u, JSON.stringify(n)))
                        } catch (t) {
                            tQ(t1.INIT_ERROR, t, {
                                extJSON: {
                                    position: "initAppInfo"
                                }
                            })
                        }
                        return n
                    })()
                }
                getAppInfoFromURL(t, e) {
                    try {
                        var r = eA(ey, t, e),
                            {
                                device_id: n,
                                uid: i
                            } = r && JSON.parse(r);
                        return {
                            device_id: n,
                            user_id: i
                        }
                    } catch (t) {
                        return {}
                    }
                }
                constructor(t) {
                    this.sandboxPixelAPI = void 0, this.sandboxPixelAPI = t
                }
            }
            var eF = r("6762"),
                eU = r.n(eF),
                eH = function(t) {
                    return t.INIT_START = "initStart", t.INIT_END = "initEnd", t.PATCH_END = "patchEnd", t.CONTEXT_INIT_START = "contextInitStart", t.CONTEXT_INIT_END = "contextInitEnd", t.PAGE_URL_WILL_CHANGE = "pageUrlWillChange", t.PAGE_URL_DID_CHANGE = "pageUrlDidChange", t.PAGE_DID_LOAD = "pageDidLoad", t.PAGE_WILL_LEAVE = "pageWillLeave", t.PAGE_LCP = "pageLcp", t.AD_INFO_INIT_START = "adInfoInitStart", t.AD_INFO_INIT_END = "adInfoInitEnd", t.BEFORE_AD_INFO_INIT_START = "beforeAdInfoInitStart", t.PIXEL_SEND = "pixelSend", t.PIXEL_DID_MOUNT = "pixelDidMount", t
                }({}),
                eB = function(t) {
                    return t.UNKNOWN = "-1", t.LOADING = "0", t.INTERACTIVE = "1", t.COMPLETE = "2", t
                }({}),
                eV = (t, e) => {
                    var r;
                    return !!(null != e && null != (r = e.cookieBasedSessionConfig) && r.enable && t.firstPartyCookieEnabled)
                },
                eG = () => {
                    var t = new Date().getTime();
                    return {
                        sessionId: t.toString() + "::" + td(20),
                        sessionCount: 1,
                        lastEventTS: t,
                        isSessionStart: !0,
                        hasReportedES: 0
                    }
                },
                eq = t => {
                    var e = {};
                    return t.split("; ").forEach(t => {
                        var [r, n] = t.split("=");
                        if (r.startsWith(d)) {
                            var i = r.replace(d, "").replace("_", ""),
                                [o, s, a, c] = n.split(".");
                            o && tc(s) && tc(a) && (e[i] = {
                                sessionId: o,
                                sessionCount: Number(s),
                                lastEventTS: Number(a),
                                hasReportedES: Number("1" === c ? 1 : 0)
                            })
                        }
                    }), e
                },
                eW = t => {
                    var {
                        sessionCount: e,
                        lastEventTS: r
                    } = t, n = new Date().getTime();
                    return n - r > 18e5 ? {
                        sessionId: n.toString() + "::" + td(20),
                        sessionCount: e + 1,
                        lastEventTS: n,
                        isSessionStart: !0
                    } : k()({}, t, {
                        lastEventTS: n,
                        isSessionStart: !1
                    })
                },
                eJ = t => {
                    var {
                        sessionId: e,
                        sessionCount: r,
                        lastEventTS: n,
                        hasReportedES: i
                    } = t;
                    return e + "." + r + "." + n + "." + (null != i ? i : 0)
                },
                eK = (t, e, r) => {
                    var {
                        sessionId: n = "",
                        sessionCount: i = 1,
                        isSessionStart: o = !1
                    } = t || {};
                    return Object.assign({
                        csid: n,
                        page_csid: e ? e.sessionId : "",
                        csct: i
                    }, o ? {
                        css: 1
                    } : {}, r ? {
                        pixel_code: r
                    } : {})
                };
            class ez {
                getParameterInfo() {
                    return N().resolve({
                        pixelCode: this.pixelCode,
                        name: this.name,
                        status: this.status,
                        setupMode: this.setupMode,
                        advertiserID: this.advertiserID,
                        partner: this.partner,
                        is_onsite: !1,
                        advancedMatchingAvailableProperties: {}
                    })
                }
                getReporterId() {
                    return ""
                }
                getReporterUniqueLoadId() {
                    return ""
                }
                getReporterPartner() {}
                getReporterInfo() {
                    return {
                        reporter: {}
                    }
                }
                getReportResultSet() {
                    return []
                }
                isOnsite() {
                    return !1
                }
                isPartnerReporter() {
                    return !1
                }
                setAdvancedMatchingAvailableProperties(t) {}
                clearHistory() {}
                page(t) {}
                identify(t, e) {}
                track(t, e, r) {
                    return N().resolve(null)
                }
                getUserInfo(t) {
                    return {}
                }
                getReporterMatchedUserFormatInfo() {
                    return {}
                }
                getReporterMatchedUserFormatInfoV2() {
                    return {}
                }
                assemblyData() {
                    return {
                        event: "",
                        message_id: "",
                        event_id: "",
                        is_onsite: !1,
                        properties: {},
                        context: {
                            ad: {},
                            device: {},
                            library: {
                                name: "",
                                version: ""
                            },
                            page: {
                                url: ""
                            },
                            pageview_id: "",
                            session_id: "",
                            variation_id: "",
                            user: {}
                        },
                        partner: "",
                        timestamp: ""
                    }
                }
                assemblySelfHostData() {
                    return this.assemblyData()
                }
                trackSync() {}
                getReportEventHistoryKey(t) {
                    return "tiktok"
                }
                hasReportEventHistory(t, e) {
                    return !1
                }
                getCookieBasedSession() {
                    return eG()
                }
                setCookieBasedSession(t) {}
                constructor(t) {
                    this.pixelCode = "", this.loaded = !1, this.status = 1, this.name = "", this.advertiserID = "", this.setupMode = 0, this.partner = "", this.reporterInfo = {}, this.plugins = {}, this.options = {}, this.rules = [], this.pixelCode = t
                }
            }
            new ez("empty");
            class eX {
                init(t, e) {
                    this.initContextInfo(t, e), this.initialize = !0
                }
                initContextInfo(t, e) {
                    this.dispatch(eH.CONTEXT_INIT_START), this.initAdInfo(t, e), this.initAppInfo(t, e), this.initLocalServiceInfo(), this.reportService.pushPreposition(N().resolve().then(() => this.initUserInfo())), this.initTestId(t, e), this.dispatch(eH.CONTEXT_INIT_END)
                }
                setPageIndex(t) {}
                setPageInfo(t, e) {
                    var r = this.context.getPageInfo().url;
                    if (r !== t) {
                        this.dispatch(eH.PAGE_URL_WILL_CHANGE, e || r, t);
                        var n = this.context.setPageInfo(t, e || r);
                        (null == n ? void 0 : n.pageIndex) && this.setPageIndex(n.pageIndex), this.dispatch(eH.PAGE_URL_DID_CHANGE, t, r)
                    }
                }
                initAdInfo(t, e) {}
                initOffsiteAdInfo(t) {}
                initAppInfo(t, e) {}
                initUserInfo() {}
                initTestId(t, e) {}
                usePlugin(t) {
                    try {
                        if (!this.plugins.find(e => e.name === t.name)) {
                            tY()(e = this.plugins).call(e, t);
                            var e, r = t.name;
                            r && (this[r[0].toLowerCase() + r.slice(1) + "Plugin"] = t)
                        }
                    } catch (t) {}
                }
                useObserver(t) {
                    try {
                        if (!this.observers.find(e => e.name === t.name)) {
                            tY()(e = this.observers).call(e, t);
                            var e, r = t.name;
                            r && (this["" + (r[0].toLowerCase() + r.slice(1))] = t)
                        }
                    } catch (t) {}
                }
                getPlugin(t) {
                    return this.plugins.find(e => e.name === t) || null
                }
                getReporter(t) {
                    return this.reporters.find(e => e.getReporterId() === t)
                }
                instance(t) {
                    var e = this.getReporter(t);
                    return e ? e : (tQ(t1.PIXEL_EMPTY, Error(""), {
                        pixelCode: t
                    }), new ez(t))
                }
                instances() {
                    return this.reporters
                }
                identify(t, e) {
                    var r = tE(t, e);
                    this.context.setUserInfo(r)
                }
                page(t) {
                    t.url !== this.context.getPageInfo().url && (this.setPageInfo(t.url, t.referrer), this.reporters.forEach(t => {
                        t.clearHistory()
                    }));
                    var e = Object.assign({}, t);
                    delete e.url, delete e.referrer, this.reporters.forEach(t => {
                        t.page(e)
                    })
                }
                isOnsitePage() {
                    return this.context.getSignalType() === tN.ONSITE || this.reporters.every(t => t.isOnsite())
                }
                track(t, e, r) {
                    void 0 === e && (e = {}), void 0 === r && (r = {}), this.instances().forEach((n, i) => {
                        n.track(t, e, Object.assign({
                            _i: i
                        }, r))
                    })
                }
                dispatch(t) {
                    for (var e = arguments.length, r = Array(e > 1 ? e - 1 : 0), n = 1; n < e; n++) r[n - 1] = arguments[n];
                    this.plugins.concat(this.observers).forEach(e => {
                        if ("function" == typeof e[t]) try {
                            e[t].apply(e, r)
                        } catch (n) {
                            tQ(t1.PLUGIN_ERROR, n, {
                                extJSON: {
                                    plugin_name: e.name,
                                    cycle_name: t,
                                    data: r
                                }
                            })
                        }
                    })
                }
                getAllReportResultSet() {
                    var t;
                    return eU()(t = this.instances()).call(t, (t, e) => t.concat(e.getReportResultSet()), [])
                }
                resetCookieExpires() {}
                enableCookie() {}
                disableCookie() {}
                enableFirstPartyCookie(t) {}
                holdConsent() {}
                revokeConsent() {}
                grantConsent() {}
                initLocalServiceInfo() {}
                getEmitter() {
                    return this.emitter
                }
                constructor(t, e, r, n) {
                    this.context = void 0, this.reportService = void 0, this.initialize = !1, this.plugins = [], this.observers = [], this.reporters = [], this.emitter = void 0, this.sensitiveRedactor = void 0, this.context = t, this.reportService = e, r && (this.emitter = r), n && (this.sensitiveRedactor = n)
                }
            }
            var eY = function(t) {
                    return t.BEFORE_REPORT = "beforeReport", t.QUEUE = "queue", t
                }({}),
                eZ = function(t) {
                    return t.UPDATE_CONFIG = "observer:updateConfig", t
                }({});
            class e$ {
                initStart() {}
                initEnd() {}
                adInfoInitStart() {}
                adInfoInitEnd() {}
                contextInitStart() {}
                contextInitEnd() {}
                pageUrlWillChange(t, e) {}
                pageUrlDidChange(t, e) {}
                pageDidLoad() {}
                pageWillLeave(t) {}
                pageLcp(t) {}
                pixelSend(t, e, r, n, i) {}
                pixelDidMount(t) {}
                patchEnd() {}
                constructor(t) {
                    var {
                        name: e,
                        context: r,
                        reporters: n
                    } = t;
                    this.context = void 0, this.reporters = [], this.name = void 0, this.context = r, this.reporters = n, this.name = e
                }
            }
            class eQ extends e$ {}
            var e0 = String.fromCharCode.bind(String),
                e1 = Array.prototype.slice.call("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="),
                e2 = t => {
                    for (var e, r, n, i, o = "", s = t.length % 3, a = 0; a < t.length;) {
                        if ((r = t.charCodeAt(a++)) > 255 || (n = t.charCodeAt(a++)) > 255 || (i = t.charCodeAt(a++)) > 255) throw TypeError("invalid character found");
                        e = r << 16 | n << 8 | i, o += e1[e >> 18 & 63] + e1[e >> 12 & 63] + e1[e >> 6 & 63] + e1[63 & e]
                    }
                    return s ? o.slice(0, s - 3) + "===".substring(s) : o
                },
                e5 = function(t) {
                    if (t.length < 2) {
                        var e = t.charCodeAt(0);
                        return e < 128 ? t : e < 2048 ? e0(192 | e >>> 6) + e0(128 | 63 & e) : e0(224 | e >>> 12 & 15) + e0(128 | e >>> 6 & 63) + e0(128 | 63 & e)
                    }
                    var r = 65536 + (t.charCodeAt(0) - 55296) * 1024 + (t.charCodeAt(1) - 56320);
                    return e0(240 | r >>> 18 & 7) + e0(128 | r >>> 12 & 63) + e0(128 | r >>> 6 & 63) + e0(128 | 63 & r)
                },
                e6 = /[\uD800-\uDBFF][\uDC00-\uDFFFF]|[^\x00-\x7F]/g,
                e3 = t => t.replace(e6, e5),
                e4 = t => t.replace(/=/g, "").replace(/[+\/]/g, function(t) {
                    return "+" === t ? "-" : "_"
                }),
                e8 = t => e4(e2(e3(t))),
                e7 = t => e8(t),
                e9 = t => e7(JSON.stringify(t)),
                rt = function(t) {
                    return t[t.NOT_DETERMINED = 0] = "NOT_DETERMINED", t[t.RESTRICTED = 1] = "RESTRICTED", t[t.DENIED = 2] = "DENIED", t[t.AUTHORIZED = 3] = "AUTHORIZED", t
                }({}),
                re = function(t) {
                    return t[t.OTHER = 0] = "OTHER", t[t.ANDROID = 1] = "ANDROID", t[t.IOS = 2] = "IOS", t
                }({}),
                rr = [t1.LOAD_START, t1.LOAD_END, t1.INIT_START, t1.INIT_END, t1.JSB_INIT_START, t1.JSB_INIT_END, t1.AD_INFO_INIT_START, t1.AD_INFO_INIT_END, t1.IDENTIFY_INIT_START, t1.IDENTIFY_INIT_END, t1.PLUGIN_INIT_START, t1.PLUGIN_INIT_END],
                rn = [t1.BEFORE_INIT, t1.INIT_START, t1.INIT_END, t1.HTTP_SEND, t1.AD_INFO_INIT_END],
                ri = t => rn.indexOf(t) > -1,
                ro = "Monitor";
            class rs extends eQ {
                reportSwitch() {
                    return !this.reporters.some(t => {
                        var e;
                        return (null == (e = t.options) ? void 0 : e.monitor) === !1
                    })
                }
                recordReportLog(t) {
                    var e, r = t.pixel_code;
                    !this.hasReportMap[r] && (this.hasReportMap[r] = []), tY()(e = this.hasReportMap[r]).call(e, t)
                }
                send(t, e) {
                    var r = this;
                    return M()(function*() {
                        !(yield r.httpService.send(t, e)) && r.httpService.sendByImage && r.httpService.sendByImage(t, {
                            log_message: e9(e)
                        })
                    })()
                }
                sendByReportService(t) {
                    var e = ri(t.metric_name);
                    this.reportService.report(e_, t, e ? es.defaultReport : es.htmlHttpReport, e ? ea.P0 : ea.P1)
                }
                report(t, e) {
                    if (void 0 === e && (e = !1), this.recordReportLog(t), e) {
                        this.send(e_, t);
                        return
                    }
                    if (!this.contextInitEndStatus) {
                        var r;
                        tY()(r = this.cachedData).call(r, t);
                        return
                    }
                    this.sendByReportService(t)
                }
                contextInitEnd() {
                    for (this.contextInitEndStatus = !0; this.cachedData.length;) {
                        var t = this.cachedData.shift();
                        t && null != t.metric_name && this.sendByReportService(t)
                    }
                }
                info(t, e, r) {
                    if (void 0 === e && (e = {}), void 0 === r && (r = !1), !!this.reportSwitch()) try {
                        var n = this.assemblyBaseData(t, e);
                        if (this.isRepeatLog(n)) return;
                        this.report(n, r)
                    } catch (t) {}
                }
                error(t, e, r, n) {
                    if (void 0 === r && (r = {}), void 0 === n && (n = !1), !!this.reportSwitch()) try {
                        var i = this.assemblyBaseData(t, r);
                        if (Object.assign(i.ext_json || {}, {
                                message: e.message,
                                stack: e.stack
                            }), this.isRepeatLog(i)) return;
                        this.report(i, n)
                    } catch (t) {}
                }
                isRepeatLog(t) {
                    var {
                        pixel_code: e,
                        metric_name: r
                    } = t;
                    if (!e || !r) return !1;
                    var n = rr.some(t => r.indexOf(t) > -1),
                        i = this.hasReportMap[e],
                        o = i && i.some(t => t.metric_name === r);
                    return n && o
                }
                getReportInfo(t) {
                    var e = this.reporters.find(e => e.getReporterId() === t);
                    if (e) return e.reporterInfo;
                    var r = b()._i[t];
                    if (r) return r.info
                }
                assemblyBaseData(t, e) {
                    var {
                        pixelCode: r,
                        extJSON: n,
                        custom_name: i,
                        custom_enum: o,
                        app_name: a = "",
                        latency: c = 0
                    } = e || {}, u = b(), {
                        env: f = "",
                        platform: l,
                        context: p,
                        reporters: d
                    } = this, {
                        libraryInfo: h,
                        pageInfo: v,
                        adInfo: g,
                        pageSign: _,
                        enableAdTracking: I
                    } = p.getAllData(), y = p.getVariationId(), S = p.getVids(), x = this.legacy || [], O = g && g.log_extra && function(t) {
                        try {
                            return JSON.parse(t)
                        } catch (t) {
                            return {}
                        }
                    }(g.log_extra) || {}, R = d.map(t => t.getReporterId()), P = r || function() {
                        var t = {
                            lib: "ttq",
                            pixelCode: "MOCK_SHOP_ID"
                        };
                        try {
                            var e = document && document.currentScript,
                                r = e && e.getAttribute("data-id") || "",
                                n = m() || "ttq";
                            t = {
                                pixelCode: r,
                                lib: n
                            }
                        } catch (e) {
                            t = {
                                lib: "ttq",
                                pixelCode: ""
                            }
                        }
                        return t
                    }().pixelCode || this.pixelCode || this.reporters[0] && this.reporters[0].getReporterId() || Object.keys(u._i)[0] || "", A = this.getReportInfo(P), N = x.length ? s()(x).call(x, P) ? "legacy-ttq" : "ttq" : this.lib, C = T(P) || this.partner || "non", w = I ? rt.AUTHORIZED : rt.DENIED, D = {
                        metric_name: t,
                        pixel_code: P,
                        platform: l,
                        app_name: a || f,
                        net_type: function() {
                            try {
                                var t = navigator && (navigator.connection || navigator.mozConnection || navigator.webkitConnection);
                                return t ? t.effectiveType : ""
                            } catch (t) {}
                            return ""
                        }(),
                        placement: O.placement || "non",
                        lib: {
                            lib_version: h && h.version || "",
                            ttq_name: N
                        },
                        in_iframe: Number(tG()),
                        time_to_last_start: -1,
                        time_to_navigation_start: -1,
                        latency: c,
                        page_url: v && v.url || eC().url,
                        att_status: w,
                        pageview_id: this.context.getPageViewId() || "",
                        session_id: _ && _.sessionId || "",
                        variation_id: y,
                        vids: S,
                        load_id: A && A.loadId || "",
                        ad_id: String(g.ad_id),
                        creative_id: String(g.creative_id || O.creative_id),
                        user_agent: E(),
                        pixel_monitor_version: "v2",
                        custom_name: i,
                        custom_enum: o,
                        partner: C,
                        ext_json: {
                            performance: [],
                            pixel_list: R.toString(),
                            ad_info_from: g.ad_info_from,
                            pixel_api_conflict_flag: t0()
                        }
                    };
                    return n && Object.assign(D.ext_json, n), D
                }
                initStart(t) {
                    this.info(t1.INIT_START, t)
                }
                initEnd(t) {
                    this.info(t1.INIT_END, t)
                }
                jsbInitStart() {
                    this.info(t1.JSB_INIT_START)
                }
                jsbInitEnd() {
                    this.info(t1.JSB_INIT_END)
                }
                beforeAdInfoInitStart(t) {
                    this.info(t1.BEFORE_AD_INFO_INIT_START, t)
                }
                adInfoInitStart(t) {
                    this.info(t1.AD_INFO_INIT_START, t)
                }
                adInfoInitEnd(t) {
                    this.info(t1.AD_INFO_INIT_END, t)
                }
                pluginInitStart(t) {
                    this.info(t + t1.PLUGIN_INIT_START)
                }
                pluginInitEnd(t) {
                    this.info(t + t1.PLUGIN_INIT_END)
                }
                constructor(t) {
                    var {
                        pixelDetails: e,
                        context: r,
                        reporters: n,
                        reportService: i,
                        httpService: o,
                        env: s,
                        ttqOptions: a
                    } = t;
                    super({
                        name: ro,
                        reporters: n,
                        context: r
                    }), this.env = void 0, this.lib = void 0, this.pixelCode = void 0, this.platform = void 0, this.hasReportMap = {}, this.cachedData = [], this.contextInitEndStatus = !1, this.reportService = void 0, this.httpService = void 0, this.partner = void 0, this.legacy = [], this.ttqOptions = void 0, this.env = s, this.lib = e.lib, this.pixelCode = e.pixelCode, this.reportService = i, this.httpService = o, this.contextInitEndStatus = !1, this.platform = tj() ? re.ANDROID : tF() ? re.IOS : re.OTHER, this.partner = a.partner || "", a.legacy && (this.legacy = a.legacy), this.ttqOptions = a
                }
            }
            var ra = r("1189"),
                rc = r.n(ra);
            class ru {
                init(t) {
                    this.userInfo = {}, this.adInfo = {}, this.appInfo = {}, this.pageInfo = {
                        url: "",
                        referrer: ""
                    }, this.pageSign = {
                        sessionId: "",
                        pageId: ""
                    }, this.libraryInfo = t
                }
                getAllData() {
                    return {
                        userInfo: this.userInfo,
                        adInfo: this.adInfo,
                        appInfo: this.appInfo,
                        libraryInfo: this.libraryInfo,
                        pageInfo: this.pageInfo,
                        pageSign: this.pageSign,
                        signalType: this.signalType,
                        userFormatInfo: this.userFormatInfo,
                        userFormatInfoV2: this.userFormatInfoV2,
                        enableAdTracking: this.enableAdTracking,
                        offsiteAdInfo: this.offsiteAdInfo,
                        tt_test_id: this.tt_test_id
                    }
                }
                getLibraryInfo() {
                    return this.libraryInfo
                }
                setSignalType(t) {
                    this.signalType = t
                }
                getSignalType() {
                    return this.signalType
                }
                setTestID(t) {
                    this.tt_test_id = t
                }
                getTestID() {
                    return this.tt_test_id
                }
                setEnableAdTracking(t) {
                    this.enableAdTracking = t
                }
                getEnableAdTracking() {
                    return this.enableAdTracking
                }
                setOffsiteAdInfo(t) {
                    this.offsiteAdInfo = Object.assign({}, this.offsiteAdInfo, t)
                }
                getOffsiteAdInfo() {
                    return this.offsiteAdInfo
                }
                getUserFormatInfo() {
                    return this.userFormatInfo
                }
                setUserFormatInfo(t) {
                    void 0 === t && (t = {}), Object.assign(this.userFormatInfo, t)
                }
                getUserFormatInfoV2() {
                    return this.userFormatInfoV2
                }
                setUserFormatInfoV2(t) {
                    void 0 === t && (t = {}), Object.assign(this.userFormatInfoV2, t)
                }
                setUserInfo(t, e) {
                    void 0 === t && (t = {}), Object.assign(this.userInfo, t)
                }
                setUserInfoWithoutIdentifyPlugin(t) {
                    if (!!t) Object.assign(this.userInfo, t)
                }
                getUserInfo() {
                    return this.userInfo
                }
                getAdInfo() {
                    return this.adInfo
                }
                setAdInfo(t) {
                    if (!!t) this.adInfo ? this.adInfo = Object.assign({}, this.adInfo, t) : this.adInfo = t
                }
                getAppInfo() {
                    return this.appInfo
                }
                setAppInfo(t) {
                    if (!!t) this.appInfo = Object.assign({}, this.appInfo, t)
                }
                getPageInfo() {
                    return this.pageInfo
                }
                getPageSign() {
                    return this.pageSign
                }
                setPageInfo(t, e) {
                    var r = k()({}, this.pageInfo),
                        n = k()({}, this.pageSign);
                    if (r.url !== t) {
                        var i = r.url;
                        if (void 0 !== r.url && (r.referrer = r.url), void 0 !== e && (r.referrer = e), void 0 !== n.pageIndex) {
                            var {
                                index: o,
                                sub: s,
                                main: a
                            } = n.pageIndex;
                            n.pageIndex = {
                                index: ++o,
                                sub: ++s,
                                main: a
                            }
                        }
                        return r.url = t, this.pageInfo = r, this.pageSign = n, {
                            from: i,
                            pageIndex: n.pageIndex
                        }
                    }
                }
                setPageInfoData(t) {
                    this.pageInfo = Object.assign({}, this.pageInfo, t)
                }
                getSessionIdFromCache() {
                    return null
                }
                setSessionIdToCache(t) {}
                setSignalDiagnosticLabels(t) {
                    Object.assign(this.signalDiagnosticLabels, t)
                }
                getSignalDiagnosticLabels() {
                    return this.signalDiagnosticLabels
                }
                getPageId(t) {
                    return void 0 === t && (t = "" + tt()), t + "-" + td(5)
                }
                getPageViewId() {
                    var {
                        pageId: t,
                        pageIndex: e
                    } = this.pageSign;
                    return "" + t + (e ? "." + e.main + "." + e.sub : "")
                }
                getVariationId() {
                    return ""
                }
                getVids() {
                    return ""
                }
                isLegacyPixel(t) {
                    return !1
                }
                initPageSign() {
                    var t = this.getSessionIdFromCache();
                    null === t && (t = to("sessionId"), this.setSessionIdToCache(t));
                    var e = to("pageId"),
                        r = {
                            sessionId: t,
                            pageId: e
                        };
                    this.pageSign = r
                }
                getPageCookieBasedSession() {
                    return this.pageCookieBasedSession
                }
                setPageCookieBasedSession(t) {
                    return t && (this.pageCookieBasedSession = t), this.pageCookieBasedSession
                }
                constructor(t) {
                    this.userInfo = void 0, this.adInfo = void 0, this.appInfo = void 0, this.libraryInfo = void 0, this.pageInfo = void 0, this.pageSign = void 0, this.signalType = void 0, this.userFormatInfo = {}, this.userFormatInfoV2 = {}, this.enableAdTracking = !0, this.offsiteAdInfo = {}, this.tt_test_id = "", this.signalDiagnosticLabels = k()({}, Q), this.pageCookieBasedSession = eG(), this.userInfoFieldAllowlist = {}, this.init(t)
                }
            }
            var rf = () => self[self[a]] || [],
                rl = (t, e) => {
                    if (t === e) return !0;
                    if (null == t || null == e || typeof t != typeof e) return !1;
                    if ("object" == typeof t) {
                        var r = Object.keys(t),
                            n = Object.keys(e);
                        if (r.length !== n.length) return !1;
                        for (var i of r)
                            if (!s()(n).call(n, i) || !rl(t[i], e[i])) return !1;
                        return !0
                    }
                    return t === e
                },
                rp = function() {
                    var t = M()(function*(t, e, r, n) {
                        var i = eG();
                        return e && (i = eW(e)), yield n.setCookieHandler(t ? d + "_" + t : d, eJ(i), et(r)), i
                    });
                    return function(e, r, n, i) {
                        return t.apply(this, arguments)
                    }
                }(),
                rd = () => rf()._sapi || self._sapi || {},
                rh = () => {
                    try {
                        var {
                            init: t
                        } = rd();
                        return t && t.context ? t.context : {}
                    } catch (t) {
                        return tQ(t1.API_ERROR, t, {
                            custom_name: "sandbox_api_error",
                            custom_enum: "get_context"
                        }), {}
                    }
                },
                rv = () => {
                    try {
                        var {
                            document: t
                        } = rh();
                        return {
                            location: t && t.location ? t.location : {},
                            referrer: t && t.referrer ? t.referrer : ""
                        }
                    } catch (t) {
                        return {
                            location: {
                                href: ""
                            },
                            referrer: ""
                        }
                    }
                },
                rg = () => {
                    var t = rf();
                    try {
                        var {
                            settings: e
                        } = rd();
                        return {
                            lib: "ttq",
                            pixelCode: e.pixelCode || ""
                        }
                    } catch (e) {
                        return {
                            lib: "ttq",
                            pixelCode: Object.keys(t._i || {})[0] || ""
                        }
                    }
                },
                r_ = function() {
                    var t = M()(function*(t, e) {
                        var {
                            browser: r
                        } = rd();
                        try {
                            return yield r.cookie.set(t, e), !0
                        } catch (t) {
                            tQ(t1.API_ERROR, t, {
                                custom_name: "sandbox_api_error",
                                custom_enum: "set_cookie"
                            })
                        }
                        return !1
                    });
                    return function(e, r) {
                        return t.apply(this, arguments)
                    }
                }(),
                rI = function() {
                    var t = M()(function*(t) {
                        var {
                            browser: e
                        } = rd();
                        try {
                            return yield e.cookie.get(t)
                        } catch (t) {
                            tQ(t1.API_ERROR, t, {
                                custom_name: "sandbox_api_error",
                                custom_enum: "get_cookie"
                            })
                        }
                        return ""
                    });
                    return function(e) {
                        return t.apply(this, arguments)
                    }
                }(),
                ry = function() {
                    var t = M()(function*(t, e) {
                        var {
                            browser: r
                        } = rd();
                        try {
                            return yield r.localStorage.setItem(t, e), !0
                        } catch (t) {
                            tQ(t1.API_ERROR, t, {
                                custom_name: "sandbox_api_error",
                                custom_enum: "set_local_storage"
                            })
                        }
                        return !1
                    });
                    return function(e, r) {
                        return t.apply(this, arguments)
                    }
                }(),
                rm = function() {
                    var t = M()(function*(t) {
                        var {
                            browser: e
                        } = rd();
                        try {
                            return (yield e.localStorage.getItem(t)) || ""
                        } catch (t) {
                            tQ(t1.API_ERROR, t, {
                                custom_name: "sandbox_api_error",
                                custom_enum: "get_local_storage"
                            })
                        }
                        return ""
                    });
                    return function(e) {
                        return t.apply(this, arguments)
                    }
                }(),
                rb = function() {
                    var t = M()(function*(t, e) {
                        var {
                            browser: r
                        } = rd();
                        try {
                            return yield r.sessionStorage.setItem(t, e), !0
                        } catch (t) {
                            tQ(t1.API_ERROR, t, {
                                custom_name: "sandbox_api_error",
                                custom_enum: "set_session_storage"
                            })
                        }
                        return !1
                    });
                    return function(e, r) {
                        return t.apply(this, arguments)
                    }
                }(),
                rS = function() {
                    var t = M()(function*(t) {
                        var {
                            browser: e
                        } = rd();
                        try {
                            return (yield e.sessionStorage.getItem(t)) || ""
                        } catch (t) {
                            tQ(t1.API_ERROR, t, {
                                custom_name: "sandbox_api_error",
                                custom_enum: "get_session_storage"
                            })
                        }
                        return ""
                    });
                    return function(e) {
                        return t.apply(this, arguments)
                    }
                }(),
                rE = function() {
                    var t = M()(function*() {
                        var t = rf();
                        t._cookie_promise = rI("").then(e => (t._cookies = e, e))
                    });
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                rx = function() {
                    var t = M()(function*(t) {
                        var e = rf(),
                            r = e._cookies;
                        if (!r && (r = yield e._cookie_promise, e._cookies = r), !t) return r;
                        var n = {};
                        for (var i of r.split("; ")) {
                            var [o, s] = i.split("=");
                            n[o] = decodeURIComponent(s)
                        }
                        return n[t] || ""
                    });
                    return function(e) {
                        return t.apply(this, arguments)
                    }
                }(),
                rO = r("7674"),
                rT = r.n(rO),
                rR = {
                    EMAIL_IS_HASHED: "email_is_hashed",
                    PHONE_IS_HASHED: "phone_is_hashed"
                };
            class rP extends eQ {
                handleUserProperties(t, e) {
                    if (!!t) return F()(t).forEach(e => {
                        var r, [n, i = ""] = e;
                        if (!!i) {
                            var o = String(i);
                            if (s()(r = ["email", "phone_number", "sha256_email", "sha256_phone_number"]).call(r, n)) switch (n) {
                                case "email":
                                    t.email = this.sha256(rc()(o).call(o));
                                    break;
                                case "phone_number":
                                    t.phone_number = this.sha256(this.handlePhoneNumber(o));
                                    break;
                                case "first_name":
                                    t.first_name = this.sha256(o);
                                    break;
                                case "last_name":
                                    t.last_name = this.sha256(o);
                                    break;
                                default:
                                    return
                            }
                        }
                    }), {
                        userProperties: t,
                        userDataFormatV2: this.identifyParamsFormattedInfoV2(t),
                        identifierLabel: this.genIdentifierLabelByUserProperties(e)
                    }
                }
                identifyParamsFormattedInfoV2(t) {
                    var e = {};
                    return F()(t).forEach(t => {
                        var r, n, [i, o = ""] = t;
                        switch (String(o), i) {
                            case "email":
                                e[rR.EMAIL_IS_HASHED] = [], tY()(r = e[rR.EMAIL_IS_HASHED]).call(r, Y.PLAIN_EMAIL);
                                break;
                            case "phone_number":
                                e[rR.PHONE_IS_HASHED] = [], tY()(n = e[rR.PHONE_IS_HASHED]).call(n, Y.PLAIN_PHONE)
                        }
                    }), e
                }
                genIdentifierLabelByUserProperties(t) {
                    var e = {};
                    return t ? (t && t.email && Object.assign(e, {
                        raw_email: {
                            label: $.valid
                        }
                    }), t && t.phone_number && Object.assign(e, {
                        raw_phone: {
                            label: $.valid
                        }
                    }), e) : e
                }
                pixelDidMount(t) {
                    1 === this.reporters.length && t.trackEnrichAM()
                }
                handlePhoneNumber(t) {
                    if (t.startsWith("+86")) {
                        var e = t.slice(3);
                        if (11 === e.length) return e
                    }
                    return t
                }
                constructor(t, e) {
                    super({
                        name: "Identify",
                        reporters: e,
                        context: t
                    }), this.initialize = !1, this.sha256 = void 0, this.sha256 = t => rT()(t).toString(), this.initialize = !0
                }
            }
            var rA = {
                main: -1,
                sub: -1,
                index: -1
            };
            class rN extends ru {
                getSessionIdFromCacheInSandbox() {
                    var t = this;
                    return M()(function*() {
                        var {
                            browser: e
                        } = t.sandboxPixelAPI, r = "";
                        try {
                            var n = yield e.sessionStorage.getItem(l);
                            r = n ? JSON.parse(n) : ""
                        } catch (t) {
                            try {
                                var i = yield e.sessionStorage.getItem(l);
                                r = i ? JSON.parse(i) : ""
                            } catch (t) {}
                        }
                        return r
                    })()
                }
                setSessionIdFromCacheInSandbox(t) {
                    return M()(function*() {
                        try {
                            var e = JSON.stringify(t);
                            yield rb(l, e)
                        } catch (t) {}
                    })()
                }
                getSessionIndex() {
                    return M()(function*() {
                        try {
                            var t = yield rS(p), e = JSON.parse(t || "{}");
                            if (e) return Object.assign({}, rA, e)
                        } catch (t) {}
                        return rA
                    })()
                }
                getVariationId() {
                    return this.globalTtqConfig.variation_id || ""
                }
                getVids() {
                    return this.globalTtqConfig.vids || ""
                }
                isLegacyPixel(t) {
                    return O(t, this.globalTtqConfig.legacy || [])
                }
                initPageSign() {
                    var t = this;
                    return M()(function*() {
                        var e = yield t.getSessionIdFromCacheInSandbox();
                        !e && (e = th(t.globalTtqConfig.server_unqiue_id || ""), yield t.setSessionIdFromCacheInSandbox(e));
                        var r = t.getPageId(tg(e)),
                            n = t.getVariationId(),
                            i = t.getVids(),
                            o = yield t.getSessionIndex();
                        o.main++, t.pageSign = {
                            sessionId: e,
                            pageId: r,
                            variationId: n,
                            vids: i,
                            pageIndex: o
                        }, t.isInitPageSignPending = !1
                    })()
                }
                setUserInfo(t) {
                    if (void 0 === t && (t = {}), 0 !== Object.keys(t).length) {
                        var e = {};
                        F()(t).forEach(t => {
                            var r, [n, i] = t;
                            if (!!i) e[n] = rc()(r = String(i)).call(r)
                        });
                        try {
                            var r, n = this.identifyPlugin.handleUserProperties(e, t);
                            if (!n) return;
                            var {
                                userProperties: i,
                                userDataFormatV2: o,
                                identifierLabel: a = {}
                            } = n, c = this.getUserInfo(), u = rl(c, i);
                            if (super.setUserInfo(Object.assign({}, this.getUserInfo(), i)), this.setUserFormatInfoV2(Object.assign({}, this.getUserFormatInfoV2(), o)), this.setSignalDiagnosticLabels(Object.assign({}, this.getSignalDiagnosticLabels(), a)), u || 0 === Object.keys(this.getUserInfo()).length || 1 === Object.keys(e).length && s()(r = Object.keys(e)).call(r, "external_id")) return;
                            this.reporters && this.reporters[0] && this.reporters[0].trackEnrichAM()
                        } catch (t) {
                            tQ(t1.API_ERROR, t, {
                                extJSON: {
                                    api: "identify"
                                }
                            })
                        }
                    }
                }
                constructor(t, e, r, n, i, o) {
                    super({
                        name: "pixel.js",
                        version: "2.2.0"
                    }), this.sandboxPixelAPI = void 0, this.reportService = void 0, this.globalTtqConfig = void 0, this.reporters = [], this.identifyPlugin = void 0, this.initPageSignPromise = void 0, this.isInitPageSignPending = !0, this.cookieService = void 0, this.sandboxPixelAPI = t, this.reportService = e, this.globalTtqConfig = n, this.reporters = i, this.identifyPlugin = new rP(this, i), tk(o) && tF() && (this.enableAdTracking = !1), this.initPageSignPromise = this.initPageSign(), this.cookieService = r
                }
            }
            var rC = [],
                rw = "tt_pixel_ei6_tracked";
            class rD extends eQ {
                isEnrichIpv6Enable() {
                    var {
                        plugins: t
                    } = this.globalTtqConfig || {};
                    return !!t && !!t.EnrichIpv6 && !!this.reporters && 0 !== this.reporters.length && this.reporters.every(t => t && t.plugins && t.plugins.EnrichIpv6)
                }
                assemblyDataEnrichIpv6Data(t) {
                    return k()({}, t, {
                        event: "EnrichIpv6",
                        trigger_event: t.event || "",
                        message_id: t.message_id + "#source=1"
                    })
                }
                trackEnrichIpv6ByEnrichAM(t) {
                    var e = this;
                    return M()(function*() {
                        if (e.hasReportedByEnrichAM) return;
                        var {
                            getSessionStorageInSandbox: r,
                            setSessionStorageInSandbox: n
                        } = e.sandboxPixelAPI, i = yield r(rw);
                        if ("true" !== i) e.hasReportedByEnrichAM = !0, yield n(rw, "true"), e.reportService.report(eI, e.assemblyDataEnrichIpv6Data(t))
                    })()
                }
                pixelSend(t, e, r, n, i) {
                    void 0 === n && (n = {}), setTimeout(() => {
                        if (!tD(this.env) && !!this.isEnrichIpv6Enable() && !!(r && r.message_id))
                            if ("EnrichAM" === e) this.trackEnrichIpv6ByEnrichAM(r);
                            else {
                                if (this.hasReported) return;
                                var t = this.context.getPageSign();
                                if (!t || !t.pageIndex || t.pageIndex.index) return;
                                this.hasReported = !0, this.reportService.report(eI, this.assemblyDataEnrichIpv6Data(r))
                            }
                    })
                }
                constructor(t, e, r, n, i, o) {
                    super({
                        name: "EnrichIpv6",
                        reporters: r,
                        context: e
                    }), this.env = void 0, this.hasReported = void 0, this.hasReportedByEnrichAM = void 0, this.reportService = void 0, this.sandboxPixelAPI = void 0, this.globalTtqConfig = void 0, this.env = t, this.hasReported = !1, this.hasReportedByEnrichAM = !1, this.reportService = n, this.sandboxPixelAPI = i, this.globalTtqConfig = o
                }
            }
            class rk extends rs {
                contextInitEnd() {
                    this.contextInitEndStatus = !0, setTimeout(() => {
                        for (tZ.info.forEach(t => {
                                this.info(t.event, t.detail, t.withoutJSB)
                            }), tZ.error.forEach(t => {
                                this.error(t.event, t.err, t.detail, t.withoutJSB)
                            }), tZ.info = [], tZ.error = []; this.monitorCachedData.length;) {
                            var t = this.monitorCachedData.shift();
                            t && this.reportSync(t, t.withoutJSB)
                        }
                    }, 0)
                }
                reportSync(t, e) {
                    if (void 0 === e && (e = !1), !this.contextInitEndStatus) {
                        var r;
                        tY()(r = this.monitorCachedData).call(r, t);
                        return
                    }
                    this.reportService.reportPreTasks.then(() => {
                        var {
                            event: r,
                            detail: n,
                            error: i
                        } = t, {
                            pixelCode: o
                        } = rg(), s = this.assemblyBaseData(r, n);
                        if (Object.assign(s, {
                                pixel_code: o
                            }), !this.isRepeatLog(s)) {
                            if (i && Object.assign(s.ext_json || {}, {
                                    message: i.message,
                                    stack: i.stack
                                }), this.recordReportLog(s), e) {
                                this.send(e_, s);
                                return
                            }
                            this.sendByReportService(s)
                        }
                    })
                }
                info(t, e, r) {
                    void 0 === e && (e = {}), void 0 === r && (r = !1), setTimeout(() => {
                        if (!!this.reportSwitch()) this.reportSync({
                            event: t,
                            detail: e,
                            withoutJSB: r
                        }, r)
                    }, 0)
                }
                error(t, e, r, n) {
                    void 0 === r && (r = {}), void 0 === n && (n = !1), setTimeout(() => {
                        if (!!this.reportSwitch()) this.reportSync({
                            event: t,
                            detail: r,
                            error: e,
                            withoutJSB: n
                        }, n)
                    }, 0)
                }
                constructor(t, e, r, n, i, o) {
                    super({
                        pixelDetails: rg(),
                        context: t,
                        reporters: e,
                        reportService: r,
                        httpService: n,
                        env: i,
                        ttqOptions: o
                    }), this.monitorCachedData = []
                }
            }
            var rL = {
                    page_viewed: "Pageview",
                    checkout_completed: "CompletePayment",
                    checkout_started: "InitiateCheckout",
                    payment_info_submitted: "AddPaymentInfo",
                    product_added_to_cart: "AddToCart",
                    product_viewed: "ViewContent",
                    search_submitted: "Search",
                    collection_viewed: "collection_viewed"
                },
                rM = t => {
                    var e = {};
                    for (var r in t) t.hasOwnProperty(r) && ("boolean" == typeof t[r] || t[r]) && (e[r] = t[r]);
                    return e
                },
                rj = t => Number(t || 0).toFixed(2),
                rF = t => t || "USD",
                rU = t => {
                    var {
                        product: e,
                        sku: r,
                        id: n
                    } = t;
                    return (e && e.id || n || r || "") + ""
                },
                rH = t => t && t.id ? "product_group" : "product",
                rB = t => Number(t || 1),
                rV = function(t, e) {
                    if (void 0 === e && (e = !1), !t) return {};
                    var r = t && t.product || {},
                        n = t && t.price || {},
                        i = t && t.product && t.product.vendor || "",
                        o = !e && t && t.title || "",
                        s = r && r.title ? r.title : "";
                    return rM({
                        content_id: rU(t || {}),
                        content_type: rH(r),
                        content_name: "" + s + (o ? " - " + o : ""),
                        price: rj(n.amount),
                        currency: rF(n.currencyCode),
                        content_category: r.type || "",
                        brand: i
                    })
                },
                rG = function(t, e) {
                    void 0 === e && (e = !1);
                    var {
                        merchandise: r,
                        quantity: n
                    } = t, i = {};
                    return Object.assign(i, rV(r, e), {
                        quantity: rB(n)
                    }), rM(i)
                },
                rq = (t, e) => {
                    var {
                        lineItems: r = [],
                        currencyCode: n,
                        order: i
                    } = e, o = "payment_info_submitted" !== t ? e && e.subtotalPrice || {} : e && e.totalPrice || {}, s = [], a = 0;
                    return r.forEach(t => {
                        var e = t || {};
                        tY()(s).call(s, Object.assign(rV(e.variant, !0), {
                            quantity: rB(e.quantity)
                        })), a += rB(e.quantity)
                    }), rM(Object.assign({}, {
                        contents: s,
                        currency: rF(n),
                        quantity: a,
                        value: rj(o.amount),
                        order_id: (null == i ? void 0 : i.id) || ""
                    }))
                };
            class rW extends eX {
                initPlugins() {
                    this.initializeMonitorPlugin(), this.context.identifyPlugin && this.usePlugin(this.context.identifyPlugin), this.usePlugin(new rD(this.env, this.context, this.reporters, this.reportService, this.sandboxPixelAPI, this.globalTtqOption))
                }
                initializeMonitorPlugin() {
                    if (!this.monitorInitialized && R(ro)) {
                        var t = new rk(this.context, this.reporters, this.reportService, this.httpService, this.env, this.globalTtqOption);
                        this.usePlugin(t), this.monitorInitialized = !0
                    }
                }
                initAdInfo(t) {
                    var e = this;
                    this.dispatch(eH.BEFORE_AD_INFO_INIT_START), this.reportService.pushPreposition(M()(function*() {
                        e.dispatch(eH.AD_INFO_INIT_START);
                        var r = {},
                            n = yield e.adService.getAdInfoFromCache();
                        Object.assign(r, Object.keys(n).length > 0 ? n : yield e.adService.getAdInfo(t)), e.context.setAdInfo(r);
                        var i = eL(r, t => {
                            tQ(t1.INIT_ERROR, t, {
                                extJSON: {
                                    position: "handleAdInfoOfficial"
                                }
                            })
                        });
                        e.context.setOffsiteAdInfo(i);
                        var o = ek(r, e.env);
                        e.context.setEnableAdTracking(o), e.dispatch(eH.AD_INFO_INIT_END, {
                            extJSON: {
                                enabledAdTracking: o
                            }
                        })
                    })())
                }
                initAppInfo(t) {
                    var e = this;
                    this.reportService.pushPreposition(M()(function*() {
                        var {
                            getShopifyPageInfo: r
                        } = e.sandboxPixelAPI, {
                            location: n,
                            referrer: i
                        } = r(), o = yield e.appService.getAppInfo(t || n.href, i);
                        return e.context.setAppInfo(o), o
                    })())
                }
                initContextInfo() {
                    var {
                        location: t,
                        referrer: e
                    } = rv();
                    super.initContextInfo(t.href, e)
                }
                initTestId(t) {
                    var e = this;
                    return M()(function*() {
                        !e.context.getTestID() && e.reportService.pushPreposition(M()(function*() {
                            var {
                                getShopifyPageInfo: r,
                                getInitialStageCookie: n
                            } = e.sandboxPixelAPI, {
                                referrer: i
                            } = r(), o = t ? eP(t, "tt_test_id") : "", s = i ? eP(i, "tt_test_id") : "", a = yield n("tt_test_id"), c = o || s || a;
                            c && (e.context.setTestID(c), yield e.cookieService.setCookieHandler("tt_test_id", c, {
                                expires: "session"
                            }))
                        })())
                    })()
                }
                initSandboxUserInfo() {
                    try {
                        var {
                            init: {
                                data: {
                                    customer: t
                                }
                            }
                        } = this.sandboxPixelAPI;
                        if (!t || 0 === Object.keys(t).length) return;
                        var e = {
                            email: t.email || "",
                            phone_number: t.phone || ""
                        };
                        this.identify(rM(e))
                    } catch (t) {
                        tQ(t1.CUSTOM_ERROR, t, {
                            custom_name: "sandbox_error",
                            custom_enum: "init_pii_error"
                        })
                    }
                }
                setPageInfo(t, e) {
                    var r = () => super.setPageInfo,
                        n = this;
                    this.context.isInitPageSignPending ? this.reportService.pushPreposition(M()(function*() {
                        yield n.context.initPageSignPromise.then(() => {
                            r().call(n, t, e)
                        })
                    })()) : super.setPageInfo(t, e)
                }
                setPageIndex(t) {
                    t && this.reportService.pushPreposition(M()(function*() {
                        var {
                            index: e,
                            main: r
                        } = t;
                        yield rb(p, JSON.stringify({
                            index: e,
                            main: r
                        }))
                    })())
                }
                getReporter(t) {
                    return this.reporters.find(e => e.getReporterId() === t)
                }
                addReporter(t) {
                    var e;
                    t.on(eY.BEFORE_REPORT, (t, e, r, n, i) => {
                        this.dispatch(eH.PIXEL_SEND, t, e, r, n, i)
                    }, {}), tY()(e = this.reporters).call(e, t), this.dispatch(eH.PIXEL_DID_MOUNT, t)
                }
                page() {}
                loadPixel() {}
                track(t, e) {
                    if (!!rL[t]) {
                        var r = e || {
                                context: {
                                    document: {}
                                }
                            },
                            n = {},
                            i = r.clientId;
                        try {
                            var {
                                context: {
                                    document: {
                                        location: o,
                                        referrer: s
                                    }
                                }
                            } = r;
                            switch (this.setPageInfo(o && o.href || "", s), t) {
                                case "checkout_started":
                                case "payment_info_submitted":
                                case "checkout_completed":
                                    var a = rL[t],
                                        {
                                            data: {
                                                checkout: c
                                            }
                                        } = r,
                                        u = c.shippingAddress || {
                                            phone: ""
                                        };
                                    if (c.email || c.phone || u.phone) {
                                        var f = c.phone || u.phone;
                                        c.email && (n.email = c.email), f && (n.phone_number = f), t$(t1.CUSTOM_INFO, {
                                            custom_name: "shopify_am",
                                            custom_enum: a + "-" + Object.keys(n).join(",")
                                        })
                                    } else t$(t1.CUSTOM_INFO, {
                                        custom_name: "shopify_non_am",
                                        custom_enum: a
                                    })
                            }
                        } catch (e) {
                            tQ(t1.CUSTOM_ERROR, e, {
                                custom_name: "parse_pii_error",
                                custom_enum: t
                            })
                        }
                        this.identify(i, rM(n)), super.track(t, e)
                    }
                }
                setCookieInfo(t) {
                    if (!!t) this.context.setUserInfoWithoutIdentifyPlugin({
                        anonymous_id: t
                    })
                }
                enableFirstPartyCookie(t) {
                    var e = this;
                    if (!!t) this.reportService.pushPreposition(M()(function*() {
                        var r = yield e.cookieService.enableFirstPartyCookie(t);
                        e.setCookieInfo(r)
                    })())
                }
                initLocalServiceInfo() {
                    var t = this;
                    this.reportService.pushPreposition(M()(function*() {
                        var {
                            getSessionStorageInSandbox: e,
                            setSessionStorageInSandbox: r,
                            getShopifyPageInfo: n
                        } = t.sandboxPixelAPI, i = yield e(_);
                        if (i) {
                            t.context.setUserInfoWithoutIdentifyPlugin({
                                [_]: i
                            });
                            return
                        }
                        var {
                            location: o,
                            referrer: s
                        } = n(), a = eA(ew(t.globalTtqOption), o.href, s);
                        a && (yield r(_, a), t.context.setUserInfoWithoutIdentifyPlugin({
                            [_]: a
                        }))
                    })())
                }
                constructor(t) {
                    var e = [],
                        {
                            env: r,
                            globalTtqOption: n,
                            sandboxAPI: i,
                            reportService: o,
                            httpService: s,
                            adService: a,
                            appService: c,
                            cookieService: u
                        } = t,
                        f = new rN(i, o, u, n, e, r);
                    super(f, o), this.env = void 0, this.context = void 0, this.reportService = void 0, this.globalTtqOption = void 0, this.adService = void 0, this.appService = void 0, this.httpService = void 0, this.reporters = void 0, this.sandboxPixelAPI = void 0, this.cookieService = void 0, this.monitorInitialized = !1, this.env = r, this.adService = a, this.appService = c, this.cookieService = u, this.reportService = o, this.httpService = s, this.reporters = e, this.context = f, this.sandboxPixelAPI = i, this.globalTtqOption = n, this.initPlugins(), this.dispatch(eH.INIT_START);
                    var {
                        location: l,
                        referrer: p
                    } = rv();
                    this.setPageInfo(l.href, p), this.initSandboxUserInfo(), this.init(l.href, p), this.dispatch(eH.INIT_END)
                }
            }
            var rJ = function(t) {
                    return t.PIXEL_CODE = "pixelCode", t.EVENT_SOURCE_ID = "eventSourceId", t.SHOP_ID = "shopId", t
                }({}),
                rK = function(t) {
                    return t.TRACK = "track", t.PERFORMANCE = "performance", t.INTERACTION = "interaction", t.PCM = "PCM", t.PERFORMANCE_INTERACTION = "performance_interaction", t.SELFHOST = "selfhost", t.AUTO_CONFIG = "auto_config", t.PAGE = "Pf", t.PAGE_PERFORMANCE = "page_performance", t.PAGE_INTERACTION = "page_interaction", t
                }({}),
                rz = ["EnrichAM"];
            class rX {
                on(t, e, r) {
                    try {
                        var n = Object.assign({
                                throttle: !1,
                                debounce: !1,
                                once: !1,
                                interval: 500
                            }, r),
                            i = this.subscriberMap.get(t) || [];
                        if (i.some(t => t.originalCallback === e)) return;
                        tY()(i).call(i, {
                            originalCallback: e,
                            wrappedCallback: this.wrapCallback(e, n),
                            options: n
                        }), this.subscriberMap.set(t, i)
                    } catch (e) {
                        tQ(t1.CUSTOM_ERROR, e, {
                            custom_name: "EventEmitter",
                            custom_enum: t
                        })
                    }
                }
                emit(t) {
                    for (var e = arguments.length, r = Array(e > 1 ? e - 1 : 0), n = 1; n < e; n++) r[n - 1] = arguments[n];
                    (this.subscriberMap.get(t) || []).forEach(e => {
                        try {
                            e.wrappedCallback(...r)
                        } catch (e) {
                            tQ(t1.CUSTOM_ERROR, e, {
                                custom_name: "EventEmitter",
                                custom_enum: t,
                                extJSON: {
                                    message: "" + JSON.stringify(this.subscriberMap.get(t))
                                }
                            })
                        }
                    })
                }
                off(t, e) {
                    var r = this.subscriberMap.get(t) || [];
                    this.subscriberMap.set(t, r.filter(t => t.originalCallback !== e))
                }
                clear() {
                    this.subscriberMap.clear()
                }
                wrapCallback(t, e) {
                    var r, n, i, o, s, a, c, u, f, l;
                    if (e.async && (t = tP(t)), e.throttle) {;
                        r = t, n = e.interval || 500, void 0 === n && (n = 500), o = -1, s = i ? r.bind(i) : r, t = function() {
                            var t = Array.prototype.slice.apply(arguments);
                            tt() - o >= n && (s(...t), o = tt())
                        }
                    }
                    if (e.debounce) {;
                        a = t, c = e.interval || 500, l = u ? a.bind(u) : a, t = function() {
                            for (var t = arguments.length, e = Array(t), r = 0; r < t; r++) e[r] = arguments[r];
                            clearTimeout(f), f = setTimeout(() => {
                                l(...e)
                            }, c)
                        }
                    }
                    return e.once && (t = tp(t)), t
                }
                setObserverConfig(t) {
                    this.emit(eZ.UPDATE_CONFIG, t)
                }
                constructor() {
                    this.subscriberMap = new Map
                }
            }
            var rY = (t, e) => {
                    if ("selfhost" === t && e && x(e)) return "https://" + x(e) + "/api/v2/pixel";
                    var r = {
                        track: eu,
                        performance: ef,
                        interaction: el,
                        performance_interaction: ep,
                        auto_config: ev,
                        page_performance: ed,
                        page_interaction: eh
                    }[t];
                    return r ? r : null
                },
                rZ = ["ttuts", "ad_info_from"];
            class r$ extends rX {
                getParameterInfo() {
                    return this.getInstance().then(() => {
                        var {
                            name: t = "",
                            status: e = 1,
                            setupMode: r = 0,
                            advertiserID: n = "",
                            is_onsite: i = !1
                        } = this.reporterInfo;
                        return {
                            pixelCode: this.getReporterId(),
                            name: t,
                            status: e,
                            setupMode: r,
                            advertiserID: n.toString(),
                            partner: this.getReporterPartner() || "",
                            is_onsite: i,
                            advancedMatchingAvailableProperties: this.advancedMatchingAvailableProperties,
                            rules: this.rules
                        }
                    })
                }
                getInstance() {
                    return this.pixelPromise = N().resolve(this)
                }
                getReporterId() {
                    return ""
                }
                getReporterUniqueLoadId() {
                    return "" + this.getReporterId()
                }
                getReporterPartner() {}
                getReporterInfo() {
                    return {
                        pixel: {
                            code: this.getReporterId()
                        }
                    }
                }
                setAdvancedMatchingAvailableProperties(t) {
                    this.advancedMatchingAvailableProperties = Object.assign({}, this.advancedMatchingAvailableProperties, t)
                }
                isOnsite() {
                    return !1
                }
                isPartnerReporter() {
                    return !1
                }
                getReportResultSet() {
                    return this.reportResultSet
                }
                getUserInfo(t) {
                    return {}
                }
                getReporterMatchedUserFormatInfo() {
                    return {}
                }
                getReporterMatchedUserFormatInfoV2() {
                    return {}
                }
                getReportEventHistoryKey(t) {
                    return "tiktok"
                }
                getCookieBasedSession() {
                    return this.session
                }
                setCookieBasedSession(t) {
                    return t && (this.session = t), this.session
                }
                convertCookieBasedSession(t, e, r) {
                    return {}
                }
                clearHistory() {
                    this.reportEventHistory = {}
                }
                pushReport(t, e) {
                    var r;
                    void 0 === e && (e = "tiktok"), !this.reportEventHistory[e] && (this.reportEventHistory[e] = []), tY()(r = this.reportEventHistory[e]).call(r, t)
                }
                hasReportEventHistory(t, e) {
                    var r, n = this.getReportEventHistoryKey(e);
                    return this.reportEventHistory[n] ? !!(s()(rC).call(rC, t) && s()(r = this.reportEventHistory[n]).call(r, t)) || !1 : (this.reportEventHistory[n] = [], !1)
                }
                page(t) {
                    void 0 === t && (t = {})
                }
                identify(t, e) {}
                track(t, e, r, n, i) {
                    var o = n || rK.TRACK,
                        s = i || es.defaultReport;
                    return !this.reportService || this.hasReportEventHistory(t, s) ? N().resolve(null) : (this.pushReport(t, this.getReportEventHistoryKey(s)), this.reportService.reportPreTasks.then(() => {
                        var n = this.getReporterId(),
                            i = this.trackSync(n, t, e, r, o, s);
                        return this.trackPostTask({
                            reporterId: n,
                            eventType: t,
                            properties: e,
                            eventConfig: r,
                            type: o,
                            reportType: s,
                            reportData: i
                        }), N().resolve({
                            reporterId: n,
                            eventType: t,
                            properties: e,
                            eventConfig: r,
                            type: o,
                            reportType: s,
                            reportData: i
                        })
                    }))
                }
                getEventType(t) {
                    return t
                }
                trackPostTask(t) {}
                trackSync(t, e, r, n, i, o, s) {
                    void 0 === i && (i = rK.TRACK), void 0 === o && (o = es.defaultReport);
                    var a, c = i !== rK.SELFHOST ? this.assemblyData(t, e, r, n, i) : this.assemblySelfHostData(t, e, r, n, i),
                        u = s || rY(i, t);
                    if (null !== u && !!this.reportService) return this.emit(eY.BEFORE_REPORT, t, e, c, n, i), tY()(a = this.reportResultSet).call(a, this.reportService.report(u, c, o, ea.P0)), c
                }
                handlePropertiesToOptions(t, e) {
                    var r = {};
                    return e.forEach(e => {
                        r[e] = t[e], delete t[e]
                    }), r
                }
                assemblyData(t, e, r, n, i) {
                    void 0 === r && (r = {}), void 0 === n && (n = {}), void 0 === i && (i = rK.TRACK);
                    var {
                        adInfo: o,
                        userInfo: s,
                        appInfo: a,
                        pageSign: c,
                        libraryInfo: u,
                        pageInfo: f,
                        signalType: l
                    } = this.context.getAllData(), {
                        sessionId: p,
                        variationId: d
                    } = c, h = Object.assign({}, r), v = h && h.is_standard_mode;
                    h && h.pixelMethod && delete h.pixelMethod;
                    var g = Object.assign({}, u, {
                            version: this.context.isLegacyPixel(t) ? "legacy-" + u.version : u.version
                        }),
                        _ = tm(o, rZ),
                        I = Object.assign({}, _, {
                            device_id: a.device_id,
                            uid: a.user_id
                        }),
                        y = this.handlePropertiesToOptions(h, [eo.LDU, eo.EVENTID, eo.EVENT_ID]),
                        {
                            limited_data_use: m
                        } = this.options,
                        b = null !== y.limited_data_use && void 0 !== y.limited_data_use ? y.limited_data_use : m;
                    null == b ? delete y.limited_data_use : y.limited_data_use = !!b;
                    var S = n && (n.event_id || n.eventID) || "";
                    y.event_id = S || y.event_id || y.eventID || "", delete y.eventID;
                    var E = this.getReporterInfo();
                    E.pixel && (E.pixel.runtime = tG(), v && (E.pixel.mode = "standard"));
                    var x = this.getUserInfo(Z.Manual) || {},
                        O = this.getUserInfo(Z.ManualV2) || {},
                        T = this.getReporterMatchedUserFormatInfoV2() || {},
                        R = this.getUserInfo(Z.Auto) || {};
                    R.auto_trigger_type && (Object.assign(h, {
                        auto_trigger_type: R.auto_trigger_type
                    }), delete R.auto_trigger_type);
                    var P = this.getUserInfo(Z.EBManual) || {};
                    tj() && Object.assign(h, {
                        android_version: a.android_version,
                        device_model: a.device_model
                    });
                    var A = {};
                    s.anonymous_id && (A.anonymous_id = s.anonymous_id);
                    var N = this.getEventType(e),
                        C = this.convertCookieBasedSession(i, n.pixelSession, n.pageSession),
                        w = {
                            event: N,
                            event_id: S,
                            message_id: ts(to("messageId"), t),
                            is_onsite: !!l,
                            timestamp: new Date().toJSON(),
                            context: k()({
                                ad: I,
                                device: {
                                    platform: a.platform
                                },
                                user: Object.assign({}, A, x, O, R, P)
                            }, E, {
                                page: Object.assign({}, f),
                                library: Object.assign({}, g),
                                session_id: ts(p, t),
                                pageview_id: ts(this.context.getPageViewId(), this.getReporterUniqueLoadId(), "::"),
                                variation_id: d || ""
                            }, C),
                            _inspection: T,
                            properties: h
                        };
                    return Object.assign(w, y)
                }
                assemblySelfHostData(t, e, r, n, i) {
                    return void 0 === r && (r = {}), void 0 === n && (n = {}), this.assemblyData(t, e, r, n, i)
                }
                constructor(t, e) {
                    super(), this.context = void 0, this.reportService = void 0, this.reporterInfo = {}, this.options = {}, this.plugins = {}, this.rules = [], this.reportEventHistory = {}, this.reportResultSet = [], this.selfHostConfig = {}, this.pixelPromise = void 0, this.currentHref = "", this.advancedMatchingAvailableProperties = {
                        external_id: !0,
                        partner_id: !0
                    }, this.session = eG(), this.reportService = e, this.context = t
                }
            }
            var rQ = ["AED", "ALL", "AMD", "ARS", "AUD", "AZN", "BDT", "BGN", "BHD", "BIF", "BOB", "BRL", "BYN", "CAD", "CHF", "CLP", "CNY", "COP", "CRC", "CZK", "DKK", "DOP", "DZD", "EGP", "EUR", "GBP", "GEL", "GTQ", "HKD", "HNL", "HUF", "IDR", "ILS", "INR", "IQD", "ISK", "JOD", "JPY", "KES", "KHR", "KRW", "KWD", "KZT", "LBP", "MAD", "MOP", "MXN", "MYR", "NGN", "NIO", "NOK", "NZD", "OMR", "PAB", "PEN", "PHP", "PKR", "PLN", "PYG", "QAR", "RON", "RSD", "RUB", "SAR", "SEK", "SGD", "THB", "TND", "TRY", "TWD", "TZS", "UAH", "USD", "UZS", "VES", "VND", "ZAR"],
                r0 = {
                    ViewForm: "ViewContent",
                    ViewConsultationPage: "ViewContent",
                    ViewDownloadPage: "ViewContent",
                    Checkout: "PlaceAnOrder",
                    Registration: "CompleteRegistration",
                    AddBilling: "AddPaymentInfo",
                    StartCheckout: "InitiateCheckout",
                    ClickInDownloadPage: "ClickButton",
                    ClickInConsultationPage: "ClickButton",
                    ClickForm: "ClickButton",
                    ClickToDownload: "Download",
                    Consult: "Contact",
                    ConsultByPhone: "Contact",
                    CompletePayment: "Purchase",
                    SubmitForm: "Lead"
                },
                r1 = ["event_experiment", "dynamic_parameter_config", "eb_version", "eb_rule_id", "tf", "trigger_source", "inter_id"],
                r2 = (e, r, n) => {
                    try {
                        var i = window.location.hostname.split(".");
                        if (void 0 !== t && t < i.length) {
                            document.cookie = e + "=" + r + transformCookieOption(Object.assign({}, n, {
                                domain: "." + i.slice(t).join(".")
                            }));
                            return
                        }
                        for (var o = i.length - 2; o >= 0; o--) {
                            var s = "." + i.slice(o).join(".");
                            if (document.cookie = e + "=" + r + transformCookieOption(Object.assign({}, n, {
                                    domain: s
                                })), getCookieInCommonBrowser(e) === r) {
                                t = o;
                                break
                            }
                        }
                    } catch (t) {}
                };
            ! function(t) {
                t.ID_SSN = "ID_SSN", t.PASSPORT = "PASSPORT", t.DRIVING_LICENSE = "DRIVING_LICENSE", t.PHONE = "PHONE", t.EMAIL = "EMAIL", t.CREDIT_CARD = "CREDIT_CARD", t.RACE_ETHNIC = "RACE_ETHNIC", t.RELIGION = "RELIGION", t.SEXUAL_ORIENTATION = "SEXUAL_ORIENTATION", t.POLITICAL_AFFILIATION = "POLITICAL_AFFILIATION", t.UNION_MEMBERSHIP = "UNION_MEMBERSHIP", t.CRIMINAL_RECORD = "CRIMINAL_RECORD", t.DEFAULT = "***"
            }(e || (e = {})), e.RACE_ETHNIC, e.RELIGION, e.SEXUAL_ORIENTATION, e.POLITICAL_AFFILIATION, e.UNION_MEMBERSHIP, e.CRIMINAL_RECORD;
            Object.values(e).reduce((t, e) => (t[e] = `<#${e}#>`, t), {});
            let r5 = {
                prefix: "(?<!<#)",
                suffix: "(?!(?:[^<]*>|[^>]*<))"
            };
            r3(["(?:\\+?\\d{1,3}[\\s-]?|\\(\\+?\\d{1,3}\\)[\\s-]?)?(?:\\d{2,4}[\\s-]?|\\(\\d{2,4}\\)[\\s-]?)?(?:\\d[\\s-]?){5,}"], r5, "g");
            let r6 = r3(["([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\\.[a-zA-Z0-9._-]+)"], r5, "gi");

            function r3(t, e = {
                prefix: "",
                suffix: ""
            }, r = "") {
                return t.map(t => {
                    try {
                        let n = new RegExp(t, r),
                            i = n.source;
                        if (i.startsWith("^") && i.endsWith("$")) return n;
                        return function(t, e = "", r = "") {
                            let n = t.source,
                                i = t.flags,
                                o = `${e}${n}${r}`;
                            return new RegExp(o, i)
                        }(n, e.prefix, e.suffix)
                    } catch (t) {
                        return /[]/
                    }
                })
            }
            r3(["(?:(?:4[0-9]{3}|5[1-5][0-9]{2}|6011|65[0-9]{2}|3[47][0-9]{2}|3(?:0[0-5]|[68][0-9])|2131|1800|35\\d{2})[-\\s]?(?:[0-9]{4}[-\\s]?){2}[0-9]{3,4}|62[0-9]{3}[-\\s]?(?:[0-9]{4}[-\\s]?){2,3}[0-9]{3,4})$(?![\\d])"], r5, "g"), r3(["\\d{3}-\\d{2}-\\d{4}|\\d{9}", "\\d{17}(\\d|X|x)$", "[A-CEGHJ-PR-TW-Z]{2}\\d{6}[A-D]?", "(?:[A-Z]\\d{10}|\\d{10})", "[A-Z0-9]{12}"], r5, "g"), r3(["[EDS]\\d{8}", "[A-HJ-NP-Z][A-HJ-NP-Z0-9]{8}", "[A-Z]{2}\\d{6}"], r5, "g"), r3(["\\d{17}[\\dXx]", "[A-Z0-9]{16}", "[A-Z0-9]{10,12}", "[A-Z0-9]{12}"], r5, "g");
            class r4 extends r$ {
                identify(t, e) {
                    var r = tE(t, e);
                    this.context.setUserInfo(r, k()({
                        reporterId: this.id
                    }, (null == e ? void 0 : e.trigger_source) && {
                        trigger_source: e.trigger_source
                    }))
                }
                getReporterId() {
                    return this.id || ""
                }
                getReporterUniqueLoadId() {
                    return this.reporterInfo.loadId + "-" + this.getReporterId()
                }
                getReporterPartner() {
                    var t;
                    return (null == (t = this.reporterInfo) ? void 0 : t.partner) || ""
                }
                setPixelInfo(t, e, r) {
                    var {
                        type: n
                    } = this;
                    this.reporterInfo = Object.assign(this.reporterInfo, k()({}, t), {
                        [n]: this.getReporterId()
                    }), e && (this.rules = e), r && (this.plugins = r)
                }
                getInstance() {
                    return N().resolve(this)
                }
                getReporterInfo() {
                    return this.reporterInfo.pixelCode ? super.getReporterInfo() : {
                        shop_id: this.reporterInfo.shopId,
                        eventSourceId: this.reporterInfo.eventSourceId
                    }
                }
                getUserInfo(t) {
                    var e = this.context.getUserInfo(),
                        r = tb(e, Object.assign({}, this.advancedMatchingAvailableProperties));
                    switch (t) {
                        case Z.Manual:
                            return tb(this.isPartnerReporter() ? r : e, {
                                external_id: !0,
                                email: !0,
                                phone_number: !0,
                                ttoclid: !0
                            });
                        case Z.ManualV2:
                            return tb(this.isPartnerReporter() ? r : e, {
                                first_name: !0,
                                last_name: !0,
                                city: !0,
                                state: !0,
                                country: !0,
                                zip_code: !0,
                                partner_id: !0,
                                ttoclid: !0
                            });
                        case Z.EBManual:
                            return tb(e, {
                                eb_email: this.advancedMatchingAvailableProperties.auto_email,
                                eb_phone_number: this.advancedMatchingAvailableProperties.auto_phone_number
                            });
                        case Z.Auto:
                            var n = tb(r, {
                                external_id: !0,
                                auto_email: !0,
                                auto_phone_number: !0,
                                ttoclid: !0
                            });
                            return Object.assign(n, (n.auto_email || n.auto_phone_number) && e.auto_trigger_type ? {
                                auto_trigger_type: e.auto_trigger_type
                            } : {});
                        default:
                            return r
                    }
                }
                getReporterMatchedUserFormatInfo() {
                    var t = this.context.getUserFormatInfo(),
                        e = ty(t, this.isPartnerReporter() ? this.advancedMatchingAvailableProperties : {
                            external_id: !0,
                            email: !0,
                            phone_number: !0
                        }),
                        r = tb(t, {
                            auto_email: !0,
                            auto_phone_number: !0
                        });
                    return Object.keys(r).length > 0 && (!e.identity_params && (e.identity_params = {}), Object.assign(e.identity_params, r)), e
                }
                getReporterMatchedUserFormatInfoV2() {
                    var t = this.context.getUserFormatInfoV2(),
                        e = this.isPartnerReporter() ? this.advancedMatchingAvailableProperties : {
                            external_id: !0,
                            email: !0,
                            phone_number: !0,
                            first_name: !0,
                            last_name: !0,
                            city: !0,
                            state: !0,
                            country: !0,
                            zip_code: !0,
                            partner_id: !0
                        };
                    return tI(t, e)
                }
                isOnsite() {
                    var t;
                    return !!(null != (t = this.reporterInfo) && t.is_onsite)
                }
                isPartnerReporter() {
                    var t = this.getReporterPartner();
                    return !!(t && "None" !== t)
                }
                getSignalDiagnosticLabels() {
                    var t = this.context.getSignalDiagnosticLabels();
                    if (!t) return Object.assign({}, Q);
                    var {
                        email: e,
                        phone_number: r,
                        auto_email: n,
                        auto_phone_number: i
                    } = this.advancedMatchingAvailableProperties;
                    e = !this.isPartnerReporter() || e, r = !this.isPartnerReporter() || r;
                    var o = tb(t, {
                        raw_email: e,
                        raw_phone: r,
                        hashed_email: e,
                        hashed_phone: r,
                        raw_auto_email: n,
                        raw_auto_phone: i,
                        raw_eb_email: !0,
                        raw_eb_phone: !0
                    });
                    return Object.assign({}, Q, o)
                }
                setCookieBasedSession(t) {
                    return t && (this.session = t), this.session
                }
                convertCookieBasedSession(t, e, r) {
                    return eV(this.reporterInfo, this.ttqOptions) && t !== rK.AUTO_CONFIG && e && r ? eK(e, r) : {}
                }
                assemblyData(t, e, r, n, i) {
                    void 0 === r && (r = {}), void 0 === n && (n = {}), void 0 === i && (i = rK.TRACK);
                    var o, s, a, c = super.assemblyData(t, e, r, n, i);
                    c.is_onsite = this.isOnsitePage.value;
                    var u = T(t) || this.ttqPartner;
                    u && (c.partner = u), c.signal_diagnostic_labels = this.getSignalDiagnosticLabels();
                    var f = b().getPlugin("SensitiveRedactor");
                    if (f) {
                        f.registerEncryptRedactor({
                            keywords: [],
                            regexArray: r6
                        }, tf);
                        var l = f.processSync(c.signal_diagnostic_labels, "encrypt");
                        l.success ? c.signal_diagnostic_labels = l.redactedOutput : tQ(t1.CUSTOM_ERROR, l.error, {
                            custom_name: "sensitive_redactor_error",
                            extJSON: {
                                message: "signal_diagnostic_labels"
                            }
                        })
                    }
                    var p = E();
                    p && (c.context.userAgent = p);
                    var d = function() {
                        try {
                            var t = document.readyState;
                            if ("loading" == t) return eB.LOADING;
                            if ("interactive" == t) return eB.INTERACTIVE;
                            else if ("complete" == t) return eB.COMPLETE;
                            return eB.UNKNOWN
                        } catch (t) {
                            return eB.UNKNOWN
                        }
                    }();
                    if (d && (c.context.page.load_progress = d), !S() && Object.keys(this.context.userInfoFieldAllowlist).length) {
                        var h = F()(this.context.userInfoFieldAllowlist).filter(e => {
                            var [, r] = e;
                            return -1 === r.indexOf("all") && -1 == r.indexOf(t)
                        }).map(t => {
                            var [e] = t;
                            return e
                        });
                        c.context.user = tm(c.context.user, h)
                    }
                    return c._inspection = (o = r1, s = c.properties, a = c._inspection, void 0 === a && (a = {}), o.forEach(t => {
                        s.hasOwnProperty(t) && (a[t] = s[t], delete s[t])
                    }), a), i !== rK.PAGE && (c._inspection.ppf = P()), c._inspection.vids = this.context.getVids(), c.context.ad.sdk_env = tC(), c.context.ad.jsb_status = function() {
                        try {
                            var t;
                            return [C.INVOKE_METHOD_ENABLED, C.INVOKE_METHOD_NOT_ENABLED][
                                [!!(null != (t = window) && null != (t = t.ToutiaoJSBridge) && t.invokeMethod), !0].findIndex(t => t)
                            ]
                        } catch (t) {
                            return C.NOT_SURE
                        }
                    }(), (i === rK.INTERACTION || i === rK.PERFORMANCE || i === rK.PERFORMANCE_INTERACTION) && !1 === this.context.getEnableAdTracking() && !this.isOnsitePage.value && (c.context.user = {}, c.context.ad = this.context.getOffsiteAdInfo(), c.context.ad = tm(c.context.ad, rZ)), c.properties.reporterId && delete c.properties.reporterId, c
                }
                page(t) {
                    void 0 === t && (t = {});
                    var {
                        url: e
                    } = eC();
                    if (e !== this.currentHref) this.currentHref = e, this.track("Pageview", t, {})
                }
                track(t, e, r, n, i) {
                    void 0 === e && (e = {}), void 0 === r && (r = {}), void 0 === n && (n = rK.TRACK), void 0 === i && (i = es.defaultReport);
                    var o = () => {
                        var o = this.getReporterId();
                        if (s()(rz).call(rz, t)) return super.track(t, e, r, n, i);
                        var a = k()({}, r);
                        return this.selfHostConfig[o] && !r.eventID && (a = Object.assign({}, a, {
                            eventID: ts(to("default_eventId"), o)
                        })), super.track(t, e, a, n, i)
                    };
                    return this.loaded ? o() : this.getInstance().then(o)
                }
                getEventType(t) {
                    return r0[t] || t
                }
                trackSync(t, e, r, n, i, o, a) {
                    if (void 0 === r && (r = {}), void 0 === n && (n = {}), void 0 === i && (i = rK.TRACK), void 0 === o && (o = es.defaultReport), "track" === i && t$(t1.PIXEL_SEND, {
                            pixelCode: t,
                            extJSON: {
                                event: e
                            }
                        }), i !== rK.TRACK) {
                        super.trackSync(t, e, r, n, i, o, a);
                        return
                    }
                    r && "string" == typeof r.currency && (r.currency = r.currency.toUpperCase());
                    var c = this.context.getTestID();
                    if (c) {
                        var u, f = this.assemblyData(t, e, r, n);
                        return f.tt_test_id = c, f.context.ad = {}, this == null || null == (u = this.reportService) || u.report(a || eu, f, es.htmlHttpReport, ea.P0), f
                    }
                    if (r && "object" == typeof r) {
                        var l, p, d, h, {
                            value: v,
                            currency: g
                        } = r;
                        if (void 0 !== v && (l = v, isNaN(l) || !(l >= 0))) t$(t1.CUSTOM_ERROR, {
                            pixelCode: t,
                            custom_name: "invalid_value",
                            extJSON: {
                                event: e,
                                value: v,
                                currency: g
                            }
                        });
                        if (void 0 !== g && (p = g, d = this.currency_list, void 0 === d && (d = null), h = d || rQ, !s()(h).call(h, p))) t$(t1.CUSTOM_ERROR, {
                            pixelCode: t,
                            custom_name: "invalid_currency",
                            extJSON: {
                                event: e,
                                value: v,
                                currency: g
                            }
                        })
                    }
                    return super.trackSync(t, e, r, n, i, o, a)
                }
                trackPostTask(t) {
                    var {
                        reporterId: e,
                        eventType: r,
                        properties: n,
                        eventConfig: i
                    } = t;
                    if (!s()(rz).call(rz, r)) this.selfHostConfig[e] && !this.hasReportEventHistory(r, es.htmlHttpReport) && (this.pushReport(r, this.getReportEventHistoryKey(es.htmlHttpReport)), this.trackSync(e, r, n, i, rK.SELFHOST, es.htmlHttpReport))
                }
                getReportEventHistoryKey(t) {
                    return t === es.htmlHttpReport ? this.selfHostConfig[this.getReporterId()] : "tiktok"
                }
                assemblySelfHostData(t, e, r, n, i) {
                    void 0 === r && (r = {}), void 0 === n && (n = {});
                    var o = this.assemblyData(t, e, r, n, i),
                        {
                            ttp: s
                        } = this;
                    return s && (o.context.user.ttp = s), o
                }
                constructor(t) {
                    var {
                        id: e,
                        type: r,
                        isOnsitePage: n,
                        context: i,
                        reporterInfo: o,
                        ttqOptions: s,
                        reportService: a,
                        plugins: c = {},
                        rules: u = [],
                        options: f = {}
                    } = t;
                    super(i, a), this.id = void 0, this.type = void 0, this.pixelCode = void 0, this.plugins = void 0, this.rules = void 0, this.reporterInfo = void 0, this.options = void 0, this.selfHostConfig = void 0, this.ttp = "", this.currency_list = void 0, this.ttqPartner = void 0, this.pixelPromise = void 0, this.isOnsitePage = void 0, this.ttqOptions = void 0, this.loaded = !1, this.id = e, this.pixelCode = e, this.type = r, this.isOnsitePage = n, this.options = f || {}, this.plugins = c || {}, this.rules = u || [], this.reporterInfo = Object.assign(o || {}, {
                        [r]: e
                    }), this.ttp = s.ttp || "", this.currency_list = s.currency_list || null, this.ttqPartner = s.partner || "", this.selfHostConfig = s.self_host_config || {}, this.ttqOptions = s, this.pixelPromise = this.getInstance()
                }
            }
            class r8 extends r4 {
                setCookieBasedSessionInShopify(t) {
                    var e = () => super.setCookieBasedSession,
                        r = this;
                    return M()(function*() {
                        var n = yield rp(r.pixelCode, t, r.ttqOptions, r.cookieService);
                        e().call(r, n)
                    })()
                }
                setPageCookieBasedSession(t) {
                    var e = this;
                    return M()(function*() {
                        var r = yield rp("", t, e.globalTtqConfig, e.cookieService);
                        return e.context.setPageCookieBasedSession(r)
                    })()
                }
                convertCookieBasedSession(t, e, r) {
                    return eV(this.reporterInfo, this.ttqOptions) && t !== rK.AUTO_CONFIG ? eK(this.getCookieBasedSession(), this.context.getPageCookieBasedSession()) : {}
                }
                trackEnrichAM() {
                    Object.keys(Object.assign({}, this.getUserInfo(Z.Manual))).length > 0 && this.track("EnrichAM", {}, {})
                }
                track(t, e, r) {
                    var n, i, o = this,
                        s = {};
                    if (eV(this.reporterInfo, this.ttqOptions) && (null == (n = this.reportService) || n.pushPreposition(M()(function*() {
                            var t = yield o.cookieService.getCookie(""), e = eq(t);
                            yield o.setCookieBasedSessionInShopify(e[o.getReporterId()]), yield o.setPageCookieBasedSession(e[""])
                        })())), "EnrichAM" === t) return super.track(t, e, r);
                    var a = rL[t];
                    if (!a) return N().resolve(null);
                    var c = e || {
                            context: {
                                document: {}
                            }
                        },
                        u = {};
                    s.event_id = null != (i = null == c ? void 0 : c.id) ? i : "", void 0 !== e.limited_data_use && null !== e.limited_data_use && Object.assign(u, {
                        limited_data_use: e.limited_data_use
                    });
                    try {
                        switch (t) {
                            case "page_viewed":
                                break;
                            case "product_viewed":
                                var {
                                    data: {
                                        productVariant: f
                                    }
                                } = c;
                                Object.assign(u, rV(f, !1));
                                break;
                            case "collection_viewed":
                                Object.assign(u, u.data || {});
                                break;
                            case "product_added_to_cart":
                                var {
                                    data: {
                                        cartLine: l
                                    }
                                } = c;
                                l && Object.assign(u, rG(l, !1));
                                break;
                            case "search_submitted":
                                var {
                                    data: {
                                        searchResult: p
                                    }
                                } = c;
                                Object.assign(u, {
                                    query: p.query
                                });
                                break;
                            case "checkout_started":
                            case "payment_info_submitted":
                            case "checkout_completed":
                                var {
                                    data: {
                                        checkout: d
                                    }
                                } = c;
                                Object.assign(u, rq(t, d))
                        }
                    } catch (e) {
                        tQ(t1.CUSTOM_ERROR, e, {
                            custom_name: "transform_shopify_event_failed",
                            custom_enum: t
                        })
                    }
                    return super.track(a, u, s)
                }
                trackSync(t, e, r, n, i, o) {
                    return void 0 === r && (r = {}), void 0 === n && (n = {}), void 0 === i && (i = rK.TRACK), void 0 === o && (o = es.defaultReport), super.trackSync(t, e, r, n, i, o, eg)
                }
                assemblyData(t, e, r, n, i) {
                    var o = super.assemblyData(t, e, r, n, i);
                    return Object.assign(o.context, {
                        report_endpoint: "/api/v2/shopify_pixel"
                    }), o
                }
                constructor(t) {
                    var {
                        id: e,
                        reportType: r,
                        isOnsitePage: n,
                        reporterInfo: i,
                        ttqOptions: o,
                        context: s,
                        reportService: a,
                        cookieService: c,
                        plugins: u,
                        options: f
                    } = t;
                    super({
                        id: e,
                        type: r,
                        isOnsitePage: n,
                        context: s,
                        reporterInfo: i,
                        ttqOptions: o,
                        reportService: a
                    }), this.id = void 0, this.reporterType = void 0, this.plugins = void 0, this.globalTtqConfig = void 0, this.loaded = !1, this.isOnsitePage = void 0, this.cookieService = void 0, this.id = e, this.reporterType = r, this.globalTtqConfig = o, this.plugins = u || {}, this.options = f || {}, this.isOnsitePage = n, this.cookieService = c
                }
            }
            var r7 = t => {
                    var e = tw(),
                        r = t5();
                    F()(r).forEach(r => {
                        var n, i, [o, s] = r;
                        if (!(s._init || t.reporters.some(t => t.getReporterId() === o))) {
                            var a = {
                                    value: e === tN.ONSITE || !!(t.reporters.every(t => t.isOnsite()) && null != (n = s.info) && n.is_onsite)
                                },
                                c = new r8({
                                    context: t.context,
                                    reportService: t.reportService,
                                    cookieService: t.cookieService,
                                    id: o,
                                    reportType: rJ.PIXEL_CODE,
                                    isOnsitePage: a,
                                    reporterInfo: s.info,
                                    options: s.options,
                                    plugins: s.plugins,
                                    ttqOptions: t.globalTtqOption
                                });
                            if (s._init = !0, t.enableFirstPartyCookie((null == (i = s.info) ? void 0 : i.firstPartyCookieEnabled) || !1), s.plugins) {
                                var {
                                    AdvancedMatching: u
                                } = s.plugins, f = {};
                                u && Object.assign(f, u), c.setAdvancedMatchingAvailableProperties(f)
                            }
                            t.addReporter(c)
                        }
                    })
                },
                r9 = () => {
                    var t = rf();
                    return !t._global_config && (t._global_config = {}), t._global_config
                },
                nt = () => {
                    var t = rf();
                    t._global_config = t._global_config ? t._global_config : {}, t4(t, t._global_config)
                },
                ne = () => k()({}, rd(), {
                    getCookieInSandbox: rI,
                    setCookieInSandbox: r_,
                    getLocalStorageInSandbox: rm,
                    setLocalStorageInSandbox: ry,
                    setSessionStorageInSandbox: rb,
                    getSessionStorageInSandbox: rS,
                    getPixelDetailInSandbox: rg,
                    getShopifyPageInfo: rv,
                    getInitialStageCookie: rx
                });
            try {
                rE(), (() => {
                    var t, e = y(),
                        r = rd(),
                        {
                            document: n = {},
                            navigator: i
                        } = (null == r || null == (t = r.init) ? void 0 : t.context) || {};
                    S() && Object.assign(e, {
                        document: Object.assign(e.document || {}, n),
                        window: e.window || e
                    }), e._userAgent = i && i.userAgent || ""
                })(), I = self[self.TiktokAnalyticsObject || "ttq"], (() => {
                    var {
                        pixelCode: t = ""
                    } = rg(), e = rf(), r = tC();
                    if (!e) {
                        t$(t1.CUSTOM_ERROR, {
                            custom_name: "non_ttq_in_sandbox"
                        });
                        return
                    }
                    if (!t && t$(t1.CUSTOM_ERROR, {
                            custom_name: "non_pixel_code_in_sandbox"
                        }), t$(t1.BEFORE_INIT), !e.initialize) {
                        nt();
                        var n = r9(),
                            i = ne(),
                            o = new ee(i, n),
                            s = new er,
                            a = new en,
                            c = new eT(s, a, o),
                            u = new eM(i),
                            f = new ej(i),
                            l = new rW({
                                env: r,
                                sandboxAPI: i,
                                globalTtqOption: n,
                                httpService: s,
                                reportService: c,
                                adService: u,
                                appService: f,
                                cookieService: o
                            });
                        t3(e, l);
                        r7(l);
                        var {
                            analytics: p
                        } = i || {};
                        if (p && p.subscribe) p.subscribe("all_standard_events", t => {
                            l.track(t.name, t)
                        });
                        else if (["track"].forEach(t => {
                                Object.defineProperty(e, t, {
                                    get: () => function() {
                                        try {
                                            var e = Array.prototype.slice.call(arguments);
                                            return l[t].apply(l, e)
                                        } catch (t) {
                                            return {}
                                        }
                                    },
                                    set() {}
                                })
                            }), e.length > 0)
                            for (; e.length;) {
                                var d = e.shift();
                                if (!!d) {
                                    var [h, ...v] = d;
                                    if ("track" === h) l.track(v[0] || "", v[1] || {})
                                }
                            }
                        e.initialize = !0
                    }
                })()
            } catch (t) {
                tQ(t1.INIT_ERROR, t)
            }
        })()
    })()
} catch (t) {}