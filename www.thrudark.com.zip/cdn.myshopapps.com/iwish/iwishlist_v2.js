var iWishCnt = 0,
    iWishlistmain = {},
    iWishsync = !1;
if (void 0 === iwishWrapperClass) var iwishWrapperClass = "form";
if (void 0 === iWishVarSelector) var iWishVarSelector = "[name=id]";
if (void 0 === iWishQtySelector) var iWishQtySelector = "[name=quantity]";
if (void 0 === iWishSelectClass) var iWishSelectClass = "#product-select, .single-option-selector, .single-option-selector__radio, select[id|='product-select'], select[id|='product-variants-option'], select[id|='variant-listbox-option']";

function iWishPost(i, t) {
    method = "post";
    var s = document.createElement("form");
    for (var e in s.setAttribute("method", method), s.setAttribute("action", i), t)
        if (t.hasOwnProperty(e)) {
            var n = document.createElement("input");
            n.setAttribute("type", "hidden"), n.setAttribute("name", e), n.setAttribute("value", t[e]), s.appendChild(n)
        }
    document.head.appendChild(s), s.submit()
}

function getSession() {
    "undefined" != typeof Storage && ("" == iwish_cid && "true" == localStorage.iWishsync && (localStorage.removeItem("iWishlistmain"), localStorage.removeItem("iWishCnt"), localStorage.removeItem("iWishsync")), localStorage.iWishlistmain && (iWishlistmain = JSON.parse(localStorage.getItem("iWishlistmain"))), localStorage.iWishCnt && !isNaN(localStorage.iWishCnt) && (iWishCnt = parseInt(localStorage.iWishCnt)), localStorage.iWishsync && parseInt(iwish_cid) > 0 && "true" == localStorage.iWishsync && (iWishsync = !0), localStorage.setItem("iWishsync", iWishsync))
}

function pushToSession() {
    "undefined" != typeof Storage && ("undefined" !== iWishlistmain && localStorage.setItem("iWishlistmain", JSON.stringify(iWishlistmain)), "undefined" !== iWishCnt && localStorage.setItem("iWishCnt", iWishCnt))
}

function isInWishlist(i, t) {
    return void 0 !== iWishlistmain[i] && null != t && iWishlistmain[i].indexOf(t) >= 0
}
async function syncWithServer() {
    let i = await requestToSever("syncWishlist", {
        customer_id: iwish_cid,
        wishlist: JSON.stringify(iWishlistmain)
    });
    "" != i.result && (jQuery.extend(iWishlistmain, i.result), iWishCnt = i.iwishCnt, pushToSession(), jQuery(".iWishCount").length && jQuery(".iWishCount").html(iWishCnt)), iWishsync = !0, localStorage.setItem("iWishsync", iWishsync), console.log("Sync done..!"), "undefined" != typeof iWishsyncFn && "function" == typeof iWishsyncFn && iWishsyncFn()
}

function checkIwish(i, t) {
    let s = i.find(".iWishAdd"),
        e = s.attr("data-product"),
        n = isInWishlist(e, t);
    console.log("checkIwish " + e + " :: " + t), n ? (s.addClass("iwishAdded"), s.not("[data-category]").html(iwish_added_txt)) : (s.removeClass("iwishAdded"), s.not("[data-category]").html(iwish_add_txt)), "undefined" != typeof iWishSelectChangeFn && "function" == typeof iWishSelectChangeFn && iWishSelectChangeFn(i, t)
}

function iwish_addOnly(i, t, s, e) {
    if (void 0 === iWishlistmain[i] && (iWishlistmain[i] = []), console.log("Adding " + i + " :: " + t), 0 > iWishlistmain[i].indexOf(t) && (iWishlistmain[i].push(t), iWishCnt++, pushToSession(), jQuery(".iWishCount").length && jQuery(".iWishCount").html(iWishCnt), parseInt(iwish_cid) > 0)) {
        let n = 1;
        s.parents(iwishWrapperClass).find(iWishQtySelector).length > 0 && (n = s.parents(iwishWrapperClass).find(iWishQtySelector).val()), requestToSever("addToWishlist", {
            customer_id: iwish_cid,
            product_id: i,
            variant_id: t,
            category_id: e,
            product_qty: n
        })
    }
}

function iwish_add(i, t) {
    let s = i.parents(iwishWrapperClass).find(".iWishAdd"),
        e = i.attr("data-product");
    if (null == t || null == e) return !1;
    let n = 0;
    if (void 0 !== i.attr("data-category") && "" != i.attr("data-category") && (n = i.attr("data-category")), isInWishlist(e, t)) iwish_remove(i, e, t, !1), 0 == n && i.not("[data-category]").html(iwish_add_txt);
    else {
        if (iwish_addOnly(e, t, i, n), iWishlistmain[e].indexOf(t) >= 0 && (s.addClass("iwishAdded"), 0 == n && s.not("[data-category]").html(iwish_added_txt), "" == iwish_cid)) {
            let h = i.parents(iwishWrapperClass);
            h.find(".iWishLoginMsg").fadeIn(500), setTimeout(function() {
                h.find(".iWishLoginMsg").fadeOut()
            }, 6e3)
        }
        "undefined" != typeof iWishAddFn && "function" == typeof iWishAddFn && iWishAddFn(i, t)
    }
}

function iwish_addCollection(i, t) {
    let s = i.attr("data-product");
    if (null == t || null == s) return !1;
    isInWishlist(s, t) ? (iwish_remove(i, s, t, !1), i.html(iwish_add_txt_col)) : (iwish_addOnly(s, t, i, 0), iWishlistmain[s].indexOf(t) >= 0 && i.addClass("iwishAdded").html(iwish_added_txt_col), "undefined" != typeof iWishaddCollFn && "function" == typeof iWishaddCollFn && iWishaddCollFn())
}

function iwish_remove(i, t, s, e) {
    let n = !1;
    if (void 0 === iWishlistmain[t]) return n;
    console.log("iwish remove :: " + s);
    let h = iWishlistmain[t].indexOf(s);
    if (h >= 0) {
        if (iWishlistmain[t].splice(h, 1), 0 == Object.keys(iWishlistmain[t]).length && delete iWishlistmain[t], iWishCnt > 0 && iWishCnt--, jQuery(".iWishCount").html(iWishCnt), pushToSession(), !1 == (e = e || !1)) {
            i.removeClass("iwishAdded");
            i.parents(iwishWrapperClass).find(".iWishAdd").removeClass("iwishAdded")
        }
        parseInt(iwish_cid) > 0 && requestToSever("removeWishlist", {
            customer_id: iwish_cid,
            product_id: t,
            variant_id: s
        }), n = !0
    }
    return "undefined" != typeof iWishRemoveFn && "function" == typeof iWishRemoveFn && iWishRemoveFn(i, s, e), n
}

function iwish_initQV() {
    setTimeout(function() {
        if (jQuery(iwish_qvWrapper + ":visible").find(".iWishAdd").length > 0) {
            let i = jQuery(iwish_qvWrapper + ":visible").find(iWishVarSelector).val();
            "" != i && checkIwish(jQuery(iwish_qvWrapper + ":visible").find(iwishWrapperClass), i), "undefined" != typeof iWishQvFn && "function" == typeof iWishQvFn && iWishQvFn()
        } else iwish_initQV()
    }, 300)
}

function iwish_updateQty(i, t, s) {
    parseInt(iwish_cid) > 0 && requestToSever("updateWishlist", {
        customer_id: iwish_cid,
        product_id: i,
        variant_id: t,
        product_qty: s
    }), "undefined" != typeof iwishUpdateQtyFn && "function" == typeof iwishUpdateQtyFn && iwishUpdateQtyFn()
}

function iwishCheckColl() {
    jQuery(".iwishcheck").length > 0 && jQuery(".iwishcheck").each(function() {
        let i = jQuery(this).attr("data-variant");
        isInWishlist(jQuery(this).attr("data-product"), i) ? jQuery(this).addClass("iwishAdded").html(iwish_added_txt_col) : jQuery(this).removeClass("iwishAdded").html(iwish_add_txt_col), jQuery(this).removeClass("iwishcheck")
    })
}

function iwishInit() {
    let i = !!jQuery.fn.on;
    if (iwish_pro_template) {
        let t = jQuery(".iWishAdd:visible").parents(iwishWrapperClass),
            s = t.find(iWishVarSelector).val();
        "" != s && checkIwish(t, s)
    }
    jQuery(".iWishCount").html(iWishCnt), parseInt(iwish_cid) > 0 && !iWishsync && (console.log("Sync Need to be done"), syncWithServer()), "undefined" != typeof iwish_qvButton && "undefined" != typeof iwish_qvWrapper && (i ? jQuery("body").on("click", iwish_qvButton, function() {
        iwish_initQV()
    }) : jQuery("body").delegate(iwish_qvButton, "click", function() {
        iwish_initQV()
    })), i ? jQuery(document).on("change", iWishSelectClass, function() {
        selectedClass = jQuery(this).parents(iwishWrapperClass), setTimeout(function() {
            let i = selectedClass.find(iWishVarSelector).val();
            "" != i ? checkIwish(selectedClass, i) : (selectedClass.find(".iWishAdd").removeClass("iwishAdded"), selectedClass.find(".iWishAdd").not("[data-category]").html(iwish_add_txt))
        }, 400)
    }) : jQuery(document).delegate(iWishSelectClass, "change", function() {
        selectedClass = jQuery(this).parents(iwishWrapperClass), setTimeout(function() {
            let i = selectedClass.find(iWishVarSelector).val();
            "" != i ? checkIwish(selectedClass, i) : (selectedClass.find(".iWishAdd").removeClass("iwishAdded"), selectedClass.find(".iWishAdd").not("[data-category]").html(iwish_add_txt))
        }, 400)
    }), "undefined" != typeof iWishinitFn && "function" == typeof iWishinitFn && iWishinitFn(), jQuery(".iwishRemoveBtn").click(function() {
        if (jQuery(this).hasClass("iwishRemoved")) return !1;
        let i = jQuery(this).attr("data-variant"),
            t = jQuery(this).attr("data-product");
        return iwish_remove(jQuery(this), t, i, !0) && (jQuery(this).addClass("iwishRemoved"), jQuery(this).parents(".iwishItem").remove(), jQuery(".iwishMsgSuccess").show(), setTimeout(function() {
            jQuery(".iwishMsgSuccess").fadeOut(), 0 == iWishCnt && jQuery(".iwishMsgInfo").fadeIn()
        }, 3e3)), !1
    }), jQuery("input[name=iwishProQuantity]").change(function() {
        let i = jQuery(this),
            t = parseInt(i.val()),
            s = i.parents("form").attr("data-product-id"),
            e = i.parents(".iwishItem").find(iWishVarSelector).val();
        parseInt(iwish_cid) > 0 && (t > 0 ? (iwish_updateQty(s, e, t), i.parents(".iwishItem").find("[name=quantity]").val(t), i.addClass("iwishProQtyAdded"), setTimeout(function() {
            i.removeClass("iwishProQtyAdded")
        }, 2e3), i.parents(".iwishItem").find(".iwishQtyMsg").fadeIn().delay(3e3).fadeOut()) : (i.val(1).addClass("iwishProQtyError"), setTimeout(function() {
            i.removeClass("iwishProQtyError")
        }, 1e3)))
    })
}
getSession();
var iWishUrl2 = "https://api.myshopapps.com/iwish/V1";
async function requestToSever(i, t, s = "POST", e = null) {
    let n = {
        method: s,
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            domain: window.Shopify.shop,
            Authorization: ""
        },
        body: new URLSearchParams(t)
    };
    try {
        let h = await fetch(iWishUrl2 + "/" + i, n),
            a = await h.json();
        return null != e && e(a), a
    } catch (d) {
        return console.error(d), d
    }
}
iwishInit(), iwishCheckColl();