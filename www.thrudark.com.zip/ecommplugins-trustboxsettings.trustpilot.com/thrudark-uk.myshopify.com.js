const trustpilot_trustbox_settings = {
    "trustboxes": [{
        "enabled": "enabled",
        "snippet": "PGRpdiBjbGFzcz0idHJ1c3RwaWxvdC13aWRnZXQiIGRhdGEtbG9jYWxlPSJlbi1HQiIgZGF0YS10ZW1wbGF0ZS1pZD0iNTNhYTg5MTJkZWM3ZTEwZDM4ZjU5ZjM2IiBkYXRhLWJ1c2luZXNzdW5pdC1pZD0iNWNkNTFkYzYwZmI0YTEwMDAxMGRhZjFkIiBkYXRhLXN0eWxlLWhlaWdodD0iMTQwcHgiIGRhdGEtc3R5bGUtd2lkdGg9IjEwMCUiIGRhdGEtc3RhcnM9IjQsNSwzIiBkYXRhLXRoZW1lPSJkYXJrIiBkYXRhLXRleHQtY29sb3I9IiNmZmZmZmYiIHBhZGRpbmd5PSI3MCIgemluZGV4PSI0IiBkYXRhLWZvbnQtZmFtaWx5PSJTb3VyY2UgU2FucyBQcm8iPgogIDxhIGhyZWY9Imh0dHBzOi8vd3d3LnRydXN0cGlsb3QuY29tL3Jldmlldy93d3cudGhydWRhcmsuY29tIiB0YXJnZXQ9Il9ibGFuayIgcmVsPSJub29wZW5lciI+VHJ1c3RwaWxvdDwvYT4KPC9kaXY+",
        "customizations": "eyJ3aWR0aCI6eyJhdHRyaWJ1dGVOYW1lIjoiZGF0YS1zdHlsZS13aWR0aCJ9LCJoZWlnaHQiOnsiYXR0cmlidXRlTmFtZSI6ImRhdGEtc3R5bGUtaGVpZ2h0In0sInN0YXJzIjp7ImF0dHJpYnV0ZU5hbWUiOiJkYXRhLXN0YXJzIiwib3B0aW9ucyI6WzEsMiwzLDQsNV19LCJ0aGVtZSI6eyJhdHRyaWJ1dGVOYW1lIjoiZGF0YS10aGVtZSIsIm9wdGlvbnMiOlsibGlnaHQiLCJkYXJrIl19LCJsb2NhbGVzIjp7ImF0dHJpYnV0ZU5hbWUiOiJkYXRhLWxvY2FsZSIsIm9wdGlvbnMiOlsiZGEtREsiLCJkZS1BVCIsImRlLUNIIiwiZGUtREUiLCJlbi1BVSIsImVuLUNBIiwiZW4tR0IiLCJlbi1JRSIsImVuLU5aIiwiZW4tVVMiLCJlcy1FUyIsImZpLUZJIiwiZnItQkUiLCJmci1GUiIsIml0LUlUIiwiamEtSlAiLCJuYi1OTyIsIm5sLUJFIiwibmwtTkwiLCJwbC1QTCIsInB0LUJSIiwicHQtUFQiLCJydS1SVSIsInN2LVNFIiwiemgtQ04iXX0sInRhZ3MiOnsiYXR0cmlidXRlTmFtZSI6ImRhdGEtdGFncyJ9LCJwcm9kdWN0TmFtZSI6ZmFsc2UsInNrdSI6ZmFsc2UsInJpY2hTbmlwcGV0cyI6eyJhdHRyaWJ1dGVOYW1lIjoiZGF0YS1zY2hlbWEtdHlwZSJ9LCJyZXZpZXdMYW5ndWFnZXMiOnsiYXR0cmlidXRlTmFtZSI6ImRhdGEtcmV2aWV3LWxhbmd1YWdlcyIsIm9wdGlvbnMiOlsiZGEiLCJkZSIsImVuIiwiZXMiLCJmaSIsImZyIiwiaXQiLCJqYSIsIm5iIiwibmwiLCJwbCIsInB0IiwicnUiLCJzdiIsInpoIl19LCJ0ZXh0Q29sb3IiOnsiYXR0cmlidXRlTmFtZSI6ImRhdGEtdGV4dC1jb2xvciJ9LCJmb250RmFtaWx5Ijp7ImF0dHJpYnV0ZU5hbWUiOiJkYXRhLWZvbnQtZmFtaWx5Iiwib3B0aW9ucyI6WyJSb2JvdG8iLCJPcGVuIFNhbnMiLCJOb3RvIFNhbnMgSlAiLCJMYXRvIiwiTW9udHNlcnJhdCIsIlJvYm90byBDb25kZW5zZWQiLCJTb3VyY2UgU2FucyBQcm8iLCJSYWxld2F5IiwiUG9wcGlucyIsIk5vdG8gU2FucyIsIlJvYm90byBTbGFiIiwiTWVycml3ZWF0aGVyIiwiUFQgU2FucyIsIlBsYXlmYWlyIERpc3BsYXkiLCJVYnVudHUiLCJNdWt0YSIsIk11bGkiLCJQVCBTZXJpZiIsIkxvcmEiLCJOdW5pdG8iLCJXb3JrIFNhbnMiLCJSdWJpayIsIkZpcmEgU2FucyIsIlRpdGlsbGl1bSBXZWIiLCJOb3RvIFNhbnMgVEMiLCJOb3RvIFNlcmlmIiwiTm90byBTYW5zIEtSIiwiTmFudW0gR290aGljIiwiUXVpY2tzYW5kIiwiSGluZCBTaWxpZ3VyaSIsIk51bml0byBTYW5zIiwiSGVlYm8iLCJBcmltbyIsIk94eWdlbiIsIkRvc2lzIiwiQmFybG93IiwiS2FybGEiLCJTbGFibyAyN3B4IiwiTGlicmUgQmFza2VydmlsbGUiLCJJbmNvbnNvbGF0YSIsIkxpYnJlIEZyYW5rbGluIiwiQ3JpbXNvbiBUZXh0IiwiSm9zZWZpbiBTYW5zIl19LCJzdGFyQ29sb3IiOmZhbHNlLCJib3JkZXJDb2xvciI6ZmFsc2UsImxpbmtDb2xvciI6ZmFsc2UsInF1b3RlQ29sb3IiOmZhbHNlLCJidXR0b25Db2xvciI6ZmFsc2UsIm5vUmV2aWV3cyI6ZmFsc2UsInNjcm9sbFRvTGlzdCI6ZmFsc2UsImFsbG93Um9ib3RzIjp7ImF0dHJpYnV0ZU5hbWUiOiJkYXRhLWFsbG93LXJvYm90cyJ9LCJtaW5SZXZpZXdDb3VudCI6ZmFsc2UsImltcG9ydGVkUmV2aWV3cyI6ZmFsc2UsIndpdGhvdXRSZXZpZXdzUHJlZmVycmVkU3RyaW5nSWQiOmZhbHNlLCJhbGlnbm1lbnQiOmZhbHNlLCJmdWxsV2lkdGgiOmZhbHNlfQ==",
        "defaults": "eyJ3aWR0aCI6IjEwMCUiLCJoZWlnaHQiOiIxNDBweCIsInRleHRDb2xvciI6eyJsaWdodCI6IiMxOTE5MTkiLCJkYXJrIjoiI2ZmZmZmZiJ9LCJmb250RmFtaWx5IjoiXCJTZWdvZSBVSVwiLFwiSGVsdmV0aWNhIE5ldWVcIixcIkhlbHZldGljYVwiLFwiQXJpYWxcIixcInNhbnMtc2VyaWZcIiJ9",
        "page": "category",
        "position": "before",
        "corner": "top: #{Y}px; left: #{X}px;",
        "paddingx": "0",
        "paddingy": "70",
        "zindex": "4",
        "clear": "both",
        "xpaths": "WyJpZChcInNob3BpZnktc2VjdGlvbi1zZWN0aW9uLXVzcHNcIikvU0VDVElPTlsxXS9ESVZbMV0vRElWWzFdL0RJVlsxXSIsIi8vRElWW0BjbGFzcz1cInNlYy1Vc3BzX0l0ZW1zXCJdIiwiL0hUTUxbMV0vQk9EWVsxXS9ESVZbMTBdL1NFQ1RJT05bMV0vRElWWzFdL0RJVlsxXS9ESVZbMV0iXQ==",
        "sku": "",
        "widgetName": "Carousel",
        "repeatable": false,
        "uuid": "fb9bf403-f420-81b1-11a7-fc5df20f342d",
        "error": null,
        "width": "100%",
        "height": "140px",
        "locale": "en-GB",
        "textColor": "#ffffff",
        "stars": [4, 5, 3],
        "fontFamily": "Source Sans Pro",
        "theme": "dark"
    }]
};
dispatchEvent(new CustomEvent('trustpilotTrustboxSettingsLoaded'));